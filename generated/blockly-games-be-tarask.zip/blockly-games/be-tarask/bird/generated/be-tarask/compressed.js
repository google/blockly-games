// Automatically generated file.  Do not edit!
'use strict';var g,l=this;function aa(a){a=a.split(".");for(var b=l,c;c=a.shift();)if(null!=b[c])b=b[c];else return null;return b}function ba(){}function ca(a){a.hc=function(){return a.ei?a.ei:a.ei=new a}}
function da(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;var c=Object.prototype.toString.call(a);if("[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==b&&"undefined"==typeof a.call)return"object";return b}function ea(a){return"array"==da(a)}function fa(a){var b=da(a);return"array"==b||"object"==b&&"number"==typeof a.length}function n(a){return"string"==typeof a}function ga(a){return"number"==typeof a}function r(a){return"function"==da(a)}function ha(a){var b=typeof a;return"object"==b&&null!=a||"function"==b}function ia(a){return a[ja]||(a[ja]=++ka)}var ja="closure_uid_"+(1E9*Math.random()>>>0),ka=0;
function la(a,b,c){return a.call.apply(a.bind,arguments)}function ma(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var c=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(c,d);return a.apply(b,c)}}return function(){return a.apply(b,arguments)}}function na(a,b,c){na=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?la:ma;return na.apply(null,arguments)}
function oa(a,b){var c=Array.prototype.slice.call(arguments,1);return function(){var b=c.slice();b.push.apply(b,arguments);return a.apply(this,b)}}var pa=Date.now||function(){return+new Date};function s(a,b){function c(){}c.prototype=b.prototype;a.m=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.Ol=function(a,c,f){return b.prototype[c].apply(a,Array.prototype.slice.call(arguments,2))}};function qa(a,b){null!=a&&this.append.apply(this,arguments)}g=qa.prototype;g.aa="";g.set=function(a){this.aa=""+a};g.append=function(a,b,c){this.aa+=a;if(null!=b)for(var d=1;d<arguments.length;d++)this.aa+=arguments[d];return this};g.clear=function(){this.aa=""};g.toString=function(){return this.aa};var ra;function sa(a){if(Error.captureStackTrace)Error.captureStackTrace(this,sa);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}s(sa,Error);sa.prototype.name="CustomError";function ta(a,b){for(var c=a.split("%s"),d="",e=Array.prototype.slice.call(arguments,1);e.length&&1<c.length;)d+=c.shift()+e.shift();return d+c.join("%s")}function ua(a){return a.replace(/[\t\r\n ]+/g," ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g,"")}var va=String.prototype.trim?function(a){return a.trim()}:function(a){return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g,"")};function wa(a,b){var c=String(a).toLowerCase(),d=String(b).toLowerCase();return c<d?-1:c==d?0:1}
function xa(a){if(!ya.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(za,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(Ba,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(Ca,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(Da,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(Ea,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(Fa,"&#0;"));return a}var za=/&/g,Ba=/</g,Ca=/>/g,Da=/"/g,Ea=/'/g,Fa=/\x00/g,ya=/[\x00&<>"']/;
function Ga(a){var b={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"'},c;c=l.document.createElement("div");return a.replace(Ha,function(a,e){var f=b[a];if(f)return f;if("#"==e.charAt(0)){var h=Number("0"+e.substr(1));isNaN(h)||(f=String.fromCharCode(h))}f||(c.innerHTML=a+" ",f=c.firstChild.nodeValue.slice(0,-1));return b[a]=f})}
function Ia(a){return a.replace(/&([^;]+);/g,function(a,c){switch(c){case "amp":return"&";case "lt":return"<";case "gt":return">";case "quot":return'"';default:if("#"==c.charAt(0)){var d=Number("0"+c.substr(1));if(!isNaN(d))return String.fromCharCode(d)}return a}})}var Ha=/&([^;\s<&]+);?/g;function Ja(a,b){return-1!=a.indexOf(b)}function Ka(a,b){return a<b?-1:a>b?1:0};function La(a,b){b.unshift(a);sa.call(this,ta.apply(null,b));b.shift()}s(La,sa);La.prototype.name="AssertionError";function Ma(a,b){throw new La("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};function Na(){this.Rg="";this.jj=Oa}Na.prototype.Ne=!0;Na.prototype.He=function(){return this.Rg};Na.prototype.toString=function(){return"Const{"+this.Rg+"}"};function Pa(a){if(a instanceof Na&&a.constructor===Na&&a.jj===Oa)return a.Rg;Ma("expected object of type Const, got '"+a+"'");return"type_error:Const"}var Oa={};function Qa(){this.pc="";this.hj=Ra}g=Qa.prototype;g.Ne=!0;g.He=function(){return this.pc};g.ci=!0;g.Be=function(){return 1};g.toString=function(){return"SafeUrl{"+this.pc+"}"};var Ra={};var Sa=Array.prototype,Ta=Sa.indexOf?function(a,b,c){return Sa.indexOf.call(a,b,c)}:function(a,b,c){c=null==c?0:0>c?Math.max(0,a.length+c):c;if(n(a))return n(b)&&1==b.length?a.indexOf(b,c):-1;for(;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},Ua=Sa.forEach?function(a,b,c){Sa.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=n(a)?a.split(""):a,f=0;f<d;f++)f in e&&b.call(c,e[f],f,a)},Va=Sa.filter?function(a,b,c){return Sa.filter.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=[],f=
0,h=n(a)?a.split(""):a,k=0;k<d;k++)if(k in h){var m=h[k];b.call(c,m,k,a)&&(e[f++]=m)}return e},Wa=Sa.map?function(a,b,c){return Sa.map.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=Array(d),f=n(a)?a.split(""):a,h=0;h<d;h++)h in f&&(e[h]=b.call(c,f[h],h,a));return e},Xa=Sa.every?function(a,b,c){return Sa.every.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=n(a)?a.split(""):a,f=0;f<d;f++)if(f in e&&!b.call(c,e[f],f,a))return!1;return!0};function Ya(a,b){return 0<=Ta(a,b)}
function Za(a,b){var c=Ta(a,b),d;(d=0<=c)&&Sa.splice.call(a,c,1);return d}function $a(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]}function ab(a,b,c,d){Sa.splice.apply(a,bb(arguments,1))}function bb(a,b,c){return 2>=arguments.length?Sa.slice.call(a,b):Sa.slice.call(a,b,c)};function cb(){this.hf="";this.gj=db}cb.prototype.Ne=!0;var db={};cb.prototype.He=function(){return this.hf};cb.prototype.toString=function(){return"SafeStyle{"+this.hf+"}"};function eb(a){var b=new cb;b.hf=a;return b}var fb=eb("");
function gb(a){var b="",c;for(c in a){if(!/^[-_a-zA-Z0-9]+$/.test(c))throw Error("Name allows only [-_a-zA-Z0-9], got: "+c);var d=a[c];null!=d&&(d instanceof Na?d=Pa(d):hb.test(d)||(Ma("String value allows only [-.%_!# a-zA-Z0-9], got: "+d),d="zClosurez"),b+=c+":"+d+";")}return b?eb(b):fb}var hb=/^[-.%_!# a-zA-Z0-9]+$/;function ib(a,b){for(var c in a)b.call(void 0,a[c],c,a)}var jb="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function kb(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var f=0;f<jb.length;f++)c=jb[f],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}}
function lb(a){var b=arguments.length;if(1==b&&ea(arguments[0]))return lb.apply(null,arguments[0]);for(var c={},d=0;d<b;d++)c[arguments[d]]=!0;return c};var mb=lb("area base br col command embed hr img input keygen link meta param source track wbr".split(" "));function nb(){this.pc="";this.fj=ob;this.Qh=null}g=nb.prototype;g.ci=!0;g.Be=function(){return this.Qh};g.Ne=!0;g.He=function(){return this.pc};g.toString=function(){return"SafeHtml{"+this.pc+"}"};function pb(a){if(a instanceof nb&&a.constructor===nb&&a.fj===ob)return a.pc;Ma("expected object of type SafeHtml, got '"+a+"'");return"type_error:SafeHtml"}function qb(a){if(a instanceof nb)return a;var b=null;a.ci&&(b=a.Be());return rb(xa(a.Ne?a.He():String(a)),b)}
var sb=/^[a-zA-Z0-9-]+$/,tb=lb("action","cite","data","formaction","href","manifest","poster","src"),vb=lb("link","script","style");
function wb(a,b,c){if(!sb.test(a))throw Error("Invalid tag name <"+a+">.");if(a.toLowerCase()in vb)throw Error("Tag name <"+a+"> is not allowed for SafeHtml.");var d=null,e="<"+a;if(b)for(var f in b){if(!sb.test(f))throw Error('Invalid attribute name "'+f+'".');var h=b[f];if(null!=h){if(h instanceof Na)h=Pa(h);else if("style"==f.toLowerCase()){if(!ha(h))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof h+" given: "+h);h instanceof cb||(h=gb(h));h instanceof
cb&&h.constructor===cb&&h.gj===db?h=h.hf:(Ma("expected object of type SafeStyle, got '"+h+"'"),h="type_error:SafeStyle")}else{if(/^on/i.test(f))throw Error('Attribute "'+f+'" requires goog.string.Const value, "'+h+'" given.');if(h instanceof Qa)h instanceof Qa&&h.constructor===Qa&&h.hj===Ra?h=h.pc:(Ma("expected object of type SafeUrl, got '"+h+"'"),h="type_error:SafeUrl");else if(f.toLowerCase()in tb)throw Error('Attribute "'+f+'" requires goog.string.Const or goog.html.SafeUrl value, "'+h+'" given.');
}e+=" "+f+'="'+xa(String(h))+'"'}}void 0!==c?ea(c)||(c=[c]):c=[];!0===mb[a.toLowerCase()]?e+=">":(d=xb(c),e+=">"+pb(d)+"</"+a+">",d=d.Be());(a=b&&b.dir)&&(d=/^(ltr|rtl|auto)$/i.test(a)?0:null);return rb(e,d)}function xb(a){function b(a){ea(a)?Ua(a,b):(a=qb(a),d+=pb(a),a=a.Be(),0==c?c=a:0!=a&&c!=a&&(c=null))}var c=0,d="";Ua(arguments,b);return rb(d,c)}var ob={};function rb(a,b){var c=new nb;c.pc=a;c.Qh=b;return c}var yb=rb("",0);var zb={lm:!0};var Ab;a:{var Bb=l.navigator;if(Bb){var Cb=Bb.userAgent;if(Cb){Ab=Cb;break a}}Ab=""};var Db,Eb,Fb,Gb,Hb=Ja(Ab,"Opera")||Ja(Ab,"OPR"),v=Ja(Ab,"Trident")||Ja(Ab,"MSIE"),Ib=Ja(Ab,"Gecko")&&!Ja(Ab.toLowerCase(),"webkit")&&!(Ja(Ab,"Trident")||Ja(Ab,"MSIE")),w=Ja(Ab.toLowerCase(),"webkit"),Jb=w&&Ja(Ab,"Mobile"),Kb=l.navigator||null;Db=Ja(Kb&&Kb.platform||"","Mac");var Lb=Ab;Eb=!!Lb&&Ja(Lb,"Android");Fb=!!Lb&&Ja(Lb,"iPhone");Gb=!!Lb&&Ja(Lb,"iPad");function Mb(){var a=l.document;return a?a.documentMode:void 0}
var Nb=function(){var a="",b;if(Hb&&l.opera)return a=l.opera.version,r(a)?a():a;Ib?b=/rv\:([^\);]+)(\)|;)/:v?b=/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/:w&&(b=/WebKit\/(\S+)/);b&&(a=(a=b.exec(Ab))?a[1]:"");return v&&(b=Mb(),b>parseFloat(a))?String(b):a}(),Ob={};
function Pb(a){var b;if(!(b=Ob[a])){b=0;for(var c=va(String(Nb)).split("."),d=va(String(a)).split("."),e=Math.max(c.length,d.length),f=0;0==b&&f<e;f++){var h=c[f]||"",k=d[f]||"",m=/(\d*)(\D*)/g,p=/(\d*)(\D*)/g;do{var q=m.exec(h)||["","",""],u=p.exec(k)||["","",""];if(0==q[0].length&&0==u[0].length)break;b=Ka(0==q[1].length?0:parseInt(q[1],10),0==u[1].length?0:parseInt(u[1],10))||Ka(0==q[2].length,0==u[2].length)||Ka(q[2],u[2])}while(0==b)}b=Ob[a]=0<=b}return b}
var Qb=l.document,Rb=Qb&&v?Mb()||("CSS1Compat"==Qb.compatMode?parseInt(Nb,10):5):void 0;function Sb(a,b){this.width=a;this.height=b}g=Sb.prototype;g.clone=function(){return new Sb(this.width,this.height)};g.toString=function(){return"("+this.width+" x "+this.height+")"};g.gi=function(){return!(this.width*this.height)};g.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};g.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
g.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};g.scale=function(a,b){var c=ga(b)?b:a;this.width*=a;this.height*=c;return this};var Tb=!v||v&&9<=Rb,Ub=!Ib&&!v||v&&v&&9<=Rb||Ib&&Pb("1.9.1"),Vb=v&&!Pb("9");function Wb(a){a%=360;return 0>360*a?a+360:a};function x(a,b){this.x=void 0!==a?a:0;this.y=void 0!==b?b:0}g=x.prototype;g.clone=function(){return new x(this.x,this.y)};g.toString=function(){return"("+this.x+", "+this.y+")"};function Xb(a,b){var c=a.x-b.x,d=a.y-b.y;return Math.sqrt(c*c+d*d)}g.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};g.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};g.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};
g.translate=function(a,b){a instanceof x?(this.x+=a.x,this.y+=a.y):(this.x+=a,ga(b)&&(this.y+=b));return this};g.scale=function(a,b){var c=ga(b)?b:a;this.x*=a;this.y*=c;return this};function Yb(a){return a?new Zb($b(a)):ra||(ra=new Zb)}function ac(a,b){ib(b,function(b,d){"style"==d?a.style.cssText=b:"class"==d?a.className=b:"for"==d?a.htmlFor=b:d in bc?a.setAttribute(bc[d],b):0==d.lastIndexOf("aria-",0)||0==d.lastIndexOf("data-",0)?a.setAttribute(d,b):a[d]=b})}var bc={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};
function cc(){var a=window.document,a="CSS1Compat"==a.compatMode?a.documentElement:a.body;return new Sb(a.clientWidth,a.clientHeight)}function dc(a,b,c){return ec(document,arguments)}
function ec(a,b){var c=b[0],d=b[1];if(!Tb&&d&&(d.name||d.type)){c=["<",c];d.name&&c.push(' name="',xa(d.name),'"');if(d.type){c.push(' type="',xa(d.type),'"');var e={};kb(e,d);delete e.type;d=e}c.push(">");c=c.join("")}c=a.createElement(c);d&&(n(d)?c.className=d:ea(d)?c.className=d.join(" "):ac(c,d));2<b.length&&fc(a,c,b,2);return c}
function fc(a,b,c,d){function e(c){c&&b.appendChild(n(c)?a.createTextNode(c):c)}for(;d<c.length;d++){var f=c[d];!fa(f)||ha(f)&&0<f.nodeType?e(f):Ua(gc(f)?$a(f):f,e)}}function hc(a){for(var b;b=a.firstChild;)a.removeChild(b)}function ic(a){var b=y.h;b.parentNode&&b.parentNode.insertBefore(a,b)}function z(a){return a&&a.parentNode?a.parentNode.removeChild(a):null}
function jc(a,b){if(a.contains&&1==b.nodeType)return a==b||a.contains(b);if("undefined"!=typeof a.compareDocumentPosition)return a==b||Boolean(a.compareDocumentPosition(b)&16);for(;b&&a!=b;)b=b.parentNode;return b==a}function $b(a){return 9==a.nodeType?a:a.ownerDocument||a.document}var kc={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1},lc={IMG:" ",BR:"\n"};function mc(a){a=a.getAttributeNode("tabindex");return null!=a&&a.specified}function nc(a){a=a.tabIndex;return ga(a)&&0<=a&&32768>a}
function oc(a){var b=[];pc(a,b,!1);return b.join("")}function pc(a,b,c){if(!(a.nodeName in kc))if(3==a.nodeType)c?b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g,"")):b.push(a.nodeValue);else if(a.nodeName in lc)b.push(lc[a.nodeName]);else for(a=a.firstChild;a;)pc(a,b,c),a=a.nextSibling}function gc(a){if(a&&"number"==typeof a.length){if(ha(a))return"function"==typeof a.item||"string"==typeof a.item;if(r(a))return"function"==typeof a.item}return!1}
function Zb(a){this.Sb=a||l.document||document}g=Zb.prototype;g.tb=Yb;g.k=function(a){return n(a)?this.Sb.getElementById(a):a};g.I=function(a,b,c){return ec(this.Sb,arguments)};g.createElement=function(a){return this.Sb.createElement(a)};g.createTextNode=function(a){return this.Sb.createTextNode(String(a))};g.appendChild=function(a,b){a.appendChild(b)};g.append=function(a,b){fc($b(a),a,arguments,1)};g.canHaveChildren=function(a){if(1!=a.nodeType)return!1;switch(a.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case "SCRIPT":case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
g.Di=hc;g.removeNode=z;g.Dc=function(a){return Ub&&void 0!=a.children?a.children:Va(a.childNodes,function(a){return 1==a.nodeType})};g.contains=jc;g.kc=function(a){var b;(b="A"==a.tagName||"INPUT"==a.tagName||"TEXTAREA"==a.tagName||"SELECT"==a.tagName||"BUTTON"==a.tagName?!a.disabled&&(!mc(a)||nc(a)):mc(a)&&nc(a))&&v?(a=r(a.getBoundingClientRect)?a.getBoundingClientRect():{height:a.offsetHeight,width:a.offsetWidth},a=null!=a&&0<a.height&&0<a.width):a=b;return a};v&&Pb(8);function qc(a){return a&&a.Aj&&a.Aj===zb?a.content:String(a).replace(rc,sc)}var tc={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"};function sc(a){return tc[a]}var rc=/[\x00\x22\x26\x27\x3c\x3e]/g;var uc={};var vc={},wc,A,xc,yc,zc,Ac;
function Bc(){for(var a=Cc,b=B,c='<div style="display: none"><span id="Games_name">Blockly Games</span><span id="Games_puzzle">\u041c\u0430\u0437\u0433\u0430\u0442\u043d\u044f</span><span id="Games_maze">\u041b\u044f\u0431\u0456\u0440\u044b\u043d\u0442</span><span id="Games_bird">Bird</span><span id="Games_turtle">\u0427\u0430\u0440\u0430\u043f\u0430\u0448\u043a\u0430</span><span id="Games_movie">Movie</span><span id="Games_pondBasic">Pond</span><span id="Games_pondAdvanced">JS Pond</span><span id="Games_linesOfCode1">You solved this level with 1 line of JavaScript:</span><span id="Games_linesOfCode2">You solved this level with %1 lines of JavaScript:</span><span id="Games_nextLevel">Are you ready for level %1?</span><span id="Games_finalLevel">Are you ready for the next challenge?</span><span id="Games_linkTooltip">\u0417\u0430\u0445\u0430\u0432\u0430\u0446\u044c \u0456 \u0437\u044c\u0432\u044f\u0437\u0430\u0446\u044c \u0437 \u0431\u043b\u0451\u043a\u0430\u043c\u0456. </span><span id="Games_runTooltip">Run the program you wrote.</span><span id="Games_runProgram">\u0417\u0430\u043f\u0443\u0441\u044c\u0446\u0456\u0446\u044c \u043f\u0440\u0430\u0433\u0440\u0430\u043c\u0443</span><span id="Games_resetTooltip">Stop the program and reset the level.</span><span id="Games_resetProgram">\u0421\u043a\u0430\u0441\u0430\u0432\u0430\u0446\u044c</span><span id="Games_help">\u0414\u0430\u043f\u0430\u043c\u043e\u0433\u0430</span><span id="Games_dialogOk">OK</span><span id="Games_dialogCancel">\u0421\u043a\u0430\u0441\u0430\u0432\u0430\u0446\u044c</span><span id="Games_catLogic">\u041b\u0451\u0433\u0456\u043a\u0430</span><span id="Games_catLoops">\u041f\u0435\u0442\u043b\u0456</span><span id="Games_catMath">\u041c\u0430\u0442\u044d\u043c\u0430\u0442\u044b\u0447\u043d\u044b\u044f \u0444\u043e\u0440\u043c\u0443\u043b\u044b</span><span id="Games_catText">\u0422\u044d\u043a\u0441\u0442</span><span id="Games_catLists">\u0421\u044c\u043f\u0456\u0441\u044b</span><span id="Games_catColour">\u041a\u043e\u043b\u0435\u0440</span><span id="Games_catVariables">\u0417\u044c\u043c\u0435\u043d\u043d\u044b\u044f</span><span id="Games_catProcedures">\u0424\u0443\u043d\u043a\u0446\u044b\u0456</span><span id="Games_httpRequestError">\u0423\u0437\u044c\u043d\u0456\u043a\u043b\u0430 \u043f\u0440\u0430\u0431\u043b\u0435\u043c\u0430 \u0437 \u0437\u0430\u043f\u044b\u0442\u0430\u043c.</span><span id="Games_linkAlert">\u041f\u0430\u0434\u0437\u044f\u043b\u0456\u0446\u0446\u0430 \u0412\u0430\u0448\u044b\u043c \u0431\u043b\u0451\u043a\u0430\u043c \u043f\u0440\u0430\u0437 \u0433\u044d\u0442\u0443\u044e \u0441\u043f\u0430\u0441\u044b\u043b\u043a\u0443:\n\n%1</span><span id="Games_hashError">\u041f\u0440\u0430\u0431\u0430\u0447\u0446\u0435, \'%1\' \u043d\u0435 \u0430\u0434\u043f\u0430\u0432\u044f\u0434\u0430\u0435 \u043d\u0456\u0432\u043e\u0434\u043d\u0430\u0439 \u0437\u0430\u0445\u0430\u0432\u0430\u043d\u0430\u0439 \u043f\u0440\u0430\u0433\u0440\u0430\u043c\u0435.</span><span id="Games_xmlError">\u041d\u0435 \u0430\u0442\u0440\u044b\u043c\u0430\u043b\u0430\u0441\u044f \u0437\u0430\u0433\u0440\u0443\u0437\u0456\u0446\u044c \u0437\u0430\u0445\u0430\u0432\u0430\u043d\u044b \u0444\u0430\u0439\u043b. \u041c\u0430\u0433\u0447\u044b\u043c\u0430, \u0451\u043d \u0431\u044b\u045e \u0441\u0442\u0432\u043e\u0440\u0430\u043d\u044b \u0437 \u0456\u043d\u0448\u0430\u0439 \u0432\u044d\u0440\u0441\u0456\u044f\u0439 \u0411\u043b\u0451\u043a\u043b\u0456?</span><span id="Games_listVariable">\u0441\u044c\u043f\u0456\u0441</span><span id="Games_textVariable">\u0442\u044d\u043a\u0441\u0442</span></div><div style="display: none"><span id="Bird_noWorm">does not have worm</span><span id="Bird_heading">heading</span><span id="Bird_noWormTooltip">The condition when the bird has not gotten the worm.</span><span id="Bird_headingTooltip">Move in the direction of the given angle: 0 is to the right, 90 is straight up, etc.</span><span id="Bird_positionTooltip">x and y mark the bird\'s position. When x = 0 the bird is near the left edge, when x = 100 it\'s near the right edge. When y = 0 the bird is at the bottom, when y = 100 it\'s at the top.</span></div><table width="100%"><tr><td><h1>'+('<span id="title">'+
(Dc?'<a href="index.html?lang='+qc(a)+'">':'<a href="./?lang='+qc(a)+'">')+"Blockly Games</a> : "+qc("Bird")+"</span>"),d=" &nbsp; ",e=1;11>e;e++)d+=" "+(e==b?'<span class="level_number level_done" id="level'+qc(e)+'">'+qc(e)+"</span>":10==e?'<a class="level_number" id="level'+qc(e)+'" href="?lang='+qc(a)+"&level="+qc(e)+qc("")+'">'+qc(e)+"</a>":'<a class="level_dot" id="level'+qc(e)+'" href="?lang='+qc(a)+"&level="+qc(e)+qc("")+'"></a>');return c+d+'</h1></td><td class="farSide"><select id="languageMenu"></select>&nbsp;<button id="linkButton" title="\u0417\u0430\u0445\u0430\u0432\u0430\u0446\u044c \u0456 \u0437\u044c\u0432\u044f\u0437\u0430\u0446\u044c \u0437 \u0431\u043b\u0451\u043a\u0430\u043c\u0456. "><img src="media/1x1.gif" class="link icon21"></button></td></tr></table><div id="visualization"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" id="svgBird" width="400px" height="400px"></svg></div><table width="400"><tr><td style="width: 190px;"></td><td><button id="runButton" class="primary" title="Run the program you wrote."><img src="media/1x1.gif" class="run icon21"> \u0417\u0430\u043f\u0443\u0441\u044c\u0446\u0456\u0446\u044c \u043f\u0440\u0430\u0433\u0440\u0430\u043c\u0443</button><button id="resetButton" class="primary" style="display: none" title="Stop the program and reset the level."><img src="media/1x1.gif" class="stop icon21"> \u0421\u043a\u0430\u0441\u0430\u0432\u0430\u0446\u044c</button></td></tr></table>'+
('<xml id="toolbox" style="display: none;"><block type="bird_heading"></block>'+(2<=b?'<block type="bird_noWorm"></block>'+(4<=b?'<block type="bird_compare"><field name="OP">LT</field><value name="A"><block type="bird_position"><field name="XY">X</field></block></value><value name="B"><block type="math_number"><field name="NUM">50</field></block></value></block>'+(5<=b?'<block type="bird_compare"><field name="OP">LT</field><value name="A"><block type="bird_position"><field name="XY">Y</field></block></value><value name="B"><block type="math_number"><field name="NUM">50</field></block></value></block>'+
(8<=b?'<block type="bird_and"></block>':""):""):""):"")+"</xml>")+'<div id="blockly"></div><div id="dialogShadow" class="dialogAnimate"></div><div id="dialogBorder"></div><div id="dialog"></div><div id="dialogDone" class="dialogHiddenContent"><div style="font-size: large; margin: 1em;">Congratulations!</div><div id="dialogLinesText" style="font-size: large; margin: 1em;"></div><pre id="containerCode"></pre><div id="dialogDoneText" style="font-size: large; margin: 1em;"></div><div id="dialogDoneButtons" class="farSide" style="padding: 1ex 3ex 0"><button id="doneCancel">\u0421\u043a\u0430\u0441\u0430\u0432\u0430\u0446\u044c</button><button id="doneOk" class="secondary">OK</button></div></div><div id="dialogAbort" class="dialogHiddenContent">This level is extremely difficult.  Would you like to skip it and go onto the next game?  You can always come back later.<div id="dialogAbortButtons" class="farSide" style="padding: 1ex 3ex 0"><button id="abortCancel">\u0421\u043a\u0430\u0441\u0430\u0432\u0430\u0446\u044c</button><button id="abortOk" class="secondary">OK</button></div></div><div id="dialogStorage" class="dialogHiddenContent"><div id="containerStorage"></div><div class="farSide" style="padding: 1ex 3ex 0"><button class="secondary" onclick="BlocklyDialogs.hideDialog(true)">OK</button></div></div><div id="dialogHelp" class="dialogHiddenContent">'+
(1==b?'<table><tr><td rowspan=2><img src="common/help.png"></td><td><div class="farSide"><img src="bird/help_heading.png" class="mirrorImg" height=27 width=141></div></td></tr><tr><td>Change the heading angle to make the bird get the worm and land in her nest.</td></tr></table>':2==b?'<table><tr><td><img src="common/help.png"></td><td>Use this block to go in one heading if you have the worm, or a different heading if you don\'t have the worm.</td><td><img src="bird/help_up.png"></td></tr></table>':
4==b?"<table><tr><td><img src=\"common/help.png\"></td><td>'x' is your current horizontal position.  Use this block to go in one heading if 'x' is less than a number, or a different heading otherwise.</td><td><img src=\"bird/help_up.png\"></td></tr></table>":5==b?'<table><tr><td><img src="bird/help_up.png"></td><td>Click the icon to modify the \'if\' block.</td><td><img src="common/help.png"></td></tr></table>':6==b?"<table><tr><td><img src=\"bird/help_up.png\"></td><td>This level needs both an 'else if' and an 'else' block.</td><td><img src=\"common/help.png\"></td></tr></table>":
8==b?'<table><tr><td><img src="bird/help_up.png"></td><td>The \'and\' block is true only if both its inputs are true.</td><td><img src="common/help.png"></td></tr></table>':"")+"</div>"+(5==b?'<div id="dialogMutatorHelp" class="dialogHiddenContent"><table><tr><td><img src="bird/help_mutator.png" class="mirrorImg" height=58 width=107></td><td>Drag an \'else\' block into the \'if\' block.</td></tr></table></div>':"")};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Ec={},C,Fc,Gc,Hc,Ic,Jc,Kc,Lc,Mc,Nc,Oc,Pc,Qc,Rc,Sc;function Tc(a){this.Ei=Object.create(null);if(a){a=a.split(",");for(var b=0;b<a.length;b++)this.Ei[a[b]]=!0}this.reset()}Tc.prototype.reset=function(){this.Pf=Object.create(null);this.Lh=Object.create(null)};Tc.prototype.getName=function(a,b){var c=a.toLowerCase()+"_"+b;if(c in this.Pf)return this.Pf[c];var d=Uc(this,a);return this.Pf[c]=d};
function Uc(a,b){var c;(c=b)?(c=encodeURI(c.replace(/ /g,"_")).replace(/[^\w]/g,"_"),-1!="0123456789".indexOf(c[0])&&(c="my_"+c)):c="unnamed";for(var d="";a.Lh[c+d]||c+d in a.Ei;)d=d?d+1:2;c+=d;a.Lh[c]=!0;return c};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Vc(a){var b;C&&(b=a.Ub().V);var c=dc("xml");a=Wc(a,!0);for(var d=0,e;e=a[d];d++){var f=Xc(e);e=D(e);f.setAttribute("x",C?b-e.x:e.x);f.setAttribute("y",e.y);c.appendChild(f)}return c}
function Xc(a){var b=dc("block");b.setAttribute("type",a.type);b.setAttribute("id",a.id);if(a.Ze){var c=a.Ze();c&&b.appendChild(c)}for(var d=0;c=a.S[d];d++)for(var e=0,f;f=c.Ca[e];e++)if(f.name&&f.nd){var h=dc("field",null,f.ic());h.setAttribute("name",f.name);b.appendChild(h)}a.ta&&(c=dc("comment",null,a.ta.Ea()),c.setAttribute("pinned",a.ta.A()),d=a.ta.Cc(),c.setAttribute("h",d.height),c.setAttribute("w",d.width),b.appendChild(c));d=!1;for(e=0;c=a.S[e];e++){var k;f=!0;5!=c.type&&(h=E(c.p),1==c.type?
(k=dc("value"),d=!0):3==c.type&&(k=dc("statement")),h&&(k.appendChild(Xc(h)),f=!1),k.setAttribute("name",c.name),f||b.appendChild(k))}d&&b.setAttribute("inline",a.Kd);a.isCollapsed()&&b.setAttribute("collapsed",!0);a.disabled&&b.setAttribute("disabled",!0);a.ec&&!F||b.setAttribute("deletable",!1);a.Ib&&!F||b.setAttribute("movable",!1);a.fc&&!F||b.setAttribute("editable",!1);if(a=Yc(a))k=dc("next",null,Xc(a)),b.appendChild(k);return b}function Zc(a){return(new XMLSerializer).serializeToString(a)}
function $c(a){a=(new DOMParser).parseFromString(a,"text/xml");if(!a||!a.firstChild||"xml"!=a.firstChild.nodeName.toLowerCase()||a.firstChild!==a.lastChild)throw"Blockly.Xml.textToDom did not obtain a valid XML tree.";return a.firstChild}function ad(a,b){if(C)var c=a.Ub().V;for(var d=0,e;e=b.childNodes[d];d++)if("block"==e.nodeName.toLowerCase()){var f=bd(a,e),h=parseInt(e.getAttribute("x"),10);e=parseInt(e.getAttribute("y"),10);isNaN(h)||isNaN(e)||f.moveBy(C?c-h:h,e)}}
function bd(a,b,c){var d=null,e=b.getAttribute("type");if(!e)throw"Block type unspecified: \n"+b.outerHTML;var f=b.getAttribute("id");if(c&&f){d=cd(f,a);if(!d)throw"Couldn't get Block with id: "+f;f=d.getParent();d.u&&d.i(!0,!1,!0);d.fill(a,e);d.Ga=f}else d=dd(a,e);d.n||ed(d);(f=b.getAttribute("inline"))&&fd(d,"true"==f);(f=b.getAttribute("disabled"))&&gd(d,"true"==f);(f=b.getAttribute("deletable"))&&hd(d,"true"==f);if(f=b.getAttribute("movable"))d.Ib="true"==f;(f=b.getAttribute("editable"))&&id(d,
"true"==f);for(var h=null,f=0,k;k=b.childNodes[f];f++)if(3!=k.nodeType||!k.data.match(/^\s*$/)){for(var h=null,m=0,p;p=k.childNodes[m];m++)3==p.nodeType&&p.data.match(/^\s*$/)||(h=p);m=k.getAttribute("name");switch(k.nodeName.toLowerCase()){case "mutation":d.Uf&&d.Uf(k);break;case "comment":jd(d,k.textContent);var q=k.getAttribute("pinned");q&&setTimeout(function(){d.ta.N("true"==q)},1);h=parseInt(k.getAttribute("w"),10);k=parseInt(k.getAttribute("h"),10);isNaN(h)||isNaN(k)||d.ta.rc(h,k);break;case "title":case "field":kd(d,
m).bb(k.textContent);break;case "value":case "statement":k=ld(d,m);if(!k)throw"Input "+m+" does not exist in block "+e;if(h&&"block"==h.nodeName.toLowerCase())if(h=bd(a,h,c),h.K)md(k.p,h.K);else if(h.F)md(k.p,h.F);else throw"Child block does not have output or previous statement.";break;case "next":if(h&&"block"==h.nodeName.toLowerCase()){if(!d.D)throw"Next statement does not exist.";if(d.D.t)throw"Next statement is already connected.";h=bd(a,h,c);if(!h.F)throw"Next block does not have previous statement.";
md(d.D,h.F)}}}(a=b.getAttribute("collapsed"))&&d.Sd("true"==a);(a=Yc(d))?a.v():d.v();return d}function nd(a){for(var b=0,c;c=a.childNodes[b];b++)if("next"==c.nodeName.toLowerCase()){a.removeChild(c);break}}window.Blockly||(window.Blockly={});window.Blockly.Xml||(window.Blockly.Xml={});window.Blockly.Xml.domToText=Zc;window.Blockly.Xml.domToWorkspace=ad;window.Blockly.Xml.textToDom=$c;window.Blockly.Xml.workspaceToDom=Vc;/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function od(a){this.s=a;this.X=null;this.Dd=new pd(a,!0,!0);this.ae=new pd(a,!1,!0);this.td=H("rect",{height:I,width:I,style:"fill: #fff"},null);qd(this.td,a.jd)}od.prototype.i=function(){J(this.ff);this.ff=null;z(this.td);this.X=this.s=this.td=null;this.Dd.i();this.Dd=null;this.ae.i();this.ae=null};
od.prototype.resize=function(){var a=this.s.Ub();if(a){var b=!1,c=!1;this.X&&this.X.V==a.V&&this.X.za==a.za&&this.X.gb==a.gb&&this.X.fb==a.fb?(this.X&&this.X.Wc==a.Wc&&this.X.Oa==a.Oa&&this.X.Qb==a.Qb||(b=!0),this.X&&this.X.Va==a.Va&&this.X.Mb==a.Mb&&this.X.qb==a.qb||(c=!0)):c=b=!0;b&&this.Dd.resize(a);c&&this.ae.resize(a);this.X&&this.X.V==a.V&&this.X.fb==a.fb||this.td.setAttribute("x",this.ae.uc);this.X&&this.X.za==a.za&&this.X.gb==a.gb||this.td.setAttribute("y",this.Dd.yf);this.X=a}};
od.prototype.set=function(a,b){this.Dd.set(a);this.ae.set(b)};function pd(a,b,c){this.s=a;this.gf=c||!1;this.Ka=b;this.Lf();b?(this.jb.setAttribute("height",I),this.ha.setAttribute("height",I-6),this.ha.setAttribute("y",3)):(this.jb.setAttribute("width",I),this.ha.setAttribute("width",I-6),this.ha.setAttribute("x",3));this.ti=K(this.jb,"mousedown",this,this.Ek);this.ui=K(this.ha,"mousedown",this,this.Fk)}var rd,sd,I="ontouchstart"in document.documentElement?25:15;g=pd.prototype;
g.i=function(){this.ef();this.ff&&(J(this.ff),this.ff=null);J(this.ti);this.ti=null;J(this.ui);this.ui=null;z(this.h);this.s=this.ha=this.jb=this.h=null};
g.resize=function(a){if(!a&&(a=this.s.Ub(),!a))return;if(this.Ka){var b=a.V;this.gf?b-=I:this.N(b<a.Va);this.Sa=b/a.Wc;if(-Infinity===this.Sa||Infinity===this.Sa||isNaN(this.Sa))this.Sa=0;var c=a.V*this.Sa,d=(a.Oa-a.Qb)*this.Sa;this.ha.setAttribute("width",Math.max(0,c));this.uc=a.fb;this.gf&&C&&(this.uc+=a.fb+I);this.yf=a.gb+a.za-I;this.h.setAttribute("transform","translate("+this.uc+", "+this.yf+")");this.jb.setAttribute("width",Math.max(0,b));this.ha.setAttribute("x",td(this,d))}else{b=a.za;this.gf?
b-=I:this.N(b<a.Va);this.Sa=b/a.Va;if(-Infinity===this.Sa||Infinity===this.Sa||isNaN(this.Sa))this.Sa=0;c=a.za*this.Sa;d=(a.Mb-a.qb)*this.Sa;this.ha.setAttribute("height",Math.max(0,c));this.uc=a.fb;C||(this.uc+=a.V-I);this.yf=a.gb;this.h.setAttribute("transform","translate("+this.uc+", "+this.yf+")");this.jb.setAttribute("height",Math.max(0,b));this.ha.setAttribute("y",td(this,d))}ud(this)};
g.Lf=function(){this.h=H("g",{},null);this.jb=H("rect",{"class":"blocklyScrollbarBackground"},this.h);var a=Math.floor((I-6)/2);this.ha=H("rect",{"class":"blocklyScrollbarKnob",rx:a,ry:a},this.h);qd(this.h,this.s.jd)};g.A=function(){return"none"!=this.h.getAttribute("display")};g.N=function(a){if(a!=this.A()){if(this.gf)throw"Unable to toggle visibility of paired scrollbars.";a?this.h.setAttribute("display","block"):(this.s.Ki({x:0,y:0}),this.h.setAttribute("display","none"))}};
g.Ek=function(a){this.ef();if(!vd(a)){var b=wd(a),b=this.Ka?b.x:b.y,c=xd(this.ha),c=this.Ka?c.x:c.y,d=parseFloat(this.ha.getAttribute(this.Ka?"width":"height")),e=parseFloat(this.ha.getAttribute(this.Ka?"x":"y")),f=.95*d;b<=c?e-=f:b>=c+d&&(e+=f);this.ha.setAttribute(this.Ka?"x":"y",td(this,e));ud(this)}a.stopPropagation()};
g.Fk=function(a){this.ef();vd(a)||(this.Yk=parseFloat(this.ha.getAttribute(this.Ka?"x":"y")),this.$k=this.Ka?a.clientX:a.clientY,rd=K(document,"mouseup",this,this.ef),sd=K(document,"mousemove",this,this.Hk));a.stopPropagation()};g.Hk=function(a){this.ha.setAttribute(this.Ka?"x":"y",td(this,this.Yk+((this.Ka?a.clientX:a.clientY)-this.$k)));ud(this)};g.ef=function(){yd();zd(!0);rd&&(J(rd),rd=null);sd&&(J(sd),sd=null)};
function td(a,b){if(0>=b||isNaN(b))b=0;else{var c=a.Ka?"width":"height",d=parseFloat(a.jb.getAttribute(c)),c=parseFloat(a.ha.getAttribute(c));b=Math.min(b,d-c)}return b}function ud(a){var b=parseFloat(a.ha.getAttribute(a.Ka?"x":"y")),c=parseFloat(a.jb.getAttribute(a.Ka?"width":"height")),b=b/c;isNaN(b)&&(b=0);c={};a.Ka?c.x=b:c.y=b;a.s.Ki(c)}g.set=function(a){this.ha.setAttribute(this.Ka?"x":"y",a*this.Sa);ud(this)};
function qd(a,b){var c=b.nextSibling,d=b.parentNode;if(!d)throw"Reference node has no parent.";c?d.insertBefore(a,c):d.appendChild(a)};function Ad(){0!=Bd&&(Cd[ia(this)]=this);this.vd=this.vd;this.bf=this.bf}var Bd=0,Cd={};Ad.prototype.vd=!1;Ad.prototype.i=function(){if(!this.vd&&(this.vd=!0,this.ba(),0!=Bd)){var a=ia(this);delete Cd[a]}};Ad.prototype.ba=function(){if(this.bf)for(;this.bf.length;)this.bf.shift()()};var Dd="closure_listenable_"+(1E6*Math.random()|0),Ed=0;function Fd(a,b,c,d,e){this.Ic=a;this.jf=null;this.src=b;this.type=c;this.re=!!d;this.Je=e;this.key=++Ed;this.fd=this.qe=!1}function Gd(a){a.fd=!0;a.Ic=null;a.jf=null;a.src=null;a.Je=null};function Hd(a){this.src=a;this.La={};this.$d=0}Hd.prototype.add=function(a,b,c,d,e){var f=a.toString();a=this.La[f];a||(a=this.La[f]=[],this.$d++);var h=Id(a,b,d,e);-1<h?(b=a[h],c||(b.qe=!1)):(b=new Fd(b,this.src,f,!!d,e),b.qe=c,a.push(b));return b};Hd.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.La))return!1;var e=this.La[a];b=Id(e,b,c,d);return-1<b?(Gd(e[b]),Sa.splice.call(e,b,1),0==e.length&&(delete this.La[a],this.$d--),!0):!1};
function Jd(a,b){var c=b.type;if(!(c in a.La))return!1;var d=Za(a.La[c],b);d&&(Gd(b),0==a.La[c].length&&(delete a.La[c],a.$d--));return d}Hd.prototype.mf=function(a){a=a&&a.toString();var b=0,c;for(c in this.La)if(!a||c==a){for(var d=this.La[c],e=0;e<d.length;e++)++b,Gd(d[e]);delete this.La[c];this.$d--}return b};Hd.prototype.Bd=function(a,b,c,d){a=this.La[a.toString()];var e=-1;a&&(e=Id(a,b,c,d));return-1<e?a[e]:null};
function Id(a,b,c,d){for(var e=0;e<a.length;++e){var f=a[e];if(!f.fd&&f.Ic==b&&f.re==!!c&&f.Je==d)return e}return-1};function Kd(a,b){this.type=a;this.currentTarget=this.target=b;this.defaultPrevented=this.Lc=!1;this.Gi=!0}Kd.prototype.ba=function(){};Kd.prototype.i=function(){};Kd.prototype.stopPropagation=function(){this.Lc=!0};Kd.prototype.preventDefault=function(){this.defaultPrevented=!0;this.Gi=!1};var Ld=!v||v&&9<=Rb,Md=!v||v&&9<=Rb,Nd=v&&!Pb("9");!w||Pb("528");Ib&&Pb("1.9b")||v&&Pb("8")||Hb&&Pb("9.5")||w&&Pb("528");Ib&&!Pb("8")||v&&Pb("9");var Od="ontouchstart"in l||!!(l.document&&document.documentElement&&"ontouchstart"in document.documentElement)||!(!l.navigator||!l.navigator.msMaxTouchPoints);function Pd(a){Pd[" "](a);return a}Pd[" "]=ba;function Qd(a,b){Kd.call(this,a?a.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.charCode=this.keyCode=this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.xg=!1;this.Tb=null;a&&this.o(a,b)}s(Qd,Kd);var Rd=[1,4,2];
Qd.prototype.o=function(a,b){var c=this.type=a.type;this.target=a.target||a.srcElement;this.currentTarget=b;var d=a.relatedTarget;if(d){if(Ib){var e;a:{try{Pd(d.nodeName);e=!0;break a}catch(f){}e=!1}e||(d=null)}}else"mouseover"==c?d=a.fromElement:"mouseout"==c&&(d=a.toElement);this.relatedTarget=d;this.offsetX=w||void 0!==a.offsetX?a.offsetX:a.layerX;this.offsetY=w||void 0!==a.offsetY?a.offsetY:a.layerY;this.clientX=void 0!==a.clientX?a.clientX:a.pageX;this.clientY=void 0!==a.clientY?a.clientY:a.pageY;
this.screenX=a.screenX||0;this.screenY=a.screenY||0;this.button=a.button;this.keyCode=a.keyCode||0;this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.xg=Db?a.metaKey:a.ctrlKey;this.state=a.state;this.Tb=a;a.defaultPrevented&&this.preventDefault()};function Sd(a){return Ld?0==a.Tb.button:"click"==a.type?!0:!!(a.Tb.button&Rd[0])}
Qd.prototype.stopPropagation=function(){Qd.m.stopPropagation.call(this);this.Tb.stopPropagation?this.Tb.stopPropagation():this.Tb.cancelBubble=!0};Qd.prototype.preventDefault=function(){Qd.m.preventDefault.call(this);var a=this.Tb;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,Nd)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(b){}};Qd.prototype.ba=function(){};var Td="closure_lm_"+(1E6*Math.random()|0),Ud={},Vd=0;function Wd(a,b,c,d,e){if(ea(b)){for(var f=0;f<b.length;f++)Wd(a,b[f],c,d,e);return null}c=Xd(c);if(a&&a[Dd])a=a.H(b,c,d,e);else{if(!b)throw Error("Invalid event type");var f=!!d,h=Yd(a);h||(a[Td]=h=new Hd(a));c=h.add(b,c,!1,d,e);c.jf||(d=Zd(),c.jf=d,d.src=a,d.Ic=c,a.addEventListener?a.addEventListener(b.toString(),d,f):a.attachEvent($d(b.toString()),d),Vd++);a=c}return a}
function Zd(){var a=ae,b=Md?function(c){return a.call(b.src,b.Ic,c)}:function(c){c=a.call(b.src,b.Ic,c);if(!c)return c};return b}function be(a,b,c,d,e){if(ea(b))for(var f=0;f<b.length;f++)be(a,b[f],c,d,e);else c=Xd(c),a&&a[Dd]?a.kb(b,c,d,e):a&&(a=Yd(a))&&(b=a.Bd(b,c,!!d,e))&&ce(b)}
function ce(a){if(ga(a)||!a||a.fd)return!1;var b=a.src;if(b&&b[Dd])return Jd(b.gc,a);var c=a.type,d=a.jf;b.removeEventListener?b.removeEventListener(c,d,a.re):b.detachEvent&&b.detachEvent($d(c),d);Vd--;(c=Yd(b))?(Jd(c,a),0==c.$d&&(c.src=null,b[Td]=null)):Gd(a);return!0}function $d(a){return a in Ud?Ud[a]:Ud[a]="on"+a}function de(a,b,c,d){var e=1;if(a=Yd(a))if(b=a.La[b.toString()])for(b=b.concat(),a=0;a<b.length;a++){var f=b[a];f&&f.re==c&&!f.fd&&(e&=!1!==ee(f,d))}return Boolean(e)}
function ee(a,b){var c=a.Ic,d=a.Je||a.src;a.qe&&ce(a);return c.call(d,b)}
function ae(a,b){if(a.fd)return!0;if(!Md){var c=b||aa("window.event"),d=new Qd(c,this),e=!0;if(!(0>c.keyCode||void 0!=c.returnValue)){a:{var f=!1;if(0==c.keyCode)try{c.keyCode=-1;break a}catch(h){f=!0}if(f||void 0==c.returnValue)c.returnValue=!0}c=[];for(f=d.currentTarget;f;f=f.parentNode)c.push(f);for(var f=a.type,k=c.length-1;!d.Lc&&0<=k;k--)d.currentTarget=c[k],e&=de(c[k],f,!0,d);for(k=0;!d.Lc&&k<c.length;k++)d.currentTarget=c[k],e&=de(c[k],f,!1,d)}return e}return ee(a,new Qd(b,this))}
function Yd(a){a=a[Td];return a instanceof Hd?a:null}var fe="__closure_events_fn_"+(1E9*Math.random()>>>0);function Xd(a){if(r(a))return a;a[fe]||(a[fe]=function(b){return a.handleEvent(b)});return a[fe]};function ge(){Ad.call(this);this.gc=new Hd(this);this.kj=this;this.wg=null}s(ge,Ad);ge.prototype[Dd]=!0;g=ge.prototype;g.Fe=function(){return this.wg};g.Jg=function(a){this.wg=a};g.addEventListener=function(a,b,c,d){Wd(this,a,b,c,d)};g.removeEventListener=function(a,b,c,d){be(this,a,b,c,d)};
g.dispatchEvent=function(a){var b,c=this.Fe();if(c)for(b=[];c;c=c.Fe())b.push(c);var c=this.kj,d=a.type||a;if(n(a))a=new Kd(a,c);else if(a instanceof Kd)a.target=a.target||c;else{var e=a;a=new Kd(d,c);kb(a,e)}var e=!0,f;if(b)for(var h=b.length-1;!a.Lc&&0<=h;h--)f=a.currentTarget=b[h],e=he(f,d,!0,a)&&e;a.Lc||(f=a.currentTarget=c,e=he(f,d,!0,a)&&e,a.Lc||(e=he(f,d,!1,a)&&e));if(b)for(h=0;!a.Lc&&h<b.length;h++)f=a.currentTarget=b[h],e=he(f,d,!1,a)&&e;return e};
g.ba=function(){ge.m.ba.call(this);this.gc&&this.gc.mf(void 0);this.wg=null};g.H=function(a,b,c,d){return this.gc.add(String(a),b,!1,c,d)};g.kb=function(a,b,c,d){return this.gc.remove(String(a),b,c,d)};function he(a,b,c,d){b=a.gc.La[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,f=0;f<b.length;++f){var h=b[f];if(h&&!h.fd&&h.re==c){var k=h.Ic,m=h.Je||h.src;h.qe&&Jd(a.gc,h);e=!1!==k.call(m,d)&&e}}return e&&0!=d.Gi}g.Bd=function(a,b,c,d){return this.gc.Bd(String(a),b,c,d)};function ie(a,b,c){if(r(a))c&&(a=na(a,c));else if(a&&"function"==typeof a.handleEvent)a=na(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<b?-1:l.setTimeout(a,b||0)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function je(a){this.s=a}g=je.prototype;g.rd=47;g.zf=45;g.od=15;g.aj=35;g.ah=35;g.ie=25;g.Gb=!1;g.h=null;g.vf=null;g.og=0;g.nc=0;g.ki=0;g.Ri=0;
g.I=function(){this.h=H("g",{filter:"url(#blocklyTrashcanShadowFilter)"},null);var a=H("clipPath",{id:"blocklyTrashBodyClipPath"},this.h);H("rect",{width:this.rd,height:this.zf,y:this.od},a);H("image",{width:ke,height:le,y:-32,"clip-path":"url(#blocklyTrashBodyClipPath)"},this.h).setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",me+ne);a=H("clipPath",{id:"blocklyTrashLidClipPath"},this.h);H("rect",{width:this.rd,height:this.od},a);this.vf=H("image",{width:ke,height:le,y:-32,"clip-path":"url(#blocklyTrashLidClipPath)"},
this.h);this.vf.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",me+ne);return this.h};g.o=function(){oe(this,!1);this.Pd();K(window,"resize",this,this.Pd)};g.i=function(){this.h&&(z(this.h),this.h=null);this.s=this.vf=null;l.clearTimeout(this.og)};g.Pd=function(){var a=this.s.Ub();a&&(this.ki=C?this.ah:a.V+a.fb-this.rd-this.ah,this.Ri=a.za+a.gb-(this.zf+this.od)-this.aj,this.h.setAttribute("transform","translate("+this.ki+","+this.Ri+")"))};
g.df=function(a){if(this.h){a=wd(a);var b=xd(this.h);a=a.x>b.x-this.ie&&a.x<b.x+this.rd+this.ie&&a.y>b.y-this.ie&&a.y<b.y+this.zf+this.od+this.ie;this.Gb!=a&&oe(this,a)}};function oe(a,b){a.Gb!=b&&(l.clearTimeout(a.og),a.Gb=b,a.mh())}g.mh=function(){this.nc+=this.Gb?10:-10;this.nc=Math.max(0,this.nc);this.vf.setAttribute("transform","rotate("+(C?-this.nc:this.nc)+", "+(C?4:this.rd-4)+", "+(this.od-2)+")");if(this.Gb?45>this.nc:0<this.nc)this.og=ie(this.mh,5,this)};g.close=function(){oe(this,!1)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function pe(a,b){this.Ub=a;this.Ki=b;this.ii=!1;this.kd=[];this.qg=Infinity;var c=[];c[1]=new qe;c[2]=new qe;c[3]=new qe;c[4]=new qe;this.zj=c}g=pe.prototype;g.Vf=!1;g.scrollX=0;g.scrollY=0;g.Ua=null;g.Xf=null;g.qc=null;g.I=function(){this.h=H("g",{},null);this.Q=H("g",{},this.h);this.jd=H("g",{},this.h);re(this);return this.h};g.i=function(){this.h&&(z(this.h),this.h=null);this.jd=this.Q=null;this.Ua&&(this.Ua.i(),this.Ua=null)};
function se(){var a=y;if(Fc&&!F){a.Ua=new je(a);var b=a.Ua.I();a.h.insertBefore(b,a.Q);a.Ua.o()}}function te(a,b){a.kd.push(b);ue&&a==y&&-1==ve.indexOf(b)&&ve.push(b);re(a)}function we(a,b){for(var c=!1,d,e=0;d=a.kd[e];e++)if(d==b){a.kd.splice(e,1);c=!0;break}if(!c)throw"Block not present in workspace's list of top-most blocks.";ue&&a==y&&ve.hm(b);re(a)}
function Wc(a,b){var c=[].concat(a.kd);if(b&&1<c.length){var d=Math.sin(3/180*Math.PI);C&&(d*=-1);c.sort(function(a,b){var c=D(a),k=D(b);return c.y+d*c.x-(k.y+d*k.x)})}return c}function xe(a){a=Wc(a,!1);for(var b=0;b<a.length;b++)a.push.apply(a,a[b].Dc());return a}g.clear=function(){for(zd();this.kd.length;)this.kd[0].i()};g.v=function(){for(var a=xe(this),b=0,c;c=a[b];b++)c.Dc().length||c.v()};function ye(a,b){for(var c=xe(a),d=0,e;e=c[d];d++)if(e.id==b)return e;return null}
function ze(a,b){a.Vg=b;a.Wg&&(J(a.Wg),a.Wg=null);b&&(a.Wg=K(a.Q,"blocklySelectChange",a,function(){this.Vg=!1}))}function Ae(a){var b=y;b.Vg&&0!=Be&&ze(b,!1);if(b.Vg){var c=null;if(a&&(c=ye(b,a),!c))return;ze(b,!1);c?c.select():L&&Ce();setTimeout(function(){ze(b,!0)},1)}}function re(a){a.Xf&&window.clearTimeout(a.Xf);var b=a.Q;b&&(a.Xf=window.setTimeout(function(){De(b,"blocklyWorkspaceChange")},0))}function Ee(a){return Infinity==a.qg?Infinity:a.qg-xe(a).length}pe.prototype.clear=pe.prototype.clear;function Fe(a,b,c,d){this.top=a;this.right=b;this.bottom=c;this.left=d}g=Fe.prototype;g.clone=function(){return new Fe(this.top,this.right,this.bottom,this.left)};g.toString=function(){return"("+this.top+"t, "+this.right+"r, "+this.bottom+"b, "+this.left+"l)"};g.contains=function(a){return this&&a?a instanceof Fe?a.left>=this.left&&a.right<=this.right&&a.top>=this.top&&a.bottom<=this.bottom:a.x>=this.left&&a.x<=this.right&&a.y>=this.top&&a.y<=this.bottom:!1};
g.expand=function(a,b,c,d){ha(a)?(this.top-=a.top,this.right+=a.right,this.bottom+=a.bottom,this.left-=a.left):(this.top-=a,this.right+=b,this.bottom+=c,this.left-=d);return this};g.ceil=function(){this.top=Math.ceil(this.top);this.right=Math.ceil(this.right);this.bottom=Math.ceil(this.bottom);this.left=Math.ceil(this.left);return this};g.floor=function(){this.top=Math.floor(this.top);this.right=Math.floor(this.right);this.bottom=Math.floor(this.bottom);this.left=Math.floor(this.left);return this};
g.round=function(){this.top=Math.round(this.top);this.right=Math.round(this.right);this.bottom=Math.round(this.bottom);this.left=Math.round(this.left);return this};g.translate=function(a,b){a instanceof x?(this.left+=a.x,this.right+=a.x,this.top+=a.y,this.bottom+=a.y):(this.left+=a,this.right+=a,ga(b)&&(this.top+=b,this.bottom+=b));return this};g.scale=function(a,b){var c=ga(b)?b:a;this.left*=a;this.right*=a;this.top*=c;this.bottom*=c;return this};function Ge(a,b,c,d){this.left=a;this.top=b;this.width=c;this.height=d}g=Ge.prototype;g.clone=function(){return new Ge(this.left,this.top,this.width,this.height)};g.toString=function(){return"("+this.left+", "+this.top+" - "+this.width+"w x "+this.height+"h)"};g.contains=function(a){return a instanceof Ge?this.left<=a.left&&this.left+this.width>=a.left+a.width&&this.top<=a.top&&this.top+this.height>=a.top+a.height:a.x>=this.left&&a.x<=this.left+this.width&&a.y>=this.top&&a.y<=this.top+this.height};
g.Xh=function(){return new Sb(this.width,this.height)};g.ceil=function(){this.left=Math.ceil(this.left);this.top=Math.ceil(this.top);this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};g.floor=function(){this.left=Math.floor(this.left);this.top=Math.floor(this.top);this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
g.round=function(){this.left=Math.round(this.left);this.top=Math.round(this.top);this.width=Math.round(this.width);this.height=Math.round(this.height);return this};g.translate=function(a,b){a instanceof x?(this.left+=a.x,this.top+=a.y):(this.left+=a,ga(b)&&(this.top+=b));return this};g.scale=function(a,b){var c=ga(b)?b:a;this.left*=a;this.width*=a;this.top*=c;this.height*=c;return this};function He(a,b){var c=$b(a);return c.defaultView&&c.defaultView.getComputedStyle&&(c=c.defaultView.getComputedStyle(a,null))?c[b]||c.getPropertyValue(b)||"":""}function Ie(a,b){return He(a,b)||(a.currentStyle?a.currentStyle[b]:null)||a.style&&a.style[b]}function Je(){var a=document,b=a.body,a=a.documentElement;return new x(b.scrollLeft||a.scrollLeft,b.scrollTop||a.scrollTop)}
function Ke(a){var b;try{b=a.getBoundingClientRect()}catch(c){return{left:0,top:0,right:0,bottom:0}}v&&a.ownerDocument.body&&(a=a.ownerDocument,b.left-=a.documentElement.clientLeft+a.body.clientLeft,b.top-=a.documentElement.clientTop+a.body.clientTop);return b}
function Le(a){if(v&&!(v&&8<=Rb))return a.offsetParent;var b=$b(a),c=Ie(a,"position"),d="fixed"==c||"absolute"==c;for(a=a.parentNode;a&&a!=b;a=a.parentNode)if(c=Ie(a,"position"),d=d&&"static"==c&&a!=b.documentElement&&a!=b.body,!d&&(a.scrollWidth>a.clientWidth||a.scrollHeight>a.clientHeight||"fixed"==c||"absolute"==c||"relative"==c))return a;return null}
function Me(a){var b,c=$b(a),d=Ie(a,"position"),e=Ib&&c.getBoxObjectFor&&!a.getBoundingClientRect&&"absolute"==d&&(b=c.getBoxObjectFor(a))&&(0>b.screenX||0>b.screenY),f=new x(0,0),h;b=c?$b(c):document;(h=!v||v&&9<=Rb)||(h="CSS1Compat"==Yb(b).Sb.compatMode);h=h?b.documentElement:b.body;if(a==h)return f;if(a.getBoundingClientRect)b=Ke(a),c=Yb(c).Sb,a=w||"CSS1Compat"!=c.compatMode?c.body||c.documentElement:c.documentElement,c=c.parentWindow||c.defaultView,a=v&&Pb("10")&&c.pageYOffset!=a.scrollTop?new x(a.scrollLeft,
a.scrollTop):new x(c.pageXOffset||a.scrollLeft,c.pageYOffset||a.scrollTop),f.x=b.left+a.x,f.y=b.top+a.y;else if(c.getBoxObjectFor&&!e)b=c.getBoxObjectFor(a),a=c.getBoxObjectFor(h),f.x=b.screenX-a.screenX,f.y=b.screenY-a.screenY;else{b=a;do{f.x+=b.offsetLeft;f.y+=b.offsetTop;b!=a&&(f.x+=b.clientLeft||0,f.y+=b.clientTop||0);if(w&&"fixed"==Ie(b,"position")){f.x+=c.body.scrollLeft;f.y+=c.body.scrollTop;break}b=b.offsetParent}while(b&&b!=a);if(Hb||w&&"absolute"==d)f.y-=c.body.offsetTop;for(b=a;(b=Le(b))&&
b!=c.body&&b!=h;)f.x-=b.scrollLeft,Hb&&"TR"==b.tagName||(f.y-=b.scrollTop)}return f}function Ne(a){var b=Oe;if("none"!=Ie(a,"display"))return b(a);var c=a.style,d=c.display,e=c.visibility,f=c.position;c.visibility="hidden";c.position="absolute";c.display="inline";a=b(a);c.display=d;c.position=f;c.visibility=e;return a}function Oe(a){var b=a.offsetWidth,c=a.offsetHeight,d=w&&!b&&!c;return(void 0===b||d)&&a.getBoundingClientRect?(a=Ke(a),new Sb(a.right-a.left,a.bottom-a.top)):new Sb(b,c)}
function Pe(a){var b=Me(a);a=Ne(a);return new Ge(b.x,b.y,a.width,a.height)}function Qe(a,b){a.style.display=b?"":"none"}var Re=Ib?"MozUserSelect":w?"WebkitUserSelect":null;function Se(a,b,c){c=c?null:a.getElementsByTagName("*");if(Re){if(b=b?"none":"",a.style[Re]=b,c){a=0;for(var d;d=c[a];a++)d.style[Re]=b}}else if(v||Hb)if(b=b?"on":"",a.setAttribute("unselectable",b),c)for(a=0;d=c[a];a++)d.setAttribute("unselectable",b)}var Te={thin:2,medium:4,thick:6};
function Ue(a,b){if("none"==(a.currentStyle?a.currentStyle[b+"Style"]:null))return 0;var c=a.currentStyle?a.currentStyle[b+"Width"]:null,d;if(c in Te)d=Te[c];else if(/^\d+px?$/.test(c))d=parseInt(c,10);else{d=a.style.left;var e=a.runtimeStyle.left;a.runtimeStyle.left=a.currentStyle.left;a.style.left=c;c=a.style.pixelLeft;a.style.left=d;a.runtimeStyle.left=e;d=c}return d}
function Ve(a){if(v&&!(v&&9<=Rb)){var b=Ue(a,"borderLeft"),c=Ue(a,"borderRight"),d=Ue(a,"borderTop");a=Ue(a,"borderBottom");return new Fe(d,c,a,b)}b=He(a,"borderLeftWidth");c=He(a,"borderRightWidth");d=He(a,"borderTopWidth");a=He(a,"borderBottomWidth");return new Fe(parseFloat(d),parseFloat(c),parseFloat(a),parseFloat(b))};function We(a){Ad.call(this);this.ai=a;this.Ue={}}s(We,Ad);var Xe=[];g=We.prototype;g.H=function(a,b,c,d){ea(b)||(b&&(Xe[0]=b.toString()),b=Xe);for(var e=0;e<b.length;e++){var f=Wd(a,b[e],c||this.handleEvent,d||!1,this.ai||this);if(!f)break;this.Ue[f.key]=f}return this};
g.kb=function(a,b,c,d,e){if(ea(b))for(var f=0;f<b.length;f++)this.kb(a,b[f],c,d,e);else c=c||this.handleEvent,e=e||this.ai||this,c=Xd(c),d=!!d,b=a&&a[Dd]?a.Bd(b,c,d,e):a?(a=Yd(a))?a.Bd(b,c,d,e):null:null,b&&(ce(b),delete this.Ue[b.key]);return this};g.mf=function(){ib(this.Ue,ce);this.Ue={}};g.ba=function(){We.m.ba.call(this);this.mf()};g.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented");};function Ye(){}ca(Ye);Ye.prototype.zk=0;function Ze(a){ge.call(this);this.ve=a||Yb();this.qf=$e;this.Me=null;this.G=!1;this.w=null;this.jc=void 0;this.bc=this.Y=this.Ga=this.Ye=null;this.jl=!1}s(Ze,ge);Ze.prototype.ik=Ye.hc();var $e=null;
function af(a,b){switch(a){case 1:return b?"disable":"enable";case 2:return b?"highlight":"unhighlight";case 4:return b?"activate":"deactivate";case 8:return b?"select":"unselect";case 16:return b?"check":"uncheck";case 32:return b?"focus":"blur";case 64:return b?"open":"close"}throw Error("Invalid component state");}function bf(a){return a.Me||(a.Me=":"+(a.ik.zk++).toString(36))}g=Ze.prototype;g.k=function(){return this.w};function cf(a){a.jc||(a.jc=new We(a));return a.jc}
g.$a=function(a){if(this==a)throw Error("Unable to set parent component");if(a&&this.Ga&&this.Me&&df(this.Ga,this.Me)&&this.Ga!=a)throw Error("Unable to set parent component");this.Ga=a;Ze.m.Jg.call(this,a)};g.getParent=function(){return this.Ga};g.Jg=function(a){if(this.Ga&&this.Ga!=a)throw Error("Method not supported");Ze.m.Jg.call(this,a)};g.tb=function(){return this.ve};g.I=function(){this.w=this.ve.createElement("div")};g.v=function(a){this.Rd(a)};
g.Rd=function(a,b){if(this.G)throw Error("Component already rendered");this.w||this.I();a?a.insertBefore(this.w,b||null):this.ve.Sb.body.appendChild(this.w);this.Ga&&!this.Ga.G||this.va()};g.va=function(){this.G=!0;ef(this,function(a){!a.G&&a.k()&&a.va()})};g.hb=function(){ef(this,function(a){a.G&&a.hb()});this.jc&&this.jc.mf();this.G=!1};
g.ba=function(){this.G&&this.hb();this.jc&&(this.jc.i(),delete this.jc);ef(this,function(a){a.i()});!this.jl&&this.w&&z(this.w);this.Ga=this.Ye=this.w=this.bc=this.Y=null;Ze.m.ba.call(this)};g.me=function(a,b){this.Uc(a,ff(this),b)};
g.Uc=function(a,b,c){if(a.G&&(c||!this.G))throw Error("Component already rendered");if(0>b||b>ff(this))throw Error("Child component index out of bounds");this.bc&&this.Y||(this.bc={},this.Y=[]);if(a.getParent()==this){var d=bf(a);this.bc[d]=a;Za(this.Y,a)}else{var d=this.bc,e=bf(a);if(e in d)throw Error('The object already contains the key "'+e+'"');d[e]=a}a.$a(this);ab(this.Y,b,0,a);a.G&&this.G&&a.getParent()==this?(c=this.sb(),c.insertBefore(a.k(),c.childNodes[b]||null)):c?(this.w||this.I(),b=M(this,
b+1),a.Rd(this.sb(),b?b.w:null)):this.G&&!a.G&&a.w&&a.w.parentNode&&1==a.w.parentNode.nodeType&&a.va()};g.sb=function(){return this.w};function gf(a){null==a.qf&&(a.qf="rtl"==Ie(a.G?a.w:a.ve.Sb.body,"direction"));return a.qf}g.Ud=function(a){if(this.G)throw Error("Component already rendered");this.qf=a};function hf(a){return!!a.Y&&0!=a.Y.length}function ff(a){return a.Y?a.Y.length:0}function df(a,b){var c;a.bc&&b?(c=a.bc,c=(b in c?c[b]:void 0)||null):c=null;return c}
function M(a,b){return a.Y?a.Y[b]||null:null}function ef(a,b,c){a.Y&&Ua(a.Y,b,c)}function jf(a,b){return a.Y&&b?Ta(a.Y,b):-1}g.removeChild=function(a,b){if(a){var c=n(a)?a:bf(a);a=df(this,c);if(c&&a){var d=this.bc;c in d&&delete d[c];Za(this.Y,a);b&&(a.hb(),a.w&&z(a.w));a.$a(null)}}if(!a)throw Error("Child is not in parent component");return a};g.Di=function(a){for(var b=[];hf(this);)b.push(this.removeChild(M(this,0),a));return b};function kf(a){if(a.classList)return a.classList;a=a.className;return n(a)&&a.match(/\S+/g)||[]}function lf(a,b){return a.classList?a.classList.contains(b):Ya(kf(a),b)}function mf(a,b){a.classList?a.classList.add(b):lf(a,b)||(a.className+=0<a.className.length?" "+b:b)}function nf(a,b){if(a.classList)Ua(b,function(b){mf(a,b)});else{var c={};Ua(kf(a),function(a){c[a]=!0});Ua(b,function(a){c[a]=!0});a.className="";for(var d in c)a.className+=0<a.className.length?" "+d:d}}
function of(a,b){a.classList?a.classList.remove(b):lf(a,b)&&(a.className=Va(kf(a),function(a){return a!=b}).join(" "))}function pf(a,b){a.classList?Ua(b,function(b){of(a,b)}):a.className=Va(kf(a),function(a){return!Ya(b,a)}).join(" ")};function qf(a,b){if(!a)throw Error("Invalid class name "+a);if(!r(b))throw Error("Invalid decorator function "+b);}var rf={};var sf;function tf(a,b){b?a.setAttribute("role",b):a.removeAttribute("role")}function uf(a,b,c){ea(c)&&(c=c.join(" "));var d="aria-"+b;""===c||void 0==c?(sf||(sf={atomic:!1,autocomplete:"none",dropeffect:"none",haspopup:!1,live:"off",multiline:!1,multiselectable:!1,orientation:"vertical",readonly:!1,relevant:"additions text",required:!1,sort:"none",busy:!1,disabled:!1,hidden:!1,invalid:"false"}),c=sf,b in c?a.setAttribute(d,c[b]):a.removeAttribute(d)):a.setAttribute(d,c)};function vf(){}var wf;ca(vf);var xf={button:"pressed",checkbox:"checked",menuitem:"selected",menuitemcheckbox:"checked",menuitemradio:"checked",radio:"checked",tab:"selected",treeitem:"selected"};g=vf.prototype;g.xe=function(){};g.I=function(a){var b=a.tb().I("div",this.Ae(a).join(" "),a.Rb);yf(a,b);return b};g.sb=function(a){return a};g.wd=function(a,b,c){if(a=a.k?a.k():a){var d=[b];v&&!Pb("7")&&(d=zf(kf(a),b),d.push(b));(c?nf:pf)(a,d)}};
g.Jd=function(a){gf(a)&&this.Ud(a.k(),!0);a.isEnabled()&&this.Pc(a,a.A())};function Af(a,b,c){if(a=c||a.xe())c=b.getAttribute("role")||null,a!=c&&tf(b,a)}function yf(a,b){a.A()||uf(b,"hidden",!a.A());a.isEnabled()||Bf(b,1,!a.isEnabled());a.$&8&&Bf(b,8,a.Re());a.$&16&&Bf(b,16,!!(a.ga&16));a.$&64&&Bf(b,64,a.Gb())}g.Gg=function(a,b){Se(a,!b,!v&&!Hb)};g.Ud=function(a,b){this.wd(a,this.Da()+"-rtl",b)};g.kc=function(a){var b;return a.$&32&&(b=a.ra())?mc(b)&&nc(b):!1};
g.Pc=function(a,b){var c;if(a.$&32&&(c=a.ra())){if(!b&&a.ga&32){try{c.blur()}catch(d){}a.ga&32&&a.Ed(null)}(mc(c)&&nc(c))!=b&&(b?c.tabIndex=0:(c.tabIndex=-1,c.removeAttribute("tabIndex")))}};g.N=function(a,b){Qe(a,b);a&&uf(a,"hidden",!b)};g.zb=function(a,b,c){var d=a.k();if(d){var e=this.ze(b);e&&this.wd(a,e,c);Bf(d,b,c)}};
function Bf(a,b,c){wf||(wf={1:"disabled",8:"selected",16:"checked",64:"expanded"});b=wf[b];var d=a.getAttribute("role")||null;d&&(d=xf[d]||b,b="checked"==b||"selected"==b?d:b);b&&uf(a,b,c)}g.ra=function(a){return a.k()};g.Da=function(){return"goog-control"};g.Ae=function(a){var b=this.Da(),c=[b],d=this.Da();d!=b&&c.push(d);b=a.ga;for(d=[];b;){var e=b&-b;d.push(this.ze(e));b&=~e}c.push.apply(c,d);(a=a.Db)&&c.push.apply(c,a);v&&!Pb("7")&&c.push.apply(c,zf(c));return c};
function zf(a,b){var c=[];b&&(a=a.concat([b]));Ua([],function(d){!Xa(d,oa(Ya,a))||b&&!Ya(d,b)||c.push(d.join("_"))});return c}g.ze=function(a){if(!this.uh){var b=this.Da();b.replace(/\xa0|\s/g," ");this.uh={1:b+"-disabled",2:b+"-hover",4:b+"-active",8:b+"-selected",16:b+"-checked",32:b+"-focused",64:b+"-open"}}return this.uh[a]};function Cf(a,b,c,d,e){if(!(v||w&&Pb("525")))return!0;if(Db&&e)return Df(a);if(e&&!d)return!1;ga(b)&&(b=Ef(b));if(!c&&(17==b||18==b||Db&&91==b))return!1;if(w&&d&&c)switch(a){case 220:case 219:case 221:case 192:case 186:case 189:case 187:case 188:case 190:case 191:case 192:case 222:return!1}if(v&&d&&b==a)return!1;switch(a){case 13:return!0;case 27:return!w}return Df(a)}
function Df(a){if(48<=a&&57>=a||96<=a&&106>=a||65<=a&&90>=a||w&&0==a)return!0;switch(a){case 32:case 63:case 107:case 109:case 110:case 111:case 186:case 59:case 189:case 187:case 61:case 188:case 190:case 191:case 192:case 222:case 219:case 220:case 221:return!0;default:return!1}}function Ef(a){if(Ib)a=Ff(a);else if(Db&&w)a:switch(a){case 93:a=91;break a}return a}
function Ff(a){switch(a){case 61:return 187;case 59:return 186;case 173:return 189;case 224:return 91;case 0:return 224;default:return a}};function Gf(a,b){ge.call(this);a&&Hf(this,a,b)}s(Gf,ge);g=Gf.prototype;g.w=null;g.Se=null;g.lg=null;g.Te=null;g.Xa=-1;g.mc=-1;g.Ff=!1;
var If={3:13,12:144,63232:38,63233:40,63234:37,63235:39,63236:112,63237:113,63238:114,63239:115,63240:116,63241:117,63242:118,63243:119,63244:120,63245:121,63246:122,63247:123,63248:44,63272:46,63273:36,63275:35,63276:33,63277:34,63289:144,63302:45},Kf={Up:38,Down:40,Left:37,Right:39,Enter:13,F1:112,F2:113,F3:114,F4:115,F5:116,F6:117,F7:118,F8:119,F9:120,F10:121,F11:122,F12:123,"U+007F":46,Home:36,End:35,PageUp:33,PageDown:34,Insert:45},Lf=v||w&&Pb("525"),Mf=Db&&Ib;g=Gf.prototype;
g.bk=function(a){w&&(17==this.Xa&&!a.ctrlKey||18==this.Xa&&!a.altKey||Db&&91==this.Xa&&!a.metaKey)&&(this.mc=this.Xa=-1);-1==this.Xa&&(a.ctrlKey&&17!=a.keyCode?this.Xa=17:a.altKey&&18!=a.keyCode?this.Xa=18:a.metaKey&&91!=a.keyCode&&(this.Xa=91));Lf&&!Cf(a.keyCode,this.Xa,a.shiftKey,a.ctrlKey,a.altKey)?this.handleEvent(a):(this.mc=Ef(a.keyCode),Mf&&(this.Ff=a.altKey))};g.ck=function(a){this.mc=this.Xa=-1;this.Ff=a.altKey};
g.handleEvent=function(a){var b=a.Tb,c,d,e=b.altKey;v&&"keypress"==a.type?(c=this.mc,d=13!=c&&27!=c?b.keyCode:0):w&&"keypress"==a.type?(c=this.mc,d=0<=b.charCode&&63232>b.charCode&&Df(c)?b.charCode:0):Hb?(c=this.mc,d=Df(c)?b.keyCode:0):(c=b.keyCode||this.mc,d=b.charCode||0,Mf&&(e=this.Ff),Db&&63==d&&224==c&&(c=191));var f=c=Ef(c),h=b.keyIdentifier;c?63232<=c&&c in If?f=If[c]:25==c&&a.shiftKey&&(f=9):h&&h in Kf&&(f=Kf[h]);a=f==this.Xa;this.Xa=f;b=new Nf(f,d,a,b);b.altKey=e;this.dispatchEvent(b)};
g.k=function(){return this.w};function Hf(a,b,c){a.Te&&a.detach();a.w=b;a.Se=Wd(a.w,"keypress",a,c);a.lg=Wd(a.w,"keydown",a.bk,c,a);a.Te=Wd(a.w,"keyup",a.ck,c,a)}g.detach=function(){this.Se&&(ce(this.Se),ce(this.lg),ce(this.Te),this.Te=this.lg=this.Se=null);this.w=null;this.mc=this.Xa=-1};g.ba=function(){Gf.m.ba.call(this);this.detach()};function Nf(a,b,c,d){Qd.call(this,d);this.type="key";this.keyCode=a;this.charCode=b;this.repeat=c}s(Nf,Qd);function N(a,b,c){Ze.call(this,c);if(!b){b=this.constructor;for(var d;b;){d=ia(b);if(d=rf[d])break;b=b.m?b.m.constructor:null}b=d?r(d.hc)?d.hc():new d:null}this.M=b;this.Vk(void 0!==a?a:null)}s(N,Ze);g=N.prototype;g.Rb=null;g.ga=0;g.$=39;g.rj=255;g.Xd=0;g.na=!0;g.Db=null;g.Gd=!0;g.Ef=!1;g.Mk=null;g.ra=function(){return this.M.ra(this)};g.Ee=function(){return this.Fa||(this.Fa=new Gf)};
g.wd=function(a,b){b?a&&(this.Db?Ya(this.Db,a)||this.Db.push(a):this.Db=[a],this.M.wd(this,a,!0)):a&&this.Db&&Za(this.Db,a)&&(0==this.Db.length&&(this.Db=null),this.M.wd(this,a,!1))};g.I=function(){var a=this.M.I(this);this.w=a;Af(this.M,a,this.Ge());this.Ef||this.M.Gg(a,!1);this.A()||this.M.N(a,!1)};g.Ge=function(){return this.Mk};g.sb=function(){return this.M.sb(this.k())};
g.va=function(){N.m.va.call(this);this.M.Jd(this);if(this.$&-2&&(this.Gd&&Of(this,!0),this.$&32)){var a=this.ra();if(a){var b=this.Ee();Hf(b,a);cf(this).H(b,"key",this.ub).H(a,"focus",this.Ie).H(a,"blur",this.Ed)}}};
function Of(a,b){var c=cf(a),d=a.k();b?(c.H(d,"mouseover",a.hg).H(d,"mousedown",a.$c).H(d,"mouseup",a.Hd).H(d,"mouseout",a.gg),a.Fd!=ba&&c.H(d,"contextmenu",a.Fd),v&&c.H(d,"dblclick",a.Zh)):(c.kb(d,"mouseover",a.hg).kb(d,"mousedown",a.$c).kb(d,"mouseup",a.Hd).kb(d,"mouseout",a.gg),a.Fd!=ba&&c.kb(d,"contextmenu",a.Fd),v&&c.kb(d,"dblclick",a.Zh))}g.hb=function(){N.m.hb.call(this);this.Fa&&this.Fa.detach();this.A()&&this.isEnabled()&&this.M.Pc(this,!1)};
g.ba=function(){N.m.ba.call(this);this.Fa&&(this.Fa.i(),delete this.Fa);delete this.M;this.Db=this.Rb=null};g.Vk=function(a){this.Rb=a};g.ag=function(){var a=this.Rb;if(!a)return"";if(!n(a))if(ea(a))a=Wa(a,oc).join("");else{if(Vb&&"innerText"in a)a=a.innerText.replace(/(\r\n|\r|\n)/g,"\n");else{var b=[];pc(a,b,!0);a=b.join("")}a=a.replace(/ \xAD /g," ").replace(/\xAD/g,"");a=a.replace(/\u200B/g,"");Vb||(a=a.replace(/ +/g," "));" "!=a&&(a=a.replace(/^\s*/,""))}return ua(a)};
g.Ud=function(a){N.m.Ud.call(this,a);var b=this.k();b&&this.M.Ud(b,a)};g.Gg=function(a){this.Ef=a;var b=this.k();b&&this.M.Gg(b,a)};g.A=function(){return this.na};g.N=function(a,b){if(b||this.na!=a&&this.dispatchEvent(a?"show":"hide")){var c=this.k();c&&this.M.N(c,a);this.isEnabled()&&this.M.Pc(this,a);this.na=a;return!0}return!1};g.isEnabled=function(){return!(this.ga&1)};
g.Td=function(a){var b=this.getParent();b&&"function"==typeof b.isEnabled&&!b.isEnabled()||!Pf(this,1,!a)||(a||(this.setActive(!1),this.yb(!1)),this.A()&&this.M.Pc(this,a),this.zb(1,!a,!0))};g.yb=function(a){Pf(this,2,a)&&this.zb(2,a)};g.setActive=function(a){Pf(this,4,a)&&this.zb(4,a)};g.Re=function(){return!!(this.ga&8)};g.Wk=function(){Pf(this,8,!0)&&this.zb(8,!0)};function Qf(a,b){Pf(a,16,b)&&a.zb(16,b)}g.Gb=function(){return!!(this.ga&64)};function Rf(a,b){Pf(a,64,b)&&a.zb(64,b)}
g.zb=function(a,b,c){c||1!=a?this.$&a&&b!=!!(this.ga&a)&&(this.M.zb(this,a,b),this.ga=b?this.ga|a:this.ga&~a):this.Td(!b)};g.ab=function(a,b){if(this.G&&this.ga&a&&!b)throw Error("Component already rendered");!b&&this.ga&a&&this.zb(a,!1);this.$=b?this.$|a:this.$&~a};function Sf(a,b){return!!(a.rj&b)&&!!(a.$&b)}function Pf(a,b,c){return!!(a.$&b)&&!!(a.ga&b)!=c&&(!(a.Xd&b)||a.dispatchEvent(af(b,c)))&&!a.vd}
g.hg=function(a){!Tf(a,this.k())&&this.dispatchEvent("enter")&&this.isEnabled()&&Sf(this,2)&&this.yb(!0)};g.gg=function(a){!Tf(a,this.k())&&this.dispatchEvent("leave")&&(Sf(this,4)&&this.setActive(!1),Sf(this,2)&&this.yb(!1))};g.Fd=ba;function Tf(a,b){return!!a.relatedTarget&&jc(b,a.relatedTarget)}g.$c=function(a){this.isEnabled()&&(Sf(this,2)&&this.yb(!0),!Sd(a)||w&&Db&&a.ctrlKey||(Sf(this,4)&&this.setActive(!0),this.M.kc(this)&&this.ra().focus()));this.Ef||!Sd(a)||w&&Db&&a.ctrlKey||a.preventDefault()};
g.Hd=function(a){this.isEnabled()&&(Sf(this,2)&&this.yb(!0),this.ga&4&&this.Od(a)&&Sf(this,4)&&this.setActive(!1))};g.Zh=function(a){this.isEnabled()&&this.Od(a)};g.Od=function(a){Sf(this,16)&&Qf(this,!(this.ga&16));Sf(this,8)&&this.Wk();Sf(this,64)&&Rf(this,!this.Gb());var b=new Kd("action",this);a&&(b.altKey=a.altKey,b.ctrlKey=a.ctrlKey,b.metaKey=a.metaKey,b.shiftKey=a.shiftKey,b.xg=a.xg);return this.dispatchEvent(b)};g.Ie=function(){Sf(this,32)&&Pf(this,32,!0)&&this.zb(32,!0)};
g.Ed=function(){Sf(this,4)&&this.setActive(!1);Sf(this,32)&&Pf(this,32,!1)&&this.zb(32,!1)};g.ub=function(a){return this.A()&&this.isEnabled()&&this.Ec(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};g.Ec=function(a){return 13==a.keyCode&&this.Od(a)};if(!r(N))throw Error("Invalid component class "+N);if(!r(vf))throw Error("Invalid renderer class "+vf);var Uf=ia(N);rf[Uf]=vf;qf("goog-control",function(){return new N(null)});function Vf(){this.vh=[]}s(Vf,vf);ca(Vf);function Wf(a,b){var c=a.vh[b];if(!c){switch(b){case 0:c=a.Da()+"-highlight";break;case 1:c=a.Da()+"-checkbox";break;case 2:c=a.Da()+"-content"}a.vh[b]=c}return c}g=Vf.prototype;g.xe=function(){return"menuitem"};g.I=function(a){var b=a.tb().I("div",this.Ae(a).join(" "),Xf(this,a.Rb,a.tb()));Yf(this,a,b,!!(a.$&8)||!!(a.$&16));return b};g.sb=function(a){return a&&a.firstChild};function Xf(a,b,c){a=Wf(a,2);return c.I("div",a,b)}
g.Li=function(a,b,c){a&&b&&Yf(this,a,b,c)};g.Hg=function(a,b,c){a&&b&&Yf(this,a,b,c)};function Yf(a,b,c,d){Af(a,c,b.Ge());yf(b,c);var e;if(e=a.sb(c)){e=e.firstChild;var f=Wf(a,1);e=!!e&&ha(e)&&1==e.nodeType&&lf(e,f)}else e=!1;d!=e&&(d?mf(c,"goog-option"):of(c,"goog-option"),c=a.sb(c),d?(a=Wf(a,1),c.insertBefore(b.tb().I("div",a),c.firstChild||null)):c.removeChild(c.firstChild))}
g.ze=function(a){switch(a){case 2:return Wf(this,0);case 16:case 8:return"goog-option-selected";default:return Vf.m.ze.call(this,a)}};g.Da=function(){return"goog-menuitem"};function Zf(a,b,c,d){N.call(this,a,d||Vf.hc(),c);this.bb(b)}s(Zf,N);g=Zf.prototype;g.ic=function(){var a=this.Ye;return null!=a?a:this.ag()};g.bb=function(a){this.Ye=a};g.ab=function(a,b){Zf.m.ab.call(this,a,b);switch(a){case 8:this.ga&16&&!b&&Qf(this,!1);var c=this.k();c&&this.M.Li(this,c,b);break;case 16:(c=this.k())&&this.M.Hg(this,c,b)}};g.Li=function(a){this.ab(8,a)};g.Hg=function(a){this.ab(16,a)};
g.ag=function(){var a=this.Rb;return ea(a)?(a=Wa(a,function(a){return ha(a)&&1==a.nodeType&&(lf(a,"goog-menuitem-accel")||lf(a,"goog-menuitem-mnemonic-separator"))?"":oc(a)}).join(""),ua(a)):Zf.m.ag.call(this)};g.Hd=function(a){var b=this.getParent();if(b){var c=b.wi;b.wi=null;if(b=c&&ga(a.clientX))b=new x(a.clientX,a.clientY),b=c==b?!0:c&&b?c.x==b.x&&c.y==b.y:!1;if(b)return}Zf.m.Hd.call(this,a)};g.Ec=function(a){return a.keyCode==this.ni&&this.Od(a)?!0:Zf.m.Ec.call(this,a)};g.Vj=function(){return this.ni};
qf("goog-menuitem",function(){return new Zf(null)});Zf.prototype.Ge=function(){return this.$&16?"menuitemcheckbox":this.$&8?"menuitemradio":Zf.m.Ge.call(this)};Zf.prototype.getParent=function(){return N.prototype.getParent.call(this)};Zf.prototype.Fe=function(){return N.prototype.Fe.call(this)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function $f(a){this.g=a;this.h=H("g",{},null);this.wf=H("path",{"class":"blocklyPathDark",transform:"translate(1, 1)"},this.h);this.Lb=H("path",{"class":"blocklyPath"},this.h);this.xf=H("path",{"class":"blocklyPathLight"},this.h);this.Lb.cb=this.g;ag(this.Lb);bg(this)}$f.prototype.height=0;$f.prototype.width=0;$f.prototype.o=function(){var a=this.g;this.tc();for(var b=0,c;c=a.S[b];b++)c.o();a.wb&&cg(a.wb)};function bg(a){a.g.Ib&&!F?dg(a.h,"blocklyDraggable"):eg(a.h,"blocklyDraggable")}
$f.prototype.wa=function(){return this.h};var fg=7*(1-Math.SQRT1_2)+1,gg=9*(1-Math.SQRT1_2)-1,hg="m "+fg+","+fg,ig="a 9,9 0 0,0 "+(-gg-1)+","+(8-gg),jg="a 9,9 0 0,0 "+(8-gg)+","+(gg+1);g=$f.prototype;g.i=function(){z(this.h);this.g=this.wf=this.xf=this.Lb=this.h=null};function kg(a){var b=(new Date-a.Og)/150;1<b?z(a):(a.setAttribute("transform","translate("+(a.Si+(C?-1:1)*a.oh.width/2*b+", "+(a.Ti+a.oh.height*b))+") scale("+(1-b)+")"),window.setTimeout(function(){kg(a)},10))}
function lg(a){var b=(new Date-a.Og)/150;1<b?z(a):(a.setAttribute("r",25*b),a.style.opacity=1-b,window.setTimeout(function(){lg(a)},10))}
g.tc=function(){if(!this.g.disabled){var a=mg(ng(this.g.Kf)),b,c;c=a;if(!og.test(c))throw Error("'"+c+"' is not a valid hex color");4==c.length&&(c=c.replace(pg,"#$1$1$2$2$3$3"));c=c.toLowerCase();b=[parseInt(c.substr(1,2),16),parseInt(c.substr(3,2),16),parseInt(c.substr(5,2),16)];c=qg([255,255,255],b,.3);b=qg([0,0,0],b,.4);this.xf.setAttribute("stroke",mg(c));this.wf.setAttribute("fill",mg(b));this.Lb.setAttribute("fill",a)}};
function rg(a){a.g.disabled||sg(a.g)?(dg(a.h,"blocklyDisabled"),a.Lb.setAttribute("fill","url(#blocklyDisabledPattern)")):(eg(a.h,"blocklyDisabled"),a.tc());a=a.g.Dc();for(var b=0,c;c=a[b];b++)rg(c.n)}g.Cf=function(){dg(this.h,"blocklySelected");this.h.parentNode.appendChild(this.h)};g.nf=function(){eg(this.h,"blocklySelected")};
g.v=function(){this.g.L=!0;var a=10;C&&(a=-a);for(var b=tg(this.g),c=0;c<b.length;c++){var d=b[c];d.g.isCollapsed()?d.xa.setAttribute("display","none"):(d.xa.setAttribute("display","block"),C&&(a-=16),d.xa.setAttribute("transform","translate("+a+", 5)"),ug(d),a=C?a-10:a+26)}var e=a+=C?10:-10,f=this.g.S,b=[];b.Z=e+20;if(this.g.F||this.g.D)b.Z=Math.max(b.Z,40);for(var d=c=0,h=!1,k=!1,m=!1,p=void 0,q=this.g.Kd&&!this.g.isCollapsed(),u=0,t;t=f[u];u++)if(t.A()){var G;q&&p&&3!=p&&3!=t.type?G=b[b.length-
1]:(p=t.type,G=[],G.type=q&&3!=t.type?-1:t.type,G.height=0,b.push(G));G.push(t);t.Nc=25;t.ya=q&&1==t.type?20.5:0;if(t.p&&t.p.t){var Aa=vg(E(t.p));t.Nc=Math.max(t.Nc,Aa.height);t.ya=Math.max(t.ya,Aa.width)}u==f.length-1&&t.Nc--;G.height=Math.max(G.height,t.Nc);t.rb=0;1==b.length&&(t.rb+=C?-e:e);for(var Aa=!1,Jf=0,ub;ub=t.Ca[Jf];Jf++){0!=Jf&&(t.rb+=10);var mi=ub.Xh();ub.ya=mi.width;ub.of=Aa&&ub.nd?10:0;t.rb+=ub.ya+ub.of;G.height=Math.max(G.height,mi.height);Aa=ub.nd}-1!=G.type&&(3==G.type?(k=!0,d=Math.max(d,
t.rb)):(1==G.type?h=!0:5==G.type&&(m=!0),c=Math.max(c,t.rb)))}for(e=0;G=b[e];e++)if(G.Qi=!1,-1==G.type)for(f=0;t=G[f];f++)if(1==t.type){G.height+=10;G.Qi=!0;break}b.uf=20+d;k&&(b.Z=Math.max(b.Z,b.uf+30));h?b.Z=Math.max(b.Z,c+20+8):m&&(b.Z=Math.max(b.Z,c+20));b.gk=h;b.$l=k;b.Zl=m;d=a;this.g.K?this.Ng=this.tf=!0:(this.Ng=this.tf=!1,this.g.F&&(a=E(this.g.F))&&Yc(a)==this.g&&(this.tf=!0),Yc(this.g)&&(this.Ng=!0));h=D(this.g);k=[];m=[];a=[];c=[];t=b.Z;this.tf?(k.push("m 0,0"),a.push("m 1,1")):(k.push("m 0,8"),
a.push(C?hg:"m 1,7"),k.push("A 8,8 0 0,1 8,0"),a.push("A 7,7 0 0,1 8,1"));this.g.F&&(k.push("H",15),a.push("H",15),k.push("l 6,4 3,0 6,-4"),a.push("l 6.5,4 2,0 6.5,-4"),this.g.F.moveTo(h.x+(C?-30:30),h.y));k.push("H",t);a.push("H",t+(C?-1:0));this.width=t;for(G=t=0;e=b[G];G++){q=10;0==G&&(q+=C?-d:d);a.push("M",b.Z-1+","+(t+1));if(this.g.isCollapsed())f=e[0],u=t+18,wg(f.Ca,q,u),k.push("l 8,0 0,4 8,4 -16,8 8,4"),C?a.push("l 8,0 0,3.8 7,3.2 m -14.5,9 l 8,4"):a.push("h 8"),f=e.height-20,k.push("v",f),
C&&a.push("v",f-2),this.width+=15;else if(-1==e.type){for(p=0;f=e[p];p++)u=t+18,e.Qi&&(u+=5),q=wg(f.Ca,q,u),5!=f.type&&(q+=f.ya+10),1==f.type&&(m.push("M",q-10+","+(t+5)),m.push("h",6-f.ya),m.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),m.push("v",f.Nc+1-20),m.push("h",f.ya+2-8),m.push("z"),C?(c.push("M",q-10-3+8-f.ya+","+(t+5+1)),c.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),c.push("v",f.Nc-20+3),c.push("h",f.ya-8+1)):(c.push("M",q-10+1+","+(t+5+1)),c.push("v",f.Nc+1),c.push("h",
6-f.ya),c.push("M",q-f.ya-10+.8+","+(t+5+20-.4)),c.push("l","3.36,-1.8")),u=C?h.x-q-8+10+f.ya+1:h.x+q+8-10-f.ya-1,Aa=h.y+t+5+1,f.p.moveTo(u,Aa),f.p.t&&xg(f.p));q=Math.max(q,b.Z);this.width=Math.max(this.width,q);k.push("H",q);a.push("H",q+(C?-1:0));k.push("v",e.height);C&&a.push("v",e.height-2)}else 1==e.type?(f=e[0],u=t+18,-1!=f.align&&(p=b.Z-f.rb-8-20,1==f.align?q+=p:0==f.align&&(q+=(p+q)/2)),wg(f.Ca,q,u),k.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),p=e.height-20,k.push("v",p),C?(a.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),
a.push("v",p)):(a.push("M",b.Z-4.2+","+(t+20-.4)),a.push("l","3.36,-1.8")),u=h.x+(C?-b.Z-1:b.Z+1),Aa=h.y+t,f.p.moveTo(u,Aa),f.p.t&&(xg(f.p),this.width=Math.max(this.width,b.Z+vg(E(f.p)).width-8+1))):5==e.type?(f=e[0],u=t+18,-1!=f.align&&(p=b.Z-f.rb-20,b.gk&&(p-=8),1==f.align?q+=p:0==f.align&&(q+=(p+q)/2)),wg(f.Ca,q,u),k.push("v",e.height),C&&a.push("v",e.height-2)):3==e.type&&(f=e[0],0==G&&(k.push("v",10),C&&a.push("v",9),t+=10),u=t+18,-1!=f.align&&(p=b.uf-f.rb-20,1==f.align?q+=p:0==f.align&&(q+=
(p+q)/2)),wg(f.Ca,q,u),q=b.uf+30,k.push("H",q),k.push("l -6,4 -3,0 -6,-4 h -7 a 8,8 0 0,0 -8,8"),k.push("v",e.height-16),k.push("a 8,8 0 0,0 8,8"),k.push("H",b.Z),C?(a.push("M",q-30+gg+","+(t+gg)),a.push(ig),a.push("v",e.height-16),a.push("a 9,9 0 0,0 9,9"),a.push("H",b.Z-1)):(a.push("M",q-30+gg+","+(t+e.height-gg)),a.push(jg),a.push("H",b.Z)),u=h.x+(C?-q:q),Aa=h.y+t+1,f.p.moveTo(u,Aa),f.p.t&&(xg(f.p),this.width=Math.max(this.width,b.uf+vg(E(f.p)).width)),G==b.length-1||3==b[G+1].type)&&(k.push("v",
10),C&&a.push("v",9),t+=10);t+=e.height}b.length||(t=25,k.push("V",t),C&&a.push("V",t-1));b=t;this.height=b+1;this.g.D&&(k.push("H","30 l -6,4 -3,0 -6,-4"),this.g.D.moveTo(C?h.x-30:h.x+30,h.y+b+1),this.g.D.t&&xg(this.g.D),this.height+=4);this.Ng?(k.push("H 0"),C||a.push("M","1,"+b)):(k.push("H",8),k.push("a","8,8 0 0,1 -8,-8"),C||(a.push("M",fg+","+(b-fg)),a.push("A","7,7 0 0,1 1,"+(b-8))));this.g.K?(this.g.K.moveTo(h.x,h.y),k.push("V",20),k.push("c 0,-10 -8,8 -8,-7.5 s 8,2.5 8,-7.5"),C?(a.push("M",
"-2.4,8.9"),a.push("l","-3.6,-2.1")):(a.push("V",19),a.push("m","-7.36,-1 q -1.52,-5.5 0,-11"),a.push("m","7.36,1 V 1 H 2")),this.width+=8):C||(this.tf?a.push("V",1):a.push("V",8));k.push("z");b=k.join(" ")+"\n"+m.join(" ");this.Lb.setAttribute("d",b);this.wf.setAttribute("d",b);b=a.join(" ")+"\n"+c.join(" ");this.xf.setAttribute("d",b);C&&(this.Lb.setAttribute("transform","scale(-1 1)"),this.xf.setAttribute("transform","scale(-1 1)"),this.wf.setAttribute("transform","translate(1,1) scale(-1 1)"));
(b=this.g.getParent())?b.v():De(window,"resize")};function wg(a,b,c){C&&(b=-b);for(var d=0,e;e=a[d];d++)C?(b-=e.of+e.ya,e.wa().setAttribute("transform","translate("+b+", "+c+")"),e.ya&&(b-=10)):(e.wa().setAttribute("transform","translate("+(b+e.of)+", "+c+")"),e.ya&&(b+=e.of+e.ya+10));return C?-b:b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function yg(a){this.j=null;this.Qa=H("g",{},null);this.wc=H("rect",{rx:4,ry:4,x:-5,y:-12,height:16},this.Qa);this.ma=H("text",{"class":"blocklyText"},this.Qa);this.hd={height:25,width:0};this.T(a);this.na=!0}g=yg.prototype;g.clone=function(){Ma("There should never be an instance of Field, only its derived classes.")};g.nd=!0;g.o=function(a){if(this.j)throw"Field has already been initialized once.";this.j=a;this.Zb();O(a).appendChild(this.Qa);this.rg=K(this.Qa,"mouseup",this,this.vg);this.T(null)};
g.i=function(){this.rg&&(J(this.rg),this.rg=null);this.j=null;z(this.Qa);this.wc=this.ma=this.Qa=null};g.Zb=function(){this.nd&&(this.j.fc&&!F?(dg(this.Qa,"blocklyEditableText"),eg(this.Qa,"blocklyNoNEditableText"),this.Qa.style.cursor=this.Zg):(dg(this.Qa,"blocklyNonEditableText"),eg(this.Qa,"blocklyEditableText"),this.Qa.style.cursor=""))};g.A=function(){return this.na};g.N=function(a){this.na=a;this.wa().style.display=a?"block":"none";this.Rd()};g.wa=function(){return this.Qa};
g.Rd=function(){try{var a=this.ma.getComputedTextLength()}catch(b){a=8*this.ma.childNodes[0].length}this.wc&&this.wc.setAttribute("width",a+10);this.hd.width=a};g.Xh=function(){this.hd.width||this.Rd();return this.hd};g.Ea=function(){return this.Ma};g.T=function(a){null!==a&&a!==this.Ma&&(this.Ma=a,zg(this),this.j&&this.j.L&&(this.j.v(),this.j.Pa(),re(this.j.u)))};
function zg(a){var b=a.Ma;hc(a.ma);b=b.replace(/\s/g,"\u00a0");C&&b&&(b+="\u200f");b||(b="\u00a0");a.ma.appendChild(document.createTextNode(b));a.hd.width=0}g.ic=function(){return this.Ea()};g.bb=function(a){this.T(a)};g.vg=function(a){if(!Fb&&!Gb||0===a.layerX||0===a.layerY)vd(a)||2!=Be&&this.j.fc&&!F&&this.sf()};g.B=function(){};function Ag(a){this.nh=a}ca(Ag);g=Ag.prototype;g.xe=function(){return this.nh};function Bg(a,b){a&&(a.tabIndex=b?0:-1)}g.I=function(a){return a.tb().I("div",this.Ae(a).join(" "))};g.sb=function(a){return a};g.Jd=function(a){a=a.k();Se(a,!0,Ib);v&&(a.hideFocus=!0);var b=this.xe();b&&tf(a,b)};g.ra=function(a){return a.k()};g.Da=function(){return"goog-container"};g.Ae=function(a){var b=this.Da(),c=[b,a.dd==Cg?b+"-horizontal":b+"-vertical"];a.isEnabled()||c.push(b+"-disabled");return c};function Dg(){}s(Dg,vf);ca(Dg);Dg.prototype.I=function(a){return a.tb().I("div",this.Da())};Dg.prototype.Da=function(){return"goog-menuseparator"};function Eg(a,b){N.call(this,null,a||Dg.hc(),b);this.ab(1,!1);this.ab(2,!1);this.ab(4,!1);this.ab(32,!1);this.ga=1}s(Eg,N);Eg.prototype.va=function(){Eg.m.va.call(this);var a=this.k();tf(a,"separator")};qf("goog-menuseparator",function(){return new Eg});function Fg(a){this.nh=a||"menu"}s(Fg,Ag);ca(Fg);Fg.prototype.Da=function(){return"goog-menu"};Fg.prototype.Jd=function(a){Fg.m.Jd.call(this,a);a=a.k();uf(a,"haspopup","true")};qf("goog-menuseparator",function(){return new Eg});function Gg(a,b,c){Ze.call(this,c);this.M=b||Ag.hc();this.dd=a||Hg}s(Gg,Ze);var Cg="horizontal",Hg="vertical";g=Gg.prototype;g.ng=null;g.Fa=null;g.M=null;g.dd=null;g.na=!0;g.Ac=!0;g.Zf=!0;g.R=-1;g.ea=null;g.cd=!1;g.mj=!1;g.Kk=!0;g.Pb=null;g.ra=function(){return this.ng||this.M.ra(this)};g.Ee=function(){return this.Fa||(this.Fa=new Gf(this.ra()))};g.I=function(){this.w=this.M.I(this)};g.sb=function(){return this.M.sb(this.k())};
g.va=function(){Gg.m.va.call(this);ef(this,function(a){a.G&&Ig(this,a)},this);var a=this.k();this.M.Jd(this);this.N(this.na,!0);cf(this).H(this,"enter",this.eg).H(this,"highlight",this.ak).H(this,"unhighlight",this.fk).H(this,"open",this.dk).H(this,"close",this.Yj).H(a,"mousedown",this.$c).H($b(a),"mouseup",this.Zj).H(a,["mousedown","mouseup","mouseover","mouseout","contextmenu"],this.Xj);this.kc()&&Jg(this,!0)};
function Jg(a,b){var c=cf(a),d=a.ra();b?c.H(d,"focus",a.Ie).H(d,"blur",a.Ed).H(a.Ee(),"key",a.ub):c.kb(d,"focus",a.Ie).kb(d,"blur",a.Ed).kb(a.Ee(),"key",a.ub)}g.hb=function(){this.gd(-1);this.ea&&Rf(this.ea,!1);this.cd=!1;Gg.m.hb.call(this)};g.ba=function(){Gg.m.ba.call(this);this.Fa&&(this.Fa.i(),this.Fa=null);this.M=this.ea=this.Pb=this.ng=null};g.eg=function(){return!0};
g.ak=function(a){var b=jf(this,a.target);if(-1<b&&b!=this.R){var c=M(this,this.R);c&&c.yb(!1);this.R=b;c=M(this,this.R);this.cd&&c.setActive(!0);this.Kk&&this.ea&&c!=this.ea&&(c.$&64?Rf(c,!0):Rf(this.ea,!1))}b=this.k();null!=a.target.k()&&uf(b,"activedescendant",a.target.k().id)};g.fk=function(a){a.target==M(this,this.R)&&(this.R=-1);this.k().removeAttribute("aria-activedescendant")};g.dk=function(a){(a=a.target)&&a!=this.ea&&a.getParent()==this&&(this.ea&&Rf(this.ea,!1),this.ea=a)};
g.Yj=function(a){a.target==this.ea&&(this.ea=null)};g.$c=function(a){this.Ac&&(this.cd=!0);var b=this.ra();b&&mc(b)&&nc(b)?b.focus():a.preventDefault()};g.Zj=function(){this.cd=!1};g.Xj=function(a){var b=Kg(this,a.target);if(b)switch(a.type){case "mousedown":b.$c(a);break;case "mouseup":b.Hd(a);break;case "mouseover":b.hg(a);break;case "mouseout":b.gg(a);break;case "contextmenu":b.Fd(a)}};
function Kg(a,b){if(a.Pb)for(var c=a.k();b&&b!==c;){var d=b.id;if(d in a.Pb)return a.Pb[d];b=b.parentNode}return null}g.Ie=function(){};g.Ed=function(){this.gd(-1);this.cd=!1;this.ea&&Rf(this.ea,!1)};g.ub=function(a){return this.isEnabled()&&this.A()&&(0!=ff(this)||this.ng)&&this.Ec(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};
g.Ec=function(a){var b=M(this,this.R);if(b&&"function"==typeof b.ub&&b.ub(a)||this.ea&&this.ea!=b&&"function"==typeof this.ea.ub&&this.ea.ub(a))return!0;if(a.shiftKey||a.ctrlKey||a.metaKey||a.altKey)return!1;switch(a.keyCode){case 27:if(this.kc())this.ra().blur();else return!1;break;case 36:Lg(this);break;case 35:Mg(this);break;case 38:if(this.dd==Hg)Ng(this);else return!1;break;case 37:if(this.dd==Cg)gf(this)?Og(this):Ng(this);else return!1;break;case 40:if(this.dd==Hg)Og(this);else return!1;break;
case 39:if(this.dd==Cg)gf(this)?Ng(this):Og(this);else return!1;break;default:return!1}return!0};function Ig(a,b){var c=b.k(),c=c.id||(c.id=bf(b));a.Pb||(a.Pb={});a.Pb[c]=b}g.me=function(a,b){Gg.m.me.call(this,a,b)};
g.Uc=function(a,b,c){a.Xd|=2;a.Xd|=64;!this.kc()&&this.mj||a.ab(32,!1);a.G&&0!=a.Gd&&Of(a,!1);a.Gd=!1;var d=a.getParent()==this?jf(this,a):-1;Gg.m.Uc.call(this,a,b,c);a.G&&this.G&&Ig(this,a);a=d;-1==a&&(a=ff(this));a==this.R?this.R=Math.min(ff(this)-1,b):a>this.R&&b<=this.R?this.R++:a<this.R&&b>this.R&&this.R--};
g.removeChild=function(a,b){if(a=n(a)?df(this,a):a){var c=jf(this,a);-1!=c&&(c==this.R?(a.yb(!1),this.R=-1):c<this.R&&this.R--);var d=a.k();d&&d.id&&this.Pb&&(c=this.Pb,d=d.id,d in c&&delete c[d])}c=a=Gg.m.removeChild.call(this,a,b);c.G&&1!=c.Gd&&Of(c,!0);c.Gd=!0;return a};g.A=function(){return this.na};
g.N=function(a,b){if(b||this.na!=a&&this.dispatchEvent(a?"show":"hide")){this.na=a;var c=this.k();c&&(Qe(c,a),this.kc()&&Bg(this.ra(),this.Ac&&this.na),b||this.dispatchEvent(this.na?"aftershow":"afterhide"));return!0}return!1};g.isEnabled=function(){return this.Ac};
g.Td=function(a){this.Ac!=a&&this.dispatchEvent(a?"enable":"disable")&&(a?(this.Ac=!0,ef(this,function(a){a.Wi?delete a.Wi:a.Td(!0)})):(ef(this,function(a){a.isEnabled()?a.Td(!1):a.Wi=!0}),this.cd=this.Ac=!1),this.kc()&&Bg(this.ra(),a&&this.na))};g.kc=function(){return this.Zf};g.Pc=function(a){a!=this.Zf&&this.G&&Jg(this,a);this.Zf=a;this.Ac&&this.na&&Bg(this.ra(),a)};g.gd=function(a){(a=M(this,a))?a.yb(!0):-1<this.R&&M(this,this.R).yb(!1)};g.yb=function(a){this.gd(jf(this,a))};
function Lg(a){Pg(a,function(a,c){return(a+1)%c},ff(a)-1)}function Mg(a){Pg(a,function(a,c){a--;return 0>a?c-1:a},0)}function Og(a){Pg(a,function(a,c){return(a+1)%c},a.R)}function Ng(a){Pg(a,function(a,c){a--;return 0>a?c-1:a},a.R)}function Pg(a,b,c){c=0>c?jf(a,a.ea):c;var d=ff(a);c=b.call(a,c,d);for(var e=0;e<=d;){var f=M(a,c);if(f&&a.sh(f)){a.gd(c);break}e++;c=b.call(a,c,d)}}g.sh=function(a){return a.A()&&a.isEnabled()&&!!(a.$&2)};function Qg(){}s(Qg,vf);ca(Qg);Qg.prototype.Da=function(){return"goog-menuheader"};function Rg(a,b,c){N.call(this,a,c||Qg.hc(),b);this.ab(1,!1);this.ab(2,!1);this.ab(4,!1);this.ab(32,!1);this.ga=1}s(Rg,N);qf("goog-menuheader",function(){return new Rg(null)});function Sg(a,b){Gg.call(this,Hg,b||Fg.hc(),a);this.Pc(!1)}s(Sg,Gg);g=Sg.prototype;g.Df=!0;g.nj=!1;g.Da=function(){return this.M.Da()};g.removeItem=function(a){(a=this.removeChild(a,!0))&&a.i()};function Tg(a){a.Df=!0;a.Pc(!0)}g.N=function(a,b,c){(b=Sg.m.N.call(this,a,b))&&a&&this.G&&this.Df&&this.ra().focus();this.wi=a&&c&&ga(c.clientX)?new x(c.clientX,c.clientY):null;return b};g.eg=function(a){this.Df&&this.ra().focus();return Sg.m.eg.call(this,a)};
g.sh=function(a){return(this.nj||a.isEnabled())&&a.A()&&!!(a.$&2)};g.Ec=function(a){var b=Sg.m.Ec.call(this,a);b||ef(this,function(c){!b&&c.Vj&&c.ni==a.keyCode&&(this.isEnabled()&&this.yb(c),b=c.ub(a))},this);return b};
g.gd=function(a){Sg.m.gd.call(this,a);if(a=M(this,a)){var b=a.k();a=this.k();var c=Me(b),d=Me(a),e=Ve(a),f=c.x-d.x-e.left,c=c.y-d.y-e.top,d=a.clientHeight-b.offsetHeight,e=a.scrollLeft,h=a.scrollTop,e=e+Math.min(f,Math.max(f-(a.clientWidth-b.offsetWidth),0)),h=h+Math.min(c,Math.max(c-d,0)),b=new x(e,h);a.scrollLeft=b.x;a.scrollTop=b.y}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function P(a,b){this.bd=a;this.Ia=b;Ug(this);var c=Vg(this)[0];this.Na=c[1];this.ne=H("tspan",{},null);this.ne.appendChild(document.createTextNode(C?Wg+" ":" "+Wg));P.m.constructor.call(this,c[0])}s(P,yg);var Wg=Eb?"\u25bc":"\u25be";g=P.prototype;g.clone=function(){return new P(this.bd,this.Ia)};g.Zg="default";
g.sf=function(){Xg(this,null);for(var a=this,b=new Sg,c=Vg(this),d=0;d<c.length;d++){var e=c[d][1],f=new Zf(c[d][0]);f.bb(e);f.Hg(!0);b.me(f,!0);Qf(f,e==this.Na)}Wd(b,"action",function(b){if(b=b.target){b=b.ic();if(a.Ia){var c=a.Ia(b);void 0!==c&&(b=c)}null!==b&&a.bb(b)}Yg==a&&Zg()});cf(b).H(b.k(),"touchstart",function(a){Kg(this,a.target).$c(a)});cf(b).H(b.k(),"touchend",function(a){Kg(this,a.target).Od(a)});c=cc();d=Je();e=$g(this.wc);f=this.wc.getBBox();b.v(ah);var h=b.k();dg(h,"blocklyDropdownMenu");
var k=Ne(h);e.y=e.y+k.height+f.height>=c.height+d.y?e.y-k.height:e.y+f.height;C?(e.x+=f.width,e.x+=25,e.x<d.x+k.width&&(e.x=d.x+k.width)):(e.x-=25,e.x>c.width+d.x-k.width&&(e.x=c.width+d.x-k.width));bh(e.x,e.y,c,d);Tg(b);h.focus()};
function Ug(a){a.yg=null;a.Sg=null;var b=a.bd;if(ea(b)&&!(2>b.length)){var c=b.map(function(a){return a[0]}),d=ch(c),e=dh(c,d),f=eh(c,d);if((e||f)&&!(d<=e+f)){e&&(a.yg=c[0].substring(0,e-1));f&&(a.Sg=c[0].substr(1-f));c=[];for(d=0;d<b.length;d++){var h=b[d][0],k=b[d][1],h=h.substring(e,h.length-f);c[d]=[h,k]}a.bd=c}}}function Vg(a){return r(a.bd)?a.bd.call(a):a.bd}g.ic=function(){return this.Na};g.bb=function(a){this.Na=a;for(var b=Vg(this),c=0;c<b.length;c++)if(b[c][1]==a){this.T(b[c][0]);return}this.T(a)};
g.T=function(a){this.j&&(this.ne.style.fill=mg(ng(this.j.Kf)));null!==a&&a!==this.Ma&&(this.Ma=a,zg(this),C?this.ma.insertBefore(this.ne,this.ma.firstChild):this.ma.appendChild(this.ne),this.j&&this.j.L&&(this.j.v(),this.j.Pa(),re(this.j.u)))};g.i=function(){Yg==this&&Zg();P.m.i.call(this)};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function fh(a,b){a.innerHTML=pb(b)};function gh(a,b,c){Ze.call(this,c);this.ua=b||hh;this.ig=a instanceof nb?a:rb(a,null)}s(gh,Ze);var ih={};g=gh.prototype;g.Fg=!1;g.xd=!1;g.il=null;g.lj=yb;g.Ld=!0;g.te=-1;g.ba=function(){gh.m.ba.call(this);this.Tc&&(this.Tc.removeNode(this),this.Tc=null);this.w=null};
g.Pe=function(){var a=this.k();if(a){var b=jh(this);b&&!b.id&&(b.id=bf(this)+".label");tf(a,"treeitem");uf(a,"selected",!1);uf(a,"expanded",!1);uf(a,"level",this.Yc());b&&uf(a,"labelledby",b.id);(a=this.De())&&tf(a,"presentation");(a=this.Ce())&&tf(a,"presentation");if(a=kh(this))if(tf(a,"group"),a.hasChildNodes())for(a=ff(this),b=1;b<=a;b++){var c=M(this,b-1).k();uf(c,"setsize",a);uf(c,"posinset",b)}}};
g.I=function(){var a=this.tb(),b=pb(this.Ug());var c=a.Sb,a=c.createElement("div");v?(a.innerHTML="<br>"+b,a.removeChild(a.firstChild)):a.innerHTML=b;if(1==a.childNodes.length)b=a.removeChild(a.firstChild);else for(b=c.createDocumentFragment();a.firstChild;)b.appendChild(a.firstChild);this.w=b};g.va=function(){gh.m.va.call(this);ih[bf(this)]=this;this.Pe()};g.hb=function(){gh.m.hb.call(this);delete ih[bf(this)]};
g.Uc=function(a,b){var c=M(this,b-1),d=M(this,b);gh.m.Uc.call(this,a,b);a.Kc=c;a.xb=d;c?c.xb=a:this.Vh=a;d?d.Kc=a:this.ji=a;var e=this.Ja();e&&lh(a,e);mh(a,this.Yc()+1);if(this.k()&&(this.ld(),this.Ra())){e=kh(this);a.k()||a.I();var f=a.k(),h=d&&d.k();e.insertBefore(f,h);this.G&&a.va();d||(c?c.ld():(Qe(e,!0),this.Yb(this.Ra())))}};g.add=function(a,b){a.getParent()&&a.getParent().removeChild(a);this.Uc(a,b?jf(this,b):ff(this));return a};
g.removeChild=function(a){var b=this.Ja(),c=b?b.Za:null;if(c==a||a.contains(c))b.hasFocus()?(this.select(),ie(this.Ik,10,this)):this.select();gh.m.removeChild.call(this,a);this.ji==a&&(this.ji=a.Kc);this.Vh==a&&(this.Vh=a.xb);a.Kc&&(a.Kc.xb=a.xb);a.xb&&(a.xb.Kc=a.Kc);c=!a.xb;a.Tc=null;a.te=-1;if(b&&(b.removeNode(this),this.G)){b=kh(this);if(a.G){var d=a.k();b.removeChild(d);a.hb()}c&&(c=M(this,ff(this)-1))&&c.ld();hf(this)||(b.style.display="none",this.ld(),this.De().className=this.ye())}return a};
g.remove=gh.prototype.removeChild;g.Ik=function(){this.select()};g.Yc=function(){var a=this.te;0>a&&(a=(a=this.getParent())?a.Yc()+1:0,mh(this,a));return a};function mh(a,b){if(b!=a.te){a.te=b;var c=nh(a);if(c){var d=oh(a)+"px";gf(a)?c.style.paddingRight=d:c.style.paddingLeft=d}ef(a,function(a){mh(a,b+1)})}}g.contains=function(a){for(;a;){if(a==this)return!0;a=a.getParent()}return!1};g.Dc=function(){var a=[];ef(this,function(b){a.push(b)});return a};g.Re=function(){return this.Fg};
g.select=function(){var a=this.Ja();a&&a.Qc(this)};function ph(a,b){if(a.Fg!=b){a.Fg=b;qh(a);var c=a.k();c&&(uf(c,"selected",b),b&&(c=a.Ja().k(),uf(c,"activedescendant",bf(a))))}}g.Ra=function(){return this.xd};
g.Yb=function(a){var b=a!=this.xd;if(!b||this.dispatchEvent(a?"beforeexpand":"beforecollapse")){var c;this.xd=a;c=this.Ja();var d=this.k();if(hf(this)){if(!a&&c&&this.contains(c.Za)&&this.select(),d){if(c=kh(this))if(Qe(c,a),a&&this.G&&!c.hasChildNodes()){var e=[];ef(this,function(a){e.push(a.Ug())});fh(c,xb(e));ef(this,function(a){a.va()})}this.ld()}}else(c=kh(this))&&Qe(c,!1);d&&(this.De().className=this.ye(),uf(d,"expanded",a));b&&this.dispatchEvent(a?"expand":"collapse")}};g.toggle=function(){this.Yb(!this.Ra())};
g.expand=function(){this.Yb(!0)};g.collapse=function(){this.Yb(!1)};g.Dg=function(){var a=this.getParent();a&&(a.Yb(!0),a.Dg())};g.Ug=function(){var a=this.Ja(),b=!a.Vd||a==this.getParent()&&!a.Lg?this.ua.yh:this.ua.xh,a=this.Ra()&&hf(this),b={"class":b,style:rh(this)},c=[];a&&ef(this,function(a){c.push(a.Ug())});a=wb("div",b,c);return wb("div",{"class":this.ua.Gh,id:bf(this)},[sh(this),a])};function oh(a){return Math.max(0,(a.Yc()-1)*a.ua.kg)}
function sh(a){var b={};b["padding-"+(gf(a)?"right":"left")]=oh(a)+"px";var b={"class":a.Cd(),style:b},c=a.bg(),d=wb("span",{style:{display:"inline-block"},"class":a.ye()}),e=wb("span",{"class":a.ua.Hh,title:a.il||null},a.ig);a=xb(e,wb("span",{},a.lj));return wb("div",b,[c,d,a])}g.Cd=function(){return this.ua.Kh+(this.Re()?" "+this.ua.Jh:"")};g.bg=function(){return wb("span",{type:"expand",style:{display:"inline-block"},"class":th(this)})};
function th(a){var b=a.Ja(),c=!b.Vd||b==a.getParent()&&!b.Lg,d=a.ua,e=new qa;e.append(d.zc," ",d.Bj," ");if(hf(a)){var f=0;b.Kg&&a.Ld&&(f=a.Ra()?2:1);c||(f=a.xb?f+8:f+4);switch(f){case 1:e.append(d.Fj);break;case 2:e.append(d.Ej);break;case 4:e.append(d.Ch);break;case 5:e.append(d.Dj);break;case 6:e.append(d.Cj);break;case 8:e.append(d.Dh);break;case 9:e.append(d.Hj);break;case 10:e.append(d.Gj);break;default:e.append(d.Bh)}}else c?e.append(d.Bh):a.xb?e.append(d.Dh):e.append(d.Ch);return e.toString()}
function rh(a){var b=a.Ra()&&hf(a);return gb({"background-position":uh(a),display:b?null:"none"})}function uh(a){return(a.xb?(a.Yc()-1)*a.ua.kg:"-100")+"px 0"}g.k=function(){var a=gh.m.k.call(this);a||(this.w=a=this.tb().k(bf(this)));return a};function nh(a){return(a=a.k())?a.firstChild:null}g.Ce=function(){var a=nh(this);return a?a.firstChild:null};g.De=function(){var a=nh(this);return a?a.childNodes[1]:null};function jh(a){return(a=nh(a))&&a.lastChild?a.lastChild.previousSibling:null}
function kh(a){return(a=a.k())?a.lastChild:null}g.T=function(a){this.ig=a=qb(a);var b=jh(this);b&&fh(b,a);(a=this.Ja())&&vh(a,this)};g.Ea=function(){var a=pb(this.ig);return Ja(a,"&")?"document"in l?Ga(a):Ia(a):a};function qh(a){var b=nh(a);b&&(b.className=a.Cd())}g.ld=function(){var a=this.Ce();a&&(a.className=th(this));if(a=kh(this))a.style.backgroundPosition=uh(this)};g.tg=function(a){"expand"==a.target.getAttribute("type")&&hf(this)?this.Ld&&this.toggle():(this.select(),qh(this))};
g.pi=function(a){"expand"==a.target.getAttribute("type")&&hf(this)||this.Ld&&this.toggle()};function wh(a){return a.Ra()&&hf(a)?wh(M(a,ff(a)-1)):a}function lh(a,b){a.Tc!=b&&(a.Tc=b,vh(b,a),ef(a,function(a){lh(a,b)}))}
var hh={kg:19,Ih:"goog-tree-root goog-tree-item",Fh:"goog-tree-hide-root",Gh:"goog-tree-item",xh:"goog-tree-children",yh:"goog-tree-children-nolines",Kh:"goog-tree-row",Hh:"goog-tree-item-label",zc:"goog-tree-icon",Bj:"goog-tree-expand-icon",Fj:"goog-tree-expand-icon-plus",Ej:"goog-tree-expand-icon-minus",Hj:"goog-tree-expand-icon-tplus",Gj:"goog-tree-expand-icon-tminus",Dj:"goog-tree-expand-icon-lplus",Cj:"goog-tree-expand-icon-lminus",Dh:"goog-tree-expand-icon-t",Ch:"goog-tree-expand-icon-l",Bh:"goog-tree-expand-icon-blank",
Nf:"goog-tree-expanded-folder-icon",zh:"goog-tree-collapsed-folder-icon",Of:"goog-tree-file-icon",Eh:"goog-tree-expanded-folder-icon",Ah:"goog-tree-collapsed-folder-icon",Jh:"selected"};function xh(a,b,c){gh.call(this,a,b,c)}s(xh,gh);xh.prototype.Ja=function(){if(this.Tc)return this.Tc;var a=this.getParent();return a&&(a=a.Ja())?(lh(this,a),a):null};xh.prototype.ye=function(){var a=this.Ra(),b=this.Qj;if(a&&b)return b;b=this.hk;if(!a&&b)return b;b=this.ua;if(hf(this)){if(a&&b.Nf)return b.zc+" "+b.Nf;if(!a&&b.zh)return b.zc+" "+b.zh}else if(b.Of)return b.zc+" "+b.Of;return""};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var yh={se:null,show:function(a,b){Xg(yh,null);if(b.length){for(var c=new Sg,d=0,e;e=b[d];d++){var f=new Zf(e.text);c.me(f,!0);f.Td(e.enabled);e.enabled&&Wd(f,"action",function(a){return function(){a()}}(e.pb))}Wd(c,"action",yh.Vb);e=cc();f=Je();c.v(ah);var h=c.k();dg(h,"blocklyContextMenu");var k=Ne(h),d=a.clientX+f.x,m=a.clientY+f.y;a.clientY+k.height>=e.height&&(m-=k.height);C?k.width>=a.clientX&&(d+=k.width):a.clientX+k.width>=e.width&&(d-=k.width);bh(d,m,e,f);Tg(c);setTimeout(function(){h.focus()},
1);yh.se=null}else yh.Vb()},Vb:function(){Yg==yh&&Zg();yh.se=null},Rl:function(a,b){return function(){var c=bd(a.u,b),d=D(a);d.x=C?d.x-zh:d.x+zh;d.y+=2*zh;c.moveBy(d.x,d.y);c.select()}}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ah(a,b,c,d,e,f,h){var k=Bh;C&&(k=-k);this.pj=k/360*Math.PI*2;this.s=a;this.Rb=b;this.Mi=c;a.jd.appendChild(this.Lf(b,!(!f||!h)));Ch(this,d,e);f&&h||(a=this.Rb.getBBox(),f=a.width+2*Dh,h=a.height+2*Dh);this.rc(f,h);Eh(this);Fh(this);this.Cg=!0;F||(K(this.oe,"mousedown",this,this.tj),this.Wb&&K(this.Wb,"mousedown",this,this.Sk))}var Dh=6,Bh=20,Gh=null,Hh=null;function Ih(){Gh&&(J(Gh),Gh=null);Hh&&(J(Hh),Hh=null)}g=Ah.prototype;g.Cg=!1;g.mb=0;g.Gf=0;g.Mc=0;g.Qd=0;g.O=0;g.ib=0;g.If=!0;
g.Lf=function(a,b){this.ob=H("g",{},null);var c=H("g",{filter:"url(#blocklyEmboss)"},this.ob);this.ph=H("path",{},c);this.oe=H("rect",{"class":"blocklyDraggable",x:0,y:0,rx:Dh,ry:Dh},c);b?(this.Wb=H("g",{"class":C?"blocklyResizeSW":"blocklyResizeSE"},this.ob),c=2*Dh,H("polygon",{points:"0,x x,x x,0".replace(/x/g,c.toString())},this.Wb),H("line",{"class":"blocklyResizeLine",x1:c/3,y1:c-1,x2:c-1,y2:c/3},this.Wb),H("line",{"class":"blocklyResizeLine",x1:2*c/3,y1:c-1,x2:c-1,y2:2*c/3},this.Wb)):this.Wb=
null;this.ob.appendChild(a);return this.ob};g.tj=function(a){Jh(this);Ih();vd(a)||Kh(a)||(Lh(!0),this.Rh=C?this.Mc+a.clientX:this.Mc-a.clientX,this.Oj=this.Qd-a.clientY,Gh=K(document,"mouseup",this,Ih),Hh=K(document,"mousemove",this,this.uj),zd(),a.stopPropagation())};g.uj=function(a){this.If=!1;this.Mc=C?this.Rh-a.clientX:this.Rh+a.clientX;this.Qd=this.Oj+a.clientY;Eh(this);Fh(this)};
g.Sk=function(a){Jh(this);Ih();vd(a)||(Lh(!0),this.Rk=C?this.O+a.clientX:this.O-a.clientX,this.Qk=this.ib-a.clientY,Gh=K(document,"mouseup",this,Ih),Hh=K(document,"mousemove",this,this.Tk),zd(),a.stopPropagation())};g.Tk=function(a){this.If=!1;var b=this.Rk,c=this.Qk+a.clientY,b=C?b-a.clientX:b+a.clientX;this.rc(b,c);C&&Eh(this)};function Jh(a){a.ob.parentNode.appendChild(a.ob)}function Ch(a,b,c){a.mb=b;a.Gf=c;a.Cg&&Eh(a)}
function Eh(a){a.ob.setAttribute("transform","translate("+(C?a.mb-a.Mc-a.O:a.mb+a.Mc)+", "+(a.Qd+a.Gf)+")")}g.Cc=function(){return{width:this.O,height:this.ib}};
g.rc=function(a,b){var c=2*Dh;a=Math.max(a,c+45);b=Math.max(b,c+18);this.O=a;this.ib=b;this.oe.setAttribute("width",a);this.oe.setAttribute("height",b);this.Wb&&(C?this.Wb.setAttribute("transform","translate("+2*Dh+", "+(b-c)+") scale(-1 1)"):this.Wb.setAttribute("transform","translate("+(a-c)+", "+(b-c)+")"));if(this.Cg){if(this.If){var c=-this.O/4,d=-this.ib-25,e=this.s.Ub();C?this.mb-e.Oa-c-this.O<I?c=this.mb-e.Oa-this.O-I:this.mb-e.Oa-c>e.V&&(c=this.mb-e.Oa-e.V):this.mb+c<e.Oa?c=e.Oa-this.mb:
e.Oa+e.V<this.mb+c+this.O+10+I&&(c=e.Oa+e.V-this.mb-this.O-I);this.Gf+d<e.Mb&&(d=this.Mi.getBBox().height);this.Mc=c;this.Qd=d}Eh(this);Fh(this)}De(this.ob,"resize")};
function Fh(a){var b=[],c=a.O/2,d=a.ib/2,e=-a.Mc,f=-a.Qd;if(c==e&&d==f)b.push("M "+c+","+d);else{f-=d;e-=c;C&&(e*=-1);var h=Math.sqrt(f*f+e*e),k=Math.acos(e/h);0>f&&(k=2*Math.PI-k);var m=k+Math.PI/2;m>2*Math.PI&&(m-=2*Math.PI);var p=Math.sin(m),q=Math.cos(m),u=a.Cc(),m=(u.width+u.height)/10,m=Math.min(m,u.width,u.height)/2,u=1-8/h,e=c+u*e,f=d+u*f,u=c+m*q,t=d+m*p,c=c-m*q,d=d-m*p,p=k+a.pj;p>2*Math.PI&&(p-=2*Math.PI);k=Math.sin(p)*h/4;h=Math.cos(p)*h/4;b.push("M"+u+","+t);b.push("C"+(u+h)+","+(t+k)+
" "+e+","+f+" "+e+","+f);b.push("C"+e+","+f+" "+(c+h)+","+(d+k)+" "+c+","+d)}b.push("z");a.ph.setAttribute("d",b.join(" "))}g.C=function(a){this.oe.setAttribute("fill",a);this.ph.setAttribute("fill",a)};g.i=function(){Ih();z(this.ob);this.Mi=this.Rb=this.s=this.ob=null};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Mh(a){this.g=a}g=Mh.prototype;g.W=null;g.Fc=0;g.Gc=0;g.yc=function(){this.xa=H("g",{},null);O(this.g).appendChild(this.xa);K(this.xa,"mouseup",this,this.jg);this.Zb()};g.i=function(){z(this.xa);this.xa=null;this.N(!1);this.g=null};g.Zb=function(){this.g.lc?eg(this.xa,"blocklyIconGroup"):dg(this.xa,"blocklyIconGroup")};g.A=function(){return!!this.W};g.jg=function(){this.g.lc||this.N(!this.A())};g.tc=function(){if(this.A()){var a=mg(ng(this.g.Kf));this.W.C(a)}};
function ug(a){var b=D(a.g),c=Nh(a.xa),d=b.x+c.x+8,b=b.y+c.y+8;if(d!==a.Fc||b!==a.Gc)a.Fc=d,a.Gc=b,a.A()&&Ch(a.W,d,b)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Oh(a){Oh.m.constructor.call(this,null);this.zi=[];for(var b=0;b<a.length;b++){var c=dc("block",{type:a[b]});this.zi[b]=c}}s(Oh,Mh);g=Oh.prototype;g.md=0;g.ee=0;function cg(a){Mh.prototype.yc.call(a);H("rect",{"class":"blocklyIconShield",width:16,height:16,rx:4,ry:4},a.xa);a.Id=H("text",{"class":"blocklyIconMark",x:8,y:12},a.xa);a.Id.appendChild(document.createTextNode("\u2605"))}g.jg=function(a){this.g.fc&&!F&&Mh.prototype.jg.call(this,a)};
g.Mf=function(){this.Sc=H("svg",{x:Dh,y:Dh},null);H("rect",{"class":"blocklyMutatorBackground",height:"100%",width:"100%"},this.Sc);var a=this;this.s=new pe(function(){var b=0;C&&(b+=a.md);return{za:a.ee,V:0,gb:0,fb:b}},null);this.qa=new Ph;this.qa.sd=!1;this.Sc.appendChild(this.qa.I());this.Sc.appendChild(this.s.I());return this.Sc};g.Zb=function(){this.g.fc&&!F?Mh.prototype.Zb.call(this):(this.N(!1),eg(this.xa,"blocklyIconGroup"))};
g.pf=function(){var a=2*Dh,b=this.s.Q.getBBox(),c=Qh(this.qa),d;d=C?-b.x:b.width+b.x;b=Math.max(b.height+3*a,c.Va+20);d+=3*a;if(Math.abs(this.md-d)>a||Math.abs(this.ee-b)>a)this.md=d,this.ee=b,this.W.rc(d+a,b+a),this.Sc.setAttribute("width",this.md),this.Sc.setAttribute("height",this.ee);C&&this.s.Q.setAttribute("transform","translate("+this.md+",0)")};
g.N=function(a){if(a!=this.A())if(a){this.W=new Ah(this.g.u,this.Mf(),this.g.n.Lb,this.Fc,this.Gc,null,null);var b=this;this.qa.o(this.s);this.qa.show(this.zi);this.Xb=this.g.Jj(this.s);a=Rh(this.Xb);for(var c=0,d;d=a[c];c++)d.v();this.Xb.Ib=!1;hd(this.Xb,!1);a=2*this.qa.sa;c=this.qa.O+a;C&&(c=-c);this.Xb.moveBy(c,a);this.g.Eg&&(this.g.Eg(this.Xb),this.Mg=K(this.g.u.Q,"blocklyWorkspaceChange",this.g,function(){b.g.Eg(b.Xb)}));this.pf();K(this.s.Q,"blocklyWorkspaceChange",this.g,function(){if(0==Be)for(var a=
Wc(b.s,!1),c=0,d;d=a[c];c++){var k=D(d),m=vg(d);d.ec&&!F&&(C?k.x>-b.qa.O+20:k.x<b.qa.O-20)?d.i(!1,!0):20>k.y+m.height&&d.moveBy(0,20-m.height-k.y)}b.Xb.u==b.s&&(a=b.g.L,b.g.L=!1,b.g.xj(b.Xb),b.g.L=a,b.g.L&&b.g.v(),b.pf(),re(b.g.u))});this.tc()}else this.Sc=null,this.qa.i(),this.qa=null,this.s.i(),this.Xb=this.s=null,this.W.i(),this.W=null,this.ee=this.md=0,this.Mg&&(J(this.Mg),this.Mg=null)};g.i=function(){this.g.wb=null;Mh.prototype.i.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Sh(a,b){this.j=a;this.t=null;this.type=b;this.U=this.Ab=0;this.Fb=!1;this.dc=this.j.u.zj}g=Sh.prototype;g.i=function(){if(this.t)throw"Disconnect connection before disposing of it.";this.Fb&&Th(this.dc[this.type],this);this.Fb=!1;Uh==this&&(Uh=null);Vh==this&&(Vh=null)};function Wh(a){return 1==a.type||3==a.type}
function md(a,b){if(a.j==b.j)throw"Attempted to connect a block to itself.";if(a.j.u!==b.j.u)throw"Blocks are on different workspaces.";if(Xh[a.type]!=b.type)throw"Attempt to connect incompatible types.";if(1==a.type||2==a.type){if(a.t)throw"Source connection already connected (value).";if(b.t){var c=E(b);c.$a(null);if(!c.K)throw"Orphan block does not have an output connection.";for(var d=a.j;d=Yh(d,c);)if(E(d))d=E(d);else{md(d,c.K);c=null;break}c&&window.setTimeout(function(){Zh(c.K,b)},$h)}}else{if(a.t)throw"Source connection already connected (block).";
if(b.t){if(4!=a.type)throw"Can only do a mid-stack connection with the top of a block.";c=E(b);c.$a(null);if(!c.F)throw"Orphan block does not have a previous connection.";for(d=a.j;d.D;)if(d.D.t)d=Yc(d);else{ai(c.F,d.D)&&(md(d.D,c.F),c=null);break}c&&window.setTimeout(function(){Zh(c.F,b)},$h)}}var e;Wh(a)?(d=a.j,e=b.j):(d=b.j,e=a.j);a.t=b;b.t=a;e.$a(d);d.L&&rg(d.n);e.L&&rg(e.n);d.L&&e.L&&(3==a.type||4==a.type?e.v():d.v())}
function Yh(a,b){for(var c=!1,d=0;d<a.S.length;d++){var e=a.S[d].p;if(e&&1==e.type&&ai(b.K,e)){if(c)return null;c=e}}return c}g.disconnect=function(){var a=this.t;if(!a)throw"Source connection not connected.";if(a.t!=this)throw"Target connection not connected to source connection.";this.t=a.t=null;var b;Wh(this)?(b=this.j,a=a.j):(b=a.j,a=this.j);b.L&&b.v();a.L&&(rg(a.n),a.v())};function E(a){return a.t?a.t.j:null}
function Zh(a,b){if(0==Be){var c=bi(a.j);if(!c.lc){var d=!1;if(!c.Ib||F){c=bi(b.j);if(!c.Ib||F)return;b=a;d=!0}O(c).parentNode.appendChild(O(c));var e=b.Ab+zh-a.Ab,f=b.U+zh-a.U;d&&(f=-f);C&&(e=-e);c.moveBy(e,f)}}}g.moveTo=function(a,b){this.Fb&&Th(this.dc[this.type],this);this.Ab=a;this.U=b;ci(this.dc[this.type],this)};g.moveBy=function(a,b){this.moveTo(this.Ab+a,this.U+b)};
g.Ke=function(){var a;1==this.type||2==this.type?(a=C?-8:8,a="m 0,0 v 5 c 0,10 "+-a+",-8 "+-a+",7.5 s "+a+",-2.5 "+a+",7.5 v 5"):a=C?"m 20,0 h -5 l -6,4 -3,0 -6,-4 h -5":"m -20,0 h 5 l 6,4 3,0 6,-4 h 5";var b=D(this.j);Sh.Le=H("path",{"class":"blocklyHighlightedConnectionPath",d:a,transform:"translate("+(this.Ab-b.x)+", "+(this.U-b.y)+")"},O(this.j))};
function xg(a){var b=Math.round(a.t.Ab-a.Ab),c=Math.round(a.t.U-a.U);if(0!=b||0!=c){a=E(a);var d=O(a);if(!d)throw"block is not rendered.";d=Nh(d);O(a).setAttribute("transform","translate("+(d.x-b)+", "+(d.y-c)+")");di(a,-b,-c)}}
function ei(a,b,c,d){function e(a){var c=f[a];if((2==c.type||4==c.type)&&c.t||1==c.type&&c.t&&(!E(c).Ib||F)||!ai(u,c))return!0;c=c.j;do{if(q==c)return!0;c=c.getParent()}while(c);var d=h-f[a].Ab,c=k-f[a].U,d=Math.sqrt(d*d+c*c);d<=b&&(p=f[a],b=d);return c<b}if(a.t)return{p:null,Ai:b};var f=a.dc[Xh[a.type]],h=a.Ab+c,k=a.U+d;c=0;for(var m=d=f.length-2;c<m;)f[m].U<k?c=m:d=m,m=Math.floor((c+d)/2);d=c=m;var p=null,q=a.j,u=a;if(f.length){for(;0<=c&&e(c);)c--;do d++;while(d<f.length&&e(d))}return{p:p,Ai:b}}
function ai(a,b){if(!a.Vc||!b.Vc)return!0;for(var c=0;c<a.Vc.length;c++)if(-1!=b.Vc.indexOf(a.Vc[c]))return!0;return!1}g.P=function(a){a?(ea(a)||(a=[a]),this.Vc=a,this.t&&!ai(this,this.t)&&(Wh(this)?E(this).$a(null):this.j.$a(null),this.j.Pa())):this.Vc=null;return this};
function fi(a){var b=zh;function c(a){var c=e-d[a].Ab,h=f-d[a].U;Math.sqrt(c*c+h*h)<=b&&m.push(d[a]);return h<b}var d=a.dc[Xh[a.type]],e=a.Ab,f=a.U;a=0;for(var h=d.length-2,k=h;a<k;)d[k].U<f?a=k:h=k,k=Math.floor((a+h)/2);var h=a=k,m=[];if(d.length){for(;0<=a&&c(a);)a--;do h++;while(h<d.length&&c(h))}return m}
function gi(a){a.Fb||ci(a.dc[a.type],a);var b=[];if(1!=a.type&&3!=a.type)return b;if(a=E(a)){var c;a.isCollapsed()?(c=[],a.K&&c.push(a.K),a.D&&c.push(a.D),a.F&&c.push(a.F)):c=hi(a,!0);for(var d=0;d<c.length;d++)b.push.apply(b,gi(c[d]));0==b.length&&(b[0]=a)}return b}function qe(){}qe.prototype=[];function ci(a,b){if(b.Fb)throw"Connection already in database.";for(var c=0,d=a.length;c<d;){var e=Math.floor((c+d)/2);if(a[e].U<b.U)c=e+1;else if(a[e].U>b.U)d=e;else{c=e;break}}a.splice(c,0,b);b.Fb=!0}
function Th(a,b){if(!b.Fb)throw"Connection not in database.";b.Fb=!1;for(var c=0,d=a.length-2,e=d;c<e;)a[e].U<b.U?c=e:d=e,e=Math.floor((c+d)/2);for(d=c=e;0<=c&&a[c].U==b.U;){if(a[c]==b){a.splice(c,1);return}c--}do{if(a[d]==b){a.splice(d,1);return}d++}while(d<a.length&&a[d].U==b.U);throw"Unable to find connection in connectionDB.";};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var R={Ml:function(a){var b={o:function(){var b=this;this.C(a.Sl);this.J=a.J;"string"==typeof a.cb?this.B(a.cb):"function"==typeof a.cb&&this.B(function(){return a.cb(b)});"undefined"!=a.Lk?Q(this,a.Lk):(ii(this,"undefined"==typeof a.Nk?!0:a.Nk),ji(this,"undefined"==typeof a.Ak?!0:a.Ak));var d=[];d.push(a.text);a.oj&&a.oj.forEach(function(a){"undefined"==a.type||1==a.type?d.push([a.name,a.check,"undefined"==typeof a.align?1:a.align]):Ma("addTemplate() can only handle value inputs.")});d.push(1);a.lk&&
this.om(a.lk);ki.prototype.vb.apply(this,d)}};b.Ze=a.qm?function(){var b=a.xk?a.dm():document.createElement("mutation");b.setAttribute("is_statement",this.isStatement||!1);return b}:a.xk;R[a.Ql]=b}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function li(a){li.m.constructor.call(this,a);this.yc()}s(li,Mh);g=li.prototype;g.Ma="";g.O=160;g.ib=80;g.yc=function(){Mh.prototype.yc.call(this);H("circle",{"class":"blocklyIconShield",r:8,cx:8,cy:8},this.xa);this.Id=H("text",{"class":"blocklyIconMark",x:8,y:13},this.xa);this.Id.appendChild(document.createTextNode("?"))};
g.Mf=function(){this.zd=H("foreignObject",{x:Dh,y:Dh},null);var a=document.createElementNS("http://www.w3.org/1999/xhtml","body");a.setAttribute("xmlns","http://www.w3.org/1999/xhtml");a.className="blocklyMinimalBody";this.Ta=document.createElementNS("http://www.w3.org/1999/xhtml","textarea");this.Ta.className="blocklyCommentTextarea";this.Ta.setAttribute("dir",C?"RTL":"LTR");a.appendChild(this.Ta);this.zd.appendChild(a);K(this.Ta,"mouseup",this,this.hl);return this.zd};
g.Zb=function(){this.A()&&(this.N(!1),this.N(!0));Mh.prototype.Zb.call(this)};g.pf=function(){var a=this.W.Cc(),b=2*Dh;this.zd.setAttribute("width",a.width-b);this.zd.setAttribute("height",a.height-b);this.Ta.style.width=a.width-b-4+"px";this.Ta.style.height=a.height-b-4+"px"};
g.N=function(a){if(a!=this.A())if((!this.g.fc||F)&&!this.Ta||v)ni.prototype.N.call(this,a);else{var b=this.Ea(),c=this.Cc();a?(this.W=new Ah(this.g.u,this.Mf(),this.g.n.Lb,this.Fc,this.Gc,this.O,this.ib),K(this.W.ob,"resize",this,this.pf),this.tc(),this.Ma=null):(this.W.i(),this.zd=this.Ta=this.W=null);this.T(b);this.rc(c.width,c.height)}};g.hl=function(){Jh(this.W);this.Ta.focus()};g.Cc=function(){return this.A()?this.W.Cc():{width:this.O,height:this.ib}};
g.rc=function(a,b){this.Ta?this.W.rc(a,b):(this.O=a,this.ib=b)};g.Ea=function(){return this.Ta?this.Ta.value:this.Ma};g.T=function(a){this.Ta?this.Ta.value=a:this.Ma=a};g.i=function(){this.g.ta=null;Mh.prototype.i.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var oi=!1,pi=0,qi=0,ri={x:0,y:0},si=null,ti=null,ui=null,vi=null,wi=null,xi=null;function yi(){var a=H("g",{"class":"blocklyHidden"},null);ui=a;xi=H("rect",{"class":"blocklyTooltipShadow",x:2,y:2},a);wi=H("rect",{"class":"blocklyTooltipBackground"},a);vi=H("text",{"class":"blocklyTooltipText"},a);return a}function ag(a){K(a,"mouseover",null,zi);K(a,"mouseout",null,Ai);K(a,"mousemove",null,Bi)}
function zi(a){for(a=a.target;!n(a.cb)&&!r(a.cb);)a=a.cb;si!=a&&(Ci(),ti=null,si=a);window.clearTimeout(pi)}function Ai(){pi=window.setTimeout(function(){ti=si=null;Ci()},1);window.clearTimeout(qi)}function Bi(a){si&&si.cb&&0==Be&&!Yg&&(oi?(a=wd(a),10<Math.sqrt(Math.pow(ri.x-a.x,2)+Math.pow(ri.y-a.y,2))&&Ci()):ti!=si&&(window.clearTimeout(qi),ri=wd(a),qi=window.setTimeout(Di,1E3)))}function Ci(){oi&&(oi=!1,ui&&(ui.style.display="none"));window.clearTimeout(qi)}
function Di(){ti=si;if(ui){hc(vi);var a=si.cb;r(a)&&(a=a());var b=a,a=50;if(b.length<=a)a=b;else{for(var c=b.trim().split(/\s+/),d=0;d<c.length;d++)c[d].length>a&&(a=c[d].length);var e,d=-Infinity,f,h=1;do{e=d;f=b;for(var b=[],k=c.length/h,m=1,d=0;d<c.length-1;d++)m<(d+1.5)/k?(m++,b[d]=!0):b[d]=!1;for(var b=Ei(c,b,a),d=Fi(c,b,a),k=c,m=[],p=0;p<k.length;p++)m.push(k[p]),void 0!==b[p]&&m.push(b[p]?"\n":" ");b=m.join("");h++}while(d>e);a=f}a=a.split("\n");for(c=0;c<a.length;c++)H("tspan",{dy:"1em",x:5},
vi).appendChild(document.createTextNode(a[c]));oi=!0;ui.style.display="block";a=vi.getBBox();c=10+a.width;e=a.height;wi.setAttribute("width",c);wi.setAttribute("height",e);xi.setAttribute("width",c);xi.setAttribute("height",e);if(C)for(e=a.width,f=0;h=vi.childNodes[f];f++)h.setAttribute("text-anchor","end"),h.setAttribute("x",e+5);e=ri.x;e=C?e-(0+c):e+0;c=ri.y+10;f=Gi();c+a.height>f.height&&(c-=a.height+20);C?e=Math.max(5,e):e+a.width>f.width-10&&(e=f.width-a.width-10);ui.setAttribute("transform",
"translate("+e+","+c+")")}}function Fi(a,b,c){for(var d=[0],e=[],f=0;f<a.length;f++)d[d.length-1]+=a[f].length,!0===b[f]?(d.push(0),e.push(a[f].charAt(a[f].length-1))):!1===b[f]&&d[d.length-1]++;a=Math.max.apply(Math,d);for(f=b=0;f<d.length;f++)b-=2*Math.pow(Math.abs(c-d[f]),1.5),b-=Math.pow(a-d[f],1.5),-1!=".?!".indexOf(e[f])?b+=c/3:-1!=",;)]}".indexOf(e[f])&&(b+=c/4);1<d.length&&d[d.length-1]<=d[d.length-2]&&(b+=.5);return b}
function Ei(a,b,c){for(var d=Fi(a,b,c),e,f=0;f<b.length-1;f++)if(b[f]!=b[f+1]){var h=[].concat(b);h[f]=!h[f];h[f+1]=!h[f+1];var k=Fi(a,h,c);k>d&&(d=k,e=h)}return e?Ei(a,e,c):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Hi(a){this.j=null;this.ma=H("text",{"class":"blocklyText"},null);this.hd={height:25,width:0};this.T(a)}s(Hi,yg);g=Hi.prototype;g.clone=function(){return new Hi(this.Ea())};g.nd=!1;g.o=function(a){if(this.j)throw"Text has already been initialized once.";this.j=a;O(a).appendChild(this.ma);this.ma.cb=this.j;ag(this.ma)};g.i=function(){z(this.ma);this.ma=null};g.wa=function(){return this.ma};g.B=function(a){this.ma.cb=a};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ii(a,b,c,d){this.type=a;this.name=b;this.j=c;this.p=d;this.Ca=[];this.align=-1;this.na=!0}function S(a,b,c){if(!b&&!c)return a;n(b)&&(b=new Hi(b));a.j.n&&b.o(a.j);b.name=c;b.yg&&S(a,b.yg);a.Ca.push(b);b.Sg&&S(a,b.Sg);a.j.L&&(a.j.v(),a.j.Pa());return a}g=Ii.prototype;g.A=function(){return this.na};
g.N=function(a){var b=[];if(this.na==a)return b;for(var c=(this.na=a)?"block":"none",d=0,e;e=this.Ca[d];d++)e.N(a);if(this.p){if(a)b=gi(this.p);else if(d=this.p,d.Fb&&Th(d.dc[d.type],d),d.t){e=Rh(E(d));for(var f=0;f<e.length;f++){for(var h=e[f],k=hi(h,!0),m=0;m<k.length;m++){var p=k[m];p.Fb&&Th(d.dc[p.type],p)}h=tg(h);for(k=0;k<h.length;k++)h[k].N(!1)}}if(d=E(this.p))d.n.wa().style.display=c,a||(d.L=!1)}return b};
g.P=function(a){if(!this.p)throw"This input does not have a connection.";this.p.P(a);return this};function Ji(a,b){a.align=b;a.j.L&&a.j.v();return a}g.o=function(){for(var a=0;a<this.Ca.length;a++)this.Ca[a].o(this.j)};g.i=function(){for(var a=0,b;b=this.Ca[a];a++)b.i();this.p&&this.p.i();this.j=null};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ni(a){ni.m.constructor.call(this,a);this.yc()}s(ni,Mh);g=ni.prototype;g.Ma="";g.yc=function(){Mh.prototype.yc.call(this);H("path",{"class":"blocklyIconShield",d:"M 2,15 Q -1,15 0.5,12 L 6.5,1.7 Q 8,-1 9.5,1.7 L 15.5,12 Q 17,15 14,15 z"},this.xa);this.Id=H("text",{"class":"blocklyIconMark",x:8,y:13},this.xa);this.Id.appendChild(document.createTextNode("!"))};
g.N=function(a){if(a!=this.A())if(a){var b=this.Ma;a=H("text",{"class":"blocklyText blocklyBubbleText",y:Dh},null);for(var b=b.split("\n"),c=0;c<b.length;c++)H("tspan",{dy:"1em",x:Dh},a).appendChild(document.createTextNode(b[c]));this.W=new Ah(this.g.u,a,this.g.n.Lb,this.Fc,this.Gc,null,null);if(C)for(var b=a.getBBox().width,c=0,d;d=a.childNodes[c];c++)d.setAttribute("text-anchor","end"),d.setAttribute("x",b+Dh);this.tc();a=this.W.Cc();this.W.rc(a.width,a.height)}else this.W.i(),this.W=null};
g.T=function(a){this.Ma!=a&&(this.Ma=a,this.A()&&(this.N(!1),this.N(!0)))};g.i=function(){this.g.ce=null;Mh.prototype.i.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Ki=0;function ki(){}function dd(a,b){if(ue)return Li.create(ki,a,b);var c=new ki;c.initialize(a,b);return c}g=ki.prototype;g.initialize=function(a,b){var c=(++Ki).toString();this.id=ue?Mi(c):c;te(a,this);this.fill(a,b);r(this.onchange)&&K(a.Q,"blocklyWorkspaceChange",this,this.onchange)};
g.fill=function(a,b){this.F=this.D=this.K=null;this.S=[];this.disabled=this.L=this.Kd=!1;this.cb="";this.contextMenu=!0;this.ed=null;this.Bb=[];this.fc=this.Ib=this.ec=!0;this.xc=!1;this.u=a;this.lc=a.ii;if(b){this.type=b;var c=R[b],d;for(d in c)this[d]=c[d]}r(this.o)&&this.o()};function cd(a,b){return ue?Ni.get(a):ye(b,a)}g.n=null;g.wb=null;g.ta=null;g.ce=null;function tg(a){var b=[];a.wb&&b.push(a.wb);a.ta&&b.push(a.ta);a.ce&&b.push(a.ce);return b}
function ed(a){a.n=new $f(a);a.n.o();F||K(a.n.wa(),"mousedown",a,a.cf);a.u.Q.appendChild(a.n.wa())}function O(a){return a.n&&a.n.wa()}var Be=0,Oi=null,Pi=null;g=ki.prototype;g.select=function(){L&&Ce();L=this;this.n.Cf();De(this.u.Q,"blocklySelectChange")};function Ce(){var a=L;L=null;a.n.nf();De(a.u.Q,"blocklySelectChange")}
g.i=function(a,b,c){this.L=!1;var d;d=!1;if(this.K)this.K.t&&this.$a(null);else{var e=null;this.F&&this.F.t&&(e=this.F.t,this.$a(null));var f=Yc(this);a&&f&&(a=this.D.t,f.$a(null),e&&md(e,a))}d&&this.moveBy(zh*(C?-1:1),2*zh);b&&this.n&&(d=this.n,Qi("delete"),b=xd(d.h),d=d.h.cloneNode(!0),d.Si=b.x,d.Ti=b.y,d.setAttribute("transform","translate("+d.Si+","+d.Ti+")"),Gc.appendChild(d),d.oh=d.getBBox(),d.Og=new Date,kg(d));this.u&&!c&&(we(this.u,this),this.u=null);L==this&&(L=null,Ri());yh.se==this&&yh.Vb();
for(c=this.Bb.length-1;0<=c;c--)this.Bb[c].i(!1);b=tg(this);for(c=0;c<b.length;c++)b[c].i();for(c=0;b=this.S[c];c++)b.i();this.S=[];b=hi(this,!0);for(c=0;c<b.length;c++)d=b[c],d.t&&d.disconnect(),b[c].i();this.n&&(this.n.i(),this.n=null);if(ue&&!Si)Ni["delete"](this.id.toString())};function D(a){var b=0,c=0;if(a.n){var d=a.n.wa();do var e=Nh(d),b=b+e.x,c=c+e.y,d=d.parentNode;while(d&&d!=a.u.Q)}return{x:b,y:c}}
g.moveBy=function(a,b){var c=D(this);this.n.wa().setAttribute("transform","translate("+(c.x+a)+", "+(c.y+b)+")");di(this,a,b);Ti(this)};function vg(a){var b=a.n.height,c=a.n.width;if(a=Yc(a))a=vg(a),b+=a.height-4,c=Math.max(c,a.width);return{height:b,width:c}}
g.cf=function(a){if(!this.lc){Ui();Ri();this.select();zd();if(vd(a))Vi(this,a);else if(this.Ib&&!F){yd();Lh(!0);var b=D(this);this.Oi=b.x;this.Pi=b.y;this.Pg=a.clientX;this.Qg=a.clientY;Be=1;Oi=K(document,"mouseup",this,this.vg);Pi=K(document,"mousemove",this,this.ug);this.we=[];for(var b=Rh(this),c=0,d;d=b[c];c++){d=tg(d);for(var e=0;e<d.length;e++){var f;f=d[e];f={x:f.Fc,y:f.Gc};f.sj=d[e];this.we.push(f)}}}else return;a.stopPropagation()}};
g.vg=function(){var a=this;Wi(function(){Ri();if(L&&Uh){md(Vh,Uh);if(a.n){var b=(Wh(Vh)?Uh:Vh).j.n;Qi("click");var c=xd(b.h);b.g.K?(c.x+=C?3:-3,c.y+=13):b.g.F&&(c.x+=C?-23:23,c.y+=3);b=H("circle",{cx:c.x,cy:c.y,r:0,fill:"none",stroke:"#888","stroke-width":10},Gc);b.Og=new Date;lg(b)}a.u.Ua&&a.u.Ua.Gb&&a.u.Ua.close()}else a.u.Ua&&a.u.Ua.Gb&&(b=a.u.Ua,ie(b.close,100,b),L.i(!1,!0),De(window,"resize"));Uh&&(z(Sh.Le),delete Sh.Le,Uh=null)})};
function Vi(a,b){if(!F&&a.contextMenu){var c=[];if(a.ec&&!F&&a.Ib&&!F&&!a.lc){var d={text:Xi,enabled:!0,pb:function(){var b=Xc(a);nd(b);var b=bd(a.u,b),c=D(a);c.x=C?c.x-zh:c.x+zh;c.y+=2*zh;b.moveBy(c.x,c.y);b.select()}};Rh(a).length>Ee(a.u)&&(d.enabled=!1);c.push(d);a.fc&&!F&&!a.xc&&Hc&&(d={enabled:!0},a.ta?(d.text=Yi,d.pb=function(){jd(a,null)}):(d.text=Zi,d.pb=function(){jd(a,"")}),c.push(d));if(!a.xc)for(d=0;d<a.S.length;d++)if(1==a.S[d].type){d={enabled:!0};d.text=a.Kd?$i:aj;d.pb=function(){fd(a,
!a.Kd)};c.push(d);break}Ic&&(a.xc?(d={enabled:!0},d.text=bj,d.pb=function(){a.Sd(!1)}):(d={enabled:!0},d.text=cj,d.pb=function(){a.Sd(!0)}),c.push(d));Jc&&(d={text:a.disabled?dj:ej,enabled:!sg(a),pb:function(){gd(a,!a.disabled)}},c.push(d));var d=Rh(a).length,e=Yc(a);e&&(d-=Rh(e).length);d={text:1==d?fj:gj.replace("%1",String(d)),enabled:!0,pb:function(){a.i(!0,!0)}};c.push(d)}d={enabled:!(r(a.J)?!a.J():!a.J)};d.text=hj;d.pb=function(){var b=r(a.J)?a.J():a.J;b&&window.open(b)};c.push(d);a.Ij&&!a.lc&&
a.Ij(c);yh.show(b,c);yh.se=a}}function hi(a,b){var c=[];if(b||a.L)if(a.K&&c.push(a.K),a.D&&c.push(a.D),a.F&&c.push(a.F),b||!a.xc)for(var d=0,e;e=a.S[d];d++)e.p&&c.push(e.p);return c}function di(a,b,c){if(a.L){for(var d=hi(a,!1),e=0;e<d.length;e++)d[e].moveBy(b,c);d=tg(a);for(e=0;e<d.length;e++)ug(d[e]);for(e=0;e<a.Bb.length;e++)di(a.Bb[e],b,c)}}function ij(a,b){b?dg(a.n.h,"blocklyDragging"):eg(a.n.h,"blocklyDragging");for(var c=0;c<a.Bb.length;c++)ij(a.Bb[c],b)}
g.ug=function(a){var b=this;Wi(function(){if(!("mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button)){yd();var c=a.clientX-b.Pg,d=a.clientY-b.Qg;1==Be&&Math.sqrt(Math.pow(c,2)+Math.pow(d,2))>jj&&(Be=2,b.$a(null),ij(b,!0));if(2==Be){b.n.wa().setAttribute("transform","translate("+(b.Oi+c)+", "+(b.Pi+d)+")");for(var e=0;e<b.we.length;e++){var f=b.we[e],h=f.sj,k=f.x+c,f=f.y+d;h.Fc=k;h.Gc=f;h.A()&&Ch(h.W,k,f)}for(var h=hi(b,!1),f=k=null,m=zh,e=0;e<h.length;e++){var p=h[e],q=ei(p,m,c,d);q.p&&(k=
q.p,f=p,m=q.Ai)}Uh&&Uh!=k&&(z(Sh.Le),delete Sh.Le,Vh=Uh=null);k&&k!=Uh&&(k.Ke(),Uh=k,Vh=f);b.u.Ua&&b.ec&&!F&&b.u.Ua.df(a)}}a.stopPropagation()})};g.Pa=function(){if(0==Be){var a=bi(this);if(!a.lc)for(var b=hi(this,!1),c=0;c<b.length;c++){var d=b[c];d.t&&Wh(d)&&E(d).Pa();for(var e=fi(d),f=0;f<e.length;f++){var h=e[f];d.t&&h.t||bi(h.j)!=a&&(Wh(d)?Zh(h,d):Zh(d,h))}}}};g.getParent=function(){return this.ed};function Yc(a){return a.D&&E(a.D)}function bi(a){var b=a;do a=b,b=a.ed;while(b);return a}
g.Dc=function(){return this.Bb};
g.$a=function(a){if(this.ed){for(var b=this.ed.Bb,c,d=0;c=b[d];d++)if(c==this){b.splice(d,1);break}b=D(this);this.u.Q.appendChild(this.n.wa());this.n.wa().setAttribute("transform","translate("+b.x+", "+b.y+")");this.ed=null;this.F&&this.F.t&&this.F.disconnect();this.K&&this.K.t&&this.K.disconnect()}else Ya(Wc(this.u,!1),this)&&we(this.u,this);(this.ed=a)?(a.Bb.push(this),b=D(this),a.n&&this.n&&a.n.wa().appendChild(this.n.wa()),a=D(this),di(this,a.x-b.x,a.y-b.y)):te(this.u,this)};
function Rh(a){for(var b=[a],c,d=0;c=a.Bb[d];d++)b.push.apply(b,Rh(c));return b}function hd(a,b){a.ec=b;a.n&&bg(a.n)}function id(a,b){a.fc=b;for(var c=0,d;d=a.S[c];c++)for(var e=0,f;f=d.Ca[e];e++)f.Zb();d=tg(a);for(c=0;c<d.length;c++)d[c].Zb()}g.C=function(a){this.Kf=a;this.n&&this.n.tc();var b=tg(this);for(a=0;a<b.length;a++)b[a].tc();if(this.L){for(a=0;b=this.S[a];a++)for(var c=0,d;d=b.Ca[c];c++)d.T(null);this.v()}};
function kd(a,b){for(var c=0,d;d=a.S[c];c++)for(var e=0,f;f=d.Ca[e];e++)if(f.name===b)return f;return null}function T(a,b){var c=kd(a,b);return c?c.ic():null}g.B=function(a){this.cb=a};function ii(a,b){var c;a.F&&(a.F.i(),a.F=null);b&&(void 0===c&&(c=null),a.F=new Sh(a,4),a.F.P(c));a.L&&(a.v(),a.Pa())}function ji(a,b){var c;a.D&&(a.D.i(),a.D=null);b&&(void 0===c&&(c=null),a.D=new Sh(a,3),a.D.P(c));a.L&&(a.v(),a.Pa())}
function Q(a,b){a.K&&(a.K.i(),a.K=null);void 0===b&&(b=null);a.K=new Sh(a,2);a.K.P(b);a.L&&(a.v(),a.Pa())}function fd(a,b){a.Kd=b;a.L&&(a.v(),a.Pa(),re(a.u))}function gd(a,b){a.disabled!=b&&(a.disabled=b,rg(a.n),re(a.u))}function sg(a){for(;;){a:for(;;){do{var b=a;a=a.getParent();if(!a){a=null;break a}}while(Yc(a)==b);break a}if(!a)return!1;if(a.disabled)return!0}}g.isCollapsed=function(){return this.xc};
g.Sd=function(a){if(this.xc!=a){this.xc=a;for(var b=[],c=0,d;d=this.S[c];c++)b.push.apply(b,d.N(!a));if(a){a=tg(this);for(c=0;c<a.length;c++)a[c].N(!1);c=this.toString(kj);S(lj(this,"_TEMP_COLLAPSED_INPUT"),c)}else mj(this,"_TEMP_COLLAPSED_INPUT");b.length||(b[0]=this);if(this.L){for(c=0;a=b[c];c++)a.v();this.Pa()}}};
g.toString=function(a){for(var b=[],c=0,d;d=this.S[c];c++){for(var e=0,f;f=d.Ca[e];e++)b.push(f.Ea());d.p&&((d=E(d.p))?b.push(d.toString()):b.push("?"))}b=va(b.join(" "))||"???";a&&b.length>a&&(b=b.substring(0,a-3)+"...");return b};function U(a,b){return nj(a,1,b)}function lj(a,b){return nj(a,5,b||"")}
g.vb=function(a,b){function c(a){a instanceof yg?S(this,a):S(this,a[1],a[0])}var d=arguments[arguments.length-1];--arguments.length;for(var e=a.split(this.vb.ij),f=[],h=0;h<e.length;h+=2){var k=va(e[h]),m=void 0;k&&f.push(new Hi(k));if((k=e[h+1])&&"%"==k.charAt(0)){var k=parseInt(k.substring(1),10),p=arguments[k];p[1]instanceof yg?f.push([p[0],p[1]]):m=Ji(U(this,p[0]).P(p[1]),p[2]);arguments[k]=null}else"\n"==k&&f.length&&(m=lj(this));m&&f.length&&(f.forEach(c,m),f=[])}f.length&&(m=Ji(lj(this),d),
f.forEach(c,m));for(h=1;h<arguments.length-1;h++);fd(this,!a.match(this.vb.$i))};g.vb.ij=/(%\d+|\n)/;g.vb.$i=/%1\s*$/;function nj(a,b,c){var d=null;if(1==b||3==b)d=new Sh(a,b);b=new Ii(b,c,a,d);a.S.push(b);a.L&&(a.v(),a.Pa());return b}function mj(a,b){for(var c=0,d;d=a.S[c];c++)if(d.name==b){d.p&&d.p.t&&E(d.p).$a(null);d.i();a.S.splice(c,1);a.L&&(a.v(),a.Pa());return}Ma('Input "%s" not found.',b)}function ld(a,b){for(var c=0,d;d=a.S[c];c++)if(d.name==b)return d;return null}
function oj(a,b){var c=ld(a,b);return c&&c.p&&E(c.p)}function pj(a){var b=new Oh(["controls_if_elseif","controls_if_else"]);a.wb&&a.wb!==b&&a.wb.i();b&&(b.g=a,a.wb=b,a.n&&cg(b))}function qj(a){return a.ta?a.ta.Ea().replace(/\s+$/,"").replace(/ +\n/g,"\n"):""}function jd(a,b){var c=!1;n(b)?(a.ta||(a.ta=new li(a),c=!0),a.ta.T(b)):a.ta&&(a.ta.i(),c=!0);a.L&&(a.v(),c&&a.Pa())}g.v=function(){this.n.v();Ti(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ph(){var a=this;this.s=new pe(function(){return Qh(a)},function(b){var c=Qh(a);c&&(ga(b.y)&&(a.s.scrollY=-c.Va*b.y-c.qb),a.s.Q.setAttribute("transform","translate(0,"+(a.s.scrollY+c.gb)+")"))});this.s.ii=!0;this.Sh=[];this.ib=this.O=0;this.pe=[];this.Hb=[]}var rj,sj,tj,uj,vj,wj;g=Ph.prototype;g.sd=!0;g.sa=8;g.I=function(){this.h=H("g",{},null);this.jb=H("path",{"class":"blocklyFlyoutBackground"},this.h);this.h.appendChild(this.s.I());return this.h};
g.i=function(){this.Vb();J(this.Sh);this.Sh.length=0;this.Oc&&(this.Oc.i(),this.Oc=null);this.s=null;this.h&&(z(this.h),this.h=null);this.Yd=this.jb=null};function Qh(a){if(!a.A())return null;var b=a.ib-2*a.sa,c=a.O;try{var d=a.s.Q.getBBox()}catch(e){d={height:0,y:0}}return{za:b,V:c,Va:d.height+d.y,Mb:-a.s.scrollY,qb:0,gb:a.sa,fb:0}}
g.o=function(a){this.Yd=a;this.Oc=new pd(this.s,!1,!1);this.Vb();K(window,"resize",this,this.Pd);this.Pd();K(this.h,"wheel",this,this.Xi);K(this.h,"mousewheel",this,this.Xi);K(this.Yd.Q,"blocklyWorkspaceChange",this,this.Wf);K(this.h,"mousedown",this,this.cf)};
g.Pd=function(){if(this.A()){var a=this.Yd.Ub();if(a){var b=this.O-this.sa;C&&(b*=-1);var c=["M "+(C?this.O:0)+",0"];c.push("h",b);c.push("a",this.sa,this.sa,0,0,C?0:1,C?-this.sa:this.sa,this.sa);c.push("v",Math.max(0,a.za-2*this.sa));c.push("a",this.sa,this.sa,0,0,C?0:1,C?this.sa:-this.sa,this.sa);c.push("h",-b);c.push("z");this.jb.setAttribute("d",c.join(" "));b=a.fb;C&&(b+=a.V,b-=this.O);this.h.setAttribute("transform","translate("+b+","+a.gb+")");this.ib=a.za;this.Oc&&this.Oc.resize()}}};
g.Xi=function(a){var b=a.deltaY||-a.wheelDeltaY;if(b){Ib&&(b*=10);var c=Qh(this),b=c.Mb+b,b=Math.min(b,c.Va-c.za),b=Math.max(b,0);this.Oc.set(b);a.preventDefault()}};g.A=function(){return this.h&&"block"==this.h.style.display};g.Vb=function(){if(this.A()){this.h.style.display="none";for(var a=0,b;b=this.Hb[a];a++)J(b);this.Hb.length=0;this.Bg&&(J(this.Bg),this.Bg=null)}};
g.show=function(a){this.Vb();for(var b=Wc(this.s,!1),c=0,d;d=b[c];c++)d.u==this.s&&d.i(!1,!1);for(var c=0,e;e=this.pe[c];c++)z(e);this.pe.length=0;var f=this.sa;this.h.style.display="block";var b=[],h=[];if(a==xj)yj(b,h,f,this.s);else if(a==zj)Aj(b,h,f,this.s);else for(var k=0;d=a[k];k++)d.tagName&&"BLOCK"==d.tagName.toUpperCase()&&(d=bd(this.s,d),b.push(d),h.push(3*f));a=f;for(k=0;d=b[k];k++){c=Rh(d);e=0;for(var m;m=c[e];e++)m.lc=!0,jd(m,null);d.v();m=O(d);e=vg(d);c=C?0:f+8;d.moveBy(c,a);a+=e.height+
h[k];e=H("rect",{"fill-opacity":0},null);this.s.Q.insertBefore(e,O(d));d.yd=e;this.pe[k]=e;this.sd?this.Hb.push(K(m,"mousedown",null,Bj(this,d))):this.Hb.push(K(m,"mousedown",null,Cj(this,d)));this.Hb.push(K(m,"mouseover",d.n,d.n.Cf));this.Hb.push(K(m,"mouseout",d.n,d.n.nf));this.Hb.push(K(e,"mousedown",null,Bj(this,d)));this.Hb.push(K(e,"mouseover",d.n,d.n.Cf));this.Hb.push(K(e,"mouseout",d.n,d.n.nf))}this.Hb.push(K(this.jb,"mouseover",this,function(){for(var a=Wc(this.s,!1),b=0,c;c=a[b];b++)c.n.nf()}));
this.O=0;this.Bi();this.Wf();Dj(window,"resize");this.Bg=K(this.s.Q,"blocklyWorkspaceChange",this,this.Bi);re(this.s)};g.Bi=function(){for(var a=0,b=this.sa,c=Wc(this.s,!1),d=0,e;e=c[d];d++)var f=vg(e),a=Math.max(a,f.width);a+=b+8+b/2+I;if(this.O!=a){for(d=0;e=c[d];d++){var f=vg(e),h=D(e);if(C){var k=a-b-8-h.x;e.moveBy(k,0);h.x+=k}e.yd&&(e.yd.setAttribute("width",f.width),e.yd.setAttribute("height",f.height),e.yd.setAttribute("x",C?h.x-f.width:h.x),e.yd.setAttribute("y",h.y))}this.O=a;De(window,"resize")}};
ki.prototype.moveTo=function(a,b){var c=D(this);this.n.wa().setAttribute("transform","translate("+a+", "+b+")");di(this,a-c.x,b-c.y)};function Cj(a,b){return function(c){Ri();zd();vd(c)?Vi(b,c):(yd(),Lh(!0),rj=c,sj=b,tj=a,uj=K(document,"mouseup",this,Ri),vj=K(document,"mousemove",this,a.Gk));c.stopPropagation()}}Ph.prototype.cf=function(a){vd(a)||(zd(!0),Ej(),this.Ni=a.clientY,wj=K(document,"mousemove",this,this.ug),uj=K(document,"mouseup",this,Ej),a.preventDefault(),a.stopPropagation())};
Ph.prototype.ug=function(a){var b=a.clientY-this.Ni;this.Ni=a.clientY;a=Qh(this);b=a.Mb-b;b=Math.min(b,a.Va-a.za);b=Math.max(b,0);this.Oc.set(b)};Ph.prototype.Gk=function(a){"mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button?a.stopPropagation():(yd(),Math.sqrt(Math.pow(a.clientX-rj.clientX,2)+Math.pow(a.clientY-rj.clientY,2))>jj&&Bj(tj,sj)(rj))};
function Bj(a,b){return function(c){if(!vd(c)&&!b.disabled){var d=Xc(b),d=bd(a.Yd,d),e=O(b);if(!e)throw"originBlock is not rendered.";var e=xd(e),f=O(d);if(!f)throw"block is not rendered.";f=xd(f);d.moveBy(e.x-f.x,e.y-f.y);a.sd?a.Vb():a.Wf();d.cf(c)}}}Ph.prototype.Wf=function(){for(var a=Ee(this.Yd),b=Wc(this.s,!1),c=0,d;d=b[c];c++){var e=Rh(d).length>a;gd(d,e)}};function Ej(){uj&&(J(uj),uj=null);vj&&(J(vj),vj=null);wj&&(J(wj),wj=null);uj&&(J(uj),uj=null);tj=sj=rj=null};function Fj(a){if("function"==typeof a.dg)return a.dg();if(n(a))return a.split("");if(fa(a)){for(var b=[],c=a.length,d=0;d<c;d++)b.push(a[d]);return b}b=[];c=0;for(d in a)b[c++]=a[d];return b};function Gj(a){this.Na=void 0;this.Aa={};if(a){var b;if("function"==typeof a.cg)b=a.cg();else if("function"!=typeof a.dg)if(fa(a)||n(a)){b=[];for(var c=a.length,d=0;d<c;d++)b.push(d)}else for(d in b=[],c=0,a)b[c++]=d;else b=void 0;a=Fj(a);for(c=0;c<b.length;c++)this.set(b[c],a[c])}}g=Gj.prototype;g.set=function(a,b){Hj(this,a,b,!1)};g.add=function(a,b){Hj(this,a,b,!0)};
function Hj(a,b,c,d){for(var e=0;e<b.length;e++){var f=b.charAt(e);a.Aa[f]||(a.Aa[f]=new Gj);a=a.Aa[f]}if(d&&void 0!==a.Na)throw Error('The collection already contains the key "'+b+'"');a.Na=c}g.get=function(a){a:{for(var b=this,c=0;c<a.length;c++)if(b=b.Aa[a.charAt(c)],!b){a=void 0;break a}a=b}return a?a.Na:void 0};g.dg=function(){var a=[];Ij(this,a);return a};function Ij(a,b){void 0!==a.Na&&b.push(a.Na);for(var c in a.Aa)Ij(a.Aa[c],b)}
g.cg=function(a){var b=[];if(a){for(var c=this,d=0;d<a.length;d++){var e=a.charAt(d);if(!c.Aa[e])return[];c=c.Aa[e]}Jj(c,a,b)}else Jj(this,"",b);return b};function Jj(a,b,c){void 0!==a.Na&&c.push(b);for(var d in a.Aa)Jj(a.Aa[d],b+d,c)}g.clear=function(){this.Aa={};this.Na=void 0};
g.remove=function(a){for(var b=this,c=[],d=0;d<a.length;d++){var e=a.charAt(d);if(!b.Aa[e])throw Error('The collection does not have the key "'+a+'"');c.push([b,e]);b=b.Aa[e]}a=b.Na;for(delete b.Na;0<c.length;)if(e=c.pop(),b=e[0],e=e[1],b.Aa[e].gi())delete b.Aa[e];else break;return a};g.clone=function(){return new Gj(this)};g.gi=function(){var a;if(a=void 0===this.Na)a:{a=this.Aa;for(var b in a){a=!1;break a}a=!0}return a};function Kj(){this.Jc=new Gj}g=Kj.prototype;g.aa="";g.pg=null;g.Xe=null;g.Nd=0;g.ad=0;function Lj(a,b){var c=!1,d=a.Jc.cg(b);d&&d.length&&(a.ad=0,a.Nd=0,c=a.Jc.get(d[0]),c=Mj(a,c))&&(a.pg=d);return c}function Mj(a,b){var c;b&&(a.ad<b.length&&(c=b[a.ad],a.Xe=b),c&&(c.Dg(),c.select()));return!!c}g.clear=function(){this.aa=""};function Nj(a){var b;b||(b=Oj(a||arguments.callee.caller,[]));return b}
function Oj(a,b){var c=[];if(Ya(b,a))c.push("[...circular reference...]");else if(a&&50>b.length){c.push(Pj(a)+"(");for(var d=a.arguments,e=0;d&&e<d.length;e++){0<e&&c.push(", ");var f;f=d[e];switch(typeof f){case "object":f=f?"object":"null";break;case "string":break;case "number":f=String(f);break;case "boolean":f=f?"true":"false";break;case "function":f=(f=Pj(f))?f:"[fn]";break;default:f=typeof f}40<f.length&&(f=f.substr(0,40)+"...");c.push(f)}b.push(a);c.push(")\n");try{c.push(Oj(a.caller,b))}catch(h){c.push("[exception trying to get caller]\n")}}else a?
c.push("[...long stack...]"):c.push("[end]");return c.join("")}function Pj(a){if(Qj[a])return Qj[a];a=String(a);if(!Qj[a]){var b=/function ([^\(]+)/.exec(a);Qj[a]=b?b[1]:"[Anonymous]"}return Qj[a]}var Qj={};function Rj(a,b,c,d,e){this.reset(a,b,c,d,e)}Rj.prototype.Uh=null;Rj.prototype.Th=null;var Sj=0;Rj.prototype.reset=function(a,b,c,d,e){"number"==typeof e||Sj++;d||pa();this.Md=a;this.wk=b;delete this.Uh;delete this.Th};Rj.prototype.Ji=function(a){this.Md=a};function Tj(a){this.$e=a;this.bi=this.Y=this.Md=this.Ga=null}function Uj(a,b){this.name=a;this.value=b}Uj.prototype.toString=function(){return this.name};var Vj=new Uj("WARNING",900),Wj=new Uj("INFO",800),Xj=new Uj("CONFIG",700),Yj=new Uj("FINE",500);g=Tj.prototype;g.getName=function(){return this.$e};g.getParent=function(){return this.Ga};g.Dc=function(){this.Y||(this.Y={});return this.Y};g.Ji=function(a){this.Md=a};
function Zj(a){if(a.Md)return a.Md;if(a.Ga)return Zj(a.Ga);Ma("Root logger has no level set.");return null}g.log=function(a,b,c){if(a.value>=Zj(this).value)for(r(b)&&(b=b()),a=this.Uj(a,b,c,Tj.prototype.log),b="log:"+a.wk,l.console&&(l.console.timeStamp?l.console.timeStamp(b):l.console.markTimeline&&l.console.markTimeline(b)),l.msWriteProfilerMark&&l.msWriteProfilerMark(b),b=this;b;){c=b;var d=a;if(c.bi)for(var e=0,f=void 0;f=c.bi[e];e++)f(d);b=b.getParent()}};
g.Uj=function(a,b,c,d){var e=new Rj(a,String(b),this.$e);if(c){var f;f=d||arguments.callee.caller;e.Uh=c;var h;try{var k;var m=aa("window.location.href");if(n(c))k={message:c,name:"Unknown error",lineNumber:"Not available",fileName:m,stack:"Not available"};else{var p,q,u=!1;try{p=c.lineNumber||c.cm||"Not available"}catch(t){p="Not available",u=!0}try{q=c.fileName||c.filename||c.sourceURL||l.$googDebugFname||m}catch(G){q="Not available",u=!0}k=!u&&c.lineNumber&&c.fileName&&c.stack&&c.message&&c.name?
c:{message:c.message||"Not available",name:c.name||"UnknownError",lineNumber:p,fileName:q,stack:c.stack||"Not available"}}h="Message: "+xa(k.message)+'\nUrl: <a href="view-source:'+k.fileName+'" target="_new">'+k.fileName+"</a>\nLine: "+k.lineNumber+"\n\nBrowser stack:\n"+xa(k.stack+"-> ")+"[end]\n\nJS stack traversal:\n"+xa(Nj(f)+"-> ")}catch(Aa){h="Exception trying to expose exception! You win, we lose. "+Aa}e.Th=h}return e};g.ce=function(a,b){this.log(Vj,a,b)};
g.info=function(a,b){this.log(Wj,a,b)};var ak={},bk=null;function ck(a){bk||(bk=new Tj(""),ak[""]=bk,bk.Ji(Xj));var b;if(!(b=ak[a])){b=new Tj(a);var c=a.lastIndexOf("."),d=a.substr(c+1),c=ck(a.substr(0,c));c.Dc()[d]=b;b.Ga=c;ak[a]=b}return b};function dk(a){ge.call(this);this.w=a;a=v?"focusout":"blur";this.pk=Wd(this.w,v?"focusin":"focus",this,!v);this.qk=Wd(this.w,a,this,!v)}s(dk,ge);dk.prototype.handleEvent=function(a){var b=new Qd(a.Tb);b.type="focusin"==a.type||"focus"==a.type?"focusin":"focusout";this.dispatchEvent(b)};dk.prototype.ba=function(){dk.m.ba.call(this);ce(this.pk);ce(this.qk);delete this.w};function ek(a,b,c){gh.call(this,a,b,c);this.xd=!0;ph(this,!0);this.Za=this;this.Zd=new Kj;if(v)try{document.execCommand("BackgroundImageCache",!1,!0)}catch(d){(a=this.mi)&&a.ce("Failed to enable background image cache",void 0)}}s(ek,gh);ek.prototype.Fa=null;ek.prototype.Yf=null;var fk=ek.prototype,gk=ck("goog.ui.tree.TreeControl");fk.mi=gk;g=ek.prototype;g.$f=!1;g.Rj=null;g.Vd=!0;g.Kg=!0;g.Rc=!0;g.Lg=!0;g.Ja=function(){return this};g.Yc=function(){return 0};g.Dg=function(){};
g.$j=function(){this.$f=!0;mf(this.k(),"focused");this.Za&&this.Za.select()};g.Wj=function(){this.$f=!1;of(this.k(),"focused")};g.hasFocus=function(){return this.$f};g.Ra=function(){return!this.Rc||ek.m.Ra.call(this)};g.Yb=function(a){this.Rc?ek.m.Yb.call(this,a):this.xd=a};g.bg=function(){return yb};g.De=function(){var a=nh(this);return a?a.firstChild:null};g.Ce=function(){return null};g.ld=function(){};g.Cd=function(){return ek.m.Cd.call(this)+(this.Rc?"":" "+this.ua.Fh)};
g.ye=function(){var a=this.Ra(),b=this.Qj;if(a&&b)return b;b=this.hk;if(!a&&b)return b;b=this.ua;return a&&b.Eh?b.zc+" "+b.Eh:!a&&b.Ah?b.zc+" "+b.Ah:""};g.Qc=function(a){if(this.Za!=a){var b=!1;this.Za&&(b=this.Za==this.Rj,ph(this.Za,!1));if(this.Za=a)ph(a,!0),b&&a.select();this.dispatchEvent("change")}};function hk(a){function b(a){var h=kh(a);if(h){var k=!d||c==a.getParent()&&!e?a.ua.yh:a.ua.xh;h.className=k;if(h=a.Ce())h.className=th(a)}ef(a,b)}var c=a,d=c.Vd,e=c.Lg;b(a)}
g.Pe=function(){ek.m.Pe.call(this);var a=this.k();tf(a,"tree");uf(a,"labelledby",jh(this).id)};g.va=function(){ek.m.va.call(this);var a=this.k();a.className=this.ua.Ih;a.setAttribute("hideFocus","true");a=this.k();a.tabIndex=0;var b=this.Fa=new Gf(a),c=this.Yf=new dk(a);cf(this).H(c,"focusout",this.Wj).H(c,"focusin",this.$j).H(b,"key",this.ub).H(a,"mousedown",this.fg).H(a,"click",this.fg).H(a,"dblclick",this.fg);this.Pe()};
g.hb=function(){ek.m.hb.call(this);this.Fa.i();this.Fa=null;this.Yf.i();this.Yf=null};g.fg=function(a){var b=this.mi;b&&b.log(Yj,"Received event "+a.type,void 0);if(b=ik(this,a))switch(a.type){case "mousedown":b.tg(a);break;case "click":a.preventDefault();break;case "dblclick":b.pi(a)}};
g.ub=function(a){var b=!1,b=this.Zd,c=!1;switch(a.keyCode){case 40:case 38:if(a.ctrlKey){var c=40==a.keyCode?1:-1,d=b.pg;if(d){var e=null,f=!1;if(b.Xe){var h=b.ad+c;0<=h&&h<b.Xe.length?(b.ad=h,e=b.Xe):f=!0}e||(h=b.Nd+c,0<=h&&h<d.length&&(b.Nd=h),d.length>b.Nd&&(e=b.Jc.get(d[b.Nd])),e&&e.length&&f&&(b.ad=-1==c?e.length-1:0));Mj(b,e)&&(b.pg=d)}c=!0}break;case 8:d=b.aa.length-1;c=!0;0<d?(b.aa=b.aa.substring(0,d),Lj(b,b.aa)):0==d?b.aa="":c=!1;break;case 27:b.aa="",c=!0}if(!(b=c)&&(b=this.Za)){b=this.Za;
c=!0;switch(a.keyCode){case 39:if(a.altKey)break;hf(b)&&(b.Ra()?M(b,0).select():b.Yb(!0));break;case 37:if(a.altKey)break;hf(b)&&b.Ra()&&b.Ld?b.Yb(!1):(d=b.getParent(),e=b.Ja(),d&&(e.Rc||d!=e)&&d.select());break;case 40:a:if(hf(b)&&b.Ra())d=M(b,0);else{for(d=b;d!=b.Ja();){e=d.xb;if(null!=e){d=e;break a}d=d.getParent()}d=null}d&&d.select();break;case 38:d=b.Kc;null!=d?d=wh(d):(d=b.getParent(),e=b.Ja(),d=!e.Rc&&d==e||b==e?null:d);d&&d.select();break;default:c=!1}c&&(a.preventDefault(),(e=b.Ja())&&e.Zd.clear());
b=c}b||(b=this.Zd,c=!1,a.ctrlKey||a.altKey||(d=String.fromCharCode(a.charCode||a.keyCode).toLowerCase(),(1==d.length&&" "<=d&&"~">=d||"\u0080"<=d&&"\ufffd">=d)&&(" "!=d||b.aa)&&(b.aa+=d,c=Lj(b,b.aa))),b=c);b&&a.preventDefault();return b};function ik(a,b){for(var c=null,d=b.target;null!=d;){if(c=ih[d.id])return c;if(d==a.k())break;d=d.parentNode}return null}g.createNode=function(a){return new xh(a||yb,this.ua,this.tb())};
function vh(a,b){var c=a.Zd,d=b.Ea();if(d&&!/^[\s\xa0]*$/.test(null==d?"":String(d))){var d=d.toLowerCase(),e=c.Jc.get(d);e?e.push(b):c.Jc.set(d,[b])}}g.removeNode=function(a){var b=this.Zd,c=a.Ea();if(c&&!/^[\s\xa0]*$/.test(null==c?"":String(c))){var c=c.toLowerCase(),d=b.Jc.get(c);d&&(Za(d,a),d.length&&b.Jc.remove(c))}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var jk,kk,lk,mk=0,nk={kg:19,Ih:"blocklyTreeRoot",Fh:"blocklyHidden",Gh:"",Kh:"blocklyTreeRow",Hh:"blocklyTreeLabel",zc:"blocklyTreeIcon",Nf:"blocklyTreeIconOpen",Of:"blocklyTreeIconNone",Jh:"blocklyTreeSelected"};function ok(a,b){jk=dc("div","blocklyToolboxDiv");jk.setAttribute("dir",C?"RTL":"LTR");b.appendChild(jk);kk=new Ph;a.appendChild(kk.I());K(jk,"mousedown",null,function(a){vd(a)||a.target==jk?zd(!1):zd(!0)})}
function pk(){nk.cleardotPath=me+"media/1x1.gif";nk.cssCollapsedFolderIcon="blocklyTreeIconClosed"+(C?"Rtl":"Ltr");var a=new qk(yb,nk);lk=a;if(0!=a.Rc){a.Rc=!1;if(a.G){var b=nh(a);b&&(b.className=a.Cd())}a.Za==a&&M(a,0)&&a.Qc(M(a,0))}0!=a.Vd&&(a.Vd=!1,a.G&&hk(a));0!=a.Kg&&(a.Kg=!1,a.G&&hk(a));a.Qc(null);jk.style.display="block";kk.o(y);rk();a.v(jk);Wd(window,"resize",sk);sk()}
function sk(){var a=jk,b=Ve(Gc),c=Gi();C?(b=tk(0,0,!1),a.style.left=b.x+c.width-a.offsetWidth+"px"):a.style.marginLeft=b.left;a.style.height=c.height+1+"px";mk=a.offsetWidth;C||--mk}
function rk(){function a(c,d){for(var e=0,f;f=c.childNodes[e];e++)if(f.tagName){var h=f.tagName.toUpperCase();if("CATEGORY"==h){h=b.createNode(f.getAttribute("name"));h.vc=[];d.add(h);var k=f.getAttribute("custom");k?h.vc=k:a(f,h)}else"BLOCK"==h&&d.vc.push(f)}}var b=lk;b.Di();b.vc=[];a(Kc,lk);if(b.vc.length)throw"Toolbox cannot have both blocks and categories in the root level.";De(window,"resize")}function qk(a,b,c){ek.call(this,a,b,c)}s(qk,ek);
qk.prototype.va=function(){qk.m.va.call(this);if(Od){var a=this.k();K(a,"touchstart",this,this.ek)}};qk.prototype.ek=function(a){a.preventDefault();var b=ik(this,a);b&&"touchstart"===a.type&&window.setTimeout(function(){b.tg(a)},1)};qk.prototype.createNode=function(a){return new uk(a?qb(a):yb,this.ua,this.tb())};qk.prototype.Qc=function(a){this.Za!=a&&(ek.prototype.Qc.call(this,a),a&&a.vc&&a.vc.length?kk.show(a.vc):kk.Vb())};
function uk(a,b,c){function d(){De(window,"resize")}gh.call(this,a,b,c);Wd(lk,"expand",d);Wd(lk,"collapse",d)}s(uk,xh);gh.prototype.bg=function(){return wb("span")};uk.prototype.tg=function(){hf(this)&&this.Ld?(this.toggle(),this.select()):this.Re()?this.Ja().Qc(null):this.select();qh(this)};uk.prototype.pi=function(){};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var xj="VARIABLE";function vk(){var a;a=xe(y);for(var b=Object.create(null),c=0;c<a.length;c++){var d=a[c].Yh;if(d)for(var d=d.call(a[c]),e=0;e<d.length;e++){var f=d[e];f&&(b[f.toLowerCase()]=f)}}a=[];for(var h in b)a.push(b[h]);return a}function wk(a,b){for(var c=xe(y),d=0;d<c.length;d++){var e=c[d].Pk;e&&e.call(c[d],a,b)}}
function yj(a,b,c,d){var e=vk();e.sort(wa);e.unshift(null);for(var f=void 0,h=0;h<e.length;h++)if(e[h]!==f){var k=R.variables_get?dd(d,"variables_get"):null;k&&ed(k);var m=R.variables_set?dd(d,"variables_set"):null;m&&ed(m);null===e[h]?f=(k||m).Yh()[0]:(k&&kd(k,"VAR").bb(e[h]),m&&kd(m,"VAR").bb(e[h]));m&&a.push(m);k&&a.push(k);k&&m?b.push(c,3*c):b.push(2*c)}}
function xk(){var a=vk(),b="";if(a.length){a.sort(wa);for(var c=0,d="i",e=0,f=!1;!b;){e=0;for(f=!1;e<a.length&&!f;)a[e].toLowerCase()==d&&(f=!0),e++;f?("z"===d[0]?(c++,d="a"):(d=String.fromCharCode(d.charCodeAt(0)+1),"l"==d[0]&&(d=String.fromCharCode(d.charCodeAt(0)+1))),0<c&&(d+=c)):b=d}}else b="i";return b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function yk(a,b){var c;if(b){var d=this;c=function(a){var c=zk.call(d,a);a=void 0===c?a:null===c?d.ic():c;b.call(d,a);return c}}else c=zk;yk.m.constructor.call(this,Ak,c);a?this.bb(a):this.bb(xk())}s(yk,P);yk.prototype.clone=function(){return new yk(this.ic(),this.Ia)};yk.prototype.ic=function(){return this.Ea()};yk.prototype.bb=function(a){this.Na=a;this.T(a)};
function Ak(){var a=vk(),b=this.Ea();b&&-1==a.indexOf(b)&&a.push(b);a.sort(wa);a.push(Bk);a.push(Ck);for(var b=[],c=0;c<a.length;c++)b[c]=[a[c],a[c]];return b}function zk(a){function b(a,b){zd();var c=window.prompt(a,b);return c&&c.replace(/[\s\xa0]+/g," ").replace(/^ | $/g,"")}if(a==Bk){var c=this.Ea();(a=b(Dk.replace("%1",c),c))&&wk(c,a);return null}if(a==Ck)return(a=b(Ek,""))?(wk(a,a),a):null};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var zj="PROCEDURE";function Fk(){for(var a=xe(y),b=[],c=[],d=0;d<a.length;d++){var e=a[d].Yl;e&&(e=e.call(a[d]))&&(e[2]?b.push(e):c.push(e))}c.sort(Gk);b.sort(Gk);return[c,b]}function Gk(a,b){var c=a[0].toLowerCase(),d=b[0].toLowerCase();return c>d?1:c<d?-1:0}
function Aj(a,b,c,d){function e(e,f){for(var m=0;m<e.length;m++){var p=dd(d,f);kd(p,"NAME").bb(e[m][0]);for(var q=[],u=0;u<e[m][1].length;u++)q[u]="ARG"+u;p.pm(e[m][1],q);ed(p);a.push(p);b.push(2*c)}}if(R.procedures_defnoreturn){var f=dd(d,"procedures_defnoreturn");ed(f);a.push(f);b.push(2*c)}R.procedures_defreturn&&(f=dd(d,"procedures_defreturn"),ed(f),a.push(f),b.push(2*c));R.procedures_ifreturn&&(f=dd(d,"procedures_ifreturn"),ed(f),a.push(f),b.push(2*c));b.length&&(b[b.length-1]=3*c);f=Fk();e(f[0],
"procedures_callnoreturn");e(f[1],"procedures_callreturn")};var pg=/#(.)(.)(.)/;function mg(a){var b=a[0],c=a[1];a=a[2];b=Number(b);c=Number(c);a=Number(a);if(isNaN(b)||0>b||255<b||isNaN(c)||0>c||255<c||isNaN(a)||0>a||255<a)throw Error('"('+b+","+c+","+a+'") is not a valid RGB color');b=Hk(b.toString(16));c=Hk(c.toString(16));a=Hk(a.toString(16));return"#"+b+c+a}var og=/^#(?:[0-9a-f]{3}){1,2}$/i;function Hk(a){return 1==a.length?"0"+a:a}
function ng(a){var b=0,c=0,d=0,e=Math.floor(a/60),f=a/60-e;a=166.4*.55;var h=166.4*(1-.45*f),f=166.4*(1-.45*(1-f));switch(e){case 1:b=h;c=166.4;d=a;break;case 2:b=a;c=166.4;d=f;break;case 3:b=a;c=h;d=166.4;break;case 4:b=f;c=a;d=166.4;break;case 5:b=166.4;c=a;d=h;break;case 6:case 0:b=166.4,c=f,d=a}return[Math.floor(b),Math.floor(c),Math.floor(d)]}function qg(a,b,c){c=Math.min(Math.max(c,0),1);return[Math.round(c*a[0]+(1-c)*b[0]),Math.round(c*a[1]+(1-c)*b[1]),Math.round(c*a[2]+(1-c)*b[2])]};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function dg(a,b){var c=a.getAttribute("class")||"";-1==(" "+c+" ").indexOf(" "+b+" ")&&(c&&(c+=" "),a.setAttribute("class",c+b))}function eg(a,b){var c=a.getAttribute("class");if(-1!=(" "+c+" ").indexOf(" "+b+" ")){for(var c=c.split(/\s+/),d=0;d<c.length;d++)c[d]&&c[d]!=b||(c.splice(d,1),d--);c.length?a.setAttribute("class",c.join(" ")):a.removeAttribute("class")}}
function K(a,b,c,d){function e(a){d.apply(c,arguments)}a.addEventListener(b,e,!1);var f=[[a,b,e]];if(b in Ik)for(var e=function(a){if(1==a.changedTouches.length){var b=a.changedTouches[0];a.clientX=b.clientX;a.clientY=b.clientY}d.apply(c,arguments);a.preventDefault()},h=0,k;k=Ik[b][h];h++)a.addEventListener(k,e,!1),f.push([a,k,e]);return f}var Ik={};"ontouchstart"in document.documentElement&&(Ik={mousedown:["touchstart"],mousemove:["touchmove"],mouseup:["touchend","touchcancel"]});
function J(a){for(;a.length;){var b=a.pop();b[0].removeEventListener(b[1],b[2],!1)}}function Dj(a,b){var c=document;if(c.createEvent)c=c.createEvent("UIEvents"),c.initEvent(b,!0,!0),a.dispatchEvent(c);else if(c.createEventObject)c=c.createEventObject(),a.fireEvent("on"+b,c);else throw"FireEvent: No event creation mechanism.";}function De(a,b){setTimeout(function(){Dj(a,b)},0)}
function Nh(a){var b={x:0,y:0},c=a.getAttribute("x");c&&(b.x=parseInt(c,10));if(c=a.getAttribute("y"))b.y=parseInt(c,10);if(a=(a=a.getAttribute("transform"))&&a.match(/translate\(\s*([-\d.]+)([ ,]\s*([-\d.]+)\s*\))?/))b.x+=parseInt(a[1],10),a[3]&&(b.y+=parseInt(a[3],10));return b}function xd(a){var b=0,c=0;do{var d=Nh(a),b=b+d.x,c=c+d.y;a=a.parentNode}while(a&&a!=Gc);return{x:b,y:c}}function $g(a){a=xd(a);return tk(a.x,a.y,!1)}
function H(a,b,c){a=document.createElementNS("http://www.w3.org/2000/svg",a);for(var d in b)a.setAttribute(d,b[d]);document.body.runtimeStyle&&(a.runtimeStyle=a.currentStyle=a.style);c&&c.appendChild(a);return a}function vd(a){return 2==a.button||a.ctrlKey}
function tk(a,b,c){c&&(a-=window.scrollX||window.pageXOffset,b-=window.scrollY||window.pageYOffset);var d=Gc.createSVGPoint();d.x=a;d.y=b;a=Gc.getScreenCTM();c&&(a=a.inverse());d=d.matrixTransform(a);c||(d.x+=window.scrollX||window.pageXOffset,d.y+=window.scrollY||window.pageYOffset);return d}function wd(a){return tk(a.clientX+(window.scrollX||window.pageXOffset),a.clientY+(window.scrollY||window.pageYOffset),!0)}
function ch(a){if(!a.length)return 0;for(var b=a[0].length,c=1;c<a.length;c++)b=Math.min(b,a[c].length);return b}function dh(a,b){if(!a.length)return 0;if(1==a.length)return a[0].length;for(var c=0,d=b||ch(a),e=0;e<d;e++){for(var f=a[0][e],h=1;h<a.length;h++)if(f!=a[h][e])return c;" "==f&&(c=e+1)}for(h=1;h<a.length;h++)if((f=a[h][e])&&" "!=f)return c;return d}
function eh(a,b){if(!a.length)return 0;if(1==a.length)return a[0].length;for(var c=0,d=b||ch(a),e=0;e<d;e++){for(var f=a[0].substr(-e-1,1),h=1;h<a.length;h++)if(f!=a[h].substr(-e-1,1))return c;" "==f&&(c=e+1)}for(h=1;h<a.length;h++)if((f=a[h].charAt(a[h].length-e-1))&&" "!=f)return c;return d};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Jk(){function a(a){a=a.slice(1).split("&");for(var c=0;c<a.length;c++){var f=a[c].split("=");b[decodeURIComponent(f[0])]=decodeURIComponent(f[1])}}var b={},c=window.location.hash;c&&a(c);(c=window.location.search)&&a(c);return b}var Kk=Jk();function V(a,b,c){if(a.hasOwnProperty(b))return a[b];void 0===c&&console.error(b+" should be present in the options.");return c}
function Lk(a){this.wj=V(a,"clientId");this.Xg=Kk.userId;document.getElementById(V(a,"authButtonElementId"));document.getElementById(V(a,"authDivElementId"))}Lk.prototype.start=function(){gapi.load("auth:client,drive-realtime,drive-share",function(){})};
function Mk(a,b,c,d){function e(c){gapi.cc.oa.files.Qe({resource:{mimeType:b,title:a,parents:[{id:c}]}}).Bc(d)}function f(){function a(b){gapi.cc.oa.Ok.Qe({fileId:"appdata",resource:{key:"folderId",value:b}}).Bc(function(){e(b)})}function b(){gapi.cc.oa.files.Qe({resource:{mimeType:"application/vnd.google-apps.folder",title:c}}).Bc(function(b){a(b.id)})}gapi.cc.oa.Ok.get({fileId:"appdata",propertyKey:"folderId"}).Bc(function(d){if(d.error)c?b():a("root");else{var f=d.result.value;gapi.cc.oa.files.get({fileId:f}).Bc(function(a){a.error||
a.labels.rm?b():e(f)})}})}gapi.cc.load("drive","v2",function(){f()})}function Nk(a){this.qi=V(a,"onFileLoaded");this.yk=V(a,"newFileMimeType","application/vnd.google-apps.drive-sdk");this.di=V(a,"initializeModel");this.Ci=V(a,"registerTypes",function(){});this.kh=V(a,"afterAuth",function(){});this.qj=V(a,"autoCreate",!1);this.Lj=V(a,"defaultTitle","New Realtime File");this.Kj=V(a,"defaultFolderTitle","");this.lh=V(a,"afterCreate",function(){});this.Hf=new Lk(a)}
function Ok(a,b,c){var d=[];b&&d.push("fileIds="+b.join(","));c&&d.push("userId="+c);c=0==d.length?window.location.pathname:window.location.pathname+"#"+d.join("&");window.history&&window.history.replaceState?window.history.replaceState("Google Drive Realtime API Playground","Google Drive Realtime API Playground",c):window.location.href=c;Kk=Jk();for(var e in b)gapi.oa.Jb.load(b[e],a.qi,a.di,a.$h)}Nk.prototype.start=function(){var a=this;this.Hf.start(function(){a.Ci&&a.Ci();a.kh&&a.kh();a.load()})};
Nk.prototype.$h=function(a){a.type!=gapi.oa.Jb.$g.Kl&&(a.type==gapi.oa.Jb.$g.kl?(alert("An Error happened: "+a.message),window.location.href="/"):a.type==gapi.oa.Jb.$g.sl&&(alert("The file was not found. It does not exist or you do not have read access to the file."),window.location.href="/"))};
Nk.prototype.load=function(){var a=Kk.fileIds;a&&(a=a.split(","));var b=this.Hf.Xg,b=Kk.state;if(a)for(var c in a)gapi.oa.Jb.load(a[c],this.qi,this.di,this.$h);else{if(b){var d;try{d=JSON.parse(b)}catch(e){d=null}if("open"==d.action){a=d.am;b=d.Xg;Ok(this,a,b);return}}this.qj&&Pk(this)}};function Pk(a){Mk(a.Lj,a.yk,a.Kj,function(b){b.id?(a.lh&&a.lh(b.id),Ok(a,[b.id],a.Hf.Xg)):(console.error("Error creating file."),console.error(b))})};/*

 Visual Blocks Editor

 Copyright 2014 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var ve,Qk,Rk="media/progress.gif",ue=!1,Sk=null,Li=null,Tk=null,Uk=null,Ni=null,Si=!1,Vk=null,Wk=null,Xk=null,Rk="media/progress.gif";function Yk(a){var b=a.Pj;a=a.Pj.length;for(var c=0;c<a;c++){var d=b[c];if(!d.nk){var e=d.target;"value_changed"==d.type&&("xmlDom"==d.yi?Zk(function(){$k(e,!1);al(e)}):"relativeX"!=d.yi&&"relativeY"!=d.yi||Zk(function(){e.n||$k(e,!1);al(e)}))}}}function bl(a){if(!a.nk){var b=a.newValue;b?$k(b,!a.oldValue):(b=a.oldValue,cl(b))}}
function Zk(a){if(Si)a();else try{Si=!0,a()}finally{Si=!1}}function $k(a,b){Zk(function(){var c=$c(a.Yg).firstChild;if(c=bd(y,c,!0))b&&te(c.u,c),(b||Ya(ve,c))&&al(c)})}function al(a){if(!isNaN(a.kf)&&!isNaN(a.lf)){var b=Gi().width,c=D(a),d=a.kf-c.x;a.moveBy(C?b-d:d,a.lf-c.y)}}function cl(a){Zk(function(){a.i(!0,!0,!0)})}
function Ti(a){if(a.u==y&&ue&&!Si){a=bi(a);var b=D(a),c=!1,d=Xc(a);d.setAttribute("id",a.id);var e=dc("xml");e.appendChild(d);d=Zc(e);d!=a.Yg&&(c=!0,a.Yg=d);if(a.kf!=b.x||a.lf!=b.y)a.kf=b.x,a.lf=b.y,c=!0;c&&Ni.set(a.id.toString(),a)}}function dl(a,b){gapi.cc.oa.xi.list({fileId:a}).Bc(function(a){for(var d=0;d<a.items.length;d++){var e=a.items[d];if("owner"==e.im){b(e.domain);break}}})}
var hl={clientId:null,authButtonElementId:"authorizeButton",authDivElementId:"authButtonDiv",initializeModel:function(a){Li=a;var b=a.Ul();a.Zc().set("blocks",b);b=a.Tl();a.Zc().set("topBlocks",b);Wk&&a.Zc().set(Wk,a.Vl(Xk))},autoCreate:!0,defaultTitle:"Realtime Blockly File",defaultFolderTitle:"Realtime Blockly Folder",newFileMimeType:null,onFileLoaded:function(a){Sk=a;a:{for(var b=a.Tj(),c=0;c<b.length;c++){var d=b[c];if(d.ok){Tk=d.mm;break a}}Tk=void 0}Li=a.Ye;Ni=Li.Zc().get("blocks");ve=Li.Zc().get("topBlocks");
Li.Zc().addEventListener(gapi.oa.Jb.Af.ul,Yk);Ni.addEventListener(gapi.oa.Jb.Af.Ll,bl);Uk();a.addEventListener(gapi.oa.Jb.Af.ll,el);a.addEventListener(gapi.oa.Jb.Af.ol,fl);gl();a=ve;for(b=0;b<a.length;b++)c=a.get(b),$k(c,!0)},registerTypes:function(){var a=gapi.oa.Jb.Wl;a.gm(ki,"Block");ki.prototype.id=a.Jf("id");ki.prototype.Yg=a.Jf("xmlDom");ki.prototype.kf=a.Jf("relativeX");ki.prototype.lf=a.Jf("relativeY");a.nm(ki,ki.prototype.initialize)},afterAuth:function(){window.setTimeout(function(){},18E5)},
afterCreate:function(a){var b=gapi.cc.oa.xi.Qe({fileId:a,resource:{type:"anyone",role:"writer",value:"default",withLink:!0}});b.Bc(function(c){c.error&&dl(a,function(c){b=gapi.cc.oa.xi.Qe({fileId:a,resource:{type:"domain",role:"writer",value:c,withLink:!0}});b.Bc(function(){})})})}};function il(){var a=Mc,b=V(a,"chatbox");b&&(Wk=V(b,"elementId"),Xk=V(b,"initText",jl));hl.wj=V(a,"clientId");Qk=V(a,"collabElementId")}
function kl(a,b){il();ue=!0;ll(b);Uk=function(){a();if(Wk){var b=Li.Zc().get(Wk),d=document.getElementById(Wk);gapi.oa.Jb.Xl.Pl(b,d);d.disabled=!1}};Vk=new Nk(hl);Vk.start()}
function ll(a){a.style.background="url("+me+Rk+") no-repeat center center";var b=Pe(a),c=dc("div");c.id=hl.authDivElementId;var d=dc("p",null,ml);c.appendChild(d);d=dc("button",null,"Authorize");d.id=hl.Nl;c.appendChild(d);a.appendChild(c);c.style.display="none";c.style.position="relative";c.style.textAlign="center";c.style.border="1px solid";c.style.backgroundColor="#f6f9ff";c.style.borderRadius="15px";c.style.boxShadow="10px 10px 5px #888";c.style.width=b.width/3+"px";a=Pe(c);c.style.left=(b.width-
a.width)/3+"px";c.style.top=(b.height-a.height)/4+"px"}function gl(){if(Qk){var a;a=Qk;a=n(a)?document.getElementById(a):a;hc(a);for(var b=Sk.Tj(),c=0;c<b.length;c++){var d=b[c],e=dc("img",{src:d.em||me+"media/anon.jpeg",alt:d.displayName,title:d.displayName+(d.ok?" ("+nl+")":"")});e.style.backgroundColor=d.color;a.appendChild(e)}}}function el(){gl()}function fl(){gl()}function Mi(a){var b=Tk+"-"+a;return Ni.has(b)?Mi("-"+a):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ol(a,b){ol.m.constructor.call(this,a);this.Ia=b}var pl;s(ol,yg);g=ol.prototype;g.clone=function(){return new ol(this.Ea(),this.Ia)};g.Zg="text";g.i=function(){Yg==this&&Zg();ol.m.i.call(this)};g.T=function(a){if(null!==a){if(this.Ia){var b=this.Ia(a);null!==b&&void 0!==b&&(a=b)}yg.prototype.T.call(this,a)}};
g.sf=function(a){a=a||!1;if(!a&&(Jb||Eb||Gb)){a=window.prompt(ql,this.Ma);if(this.Ia){var b=this.Ia(a);void 0!==b&&(a=b)}null!==a&&this.T(a)}else{Xg(this,rl(this));var b=ah,c=dc("input","blocklyHtmlInput");pl=c;b.appendChild(c);c.value=c.defaultValue=this.Ma;c.oi=null;sl(this);this.Fi();a||(c.focus(),c.select());c.Dk=K(c,"keyup",this,this.ri);c.Ck=K(c,"keypress",this,this.ri);c.Jk=K(this.j.u.Q,"blocklyWorkspaceChange",this,this.Fi)}};
g.ri=function(a){var b=pl;13==a.keyCode?Zg():27==a.keyCode?(this.T(b.defaultValue),Zg()):(a=b.value,a!==b.oi?(b.oi=a,this.T(a),sl(this)):w&&this.j.v())};function sl(a){var b=!0,c=pl;a.Ia&&(b=a.Ia(c.value));null===b?dg(c,"blocklyInvalidInput"):eg(c,"blocklyInvalidInput")}g.Fi=function(){var a=ah,b=this.Qa.getBBox();a.style.width=b.width+"px";b=$g(this.wc);if(C){var c=this.wc.getBBox();b.x+=c.width;b.x-=a.offsetWidth}b.y+=1;w&&(b.y-=3);a.style.left=b.x+"px";a.style.top=b.y+"px"};
function rl(a){return function(){var b=pl,c=b.value;a.Ia&&(c=a.Ia(c),null===c&&(c=b.defaultValue));a.T(c);a.j.L&&a.j.v();J(b.Dk);J(b.Ck);J(b.Jk);pl=null;ah.style.width="auto"}}function tl(a){a=a.replace(/O/ig,"0");a=a.replace(/,/g,"");a=parseFloat(a||0);return isNaN(a)?null:String(a)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ul(a){this.$e=a;this.Bf="";this.Yi=new RegExp(this.$b,"g")}ul.prototype.hh=null;function vl(){var a=W,b=[];a.o();for(var c=Wc(y,!0),d=0,e;e=c[d];d++){var f=wl(a,e);ea(f)&&(f=f[0]);f&&(e.K&&a.Hi&&(f=a.Hi(f)),b.push(f))}b=b.join("\n");b=a.finish(b);b=b.replace(/^\s+\n/,"");b=b.replace(/\n\s+$/,"\n");return b=b.replace(/[ \t]+\n/g,"\n")}function xl(a,b){return b+a.replace(/\n(.)/g,"\n"+b+"$1")}
function wl(a,b){if(!b)return"";if(b.disabled)return wl(a,Yc(b));var c=a[b.type];if(!c)throw'Language "'+a.$e+'" does not know how to generate code for block type "'+b.type+'".';c=c.call(b,b);if(ea(c))return[a.Ii(b,c[0]),c[1]];if(n(c))return a.hh&&(c=a.hh.replace(/%1/g,"'"+b.id+"'")+c),a.Ii(b,c);if(null===c)return"";throw"Invalid code generated: "+c;}
function X(a,b,c){var d=W;if(isNaN(c))throw'Expecting valid order from block "'+a.type+'".';a=oj(a,b);if(!a)return"";b=wl(d,a);if(""===b)return"";if(!ea(b))throw'Expecting tuple from value block "'+a.type+'".';d=b[0];b=b[1];if(isNaN(b))throw'Expecting valid order from value block "'+a.type+'".';d&&c<=b&&c!=b&&0!=c&&99!=c&&(d="("+d+")");return d}function yl(a,b){var c=W,d=oj(a,b),e=wl(c,d);if(!n(e))throw'Expecting code from statement block "'+d.type+'".';e&&(e=xl(e,c.Zi));return e}
ul.prototype.Zi="  ";function zl(a){var b=W;b.Bf+=a+","}ul.prototype.$b="{leCUI8hutHZI4480Dc}";function Al(a,b){var c=W;if(!c.ud[a]){var d=Uc(c.be,a);c.Wh[a]=d;c.ud[a]=b.join("\n").replace(c.Yi,d)}return c.Wh[a]};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Bl(){var a=Cl.join("\n"),b=me.replace(/[\\\/]$/,""),a=a.replace(/<<<PATH>>>/g,b),b=document,c=b.createElement("style");c.type="text/css";b.getElementsByTagName("head")[0].appendChild(c);c.styleSheet?c.styleSheet.cssText=a:c.appendChild(b.createTextNode(a))}
var Cl=[".blocklySvg {","  background-color: #fff;","  border: 1px solid #ddd;","  overflow: hidden;","}",".blocklyWidgetDiv {","  position: absolute;","  display: none;","  z-index: 999;","}",".blocklyDraggable {","  cursor: url(<<<PATH>>>/media/handopen.cur) 8 5, auto;","}",".blocklyResizeSE {","  fill: #aaa;","  cursor: se-resize;","}",".blocklyResizeSW {","  fill: #aaa;","  cursor: sw-resize;","}",".blocklyResizeLine {","  stroke-width: 1;","  stroke: #888;","}",".blocklyHighlightedConnectionPath {",
"  stroke-width: 4px;","  stroke: #fc3;","  fill: none;","}",".blocklyPathLight {","  fill: none;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklySelected>.blocklyPath {","  stroke-width: 3px;","  stroke: #fc3;","}",".blocklySelected>.blocklyPathLight {","  display: none;","}",".blocklyDragging>.blocklyPath,",".blocklyDragging>.blocklyPathLight {","  fill-opacity: .8;","  stroke-opacity: .8;","}",".blocklyDragging>.blocklyPathDark {","  display: none;","}",".blocklyDisabled>.blocklyPath {",
"  fill-opacity: .5;","  stroke-opacity: .5;","}",".blocklyDisabled>.blocklyPathLight,",".blocklyDisabled>.blocklyPathDark {","  display: none;","}",".blocklyText {","  cursor: default;","  font-family: sans-serif;","  font-size: 11pt;","  fill: #fff;","}",".blocklyNonEditableText>text {","  pointer-events: none;","}",".blocklyNonEditableText>rect,",".blocklyEditableText>rect {","  fill: #fff;","  fill-opacity: .6;","}",".blocklyNonEditableText>text,",".blocklyEditableText>text {","  fill: #000;",
"}",".blocklyEditableText:hover>rect {","  stroke-width: 2;","  stroke: #fff;","}",".blocklyBubbleText {","  fill: #000;","}",".blocklySvg text {","  -moz-user-select: none;","  -webkit-user-select: none;","  user-select: none;","  cursor: inherit;","}",".blocklyHidden {","  display: none;","}",".blocklyFieldDropdown:not(.blocklyHidden) {","  display: block;","}",".blocklyTooltipBackground {","  fill: #ffffc7;","  stroke-width: 1px;","  stroke: #d8d8d8;","}",".blocklyTooltipShadow,",".blocklyDropdownMenuShadow {",
"  fill: #bbb;","  filter: url(#blocklyShadowFilter);","}",".blocklyTooltipText {","  font-family: sans-serif;","  font-size: 9pt;","  fill: #000;","}",".blocklyIconShield {","  cursor: default;","  fill: #00c;","  stroke-width: 1px;","  stroke: #ccc;","}",".blocklyIconGroup:hover>.blocklyIconShield {","  fill: #00f;","  stroke: #fff;","}",".blocklyIconGroup:hover>.blocklyIconMark {","  fill: #fff;","}",".blocklyIconMark {","  cursor: default !important;","  font-family: sans-serif;","  font-size: 9pt;",
"  font-weight: bold;","  fill: #ccc;","  text-anchor: middle;","}",".blocklyWarningBody {","}",".blocklyMinimalBody {","  margin: 0;","  padding: 0;","}",".blocklyCommentTextarea {","  margin: 0;","  padding: 2px;","  border: 0;","  resize: none;","  background-color: #ffc;","}",".blocklyHtmlInput {","  font-family: sans-serif;","  font-size: 11pt;","  border: none;","  outline: none;","  width: 100%","}",".blocklyMutatorBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #ddd;","}",".blocklyFlyoutBackground {",
"  fill: #ddd;","  fill-opacity: .8;","}",".blocklyColourBackground {","  fill: #666;","}",".blocklyScrollbarBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #e4e4e4;","}",".blocklyScrollbarKnob {","  fill: #ccc;","}",".blocklyScrollbarBackground:hover+.blocklyScrollbarKnob,",".blocklyScrollbarKnob:hover {","  fill: #bbb;","}",".blocklyInvalidInput {","  background: #faa;","}",".blocklyAngleCircle {","  stroke: #444;","  stroke-width: 1;","  fill: #ddd;","  fill-opacity: .8;","}",".blocklyAngleMarks {",
"  stroke: #444;","  stroke-width: 1;","}",".blocklyAngleGauge {","  fill: #f88;","  fill-opacity: .8;  ","}",".blocklyAngleLine {","  stroke: #f00;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklyContextMenu {","  border-radius: 4px;","}",".blocklyDropdownMenu {","  padding: 0 !important;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(<<<PATH>>>/media/sprites.png) no-repeat -48px -16px !important;",
"}",".blocklyToolboxDiv {","  background-color: #ddd;","  display: none;","  overflow-x: visible;","  overflow-y: auto;","  position: absolute;","}",".blocklyTreeRoot {","  padding: 4px 0;","}",".blocklyTreeRoot:focus {","  outline: none;","}",".blocklyTreeRow {","  line-height: 22px;","  height: 22px;","  padding-right: 1em;","  white-space: nowrap;","}",'.blocklyToolboxDiv[dir="RTL"] .blocklyTreeRow {',"  padding-right: 0;","  padding-left: 1em !important;","}",".blocklyTreeRow:hover {","  background-color: #e4e4e4;",
"}",".blocklyTreeIcon {","  height: 16px;","  width: 16px;","  vertical-align: middle;","  background-image: url(<<<PATH>>>/media/sprites.png);","}",".blocklyTreeIconClosedLtr {","  background-position: -32px -1px;","}",".blocklyTreeIconClosedRtl {","  background-position: 0px -1px;","}",".blocklyTreeIconOpen {","  background-position: -16px -1px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedLtr {","  background-position: -32px -17px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedRtl {","  background-position: 0px -17px;",
"}",".blocklyTreeSelected>.blocklyTreeIconOpen {","  background-position: -16px -17px;","}",".blocklyTreeIconNone,",".blocklyTreeSelected>.blocklyTreeIconNone {","  background-position: -48px -1px;","}",".blocklyTreeLabel {","  cursor: default;","  font-family: sans-serif;","  font-size: 16px;","  padding: 0 3px;","  vertical-align: middle;","}",".blocklyTreeSelected  {","  background-color: #57e !important;","}",".blocklyTreeSelected .blocklyTreeLabel {","  color: #fff;","}",".blocklyWidgetDiv .goog-palette {",
"  outline: none;","  cursor: default;","}",".blocklyWidgetDiv .goog-palette-table {","  border: 1px solid #666;","  border-collapse: collapse;","}",".blocklyWidgetDiv .goog-palette-cell {","  height: 13px;","  width: 15px;","  margin: 0;","  border: 0;","  text-align: center;","  vertical-align: middle;","  border-right: 1px solid #666;","  font-size: 1px;","}",".blocklyWidgetDiv .goog-palette-colorswatch {","  position: relative;","  height: 13px;","  width: 15px;","  border: 1px solid #666;","}",
".blocklyWidgetDiv .goog-palette-cell-hover .goog-palette-colorswatch {","  border: 1px solid #FFF;","}",".blocklyWidgetDiv .goog-palette-cell-selected .goog-palette-colorswatch {","  border: 1px solid #000;","  color: #fff;","}",".blocklyWidgetDiv .goog-menu {","  background: #fff;","  border-color: #ccc #666 #666 #ccc;","  border-style: solid;","  border-width: 1px;","  cursor: default;","  font: normal 13px Arial, sans-serif;","  margin: 0;","  outline: none;","  padding: 4px 0;","  position: absolute;",
"  z-index: 20000;","}",".blocklyWidgetDiv .goog-menuitem {","  color: #000;","  font: normal 13px Arial, sans-serif;","  list-style: none;","  margin: 0;","  padding: 4px 7em 4px 28px;","  white-space: nowrap;","}",".blocklyWidgetDiv .goog-menuitem.goog-menuitem-rtl {","  padding-left: 7em;","  padding-right: 28px;","}",".blocklyWidgetDiv .goog-menu-nocheckbox .goog-menuitem,",".blocklyWidgetDiv .goog-menu-noicon .goog-menuitem {","  padding-left: 12px;","}",".blocklyWidgetDiv .goog-menu-noaccel .goog-menuitem {",
"  padding-right: 20px;","}",".blocklyWidgetDiv .goog-menuitem-content {","  color: #000;","  font: normal 13px Arial, sans-serif;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-accel,",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-content {","  color: #ccc !important;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-icon {","  opacity: 0.3;","  -moz-opacity: 0.3;","  filter: alpha(opacity=30);","}",".blocklyWidgetDiv .goog-menuitem-highlight,",".blocklyWidgetDiv .goog-menuitem-hover {",
"  background-color: #d6e9f8;","  border-color: #d6e9f8;","  border-style: dotted;","  border-width: 1px 0;","  padding-bottom: 3px;","  padding-top: 3px;","}",".blocklyWidgetDiv .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-icon {","  background-repeat: no-repeat;","  height: 16px;","  left: 6px;","  position: absolute;","  right: auto;","  vertical-align: middle;","  width: 16px;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-icon {",
"  left: auto;","  right: 6px;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(//ssl.gstatic.com/editor/editortoolbar.png) no-repeat -512px 0;","}",".blocklyWidgetDiv .goog-menuitem-accel {","  color: #999;","  direction: ltr;","  left: auto;","  padding: 0 6px;","  position: absolute;","  right: 0;","  text-align: right;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-accel {","  left: 0;",
"  right: auto;","  text-align: left;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-hint {","  text-decoration: underline;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-separator {","  color: #999;","  font-size: 12px;","  padding-left: 4px;","}",".blocklyWidgetDiv .goog-menuseparator {","  border-top: 1px solid #ccc;","  margin: 4px 0;","  padding: 0;","}",""];/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Dl(a,b){function c(){El(a);Fl()}if(!jc(document,a))throw"Error: container is not in current document.";b&&Gl(b);if(Lc){var d=document.getElementById("realtime");d&&(d.style.display="block");kl(c,a)}else c()}
function Gl(a){var b=!!a.readOnly;if(b)var c=!1,d=!1,e=!1,f=!1,h=!1,k=null;else(c=a.toolbox)?("string"!=typeof c&&"undefined"==typeof XSLTProcessor&&(c=c.outerHTML),"string"==typeof c&&(c=$c(c))):c=null,k=c,c=Boolean(k&&k.getElementsByTagName("category").length),d=a.trashcan,void 0===d&&(d=c),e=a.collapse,void 0===e&&(e=c),f=a.comments,void 0===f&&(f=c),h=a.disable,void 0===h&&(h=c);if(k&&!c)var m=!1;else m=a.scrollbars,void 0===m&&(m=!0);var p=a.sounds;void 0===p&&(p=!0);var q=!!a.realtime,u=q?a.realtimeOptions:
void 0;C=!!a.rtl;Ic=e;Hc=f;Jc=h;F=b;Nc=a.maxBlocks||Infinity;me=a.path||"./";Oc=c;Pc=m;Fc=d;Qc=p;Kc=k;Lc=q;Mc=u}
function El(a){a.setAttribute("dir","LTR");$e=C;Bl();var b=H("svg",{xmlns:"http://www.w3.org/2000/svg","xmlns:html":"http://www.w3.org/1999/xhtml","xmlns:xlink":"http://www.w3.org/1999/xlink",version:"1.1","class":"blocklySvg"},null),c=H("defs",{},b),d,e;d=H("filter",{id:"blocklyEmboss"},c);H("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:1,result:"blur"},d);e=H("feSpecularLighting",{"in":"blur",surfaceScale:1,specularConstant:.5,specularExponent:10,"lighting-color":"white",result:"specOut"},d);
H("fePointLight",{x:-5E3,y:-1E4,z:2E4},e);H("feComposite",{"in":"specOut",in2:"SourceAlpha",operator:"in",result:"specOut"},d);H("feComposite",{"in":"SourceGraphic",in2:"specOut",operator:"arithmetic",k1:0,k2:1,k3:1,k4:0},d);d=H("filter",{id:"blocklyTrashcanShadowFilter"},c);H("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:2,result:"blur"},d);H("feOffset",{"in":"blur",dx:1,dy:1,result:"offsetBlur"},d);d=H("feMerge",{},d);H("feMergeNode",{"in":"offsetBlur"},d);H("feMergeNode",{"in":"SourceGraphic"},
d);d=H("filter",{id:"blocklyShadowFilter"},c);H("feGaussianBlur",{stdDeviation:2},d);c=H("pattern",{id:"blocklyDisabledPattern",patternUnits:"userSpaceOnUse",width:10,height:10},c);H("rect",{width:10,height:10,fill:"#aaa"},c);H("path",{d:"M 0 0 L 10 10 M 10 0 L 0 10",stroke:"#cc0"},c);y=new pe(Hl,Il);b.appendChild(y.I());y.qg=Nc;F||(Oc?ok(b,a):(y.qa=new Ph,c=y.qa,d=c.I(),c.sd=!1,ic(d),Jl(function(){if(0==Be){var a=y.Ub();if(0>a.qb||a.qb+a.Va>a.za+a.Mb||a.Qb<(C?a.Oa:0)||a.Qb+a.Wc>(C?a.V:a.V+a.Oa))for(var b=
Wc(y,!1),c=0,d;d=b[c];c++){var e=D(d),q=vg(d),u=a.Mb+25-q.height-e.y;0<u&&d.moveBy(0,u);u=a.Mb+a.za-25-e.y;0>u&&d.moveBy(0,u);u=25+a.Oa-e.x-(C?0:q.width);0<u&&d.moveBy(u,0);u=a.Oa+a.V-25-e.x+(C?q.width:0);0>u&&d.moveBy(u,0);d.ec&&!F&&50<(C?e.x-a.V:-e.x)&&d.i(!1,!0)}}})));b.appendChild(yi());a.appendChild(b);Gc=b;Ui();ah=dc("div","blocklyWidgetDiv");ah.style.direction=C?"rtl":"ltr";document.body.appendChild(ah)}
function Fl(){K(Gc,"mousedown",null,Kl);K(Gc,"contextmenu",null,Ll);K(ah,"contextmenu",null,Ll);Rc||(K(window,"resize",document,Ui),K(document,"keydown",null,Ml),document.addEventListener("mouseup",Nl,!1),Gb&&K(window,"orientationchange",document,function(){De(window,"resize")}),Rc=!0);if(Kc)if(Oc)pk();else{y.qa.o(y);y.qa.show(Kc.childNodes);y.scrollX=y.qa.O;C&&(y.scrollX*=-1);var a="translate("+y.scrollX+", 0)";y.Q.setAttribute("transform",a);y.jd.setAttribute("transform",a)}Pc&&(y.qc=new od(y),
y.qc.resize());se();if(Qc){Ol(["media/click.mp3","media/click.wav","media/click.ogg"],"click");Ol(["media/delete.mp3","media/delete.ogg","media/delete.wav"],"delete");var b=[],a=function(){for(;b.length;)J(b.pop());for(var a in Pl){var d=Pl[a];d.volume=.01;d.play();d.pause();if(Gb||Fb)break}};b.push(K(document,"mousemove",null,a));b.push(K(document,"touchstart",null,a))}};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var ah=null,Yg=null,Ql=null;function Xg(a,b){Zg();Yg=a;Ql=b;ah.style.display="block"}function Zg(){Yg&&(ah.style.display="none",Ql&&Ql(),Ql=Yg=null,hc(ah))}function bh(a,b,c,d){b<d.y&&(b=d.y);C?a>c.width+d.x&&(a=c.width+d.x):a<d.x&&(a=d.x);ah.style.left=a+"px";ah.style.top=b+"px"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Rl(a,b){var c;if(b){var d=this;c=function(a){a=Sl.call(d,a);null!==a&&b.call(d,a);return a}}else c=Sl;this.Tg=H("tspan",{},null);this.Tg.appendChild(document.createTextNode("\u00b0"));Rl.m.constructor.call(this,a,c)}s(Rl,ol);Rl.prototype.clone=function(){return new Rl(this.Ea(),this.Ia)};
Rl.prototype.sf=function(){Rl.m.sf.call(this,Jb||Eb||Gb);var a=ah;if(a.firstChild){var a=H("svg",{xmlns:"http://www.w3.org/2000/svg","xmlns:html":"http://www.w3.org/1999/xhtml","xmlns:xlink":"http://www.w3.org/1999/xlink",version:"1.1",height:"100px",width:"100px"},a),b=H("circle",{cx:50,cy:50,r:49,"class":"blocklyAngleCircle"},a);this.Ad=H("path",{"class":"blocklyAngleGauge"},a);this.Ve=H("line",{x1:50,y1:50,"class":"blocklyAngleLine"},a);for(var c=0;360>c;c+=15)H("line",{x1:99,y1:50,x2:99-(0==c%
45?10:5),y2:50,"class":"blocklyAngleMarks",transform:"rotate("+c+", 50, 50)"},a);a.style.marginLeft="-35px";K(a,"click",this,Zg);K(b,"mousemove",this,this.df);K(this.Ad,"mousemove",this,this.df);Tl(this)}};Rl.prototype.df=function(a){var b=this.Ad.ownerSVGElement.getBoundingClientRect(),c=a.clientX-b.left-50;a=a.clientY-b.top-50;b=Math.atan(-a/c);isNaN(b)||(b=b/Math.PI*180,0>c?b+=180:0<a&&(b+=360),b=15*Math.round(b/15),360<=b&&(b-=360),b=String(b),pl.value=b,this.T(b))};
Rl.prototype.T=function(a){Rl.m.T.call(this,a);Tl(this);C?this.ma.insertBefore(this.Tg,this.ma.firstChild):this.ma.appendChild(this.Tg);this.hd.width=0};function Tl(a){if(a.Ad){var b=Number(a.Ea())/180*Math.PI;if(isNaN(b))a.Ad.setAttribute("d","M 50, 50"),a.Ve.setAttribute("x2",50),a.Ve.setAttribute("y2",50);else{var c=50+49*Math.cos(b),d=50+-49*Math.sin(b);a.Ad.setAttribute("d","M 50, 50 h 49 A 49,49 0 "+(b>Math.PI?1:0)+" 0 "+c+","+d+" z");a.Ve.setAttribute("x2",c);a.Ve.setAttribute("y2",d)}}}
function Sl(a){a=tl(a);null!==a&&(a%=360,0>a&&(a+=360),a=String(a));return a};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var me="./",ke=64,le=92,ne="media/sprites.png",Xh=[,2,1,4,3],Pl=Object.create(null),L=null,F=!1,Uh=null,Vh=null,jj=5,zh=20,$h=250,kj=30,y=null,Ul=null,Vl=null;function Gi(){return{width:Gc.rh,height:Gc.qh}}function Ui(){var a=Gc,b=a.parentNode,c=b.offsetWidth,b=b.offsetHeight;a.rh!=c&&(a.setAttribute("width",c+"px"),a.rh=c);a.qh!=b&&(a.setAttribute("height",b+"px"),a.qh=b);y.qc&&y.qc.resize()}
function Kl(a){Ui();Ri();zd();var b=a.target&&a.target.nodeName&&"svg"==a.target.nodeName.toLowerCase();!F&&L&&b&&Ce();a.target==Gc&&vd(a)?Wl(a):(F||b)&&y.qc&&(y.Vf=!0,y.Pg=a.clientX,y.Qg=a.clientY,y.Zk=y.Ub(),y.al=y.scrollX,y.bl=y.scrollY,"mouseup"in Ik&&(Vl=K(document,"mouseup",null,Nl)),Sc=K(document,"mousemove",null,Xl))}function Nl(){Lh(!1);y.Vf=!1;Vl&&(J(Vl),Vl=null);Sc&&(J(Sc),Sc=null)}
function Xl(a){if(y.Vf){yd();var b=y.Zk,c=y.al+(a.clientX-y.Pg),d=y.bl+(a.clientY-y.Qg),c=Math.min(c,-b.Qb),d=Math.min(d,-b.qb),c=Math.max(c,b.V-b.Qb-b.Wc),d=Math.max(d,b.za-b.qb-b.Va);y.qc.set(-c-b.Qb,-d-b.qb);a.stopPropagation()}}
function Ml(a){if(!Kh(a))if(27==a.keyCode)zd();else if(8==a.keyCode||46==a.keyCode)try{L&&L.ec&&!F&&(zd(),L.i(!0,!0))}finally{a.preventDefault()}else if(a.altKey||a.ctrlKey||a.metaKey)if(L&&L.ec&&!F&&L.Ib&&!F&&L.u==y&&(zd(),67==a.keyCode?Yl():88==a.keyCode&&(Yl(),L.i(!0,!0))),86==a.keyCode&&Ul){a=y;var b=Ul;if(!(b.getElementsByTagName("block").length>=Ee(a))){var c=bd(a,b),d=parseInt(b.getAttribute("x"),10),b=parseInt(b.getAttribute("y"),10);if(!isNaN(d)&&!isNaN(b)){C&&(d=-d);do for(var e=!1,f=xe(a),
h=0,k;k=f[h];h++)k=D(k),1>=Math.abs(d-k.x)&&1>=Math.abs(b-k.y)&&(d=C?d-zh:d+zh,b+=2*zh,e=!0);while(e);c.moveBy(d,b)}c.select()}}}function Ri(){Oi&&(J(Oi),Oi=null);Pi&&(J(Pi),Pi=null);var a=L;if(2==Be&&a){var b=D(a);di(a,b.x-a.Oi,b.y-a.Pi);delete a.we;ij(a,!1);a.v();ie(a.Pa,$h,a);De(window,"resize")}a&&re(a.u);Be=0;Ej()}function Yl(){var a=L,b=Xc(a);nd(b);a=D(a);b.setAttribute("x",C?-a.x:a.x);b.setAttribute("y",a.y);Ul=b}
function Wl(a){if(!F){var b=[];if(Ic){for(var c=!1,d=!1,e=Wc(y,!1),f=0;f<e.length;f++)for(var h=e[f];h;)h.isCollapsed()?c=!0:d=!0,h=Yc(h);d={enabled:d};d.text=Zl;d.pb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Sd.bind(c,!0),a),c=Yc(c),a+=10};b.push(d);c={enabled:c};c.text=$l;c.pb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Sd.bind(c,!1),a),c=Yc(c),a+=10};b.push(c)}yh.show(a,b)}}function Ll(a){Kh(a)||a.preventDefault()}
function zd(a){Ci();Zg();!a&&kk&&kk.sd&&lk.Qc(null)}function yd(){if(window.getSelection){var a=window.getSelection();a&&a.removeAllRanges&&(a.removeAllRanges(),window.setTimeout(function(){try{window.getSelection().removeAllRanges()}catch(a){}},0))}}function Kh(a){return"textarea"==a.target.type||"text"==a.target.type}
function Ol(a,b){if(window.Audio&&a.length){for(var c,d=new window.Audio,e=0;e<a.length;e++){var f=a[e],h=f.match(/\.(\w+)$/);if(h&&d.canPlayType("audio/"+h[1])){c=new window.Audio(me+f);break}}c&&c.play&&(Pl[b]=c)}}function Qi(a,b){var c=Pl[a];c&&(c=Rb&&9===Rb||Gb||Eb?c:c.cloneNode(),c.volume=void 0===b?1:b,c.play())}function Lh(a){if(!F){var b="";a&&(b="url("+me+"media/handclosed.cur) 7 3, auto");L&&(O(L).style.cursor=b);Gc.style.cursor=b}}
function Hl(){var a=Gi();a.width-=mk;var b=a.width-I,c=a.height-I;try{var d=y.Q.getBBox()}catch(e){return null}if(y.qc)var f=Math.min(d.x-b/2,d.x+d.width-b),b=Math.max(d.x+d.width+b/2,d.x+b),h=Math.min(d.y-c/2,d.y+d.height-c),c=Math.max(d.y+d.height+c/2,d.y+c);else f=d.x,b=f+d.width,h=d.y,c=h+d.height;return{za:a.height,V:a.width,Va:c-h,Wc:b-f,Mb:-y.scrollY,Oa:-y.scrollX,qb:h,Qb:f,gb:0,fb:C?0:mk}}
function Il(a){if(!y.qc)throw"Attempt to set main workspace scroll without scrollbars.";var b=Hl();ga(a.x)&&(y.scrollX=-b.Wc*a.x-b.Qb);ga(a.y)&&(y.scrollY=-b.Va*a.y-b.qb);a="translate("+(y.scrollX+b.fb)+","+(y.scrollY+b.gb)+")";y.Q.setAttribute("transform",a);y.jd.setAttribute("transform",a)}function Wi(a){a()}function Jl(a){return K(y.Q,"blocklyWorkspaceChange",null,a)}window.Blockly||(window.Blockly={});window.Blockly.getMainWorkspace=function(){return y};window.Blockly.addChangeListener=Jl;
window.Blockly.removeChangeListener=function(a){J(a)};var Zi="Add Comment",ml="Please authorize this app to enable your work to be saved and to allow it to be shared by you.",ql="Change value:",jl="Chat with your collaborator by typing in this box!",Zl="Collapse Blocks",cj="Collapse Block",fj="Delete Block",gj="Delete %1 Blocks",ej="Disable Block",Xi="Duplicate",dj="Enable Block",$l="Expand Blocks",bj="Expand Block",$i="External Inputs",hj="Help",aj="Inline Inputs",nl="Me",Ck="New variable...",Ek="New variable name:",Yi="Remove Comment",Bk="Rename variable...",
Dk="Rename all '%1' variables to:";function am(a,b){var c;c=a.className;for(var d=c=n(c)&&c.match(/\S+/g)||[],e=bb(arguments,1),f=0;f<e.length;f++)Ya(d,e[f])||d.push(e[f]);a.className=c.join(" ")};var bm={ace:"\u0628\u0647\u0633\u0627 \u0627\u0686\u064a\u0647",af:"Afrikaans",ar:"\u0627\u0644\u0639\u0631\u0628\u064a\u0629",az:"Az\u0259rbaycanca","be-tarask":"Tara\u0161kievica",br:"Brezhoneg",ca:"Catal\u00e0",cdo:"\u95a9\u6771\u8a9e",cs:"\u010cesky",da:"Dansk",de:"Deutsch",el:"\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac",en:"English",es:"Espa\u00f1ol",eu:"Euskara",fa:"\u0641\u0627\u0631\u0633\u06cc",fi:"Suomi",fo:"F\u00f8royskt",fr:"Fran\u00e7ais",frr:"Frasch",gl:"Galego",hak:"\u5ba2\u5bb6\u8a71",
he:"\u05e2\u05d1\u05e8\u05d9\u05ea",hi:"\u0939\u093f\u0928\u094d\u0926\u0940",hrx:"Hunsrik",hu:"Magyar",ia:"Interlingua",id:"Bahasa Indonesia",is:"\u00cdslenska",it:"Italiano",ja:"\u65e5\u672c\u8a9e",ka:"\u10e5\u10d0\u10e0\u10d7\u10e3\u10da\u10d8",km:"\u1797\u17b6\u179f\u17b6\u1781\u17d2\u1798\u17c2\u179a",ko:"\ud55c\uad6d\uc5b4",ksh:"Ripoar\u0117sch",ky:"\u041a\u044b\u0440\u0433\u044b\u0437\u0447\u0430",la:"Latine",lb:"L\u00ebtzebuergesch",lt:"Lietuvi\u0173",lv:"Latvie\u0161u",mg:"Malagasy",ml:"\u0d2e\u0d32\u0d2f\u0d3e\u0d33\u0d02",
mk:"\u041c\u0430\u043a\u0435\u0434\u043e\u043d\u0441\u043a\u0438",mr:"\u092e\u0930\u093e\u0920\u0940",ms:"Bahasa Melayu",mzn:"\u0645\u0627\u0632\u0650\u0631\u0648\u0646\u06cc",nb:"Norsk Bokm\u00e5l",nl:"Nederlands, Vlaams",oc:"Lenga d'\u00f2c",pa:"\u092a\u0902\u091c\u093e\u092c\u0940",pl:"Polski",pms:"Piemont\u00e8is",ps:"\u067e\u069a\u062a\u0648",pt:"Portugu\u00eas","pt-br":"Portugu\u00eas Brasileiro",ro:"Rom\u00e2n\u0103",ru:"\u0420\u0443\u0441\u0441\u043a\u0438\u0439",sc:"Sardu",sco:"Scots",si:"\u0dc3\u0dd2\u0d82\u0dc4\u0dbd",
sk:"Sloven\u010dina",sr:"\u0421\u0440\u043f\u0441\u043a\u0438",sv:"Svenska",sw:"Kishwahili",th:"\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22",tl:"Tagalog",tlh:"tlhIngan Hol",tr:"T\u00fcrk\u00e7e",uk:"\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430",vi:"Ti\u1ebfng Vi\u1ec7t","zh-hans":"\u7c21\u9ad4\u4e2d\u6587","zh-hant":"\u6b63\u9ad4\u4e2d\u6587"},cm="ace ar fa he mzn ps".split(" "),Cc=window.BlocklyGamesLang,dm=window.BlocklyGamesLanguages,Dc=!!window.location.pathname.match(/\.html$/);
function em(a,b){var c=window.location.search.match(new RegExp("[?&]"+a+"=([^&]+)"));return c?decodeURIComponent(c[1].replace(/\+/g,"%20")):b}var B,fm=Number(em("level","NaN"));B=isNaN(fm)?1:Math.min(Math.max(1,fm),10);
function gm(){document.title=document.getElementById("title").textContent;document.head.parentElement.setAttribute("dir",-1!=cm.indexOf(Cc)?"rtl":"ltr");document.head.parentElement.setAttribute("lang",Cc);for(var a=[],b=0;b<dm.length;b++){var c=dm[b];a.push([bm[c],c])}a.sort(function(a,b){return a[0]>b[0]?1:a[0]<b[0]?-1:0});for(var d=document.getElementById("languageMenu"),b=d.options.length=0;b<a.length;b++){var e=a[b],c=e[1],e=new Option(e[0],c);c==Cc&&(e.selected=!0);d.options.add(e)}1>=d.options.length&&
(d.style.display="none");for(b=1;10>=b;b++)a=document.getElementById("level"+b),c=!!hm(b),a&&c&&am(a,"level_done");(b=document.querySelector('meta[name="viewport"]'))&&725>screen.availWidth&&b.setAttribute("content","width=725, initial-scale=.35, user-scalable=no");setTimeout(im,1)}function hm(a){var b=jm,c;try{c=window.localStorage[b+a]}catch(d){}return c}
function km(a){var b;(b=document.getElementById(a))?(b=b.textContent,b=b.replace(/\\n/g,"\n")):b=null;return null===b?"[Unknown message: "+a+"]":b}function lm(a,b){"string"==typeof a&&(a=document.getElementById(a));a.addEventListener("click",b,!0);a.addEventListener("touchend",b,!0)}
function im(){if(!Dc){window.GoogleAnalyticsObject="GoogleAnalyticsFunction";var a=function(){(a.q=a.q||[]).push(arguments)};window.GoogleAnalyticsFunction=a;a.l=1*new Date;var b=document.createElement("script");b.async=1;b.src="//www.google-analytics.com/analytics.js";document.head.appendChild(b);a("create","UA-50448074-1","auto");a("send","pageview")}};var Y={Xc:null,o:function(){gm();var a=document.getElementById("linkButton");"BlocklyStorage"in window?(BlocklyStorage.HTTPREQUEST_ERROR=km("Games_httpRequestError"),BlocklyStorage.LINK_ALERT=km("Games_linkAlert"),BlocklyStorage.HASH_ERROR=km("Games_hashError"),BlocklyStorage.XML_ERROR=km("Games_xmlError"),BlocklyStorage.alert=uc.dl,a&&lm(a,BlocklyStorage.link)):a&&(a.style.display="none");document.getElementById("languageMenu").addEventListener("change",Y.vj,!0)},bm:function(a){document.body.innerHTML=
a;a=document.getElementById("blockly");a.style.height=window.innerHeight+"px";Dl(a,{path:"./",readOnly:!0,jm:-1!=cm.indexOf(Cc),scrollbars:!1});a=em("xml","");Y.Ig("<xml>"+a+"</xml>")},rk:function(a,b){if("BlocklyStorage"in window&&1<window.location.hash.length)BlocklyStorage.retrieveXml(window.location.hash.substring(1));else{var c=null;try{c=window.sessionStorage.li}catch(d){}c&&delete window.sessionStorage.li;var e=hm(B),f=b&&hm(B-1);(c=c||e||f||a)&&Y.Ig(c)}},Ig:function(a){Y.Xc?Y.Xc.setValue(a,
-1):(a=$c(a),ad(y,a))},Uk:function(){if(void 0!=typeof Ec&&window.localStorage){var a=jm+B;if(Y.Xc)var b=Y.Xc.getValue();else b=Vc(y),b=Zc(b);window.localStorage[a]=b}},Oe:function(){window.location=(Dc?"index.html":"./")+"?lang="+Cc},vj:function(){if(window.sessionStorage){if(Y.Xc)var a=Y.Xc.getValue();else a=Vc(y),a=Zc(a);window.sessionStorage.li=a}var a=document.getElementById("languageMenu"),a=encodeURIComponent(a.options[a.selectedIndex].value),b=window.location.search,b=1>=b.length?"?lang="+
a:b.match(/[?&]lang=[^&]*/)?b.replace(/([?&]lang=)[^&]*/,"$1"+a):b.replace(/\?/,"?lang="+a+"&");window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+b},Ke:function(a){if(a){var b=a.match(/^block_id_(\d+)$/);b&&(a=b[1])}Ae(a)},fl:function(a){return a.replace(/(,\s*)?'block_id_\d+'\)/g,")").trimRight()},Cb:function(a){if("click"==a.type&&"touchend"==Y.Cb.Ag&&Y.Cb.zg+2E3>Date.now()||Y.Cb.Ag==a.type&&Y.Cb.zg+400>Date.now())return a.preventDefault(),a.stopPropagation(),
!0;Y.Cb.Ag=a.type;Y.Cb.zg=Date.now();return!1}};Y.Cb.Ag=null;Y.Cb.zg=0;Y.jk=function(){var a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","js-read-only/JS-Interpreter/compiled.js");document.head.appendChild(a)};
Y.kk=function(){var a=document.createElement("link");a.setAttribute("rel","stylesheet");a.setAttribute("type","text/css");a.setAttribute("href","common/prettify.css");document.head.appendChild(a);a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","common/prettify.js");document.head.appendChild(a)};window.BlocklyInterface=Y;Y.setCode=Y.Ig;var Z={Hc:!1,Nh:null,ue:null,rf:function(a,b,c,d,e,f){function h(){Z.Hc&&(k.style.visibility="visible",k.style.zIndex=10,m.style.visibility="hidden")}Z.Hc&&Z.Eb(!1);zd(!0);Z.Hc=!0;Z.Nh=b;Z.ue=f;var k=document.getElementById("dialog");f=document.getElementById("dialogShadow");var m=document.getElementById("dialogBorder"),p;for(p in e)k.style[p]=e[p];d&&(f.style.visibility="visible",f.style.opacity=.3,f.style.zIndex=9,d=document.createElement("div"),d.id="dialogHeader",k.appendChild(d),Z.Qf=K(d,"mousedown",
null,Z.Mj));k.appendChild(a);a.className=a.className.replace("dialogHiddenContent","");c&&b?(Z.We(b,!1,.2),Z.We(k,!0,.8),setTimeout(h,175)):h()},Oh:0,Ph:0,Mj:function(a){Z.Tf();if(!vd(a)){var b=document.getElementById("dialog");Z.Oh=b.offsetLeft-a.clientX;Z.Ph=b.offsetTop-a.clientY;Z.Sf=K(document,"mouseup",null,Z.Tf);Z.Rf=K(document,"mousemove",null,Z.Nj);a.stopPropagation()}},Nj:function(a){var b=document.getElementById("dialog"),c=Z.Oh+a.clientX;a=Z.Ph+a.clientY;a=Math.max(a,0);a=Math.min(a,window.innerHeight-
b.offsetHeight);c=Math.max(c,0);c=Math.min(c,window.innerWidth-b.offsetWidth);b.style.left=c+"px";b.style.top=a+"px"},Tf:function(){Z.Sf&&(J(Z.Sf),Z.Sf=null);Z.Rf&&(J(Z.Rf),Z.Rf=null)},Eb:function(a){function b(){d.style.zIndex=-1;d.style.visibility="hidden";document.getElementById("dialogBorder").style.visibility="hidden"}if(Z.Hc){Z.Tf();Z.Qf&&(J(Z.Qf),Z.Qf=null);Z.Hc=!1;Z.ue&&Z.ue();Z.ue=null;var c=!1===a?null:Z.Nh;a=document.getElementById("dialog");var d=document.getElementById("dialogShadow");
d.style.opacity=0;c?(Z.We(a,!1,.8),Z.We(c,!0,.2),setTimeout(b,175)):b();a.style.visibility="hidden";a.style.zIndex=-1;for((c=document.getElementById("dialogHeader"))&&c.parentNode.removeChild(c);a.firstChild;)c=a.firstChild,c.className+=" dialogHiddenContent",document.body.appendChild(c)}},We:function(a,b,c){function d(){e.style.width=f.width+"px";e.style.height=f.height+"px";e.style.left=f.x+"px";e.style.top=f.y+"px";e.style.opacity=c}if(a){var e=document.getElementById("dialogBorder"),f=Z.Sj(a);
b?(e.className="dialogAnimate",setTimeout(d,1)):(e.className="",d());e.style.visibility="visible"}},Sj:function(a){if(a.getBBox){var b=a.getBBox(),c=b.height,b=b.width;a=$g(a);var d=a.x,e=a.y}else{c=a.offsetHeight;b=a.offsetWidth;e=d=0;do d+=a.offsetLeft,e+=a.offsetTop,a=a.offsetParent;while(a)}return{height:c,width:b,x:d,y:e}},dl:function(a){var b=document.getElementById("containerStorage");b.textContent="";a=a.split("\n");for(var c=0;c<a.length;c++){var d=document.createElement("p");d.appendChild(document.createTextNode(a[c]));
b.appendChild(d)}b=document.getElementById("dialogStorage");a=document.getElementById("linkButton");Z.rf(b,a,!0,!0,{width:"50%",left:"25%",top:"5em"},Z.cl);Z.Xk()},jh:function(){if(!hm(B))if(Z.Hc||0!=Be)setTimeout(Z.jh,15E3);else{var a=document.getElementById("dialogAbort"),b=document.getElementById("abortCancel");b.addEventListener("click",Z.Eb,!0);b.addEventListener("touchend",Z.Eb,!0);b=document.getElementById("abortOk");b.addEventListener("click",Y.Oe,!0);b.addEventListener("touchend",Y.Oe,!0);
Z.rf(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},function(){document.body.removeEventListener("keydown",Z.ih,!0)});document.body.addEventListener("keydown",Z.ih,!0)}},yj:function(){var a=document.getElementById("dialogDone");if(y){var b=document.getElementById("dialogLinesText");b.textContent="";var c=vl(),c=Y.fl(c),d=c.split("\n").length,e=document.getElementById("containerCode");e.textContent=c;"function"==typeof prettyPrintOne&&(c=e.innerHTML,c=prettyPrintOne(c,"js"),e.innerHTML=c);c=1==d?
km("Games_linesOfCode1"):km("Games_linesOfCode2").replace("%1",d);b.appendChild(document.createTextNode(c))}c=10>B?km("Games_nextLevel").replace("%1",B+1):km("Games_finalLevel");b=document.getElementById("doneCancel");b.addEventListener("click",Z.Eb,!0);b.addEventListener("touchend",Z.Eb,!0);b=document.getElementById("doneOk");b.addEventListener("click",Y.sg,!0);b.addEventListener("touchend",Y.sg,!0);Z.rf(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},function(){document.body.removeEventListener("keydown",
Z.wh,!0)});document.body.addEventListener("keydown",Z.wh,!0);document.getElementById("dialogDoneText").textContent=c},Mh:function(a){!Z.Hc||13!=a.keyCode&&27!=a.keyCode&&32!=a.keyCode||(Z.Eb(!0),a.stopPropagation(),a.preventDefault())},Xk:function(){document.body.addEventListener("keydown",Z.Mh,!0)},cl:function(){document.body.removeEventListener("keydown",Z.Mh,!0)},wh:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)Z.Eb(!0),a.stopPropagation(),a.preventDefault(),27!=a.keyCode&&Y.sg()},
ih:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)Z.Eb(!0),a.stopPropagation(),a.preventDefault(),27!=a.keyCode&&Y.Oe()}};window.BlocklyDialogs=Z;Z.hideDialog=Z.Eb;/*

 Visual Blocks Language

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var W=new ul("JavaScript");zl("Blockly,break,case,catch,continue,debugger,default,delete,do,else,finally,for,function,if,in,instanceof,new,return,switch,this,throw,try,typeof,var,void,while,with,class,enum,export,extends,import,super,implements,interface,let,package,private,protected,public,static,yield,const,null,true,false,Array,ArrayBuffer,Boolean,Date,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Error,eval,EvalError,Float32Array,Float64Array,Function,Infinity,Int16Array,Int32Array,Int8Array,isFinite,isNaN,Iterator,JSON,Math,NaN,Number,Object,parseFloat,parseInt,RangeError,ReferenceError,RegExp,StopIteration,String,SyntaxError,TypeError,Uint16Array,Uint32Array,Uint8Array,Uint8ClampedArray,undefined,uneval,URIError,applicationCache,closed,Components,content,_content,controllers,crypto,defaultStatus,dialogArguments,directories,document,frameElement,frames,fullScreen,globalStorage,history,innerHeight,innerWidth,length,location,locationbar,localStorage,menubar,messageManager,mozAnimationStartTime,mozInnerScreenX,mozInnerScreenY,mozPaintCount,name,navigator,opener,outerHeight,outerWidth,pageXOffset,pageYOffset,parent,performance,personalbar,pkcs11,returnValue,screen,screenX,screenY,scrollbars,scrollMaxX,scrollMaxY,scrollX,scrollY,self,sessionStorage,sidebar,status,statusbar,toolbar,top,URL,window,addEventListener,alert,atob,back,blur,btoa,captureEvents,clearImmediate,clearInterval,clearTimeout,close,confirm,disableExternalCapture,dispatchEvent,dump,enableExternalCapture,escape,find,focus,forward,GeckoActiveXObject,getAttention,getAttentionWithCycleCount,getComputedStyle,getSelection,home,matchMedia,maximize,minimize,moveBy,moveTo,mozRequestAnimationFrame,open,openDialog,postMessage,print,prompt,QueryInterface,releaseEvents,removeEventListener,resizeBy,resizeTo,restore,routeEvent,scroll,scrollBy,scrollByLines,scrollByPages,scrollTo,setCursor,setImmediate,setInterval,setResizable,setTimeout,showModalDialog,sizeToContent,stop,unescape,updateCommands,XPCNativeWrapper,XPCSafeJSObjectWrapper,onabort,onbeforeunload,onblur,onchange,onclick,onclose,oncontextmenu,ondevicemotion,ondeviceorientation,ondragdrop,onerror,onfocus,onhashchange,onkeydown,onkeypress,onkeyup,onload,onmousedown,onmousemove,onmouseout,onmouseover,onmouseup,onmozbeforepaint,onpaint,onpopstate,onreset,onresize,onscroll,onselect,onsubmit,onunload,onpageshow,onpagehide,Image,Option,Worker,Event,Range,File,FileReader,Blob,BlobBuilder,Attr,CDATASection,CharacterData,Comment,console,DocumentFragment,DocumentType,DomConfiguration,DOMError,DOMErrorHandler,DOMException,DOMImplementation,DOMImplementationList,DOMImplementationRegistry,DOMImplementationSource,DOMLocator,DOMObject,DOMString,DOMStringList,DOMTimeStamp,DOMUserData,Entity,EntityReference,MediaQueryList,MediaQueryListListener,NameList,NamedNodeMap,Node,NodeFilter,NodeIterator,NodeList,Notation,Plugin,PluginArray,ProcessingInstruction,SharedWorker,Text,TimeRanges,Treewalker,TypeInfo,UserDataHandler,Worker,WorkerGlobalScope,HTMLDocument,HTMLElement,HTMLAnchorElement,HTMLAppletElement,HTMLAudioElement,HTMLAreaElement,HTMLBaseElement,HTMLBaseFontElement,HTMLBodyElement,HTMLBRElement,HTMLButtonElement,HTMLCanvasElement,HTMLDirectoryElement,HTMLDivElement,HTMLDListElement,HTMLEmbedElement,HTMLFieldSetElement,HTMLFontElement,HTMLFormElement,HTMLFrameElement,HTMLFrameSetElement,HTMLHeadElement,HTMLHeadingElement,HTMLHtmlElement,HTMLHRElement,HTMLIFrameElement,HTMLImageElement,HTMLInputElement,HTMLKeygenElement,HTMLLabelElement,HTMLLIElement,HTMLLinkElement,HTMLMapElement,HTMLMenuElement,HTMLMetaElement,HTMLModElement,HTMLObjectElement,HTMLOListElement,HTMLOptGroupElement,HTMLOptionElement,HTMLOutputElement,HTMLParagraphElement,HTMLParamElement,HTMLPreElement,HTMLQuoteElement,HTMLScriptElement,HTMLSelectElement,HTMLSourceElement,HTMLSpanElement,HTMLStyleElement,HTMLTableElement,HTMLTableCaptionElement,HTMLTableCellElement,HTMLTableDataCellElement,HTMLTableHeaderCellElement,HTMLTableColElement,HTMLTableRowElement,HTMLTableSectionElement,HTMLTextAreaElement,HTMLTimeElement,HTMLTitleElement,HTMLTrackElement,HTMLUListElement,HTMLUnknownElement,HTMLVideoElement,HTMLCanvasElement,CanvasRenderingContext2D,CanvasGradient,CanvasPattern,TextMetrics,ImageData,CanvasPixelArray,HTMLAudioElement,HTMLVideoElement,NotifyAudioAvailableEvent,HTMLCollection,HTMLAllCollection,HTMLFormControlsCollection,HTMLOptionsCollection,HTMLPropertiesCollection,DOMTokenList,DOMSettableTokenList,DOMStringMap,RadioNodeList,SVGDocument,SVGElement,SVGAElement,SVGAltGlyphElement,SVGAltGlyphDefElement,SVGAltGlyphItemElement,SVGAnimationElement,SVGAnimateElement,SVGAnimateColorElement,SVGAnimateMotionElement,SVGAnimateTransformElement,SVGSetElement,SVGCircleElement,SVGClipPathElement,SVGColorProfileElement,SVGCursorElement,SVGDefsElement,SVGDescElement,SVGEllipseElement,SVGFilterElement,SVGFilterPrimitiveStandardAttributes,SVGFEBlendElement,SVGFEColorMatrixElement,SVGFEComponentTransferElement,SVGFECompositeElement,SVGFEConvolveMatrixElement,SVGFEDiffuseLightingElement,SVGFEDisplacementMapElement,SVGFEDistantLightElement,SVGFEFloodElement,SVGFEGaussianBlurElement,SVGFEImageElement,SVGFEMergeElement,SVGFEMergeNodeElement,SVGFEMorphologyElement,SVGFEOffsetElement,SVGFEPointLightElement,SVGFESpecularLightingElement,SVGFESpotLightElement,SVGFETileElement,SVGFETurbulenceElement,SVGComponentTransferFunctionElement,SVGFEFuncRElement,SVGFEFuncGElement,SVGFEFuncBElement,SVGFEFuncAElement,SVGFontElement,SVGFontFaceElement,SVGFontFaceFormatElement,SVGFontFaceNameElement,SVGFontFaceSrcElement,SVGFontFaceUriElement,SVGForeignObjectElement,SVGGElement,SVGGlyphElement,SVGGlyphRefElement,SVGGradientElement,SVGLinearGradientElement,SVGRadialGradientElement,SVGHKernElement,SVGImageElement,SVGLineElement,SVGMarkerElement,SVGMaskElement,SVGMetadataElement,SVGMissingGlyphElement,SVGMPathElement,SVGPathElement,SVGPatternElement,SVGPolylineElement,SVGPolygonElement,SVGRectElement,SVGScriptElement,SVGStopElement,SVGStyleElement,SVGSVGElement,SVGSwitchElement,SVGSymbolElement,SVGTextElement,SVGTextPathElement,SVGTitleElement,SVGTRefElement,SVGTSpanElement,SVGUseElement,SVGViewElement,SVGVKernElement,SVGAngle,SVGColor,SVGICCColor,SVGElementInstance,SVGElementInstanceList,SVGLength,SVGLengthList,SVGMatrix,SVGNumber,SVGNumberList,SVGPaint,SVGPoint,SVGPointList,SVGPreserveAspectRatio,SVGRect,SVGStringList,SVGTransform,SVGTransformList,SVGAnimatedAngle,SVGAnimatedBoolean,SVGAnimatedEnumeration,SVGAnimatedInteger,SVGAnimatedLength,SVGAnimatedLengthList,SVGAnimatedNumber,SVGAnimatedNumberList,SVGAnimatedPreserveAspectRatio,SVGAnimatedRect,SVGAnimatedString,SVGAnimatedTransformList,SVGPathSegList,SVGPathSeg,SVGPathSegArcAbs,SVGPathSegArcRel,SVGPathSegClosePath,SVGPathSegCurvetoCubicAbs,SVGPathSegCurvetoCubicRel,SVGPathSegCurvetoCubicSmoothAbs,SVGPathSegCurvetoCubicSmoothRel,SVGPathSegCurvetoQuadraticAbs,SVGPathSegCurvetoQuadraticRel,SVGPathSegCurvetoQuadraticSmoothAbs,SVGPathSegCurvetoQuadraticSmoothRel,SVGPathSegLinetoAbs,SVGPathSegLinetoHorizontalAbs,SVGPathSegLinetoHorizontalRel,SVGPathSegLinetoRel,SVGPathSegLinetoVerticalAbs,SVGPathSegLinetoVerticalRel,SVGPathSegMovetoAbs,SVGPathSegMovetoRel,ElementTimeControl,TimeEvent,SVGAnimatedPathData,SVGAnimatedPoints,SVGColorProfileRule,SVGCSSRule,SVGExternalResourcesRequired,SVGFitToViewBox,SVGLangSpace,SVGLocatable,SVGRenderingIntent,SVGStylable,SVGTests,SVGTextContentElement,SVGTextPositioningElement,SVGTransformable,SVGUnitTypes,SVGURIReference,SVGViewSpec,SVGZoomAndPan");
W.je=0;W.pd=1;W.Gl=1;W.Nb=2;W.El=3;W.Bl=3;W.bj=4;W.xl=4;W.Il=4;W.gh=4;W.Hl=4;W.Jl=4;W.Cl=4;W.dj=5;W.le=5;W.qd=5;W.bh=6;W.ej=6;W.zl=7;W.fh=8;W.Dl=8;W.Fl=8;W.dh=9;W.wl=10;W.Al=11;W.yl=12;W.eh=13;W.cj=14;W.ke=15;W.vl=16;W.ac=17;W.Ob=99;W.o=function(){W.ud=Object.create(null);W.Wh=Object.create(null);W.be?W.be.reset():W.be=new Tc(W.Bf);for(var a=[],b=vk(),c=0;c<b.length;c++)a[c]="var "+W.be.getName(b[c],xj)+";";W.ud.variables=a.join("\n")};
W.finish=function(a){var b=[],c;for(c in W.ud)b.push(W.ud[c]);return b.join("\n\n")+"\n\n\n"+a};W.Hi=function(a){return a+";\n"};W.fm=function(a){a=a.replace(/\\/g,"\\\\").replace(/\n/g,"\\\n").replace(/'/g,"\\'");return"'"+a+"'"};
W.Ii=function(a,b){var c="";if(!a.K||!a.K.t){var d=qj(a);d&&(c+=xl(d,"// ")+"\n");for(var e=0;e<a.S.length;e++)if(1==a.S[e].type){var f=E(a.S[e].p);if(f){for(var d=[],f=Rh(f),h=0;h<f.length;h++){var k=qj(f[h]);k&&d.push(k)}d.length&&d.push("");(d=d.join("\n"))&&(c+=xl(d,"// "))}}}e=wl(W,a.D&&E(a.D));return c+b+e};/*

 Visual Blocks Language

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
W.vk={};W.math_number=function(a){return[parseFloat(T(a,"NUM")),W.je]};W.math_arithmetic=function(a){var b={ADD:[" + ",W.bh],MINUS:[" - ",W.ej],MULTIPLY:[" * ",W.dj],DIVIDE:[" / ",W.le],POWER:[null,W.ac]}[T(a,"OP")],c=b[0],b=b[1],d=X(a,"A",b)||"0";a=X(a,"B",b)||"0";return c?[d+c+a,b]:["Math.pow("+d+", "+a+")",W.Nb]};
W.math_single=function(a){var b=T(a,"OP"),c;if("NEG"==b)return a=X(a,"NUM",W.gh)||"0","-"==a[0]&&(a=" "+a),["-"+a,W.gh];a="SIN"==b||"COS"==b||"TAN"==b?X(a,"NUM",W.le)||"0":X(a,"NUM",W.Ob)||"0";switch(b){case "ABS":c="Math.abs("+a+")";break;case "ROOT":c="Math.sqrt("+a+")";break;case "LN":c="Math.log("+a+")";break;case "EXP":c="Math.exp("+a+")";break;case "POW10":c="Math.pow(10,"+a+")";break;case "ROUND":c="Math.round("+a+")";break;case "ROUNDUP":c="Math.ceil("+a+")";break;case "ROUNDDOWN":c="Math.floor("+
a+")";break;case "SIN":c="Math.sin("+a+" / 180 * Math.PI)";break;case "COS":c="Math.cos("+a+" / 180 * Math.PI)";break;case "TAN":c="Math.tan("+a+" / 180 * Math.PI)"}if(c)return[c,W.Nb];switch(b){case "LOG10":c="Math.log("+a+") / Math.log(10)";break;case "ASIN":c="Math.asin("+a+") / Math.PI * 180";break;case "ACOS":c="Math.acos("+a+") / Math.PI * 180";break;case "ATAN":c="Math.atan("+a+") / Math.PI * 180";break;default:throw"Unknown math operator: "+b;}return[c,W.le]};
W.math_constant=function(a){return{PI:["Math.PI",W.pd],E:["Math.E",W.pd],GOLDEN_RATIO:["(1 + Math.sqrt(5)) / 2",W.le],SQRT2:["Math.SQRT2",W.pd],SQRT1_2:["Math.SQRT1_2",W.pd],INFINITY:["Infinity",W.je]}[T(a,"CONSTANT")]};
W.math_number_property=function(a){var b=X(a,"NUMBER_TO_CHECK",W.qd)||"0",c=T(a,"PROPERTY"),d;if("PRIME"==c)return d=Al("math_isPrime",["function "+W.$b+"(n) {","  // https://en.wikipedia.org/wiki/Primality_test#Naive_methods","  if (n == 2 || n == 3) {","    return true;","  }","  // False if n is NaN, negative, is 1, or not whole.","  // And false if n is divisible by 2 or 3.","  if (isNaN(n) || n <= 1 || n % 1 != 0 || n % 2 == 0 || n % 3 == 0) {","    return false;","  }","  // Check all the numbers of form 6k +/- 1, up to sqrt(n).",
"  for (var x = 6; x <= Math.sqrt(n) + 1; x += 6) {","    if (n % (x - 1) == 0 || n % (x + 1) == 0) {","      return false;","    }","  }","  return true;","}"])+"("+b+")",[d,W.Nb];switch(c){case "EVEN":d=b+" % 2 == 0";break;case "ODD":d=b+" % 2 == 1";break;case "WHOLE":d=b+" % 1 == 0";break;case "POSITIVE":d=b+" > 0";break;case "NEGATIVE":d=b+" < 0";break;case "DIVISIBLE_BY":a=X(a,"DIVISOR",W.qd)||"0",d=b+" % "+a+" == 0"}return[d,W.dh]};
W.math_change=function(a){var b=X(a,"DELTA",W.bh)||"0";a=W.be.getName(T(a,"VAR"),xj);return a+" = (typeof "+a+" == 'number' ? "+a+" : 0) + "+b+";\n"};W.math_round=W.math_single;W.math_trig=W.math_single;
W.math_on_list=function(a){var b=T(a,"OP");switch(b){case "SUM":a=X(a,"LIST",W.pd)||"[]";a+=".reduce(function(x, y) {return x + y;})";break;case "MIN":a=X(a,"LIST",W.ac)||"[]";a="Math.min.apply(null, "+a+")";break;case "MAX":a=X(a,"LIST",W.ac)||"[]";a="Math.max.apply(null, "+a+")";break;case "AVERAGE":b=Al("math_mean",["function "+W.$b+"(myList) {","  return myList.reduce(function(x, y) {return x + y;}) / myList.length;","}"]);a=X(a,"LIST",W.Ob)||"[]";a=b+"("+a+")";break;case "MEDIAN":b=Al("math_median",
["function "+W.$b+"(myList) {","  var localList = myList.filter(function (x) {return typeof x == 'number';});","  if (!localList.length) return null;","  localList.sort(function(a, b) {return b - a;});","  if (localList.length % 2 == 0) {","    return (localList[localList.length / 2 - 1] + localList[localList.length / 2]) / 2;","  } else {","    return localList[(localList.length - 1) / 2];","  }","}"]);a=X(a,"LIST",W.Ob)||"[]";a=b+"("+a+")";break;case "MODE":b=Al("math_modes",["function "+W.$b+"(values) {",
"  var modes = [];","  var counts = [];","  var maxCount = 0;","  for (var i = 0; i < values.length; i++) {","    var value = values[i];","    var found = false;","    var thisCount;","    for (var j = 0; j < counts.length; j++) {","      if (counts[j][0] === value) {","        thisCount = ++counts[j][1];","        found = true;","        break;","      }","    }","    if (!found) {","      counts.push([value, 1]);","      thisCount = 1;","    }","    maxCount = Math.max(thisCount, maxCount);","  }",
"  for (var j = 0; j < counts.length; j++) {","    if (counts[j][1] == maxCount) {","        modes.push(counts[j][0]);","    }","  }","  return modes;","}"]);a=X(a,"LIST",W.Ob)||"[]";a=b+"("+a+")";break;case "STD_DEV":b=Al("math_standard_deviation",["function "+W.$b+"(numbers) {","  var n = numbers.length;","  if (!n) return null;","  var mean = numbers.reduce(function(x, y) {return x + y;}) / n;","  var variance = 0;","  for (var j = 0; j < n; j++) {","    variance += Math.pow(numbers[j] - mean, 2);",
"  }","  variance = variance / n;","  return Math.sqrt(variance);","}"]);a=X(a,"LIST",W.Ob)||"[]";a=b+"("+a+")";break;case "RANDOM":b=Al("math_random_list",["function "+W.$b+"(list) {","  var x = Math.floor(Math.random() * list.length);","  return list[x];","}"]);a=X(a,"LIST",W.Ob)||"[]";a=b+"("+a+")";break;default:throw"Unknown operator: "+b;}return[a,W.Nb]};W.math_modulo=function(a){var b=X(a,"DIVIDEND",W.qd)||"0";a=X(a,"DIVISOR",W.qd)||"0";return[b+" % "+a,W.qd]};
W.math_constrain=function(a){var b=X(a,"VALUE",W.ac)||"0",c=X(a,"LOW",W.ac)||"0";a=X(a,"HIGH",W.ac)||"Infinity";return["Math.min(Math.max("+b+", "+c+"), "+a+")",W.Nb]};W.math_random_int=function(a){var b=X(a,"FROM",W.ac)||"0";a=X(a,"TO",W.ac)||"0";return[Al("math_random_int",["function "+W.$b+"(a, b) {","  if (a > b) {","    // Swap a and b to ensure a is smaller.","    var c = a;","    a = b;","    b = c;","  }","  return Math.floor(Math.random() * (b - a + 1) + a);","}"])+"("+b+", "+a+")",W.Nb]};
W.math_random_float=function(){return["Math.random()",W.Nb]};/*

 Visual Blocks Language

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
W.tk={};W.controls_if=function(a){for(var b=0,c=X(a,"IF"+b,W.Ob)||"false",d=yl(a,"DO"+b),e="if ("+c+") {\n"+d+"}",b=1;b<=a.Ba;b++)c=X(a,"IF"+b,W.Ob)||"false",d=yl(a,"DO"+b),e+=" else if ("+c+") {\n"+d+"}";a.Wa&&(d=yl(a,"ELSE"),e+=" else {\n"+d+"}");return e+"\n"};W.logic_compare=function(a){var b={EQ:"==",NEQ:"!=",LT:"<",LTE:"<=",GT:">",GTE:">="}[T(a,"OP")],c="=="==b||"!="==b?W.dh:W.fh,d=X(a,"A",c)||"0";a=X(a,"B",c)||"0";return[d+" "+b+" "+a,c]};
W.logic_operation=function(a){var b="AND"==T(a,"OP")?"&&":"||",c="&&"==b?W.eh:W.cj,d=X(a,"A",c);a=X(a,"B",c);if(d||a){var e="&&"==b?"true":"false";d||(d=e);a||(a=e)}else a=d="false";return[d+" "+b+" "+a,c]};W.logic_negate=function(a){var b=W.bj;return["!"+(X(a,"BOOL",b)||"true"),b]};W.logic_boolean=function(a){return["TRUE"==T(a,"BOOL")?"true":"false",W.je]};W.logic_null=function(){return["null",W.je]};
W.logic_ternary=function(a){var b=X(a,"IF",W.ke)||"false",c=X(a,"THEN",W.ke)||"null";a=X(a,"ELSE",W.ke)||"null";return[b+" ? "+c+" : "+a,W.ke]};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
R.tk={};
R.controls_if={o:function(){this.J="https://github.com/google/blockly/wiki/IfElse";this.C(210);S(U(this,"IF0").P("Boolean"),"if");S(nj(this,3,"DO0"),"do");ii(this,!0);ji(this,!0);pj(this);var a=this;this.B(function(){if(a.Ba||a.Wa){if(!a.Ba&&a.Wa)return"If a value is true, then do the first block of statements.  Otherwise, do the second block of statements.";if(a.Ba&&!a.Wa)return"If the first value is true, then do the first block of statements.  Otherwise, if the second value is true, do the second block of statements.";if(a.Ba&&
a.Wa)return"If the first value is true, then do the first block of statements.  Otherwise, if the second value is true, do the second block of statements.  If none of the values are true, do the last block of statements."}else return"If a value is true, then do some statements.";return""});this.Wa=this.Ba=0},Ze:function(){if(!this.Ba&&!this.Wa)return null;var a=document.createElement("mutation");this.Ba&&a.setAttribute("elseif",this.Ba);this.Wa&&a.setAttribute("else",1);return a},Uf:function(a){this.Ba=
parseInt(a.getAttribute("elseif"),10);this.Wa=parseInt(a.getAttribute("else"),10);for(a=1;a<=this.Ba;a++)S(U(this,"IF"+a).P("Boolean"),"else if"),S(nj(this,3,"DO"+a),"do");this.Wa&&S(nj(this,3,"ELSE"),"else")},Jj:function(a){var b=dd(a,"controls_if_if");ed(b);for(var c=ld(b,"STACK").p,d=1;d<=this.Ba;d++){var e=dd(a,"controls_if_elseif");ed(e);md(c,e.F);c=e.D}this.Wa&&(a=dd(a,"controls_if_else"),ed(a),md(c,a.F));return b},xj:function(a){this.Wa&&mj(this,"ELSE");this.Wa=0;for(var b=this.Ba;0<b;b--)mj(this,
"IF"+b),mj(this,"DO"+b);this.Ba=0;for(a=oj(a,"STACK");a;){switch(a.type){case "controls_if_elseif":this.Ba++;var b=S(U(this,"IF"+this.Ba).P("Boolean"),"else if"),c=nj(this,3,"DO"+this.Ba);S(c,"do");a.Vi&&md(b.p,a.Vi);a.Wd&&md(c.p,a.Wd);break;case "controls_if_else":this.Wa++;b=nj(this,3,"ELSE");S(b,"else");a.Wd&&md(b.p,a.Wd);break;default:throw"Unknown block type.";}a=a.D&&E(a.D)}},Eg:function(a){a=oj(a,"STACK");for(var b=1;a;){switch(a.type){case "controls_if_elseif":var c=ld(this,"IF"+b),d=ld(this,
"DO"+b);a.Vi=c&&c.p.t;a.Wd=d&&d.p.t;b++;break;case "controls_if_else":d=ld(this,"ELSE");a.Wd=d&&d.p.t;break;default:throw"Unknown block type.";}a=a.D&&E(a.D)}}};R.controls_if_if={o:function(){this.C(210);S(lj(this),"if");nj(this,3,"STACK");this.B("Add, remove, or reorder sections to reconfigure this if block.");this.contextMenu=!1}};R.controls_if_elseif={o:function(){this.C(210);S(lj(this),"else if");ii(this,!0);ji(this,!0);this.B("Add a condition to the if block.");this.contextMenu=!1}};
R.controls_if_else={o:function(){this.C(210);S(lj(this),"else");ii(this,!0);this.B("Add a final, catch-all condition to the if block.");this.contextMenu=!1}};
R.logic_compare={o:function(){var a=C?[["=","EQ"],["\u2260","NEQ"],[">","LT"],["\u2265","LTE"],["<","GT"],["\u2264","GTE"]]:[["=","EQ"],["\u2260","NEQ"],["<","LT"],["\u2264","LTE"],[">","GT"],["\u2265","GTE"]];this.J="https://en.wikipedia.org/wiki/Inequality_(mathematics)";this.C(210);Q(this,"Boolean");U(this,"A");S(U(this,"B"),new P(a),"OP");fd(this,!0);var b=this;this.B(function(){return{EQ:"Return true if both inputs equal each other.",NEQ:"Return true if both inputs are not equal to each other.",
LT:"Return true if the first input is smaller than the second input.",LTE:"Return true if the first input is smaller than or equal to the second input.",GT:"Return true if the first input is greater than the second input.",GTE:"Return true if the first input is greater than or equal to the second input."}[T(b,"OP")]})}};
R.logic_operation={o:function(){this.J="https://github.com/google/blockly/wiki/Logic#logical-operations";this.C(210);Q(this,"Boolean");U(this,"A").P("Boolean");S(U(this,"B").P("Boolean"),new P([["and","AND"],["or","OR"]]),"OP");fd(this,!0);var a=this;this.B(function(){return{AND:"Return true if both inputs are true.",OR:"Return true if at least one of the inputs is true."}[T(a,"OP")]})}};
R.logic_negate={o:function(){this.J="https://github.com/google/blockly/wiki/Logic#not";this.C(210);Q(this,"Boolean");this.vb("not %1",["BOOL","Boolean",1],1);this.B("Returns true if the input is false.  Returns false if the input is true.")}};R.logic_boolean={o:function(){this.J="https://github.com/google/blockly/wiki/Logic#values";this.C(210);Q(this,"Boolean");S(lj(this),new P([["true","TRUE"],["false","FALSE"]]),"BOOL");this.B("Returns either true or false.")}};
R.logic_null={o:function(){this.J="https://en.wikipedia.org/wiki/Nullable_type";this.C(210);Q(this);S(lj(this),"null");this.B("Returns null.")}};R.logic_ternary={o:function(){this.J="https://en.wikipedia.org/wiki/%3F:";this.C(210);S(U(this,"IF").P("Boolean"),"test");S(U(this,"THEN"),"if true");S(U(this,"ELSE"),"if false");Q(this);this.B("Check the condition in 'test'. If the condition is true, returns the 'if true' value; otherwise returns the 'if false' value.")}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
R.vk={};R.math_number={o:function(){this.J="https://en.wikipedia.org/wiki/Number";this.C(230);S(lj(this),new ol("0",tl),"NUM");Q(this,"Number");this.B("A number.")}};
R.math_arithmetic={o:function(){this.J="https://en.wikipedia.org/wiki/Arithmetic";this.C(230);Q(this,"Number");U(this,"A").P("Number");S(U(this,"B").P("Number"),new P([["+","ADD"],["-","MINUS"],["\u00d7","MULTIPLY"],["\u00f7","DIVIDE"],["^","POWER"]]),"OP");fd(this,!0);var a=this;this.B(function(){return{ADD:"Return the sum of the two numbers.",MINUS:"Return the difference of the two numbers.",MULTIPLY:"Return the product of the two numbers.",DIVIDE:"Return the quotient of the two numbers.",POWER:"Return the first number raised to the power of the second number."}[T(a,
"OP")]})}};
R.math_single={o:function(){this.J="https://en.wikipedia.org/wiki/Square_root";this.C(230);Q(this,"Number");this.vb("%1 %2",["OP",new P([["square root","ROOT"],["absolute","ABS"],["-","NEG"],["ln","LN"],["log10","LOG10"],["e^","EXP"],["10^","POW10"]])],["NUM","Number",1],1);var a=this;this.B(function(){return{ROOT:"Return the square root of a number.",ABS:"Return the absolute value of a number.",NEG:"Return the negation of a number.",LN:"Return the natural logarithm of a number.",LOG10:"Return the base 10 logarithm of a number.",EXP:"Return e to the power of a number.",
POW10:"Return 10 to the power of a number."}[T(a,"OP")]})}};
R.math_trig={o:function(){this.J="https://en.wikipedia.org/wiki/Trigonometric_functions";this.C(230);Q(this,"Number");S(U(this,"NUM").P("Number"),new P([["sin","SIN"],["cos","COS"],["tan","TAN"],["asin","ASIN"],["acos","ACOS"],["atan","ATAN"]]),"OP");var a=this;this.B(function(){return{SIN:"Return the sine of a degree (not radian).",COS:"Return the cosine of a degree (not radian).",TAN:"Return the tangent of a degree (not radian).",ASIN:"Return the arcsine of a number.",ACOS:"Return the arccosine of a number.",
ATAN:"Return the arctangent of a number."}[T(a,"OP")]})}};R.math_constant={o:function(){this.J="https://en.wikipedia.org/wiki/Mathematical_constant";this.C(230);Q(this,"Number");S(lj(this),new P([["\u03c0","PI"],["e","E"],["\u03c6","GOLDEN_RATIO"],["sqrt(2)","SQRT2"],["sqrt(\u00bd)","SQRT1_2"],["\u221e","INFINITY"]]),"CONSTANT");this.B("Return one of the common constants: \u03c0 (3.141\u2026), e (2.718\u2026), \u03c6 (1.618\u2026), sqrt(2) (1.414\u2026), sqrt(\u00bd) (0.707\u2026), or \u221e (infinity).")}};
R.math_number_property={o:function(){this.C(230);U(this,"NUMBER_TO_CHECK").P("Number");var a=new P([["is even","EVEN"],["is odd","ODD"],["is prime","PRIME"],["is whole","WHOLE"],["is positive","POSITIVE"],["is negative","NEGATIVE"],["is divisible by","DIVISIBLE_BY"]],function(a){this.j.Ui("DIVISIBLE_BY"==a)});S(lj(this),a,"PROPERTY");fd(this,!0);Q(this,"Boolean");this.B("Check if a number is an even, odd, prime, whole, positive, negative, or if it is divisible by certain number.  Returns true or false.")},
Ze:function(){var a=document.createElement("mutation"),b="DIVISIBLE_BY"==T(this,"PROPERTY");a.setAttribute("divisor_input",b);return a},Uf:function(a){a="true"==a.getAttribute("divisor_input");this.Ui(a)},Ui:function(a){var b=ld(this,"DIVISOR");a?b||U(this,"DIVISOR").P("Number"):b&&mj(this,"DIVISOR")}};
R.math_change={o:function(){this.J="https://en.wikipedia.org/wiki/Programming_idiom#Incrementing_a_counter";this.C(230);this.vb("change %1 by %2",["VAR",new yk("item")],["DELTA","Number",1],1);ii(this,!0);ji(this,!0);var a=this;this.B(function(){return"Add a number to variable '%1'.".replace("%1",T(a,"VAR"))})},Yh:function(){return[T(this,"VAR")]},Pk:function(a,b){var c=T(this,"VAR");a.toLowerCase()==c.toLowerCase()&&kd(this,"VAR").bb(b)}};
R.math_round={o:function(){this.J="https://en.wikipedia.org/wiki/Rounding";this.C(230);Q(this,"Number");S(U(this,"NUM").P("Number"),new P([["round","ROUND"],["round up","ROUNDUP"],["round down","ROUNDDOWN"]]),"OP");this.B("Round a number up or down.")}};
R.math_on_list={o:function(){var a=this;this.J="";this.C(230);Q(this,"Number");var b=new P([["sum of list","SUM"],["min of list","MIN"],["max of list","MAX"],["average of list","AVERAGE"],["median of list","MEDIAN"],["modes of list","MODE"],["standard deviation of list","STD_DEV"],["random item of list","RANDOM"]],function(b){"MODE"==b?a.K.P("Array"):a.K.P("Number")});S(U(this,"LIST").P("Array"),b,"OP");this.B(function(){return{SUM:"Return the sum of all the numbers in the list.",MIN:"Return the smallest number in the list.",
MAX:"Return the largest number in the list.",AVERAGE:"Return the average (arithmetic mean) of the numeric values in the list.",MEDIAN:"Return the median number in the list.",MODE:"Return a list of the most common item(s) in the list.",STD_DEV:"Return the standard deviation of the list.",RANDOM:"Return a random element from the list."}[T(a,"OP")]})}};
R.math_modulo={o:function(){this.J="https://en.wikipedia.org/wiki/Modulo_operation";this.C(230);Q(this,"Number");this.vb("remainder of %1 \u00f7 %2",["DIVIDEND","Number",1],["DIVISOR","Number",1],1);fd(this,!0);this.B("Return the remainder from dividing the two numbers.")}};
R.math_constrain={o:function(){this.J="https://en.wikipedia.org/wiki/Clamping_%28graphics%29";this.C(230);Q(this,"Number");this.vb("constrain %1 low %2 high %3",["VALUE","Number",1],["LOW","Number",1],["HIGH","Number",1],1);fd(this,!0);this.B("Constrain a number to be between the specified limits (inclusive).")}};
R.math_random_int={o:function(){this.J="https://en.wikipedia.org/wiki/Random_number_generation";this.C(230);Q(this,"Number");this.vb("random integer from %1 to %2",["FROM","Number",1],["TO","Number",1],1);fd(this,!0);this.B("Return a random integer between the two specified limits, inclusive.")}};R.math_random_float={o:function(){this.J="https://en.wikipedia.org/wiki/Random_number_generation";this.C(230);Q(this,"Number");S(lj(this),"random fraction");this.B("Return a random fraction between 0.0 (inclusive) and 1.0 (exclusive).")}};R.bird_noWorm={o:function(){this.C(330);S(lj(this),km("Bird_noWorm"));Q(this,"Boolean");this.B(km("Bird_noWormTooltip"))}};W.bird_noWorm=function(){return["noWorm()",W.Nb]};R.bird_heading={o:function(){this.C(290);S(S(lj(this),km("Bird_heading")),new Rl("90"),"ANGLE");ii(this,!0);this.B(km("Bird_headingTooltip"))}};W.bird_heading=function(a){return"heading("+parseFloat(T(a,"ANGLE"))+", 'block_id_"+a.id+"');\n"};
R.bird_position={o:function(){this.C(330);S(lj(this),new P([["x","X"],["y","Y"]]),"XY");Q(this,"Number");this.B(km("Bird_positionTooltip"))}};W.bird_position=function(a){return["get"+T(a,"XY").charAt(0)+"()",W.Nb]};
R.bird_compare={o:function(){this.J="https://en.wikipedia.org/wiki/Inequality_(mathematics)";var a=C?[[">","LT"],["<","GT"]]:[["<","LT"],[">","GT"]];this.C(210);Q(this,"Boolean");U(this,"A").P("Number");S(U(this,"B").P("Number"),new P(a),"OP");fd(this,!0);var b=this;this.B(function(){return{rl:"Return true if the first input is smaller than the second input.",ql:"Return true if the first input is greater than the second input."}[T(b,"OP")]})}};
W.bird_compare=function(a){var b="LT"==T(a,"OP")?"<":">",c=W.fh,d=X(a,"A",c)||"0";a=X(a,"B",c)||"0";return[d+" "+b+" "+a,c]};R.bird_and={o:function(){this.J="https://github.com/google/blockly/wiki/Logic#logical-operations";this.C(210);Q(this,"Boolean");U(this,"A").P("Boolean");S(U(this,"B").P("Boolean"),"and","AND");fd(this,!0);this.B("Return true if both inputs are true.")}};
W.bird_and=function(a){var b=W.eh,c=X(a,"A",b);a=X(a,"B",b);c||a?(c||(c="true"),a||(a="true")):a=c="false";return[c+" && "+a,b]};R.bird_ifElse={o:function(){this.J="https://github.com/google/blockly/wiki/IfElse";this.C(210);S(U(this,"CONDITION"),"if").P("Boolean");S(nj(this,3,"DO"),"do");S(nj(this,3,"ELSE"),"else");hd(this,!1);this.B("If a value is true, then do the first block of statements.  Otherwise, do the second block of statements.")}};
W.bird_ifElse=function(a){var b=X(a,"CONDITION",W.Ob)||"false",c=yl(a,"DO");a=yl(a,"ELSE");return"if ("+b+") {\n"+c+"} else {\n"+a+"}\n"};R.controls_if.Bk=R.controls_if.o;R.controls_if.o=function(){this.Bk();ii(this,!1);ji(this,!1);hd(this,!1)};function $(a,b,c,d){this.fe=a;this.ge=b;this.x1=c;this.y1=d}$.prototype.clone=function(){return new $(this.fe,this.ge,this.x1,this.y1)};var jm="bird";Y.sg=function(){10>B?window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+"?lang="+Cc+"&level="+(B+1):Y.Oe()};
var mm=[void 0,{start:new x(20,20),Kb:90,eb:new x(50,50),Ya:new x(80,80),Ha:[]},{start:new x(20,20),Kb:0,eb:new x(80,20),Ya:new x(80,80),Ha:[new $(0,50,60,50)]},{start:new x(20,70),Kb:270,eb:new x(50,20),Ya:new x(80,70),Ha:[new $(50,50,50,100)]},{start:new x(20,80),Kb:0,eb:new x(50,80),Ya:new x(80,20),Ha:[new $(0,0,65,65)]},{start:new x(80,80),Kb:270,eb:new x(50,20),Ya:new x(20,20),Ha:[new $(0,100,65,35)]},{start:new x(20,40),Kb:0,eb:new x(80,20),Ya:new x(20,80),Ha:[new $(0,59,50,59)]},{start:new x(80,
80),Kb:180,eb:new x(80,20),Ya:new x(20,20),Ha:[new $(0,70,40,70),new $(70,50,100,50)]},{start:new x(20,25),Kb:90,eb:new x(80,25),Ya:new x(80,75),Ha:[new $(50,0,50,25),new $(75,50,100,50)]},{start:new x(80,70),Kb:180,eb:new x(20,20),Ya:new x(80,20),Ha:[new $(0,69,31,100),new $(40,50,71,0),new $(80,50,100,50)]},{start:new x(20,20),Kb:90,eb:new x(80,50),Ya:new x(20,20),Ha:[new $(40,60,60,60),new $(40,60,60,30),new $(60,30,100,30)]}][B],nm=[],om=1;
function pm(){var a=document.getElementById("svgBird");mm.Ha.push(new $(-5,-5,-5,105));mm.Ha.push(new $(-5,105,105,105));mm.Ha.push(new $(105,105,105,-5));mm.Ha.push(new $(105,-5,-5,-5));for(var b=0;b<mm.Ha.length;b++){var c=mm.Ha[b],d=document.createElementNS("http://www.w3.org/2000/svg","line");d.setAttribute("x1",c.fe/100*400);d.setAttribute("y1",400*(1-c.ge/100));d.setAttribute("x2",c.x1/100*400);d.setAttribute("y2",400*(1-c.y1/100));d.setAttribute("stroke","#CCB");d.setAttribute("stroke-width",
10);d.setAttribute("stroke-linecap","round");a.appendChild(d)}b=document.createElementNS("http://www.w3.org/2000/svg","image");b.setAttribute("id","nest");b.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href","bird/nest.png");b.setAttribute("height",100);b.setAttribute("width",100);a.appendChild(b);b=document.createElementNS("http://www.w3.org/2000/svg","image");b.setAttribute("id","worm");b.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href","bird/worm.png");b.setAttribute("height",
100);b.setAttribute("width",100);a.appendChild(b);b=document.createElementNS("http://www.w3.org/2000/svg","clipPath");b.setAttribute("id","birdClipPath");c=document.createElementNS("http://www.w3.org/2000/svg","rect");c.setAttribute("id","clipRect");c.setAttribute("width",120);c.setAttribute("height",120);b.appendChild(c);a.appendChild(b);b=document.createElementNS("http://www.w3.org/2000/svg","image");b.setAttribute("id","bird");b.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href","bird/birds-120.png");
b.setAttribute("height",480);b.setAttribute("width",1440);b.setAttribute("clip-path","url(#birdClipPath)");a.appendChild(b);b=document.createElementNS("http://www.w3.org/2000/svg","rect");b.setAttribute("class","edges");b.setAttribute("width",400);b.setAttribute("height",400);a.appendChild(b);for(var b=3<B,c=4<B,d=1,e=.1;.9>e;e+=.1){if(b){var f=document.createElementNS("http://www.w3.org/2000/svg","line");f.setAttribute("class","edges");f.setAttribute("x1",400*e);f.setAttribute("y1",400);f.setAttribute("x2",
400*e);f.setAttribute("y2",400-9*d);a.appendChild(f)}c&&(f=document.createElementNS("http://www.w3.org/2000/svg","line"),f.setAttribute("class","edges"),f.setAttribute("x1",0),f.setAttribute("y1",400*e),f.setAttribute("x2",9*d),f.setAttribute("y2",400*e),a.appendChild(f));2==d&&(b&&(f=document.createElementNS("http://www.w3.org/2000/svg","text"),f.setAttribute("class","edgeX"),f.setAttribute("x",400*e+2),f.setAttribute("y",396),f.appendChild(document.createTextNode(Math.round(100*e))),a.appendChild(f)),
c&&(f=document.createElementNS("http://www.w3.org/2000/svg","text"),f.setAttribute("class","edgeY"),f.setAttribute("x",3),f.setAttribute("y",400*e-2),f.appendChild(document.createTextNode(Math.round(100-100*e))),a.appendChild(f)));d=1==d?2:1}}
window.addEventListener("load",function(){function a(){c.style.top=Math.max(10,d.offsetTop-window.pageYOffset)+"px";c.style.left=b?"10px":"420px";c.style.width=window.innerWidth-440+"px"}document.body.innerHTML=Bc();Y.o();var b=-1!=cm.indexOf(Cc),c=document.getElementById("blockly"),d=document.getElementById("visualization");window.addEventListener("scroll",function(){a();De(window,"resize")});window.addEventListener("resize",a);a();var e=document.getElementById("toolbox");Dl(document.getElementById("blockly"),
{path:"./",rtl:b,toolbox:e,trashcan:!0});Ol(["bird/quack.ogg","bird/quack.mp3"],"quack");Ol(["bird/whack.mp3","bird/whack.ogg"],"whack");Ol(["bird/worm.mp3","bird/worm.ogg"],"worm");zl("noWorm,heading,getX,getY");pm();e="";e=1==B?'<xml>  <block type="bird_heading" x="70" y="70"></block></xml>':5>B?'<xml>  <block type="bird_ifElse" x="70" y="70"></block></xml>':'<xml>  <block type="controls_if" x="70" y="70"></block></xml>';Y.rk(e,!1);qm();lm("runButton",rm);lm("resetButton",sm);setTimeout(function(){Jl(function(){tm()});
tm()},5E3);8<B&&setTimeout(Z.jh,3E5);setTimeout(Y.jk,1);setTimeout(Y.kk,1)});
function tm(){if(0==Be&&vc.result!=um&&!hm(B)){var a=Zc(Vc(y)),b=Wc(y.qa.s,!0),c=document.getElementById("dialogHelp"),d=null,e=null;if(1==B){if(-1!=a.indexOf(">90<")||-1==a.indexOf("bird_heading"))e={width:"370px",top:"140px"},e[C?"right":"left"]="215px",d=Wc(y,!0),d=d.length?O(d[0]):O(b[0])}else if(2==B)-1==a.indexOf("bird_noWorm")&&(e={width:"350px",top:"170px"},e[C?"right":"left"]="180px",d=O(b[1]));else if(4==B)-1==a.indexOf("bird_compare")&&(e={width:"350px",top:"230px"},e[C?"right":"left"]=
"180px",d=O(b[2]));else if(5==B){if(-1==a.indexOf("mutation else")){d=Wc(y,!1);for(e=0;(b=d[e])&&"controls_if"!=b.type;e++);b.wb.A()?(c=document.getElementById("dialogMutatorHelp"),d=b.wb.qa.pe[1],a=$g(d),e={width:"340px",top:a.y+60+"px"},e.left=a.x-(C?310:0)+"px"):(a=$g(O(b)),e={width:"340px",top:a.y+100+"px"},e.left=a.x-(C?350:0)+"px",d=O(b))}}else if(6==B){if(-1==a.indexOf("mutation")){d=Wc(y,!1);for(e=0;(b=d[e])&&"controls_if"!=b.type;e++);a=$g(O(b));e={width:"350px",top:a.y+220+"px"};e.left=
a.x-(C?350:0)+"px";d=O(b)}}else 8==B&&-1==a.indexOf("bird_and")&&(e={width:"350px",top:"360px"},e[C?"right":"left"]="450px",d=O(b[4]));e?c.parentNode!=document.getElementById("dialog")&&Z.rf(c,d,!0,!1,e,null):Z.Eb(!1)}}
function qm(){for(var a=0;a<nm.length;a++)window.clearTimeout(nm[a]);nm=[];A=mm.start.clone();yc=xc=mm.Kb;zc=!1;om=1;vm();a=document.getElementById("worm");a.setAttribute("x",mm.eb.x/100*400-50);a.setAttribute("y",400*(1-mm.eb.y/100)-50);a.style.visibility="visible";a=document.getElementById("nest");a.setAttribute("x",mm.Ya.x/100*400-50);a.setAttribute("y",400*(1-mm.Ya.y/100)-50)}
function rm(a){if(!Y.Cb(a)){a=document.getElementById("runButton");var b=document.getElementById("resetButton");b.style.minWidth||(b.style.minWidth=a.offsetWidth+"px");a.style.display="none";b.style.display="inline";ze(y,!0);qm();wm()}}function sm(a){Y.Cb(a)||(document.getElementById("runButton").style.display="inline",document.getElementById("resetButton").style.display="none",ze(y,!1),qm())}var um=1;
function xm(a,b){var c;c=function(a,b){var c=a.valueOf(),h=b.toString(),k=c*Math.PI/180;A.x+=Math.cos(k);A.y+=Math.sin(k);xc=c;Ac.push(["move",A.x,A.y,xc,h]);if(zc&&15>Xb(A,mm.Ya))throw Ac.push(["play","quack",null]),ym(mm.Ya),Ac.push(["finish",null]),!0;!zc&&15>Xb(A,mm.eb)&&(ym(mm.eb),Ac.push(["worm",null]),Ac.push(["play","worm",null]),zc=!0);a:{for(c=0;h=mm.Ha[c];c++){var k=A,m=void 0;k instanceof x?(m=k.y,k=k.x):m=void 0;var p=h.fe,q=h.ge,u=h.x1-h.fe,t=h.y1-h.ge,k=Math.min(Math.max(((k-p)*(h.x1-
p)+(m-q)*(h.y1-q))/(u*u+t*t),0),1),m=h.fe,p=h.ge;if(6>Xb(new x(m+k*(h.x1-m),p+k*(h.y1-p)),A)){c=!0;break a}}c=!1}if(c)throw Ac.push(["play","whack",null]),!1;};a.setProperty(b,"heading",a.createNativeFunction(c));a.setProperty(b,"noWorm",a.createNativeFunction(function(){return a.createPrimitive(!zc)}));a.setProperty(b,"getX",a.createNativeFunction(function(){return a.createPrimitive(A.x)}));a.setProperty(b,"getY",a.createNativeFunction(function(){return a.createPrimitive(A.y)}))}
function wm(){if("Interpreter"in window){Ac=[];var a=vl(),b=a.indexOf("if ("),c=a.indexOf("}\n");-1!=b&&-1!=c&&(a=a.substring(b,c+2));b=0;a=new Interpreter("while(true) {\n"+a+"}",xm);try{for(c=1E5;a.step();)if(0==c--)throw Infinity;b=-1}catch(d){Infinity===d?b=2:!0===d?b=um:!1===d?b=-2:(b=-2,window.alert(d))}wc=b==um?10:15;qm();nm.push(setTimeout(zm,1))}else setTimeout(wm,250)}
function zm(){nm=[];var a=Ac.shift();a?(Y.Ke(a.pop()),"move"==a[0]||"goto"==a[0]?(A.x=a[1],A.y=a[2],xc=a[3],om="move"==a[0]?2:1,vm()):"worm"==a[0]?document.getElementById("worm").style.visibility="hidden":"finish"==a[0]?(om=3,vm(),Y.Uk(),Z.yj()):"play"==a[0]&&Qi(a[1],.5),nm.push(setTimeout(zm,5*wc))):Y.Ke(null)}
function vm(){var a;a=Wb(yc)-Wb(xc);180<a?a-=360:-180>=a&&(a=360+a);10>=Math.abs(a)?yc=xc:(yc-=10*(0==a?0:0>a?-1:1),yc=Wb(yc));var b=(14-Math.round(yc/360*12))%12,c=yc%30;15<=c&&(c-=30);var c=-1*c,d;if(1==om)d=0;else if(3==om)d=3;else if(2==om)d=Math.round(Date.now()/100)%3;else throw"Unknown pose.";a=A.x/100*400-60;var e=400*(1-A.y/100)-60,f=document.getElementById("bird");f.setAttribute("x",a-120*b);f.setAttribute("y",e-120*d);f.setAttribute("transform","rotate("+c+", "+(a+60)+", "+(e+60)+")");
b=document.getElementById("clipRect");b.setAttribute("x",a);b.setAttribute("y",e)}function ym(a){var b=Math.round(Xb(A,a));a=Wb(180*Math.atan2(a.y-A.y,a.x-A.x)/Math.PI);for(var c=a*Math.PI/180,d=0;d<b;d++)A.x+=Math.cos(c),A.y+=Math.sin(c),Ac.push(["goto",A.x,A.y,a,null])};
