// Automatically generated file.  Do not edit!
'use strict';var f,n=this;function aa(a){a=a.split(".");for(var b=n,c;c=a.shift();)if(null!=b[c])b=b[c];else return null;return b}function ba(){}function ca(a){a.Vb=function(){return a.Dh?a.Dh:a.Dh=new a}}
function da(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;var c=Object.prototype.toString.call(a);if("[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==b&&"undefined"==typeof a.call)return"object";return b}function ea(a){return"array"==da(a)}function fa(a){var b=da(a);return"array"==b||"object"==b&&"number"==typeof a.length}function p(a){return"string"==typeof a}function r(a){return"number"==typeof a}function s(a){return"function"==da(a)}function ga(a){var b=typeof a;return"object"==b&&null!=a||"function"==b}function ia(a){return a[ja]||(a[ja]=++ka)}var ja="closure_uid_"+(1E9*Math.random()>>>0),ka=0;
function la(a,b,c){return a.call.apply(a.bind,arguments)}function ma(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var c=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(c,d);return a.apply(b,c)}}return function(){return a.apply(b,arguments)}}function na(a,b,c){na=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?la:ma;return na.apply(null,arguments)}
function oa(a,b){var c=Array.prototype.slice.call(arguments,1);return function(){var b=c.slice();b.push.apply(b,arguments);return a.apply(this,b)}}var pa=Date.now||function(){return+new Date};function u(a,b){function c(){}c.prototype=b.prototype;a.n=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.Yk=function(a,c,g){return b.prototype[c].apply(a,Array.prototype.slice.call(arguments,2))}};function qa(a,b){null!=a&&this.append.apply(this,arguments)}f=qa.prototype;f.W="";f.set=function(a){this.W=""+a};f.append=function(a,b,c){this.W+=a;if(null!=b)for(var d=1;d<arguments.length;d++)this.W+=arguments[d];return this};f.clear=function(){this.W=""};f.toString=function(){return this.W};var ra;function sa(a){if(Error.captureStackTrace)Error.captureStackTrace(this,sa);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}u(sa,Error);sa.prototype.name="CustomError";function ta(a,b){for(var c=a.split("%s"),d="",e=Array.prototype.slice.call(arguments,1);e.length&&1<c.length;)d+=c.shift()+e.shift();return d+c.join("%s")}function ua(a){return a.replace(/[\t\r\n ]+/g," ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g,"")}var va=String.prototype.trim?function(a){return a.trim()}:function(a){return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g,"")};function wa(a,b){var c=String(a).toLowerCase(),d=String(b).toLowerCase();return c<d?-1:c==d?0:1}
function xa(a){if(!ya.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(za,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(Aa,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(Ba,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(Ca,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(Da,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(Ea,"&#0;"));return a}var za=/&/g,Aa=/</g,Ba=/>/g,Ca=/"/g,Da=/'/g,Ea=/\x00/g,ya=/[\x00&<>"']/;
function Fa(a){var b={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"'},c;c=n.document.createElement("div");return a.replace(Ga,function(a,e){var g=b[a];if(g)return g;if("#"==e.charAt(0)){var h=Number("0"+e.substr(1));isNaN(h)||(g=String.fromCharCode(h))}g||(c.innerHTML=a+" ",g=c.firstChild.nodeValue.slice(0,-1));return b[a]=g})}
function Ha(a){return a.replace(/&([^;]+);/g,function(a,c){switch(c){case "amp":return"&";case "lt":return"<";case "gt":return">";case "quot":return'"';default:if("#"==c.charAt(0)){var d=Number("0"+c.substr(1));if(!isNaN(d))return String.fromCharCode(d)}return a}})}var Ga=/&([^;\s<&]+);?/g;function Ia(a,b){return a<b?-1:a>b?1:0};function Ja(a,b){b.unshift(a);sa.call(this,ta.apply(null,b));b.shift()}u(Ja,sa);Ja.prototype.name="AssertionError";function Ka(a,b){throw new Ja("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};function La(){this.xg="";this.Gi=Ma}La.prototype.Qc=!0;La.prototype.Nc=function(){return this.xg};La.prototype.toString=function(){return"Const{"+this.xg+"}"};function Na(a){if(a instanceof La&&a.constructor===La&&a.Gi===Ma)return a.xg;Ka("expected object of type Const, got '"+a+"'");return"type_error:Const"}var Ma={};function Oa(){this.bc="";this.Ci=Pa}f=Oa.prototype;f.Qc=!0;f.Nc=function(){return this.bc};f.Pf=!0;f.nd=function(){return 1};f.toString=function(){return"SafeUrl{"+this.bc+"}"};var Pa={};var w=Array.prototype,Qa=w.indexOf?function(a,b,c){return w.indexOf.call(a,b,c)}:function(a,b,c){c=null==c?0:0>c?Math.max(0,a.length+c):c;if(p(a))return p(b)&&1==b.length?a.indexOf(b,c):-1;for(;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},Ra=w.forEach?function(a,b,c){w.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=p(a)?a.split(""):a,g=0;g<d;g++)g in e&&b.call(c,e[g],g,a)},Sa=w.filter?function(a,b,c){return w.filter.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=[],g=0,h=p(a)?
a.split(""):a,k=0;k<d;k++)if(k in h){var l=h[k];b.call(c,l,k,a)&&(e[g++]=l)}return e},Ta=w.map?function(a,b,c){return w.map.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=Array(d),g=p(a)?a.split(""):a,h=0;h<d;h++)h in g&&(e[h]=b.call(c,g[h],h,a));return e},Ua=w.every?function(a,b,c){return w.every.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=p(a)?a.split(""):a,g=0;g<d;g++)if(g in e&&!b.call(c,e[g],g,a))return!1;return!0};function Va(a,b){return 0<=Qa(a,b)}
function Wa(a,b){var c=Qa(a,b),d;(d=0<=c)&&w.splice.call(a,c,1);return d}function Xa(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]}function Ya(a,b,c,d){w.splice.apply(a,Za(arguments,1))}function Za(a,b,c){return 2>=arguments.length?w.slice.call(a,b):w.slice.call(a,b,c)};function ab(){this.Ke="";this.Bi=bb}ab.prototype.Qc=!0;var bb={};ab.prototype.Nc=function(){return this.Ke};ab.prototype.toString=function(){return"SafeStyle{"+this.Ke+"}"};function cb(a){var b=new ab;b.Ke=a;return b}var db=cb("");
function eb(a){var b="",c;for(c in a){if(!/^[-_a-zA-Z0-9]+$/.test(c))throw Error("Name allows only [-_a-zA-Z0-9], got: "+c);var d=a[c];null!=d&&(d instanceof La?d=Na(d):fb.test(d)||(Ka("String value allows only [-.%_!# a-zA-Z0-9], got: "+d),d="zClosurez"),b+=c+":"+d+";")}return b?cb(b):db}var fb=/^[-.%_!# a-zA-Z0-9]+$/;function gb(){this.fg="";this.Ii=hb}f=gb.prototype;f.Qc=!0;f.Nc=function(){return this.fg};f.Pf=!0;f.nd=function(){return 1};f.toString=function(){return"TrustedResourceUrl{"+this.fg+"}"};var hb={};function ib(a,b){for(var c in a)b.call(void 0,a[c],c,a)}var jb="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function kb(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var g=0;g<jb.length;g++)c=jb[g],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}}
function lb(a){var b=arguments.length;if(1==b&&ea(arguments[0]))return lb.apply(null,arguments[0]);for(var c={},d=0;d<b;d++)c[arguments[d]]=!0;return c};var mb=lb("area base br col command embed hr img input keygen link meta param source track wbr".split(" "));function nb(){this.bc="";this.Ai=ob;this.oh=null}f=nb.prototype;f.Pf=!0;f.nd=function(){return this.oh};f.Qc=!0;f.Nc=function(){return this.bc};f.toString=function(){return"SafeHtml{"+this.bc+"}"};function pb(a){if(a instanceof nb&&a.constructor===nb&&a.Ai===ob)return a.bc;Ka("expected object of type SafeHtml, got '"+a+"'");return"type_error:SafeHtml"}function qb(a){if(a instanceof nb)return a;var b=null;a.Pf&&(b=a.nd());return rb(xa(a.Qc?a.Nc():String(a)),b)}
var sb=/^[a-zA-Z0-9-]+$/,tb=lb("action","cite","data","formaction","href","manifest","poster","src"),ub=lb("embed","iframe","link","script","style","template");
function vb(a,b,c){if(!sb.test(a))throw Error("Invalid tag name <"+a+">.");if(a.toLowerCase()in ub)throw Error("Tag name <"+a+"> is not allowed for SafeHtml.");var d=null,e="<"+a;if(b)for(var g in b){if(!sb.test(g))throw Error('Invalid attribute name "'+g+'".');var h=b[g];if(null!=h){var k,l=a;k=g;if(h instanceof La)h=Na(h);else if("style"==k.toLowerCase()){if(!ga(h))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof h+" given: "+h);h instanceof ab||
(h=eb(h));h instanceof ab&&h.constructor===ab&&h.Bi===bb?h=h.Ke:(Ka("expected object of type SafeStyle, got '"+h+"'"),h="type_error:SafeStyle")}else{if(/^on/i.test(k))throw Error('Attribute "'+k+'" requires goog.string.Const value, "'+h+'" given.');if(k.toLowerCase()in tb)if(h instanceof gb)h instanceof gb&&h.constructor===gb&&h.Ii===hb?h=h.fg:(Ka("expected object of type TrustedResourceUrl, got '"+h+"'"),h="type_error:TrustedResourceUrl");else if(h instanceof Oa)h instanceof Oa&&h.constructor===
Oa&&h.Ci===Pa?h=h.bc:(Ka("expected object of type SafeUrl, got '"+h+"'"),h="type_error:SafeUrl");else throw Error('Attribute "'+k+'" on tag "'+l+'" requires goog.html.SafeUrl or goog.string.Const value, "'+h+'" given.');}h.Qc&&(h=h.Nc());k=k+'="'+xa(String(h))+'"';e+=" "+k}}void 0!==c?ea(c)||(c=[c]):c=[];!0===mb[a.toLowerCase()]?e+=">":(d=wb(c),e+=">"+pb(d)+"</"+a+">",d=d.nd());(a=b&&b.dir)&&(d=/^(ltr|rtl|auto)$/i.test(a)?0:null);return rb(e,d)}
function wb(a){function b(a){ea(a)?Ra(a,b):(a=qb(a),d+=pb(a),a=a.nd(),0==c?c=a:0!=a&&c!=a&&(c=null))}var c=0,d="";Ra(arguments,b);return rb(d,c)}var ob={};function rb(a,b){var c=new nb;c.bc=a;c.oh=b;return c}var xb=rb("",0);var yb={Al:!0};var zb;a:{var Ab=n.navigator;if(Ab){var Bb=Ab.userAgent;if(Bb){zb=Bb;break a}}zb=""}function Cb(a){return-1!=zb.indexOf(a)};var Db=Cb("Opera")||Cb("OPR"),x=Cb("Trident")||Cb("MSIE"),Eb=Cb("Gecko")&&-1==zb.toLowerCase().indexOf("webkit")&&!(Cb("Trident")||Cb("MSIE")),y=-1!=zb.toLowerCase().indexOf("webkit"),Fb=Cb("Macintosh"),Gb=Cb("Android"),Hb=Cb("iPhone")&&!Cb("iPod")&&!Cb("iPad"),Ib=Cb("iPad");function Jb(){var a=n.document;return a?a.documentMode:void 0}
var Kb=function(){var a="",b;if(Db&&n.opera)return a=n.opera.version,s(a)?a():a;Eb?b=/rv\:([^\);]+)(\)|;)/:x?b=/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/:y&&(b=/WebKit\/(\S+)/);b&&(a=(a=b.exec(zb))?a[1]:"");return x&&(b=Jb(),b>parseFloat(a))?String(b):a}(),Lb={};
function z(a){var b;if(!(b=Lb[a])){b=0;for(var c=va(String(Kb)).split("."),d=va(String(a)).split("."),e=Math.max(c.length,d.length),g=0;0==b&&g<e;g++){var h=c[g]||"",k=d[g]||"",l=/(\d*)(\D*)/g,q=/(\d*)(\D*)/g;do{var m=l.exec(h)||["","",""],t=q.exec(k)||["","",""];if(0==m[0].length&&0==t[0].length)break;b=Ia(0==m[1].length?0:parseInt(m[1],10),0==t[1].length?0:parseInt(t[1],10))||Ia(0==m[2].length,0==t[2].length)||Ia(m[2],t[2])}while(0==b)}b=Lb[a]=0<=b}return b}
var Mb=n.document,Nb=Mb&&x?Jb()||("CSS1Compat"==Mb.compatMode?parseInt(Kb,10):5):void 0;function Ob(a,b){this.width=a;this.height=b}f=Ob.prototype;f.clone=function(){return new Ob(this.width,this.height)};f.toString=function(){return"("+this.width+" x "+this.height+")"};f.Fh=function(){return!(this.width*this.height)};f.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};f.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
f.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};f.scale=function(a,b){var c=r(b)?b:a;this.width*=a;this.height*=c;return this};var Pb=!x||x&&9<=Nb,Qb=!Eb&&!x||x&&x&&9<=Nb||Eb&&z("1.9.1"),Rb=x&&!z("9");function Sb(a,b,c){return Math.min(Math.max(a,b),c)}function Tb(a){a%=360;return 0>360*a?a+360:a};function A(a,b){this.x=void 0!==a?a:0;this.y=void 0!==b?b:0}f=A.prototype;f.clone=function(){return new A(this.x,this.y)};f.toString=function(){return"("+this.x+", "+this.y+")"};function Ub(a,b){var c=a.x-b.x,d=a.y-b.y;return Math.sqrt(c*c+d*d)}f.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};f.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};f.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};
f.translate=function(a,b){a instanceof A?(this.x+=a.x,this.y+=a.y):(this.x+=a,r(b)&&(this.y+=b));return this};f.scale=function(a,b){var c=r(b)?b:a;this.x*=a;this.y*=c;return this};function Vb(a){return a?new Wb(Xb(a)):ra||(ra=new Wb)}function Yb(a,b){ib(b,function(b,d){"style"==d?a.style.cssText=b:"class"==d?a.className=b:"for"==d?a.htmlFor=b:d in Zb?a.setAttribute(Zb[d],b):0==d.lastIndexOf("aria-",0)||0==d.lastIndexOf("data-",0)?a.setAttribute(d,b):a[d]=b})}var Zb={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};
function $b(){var a=window.document,a="CSS1Compat"==a.compatMode?a.documentElement:a.body;return new Ob(a.clientWidth,a.clientHeight)}function C(a,b,c){return ac(document,arguments)}
function ac(a,b){var c=b[0],d=b[1];if(!Pb&&d&&(d.name||d.type)){c=["<",c];d.name&&c.push(' name="',xa(d.name),'"');if(d.type){c.push(' type="',xa(d.type),'"');var e={};kb(e,d);delete e.type;d=e}c.push(">");c=c.join("")}c=a.createElement(c);d&&(p(d)?c.className=d:ea(d)?c.className=d.join(" "):Yb(c,d));2<b.length&&bc(a,c,b,2);return c}
function bc(a,b,c,d){function e(c){c&&b.appendChild(p(c)?a.createTextNode(c):c)}for(;d<c.length;d++){var g=c[d];!fa(g)||ga(g)&&0<g.nodeType?e(g):Ra(cc(g)?Xa(g):g,e)}}function dc(a){for(var b;b=a.firstChild;)a.removeChild(b)}function ec(a){var b=D.g;b.parentNode&&b.parentNode.insertBefore(a,b)}function E(a){return a&&a.parentNode?a.parentNode.removeChild(a):null}
function fc(a,b){if(a.contains&&1==b.nodeType)return a==b||a.contains(b);if("undefined"!=typeof a.compareDocumentPosition)return a==b||Boolean(a.compareDocumentPosition(b)&16);for(;b&&a!=b;)b=b.parentNode;return b==a}function Xb(a){return 9==a.nodeType?a:a.ownerDocument||a.document}var gc={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1},hc={IMG:" ",BR:"\n"};function ic(a){a=a.getAttributeNode("tabindex");return null!=a&&a.specified}function jc(a){a=a.tabIndex;return r(a)&&0<=a&&32768>a}
function kc(a){var b=[];lc(a,b,!1);return b.join("")}function lc(a,b,c){if(!(a.nodeName in gc))if(3==a.nodeType)c?b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g,"")):b.push(a.nodeValue);else if(a.nodeName in hc)b.push(hc[a.nodeName]);else for(a=a.firstChild;a;)lc(a,b,c),a=a.nextSibling}function cc(a){if(a&&"number"==typeof a.length){if(ga(a))return"function"==typeof a.item||"string"==typeof a.item;if(s(a))return"function"==typeof a.item}return!1}
function Wb(a){this.Fb=a||n.document||document}f=Wb.prototype;f.ib=Vb;f.h=function(a){return p(a)?this.Fb.getElementById(a):a};f.H=function(a,b,c){return ac(this.Fb,arguments)};f.createElement=function(a){return this.Fb.createElement(a)};f.createTextNode=function(a){return this.Fb.createTextNode(String(a))};f.appendChild=function(a,b){a.appendChild(b)};f.append=function(a,b){bc(Xb(a),a,arguments,1)};f.canHaveChildren=function(a){if(1!=a.nodeType)return!1;switch(a.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case "SCRIPT":case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
f.Zh=dc;f.removeNode=E;f.lc=function(a){return Qb&&void 0!=a.children?a.children:Sa(a.childNodes,function(a){return 1==a.nodeType})};f.contains=fc;f.Xb=function(a){var b;(b="A"==a.tagName||"INPUT"==a.tagName||"TEXTAREA"==a.tagName||"SELECT"==a.tagName||"BUTTON"==a.tagName?!a.disabled&&(!ic(a)||jc(a)):ic(a)&&jc(a))&&x?(a=s(a.getBoundingClientRect)?a.getBoundingClientRect():{height:a.offsetHeight,width:a.offsetWidth},a=null!=a&&0<a.height&&0<a.width):a=b;return a};x&&z(8);function F(a){return a&&a.$i&&a.$i===yb?a.content:String(a).replace(mc,nc)}var oc={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"};function nc(a){return oc[a]}var mc=/[\x00\x22\x26\x27\x3c\x3e]/g;var pc={};function qc(){return'<div class="farSide" style="padding: 1ex 3ex 0"><button class="secondary" onclick="BlocklyDialogs.hideDialog(true)">Sawa</button></div>'};function rc(){for(var a=sc,b=G,c='<div style="display: none"><span id="Games_name">Blockly Games</span><span id="Games_puzzle">Fumbo</span><span id="Games_maze">Mzingile</span><span id="Games_bird">Bird</span><span id="Games_turtle">Turtle</span><span id="Games_movie">Movie</span><span id="Games_pondBasic">Pond</span><span id="Games_pondAdvanced">JS Pond</span><span id="Games_linesOfCode1">You solved this level with 1 line of JavaScript:</span><span id="Games_linesOfCode2">You solved this level with %1 lines of JavaScript:</span><span id="Games_nextLevel">Are you ready for level %1?</span><span id="Games_finalLevel">Are you ready for the next challenge?</span><span id="Games_linkTooltip">Hifadhi na kiungo cha vishiku. </span><span id="Games_runTooltip">Run the program you wrote.</span><span id="Games_runProgram">Endesha Programu</span><span id="Games_resetTooltip">Stop the program and reset the level.</span><span id="Games_resetProgram">Seti upya</span><span id="Games_help">Huduma</span><span id="Games_dialogOk">Sawa</span><span id="Games_dialogCancel">Cancel</span><span id="Games_catLogic">Logic</span><span id="Games_catLoops">Loops</span><span id="Games_catMath">Math</span><span id="Games_catText">Text</span><span id="Games_catLists">Lists</span><span id="Games_catColour">Colour</span><span id="Games_catVariables">Variables</span><span id="Games_catProcedures">Functions</span><span id="Games_httpRequestError">Kuna shida na amri.</span><span id="Games_linkAlert">Sambaza vishiku vyako na kiungo hiki: \n\n%1</span><span id="Games_hashError">Samahani, \'%1\' haiendani na faili yoyote ya Blockly.</span><span id="Games_xmlError">Upakiaji wa faili yako iliyohifadhiwa haiwezekani.  Labda iliundwa na toleo tofauti ya Blockly?</span><span id="Games_listVariable">list</span><span id="Games_textVariable">text</span></div><div style="display: none"><span id="Pond_playerName">Player</span><span id="Pond_targetName">Target</span><span id="Pond_rabbitName">Rabbit</span><span id="Pond_counterName">Counter</span><span id="Pond_rookName">Rook</span><span id="Pond_sniperName">Sniper</span><span id="Pond_pendulumName">Pendulum</span><span id="Pond_scaredName">Scared</span><span id="Pond_scanTooltip">Scan for enemies. Specify a direction (0-360). Returns the distance to the closest enemy in that direction. Returns Infinity if no enemy found.</span><span id="Pond_cannonTooltip">Fire the cannon. Specify a direction (0-360) and a range (0-70).</span><span id="Pond_swimTooltip">Swim forward. Specify a direction (0-360).</span><span id="Pond_stopTooltip">Stop swimming. Player will slow to a stop.</span><span id="Pond_healthTooltip">Returns the player\'s current health (0 is dead, 100 is healthy).</span><span id="Pond_speedTooltip">Returns the current speed of the player (0 is stopped, 100 is full speed).</span><span id="Pond_locXTooltip">Returns the X coordinate of the player (0 is the left edge, 100 is the right edge).</span><span id="Pond_locYTooltip">Returns the Y coordinate of the player (0 is the bottom edge, 100 is the top edge).</span></div><div style="display: none"></div><table width="100%"><tr><td><h1>'+
('<span id="title">'+(tc?'<a href="index.html?lang='+F(a)+'">':'<a href="./?lang='+F(a)+'">')+"Blockly Games</a> : "+F("JS Pond")+"</span>"),d=" &nbsp; ",e=1;11>e;e++)d+=" "+(e==b?'<span class="level_number level_done" id="level'+F(e)+'">'+F(e)+"</span>":10==e?'<a class="level_number" id="level'+F(e)+'" href="?lang='+F(a)+"&level="+F(e)+F("")+'">'+F(e)+"</a>":'<a class="level_dot" id="level'+F(e)+'" href="?lang='+F(a)+"&level="+F(e)+F("")+'"></a>');return c+d+'</h1></td><td class="farSide"><select id="languageMenu"></select>&nbsp;<button id="linkButton" title="Hifadhi na kiungo cha vishiku. "><img src="media/1x1.gif" class="link icon21"></button>&nbsp;<button id="helpButton">Huduma</button></td></tr></table><div id="visualization"><canvas id="scratch" width="400" height="400" style="display: none"></canvas><canvas id="display" width="400" height="400"></canvas></div><table id="playerStatTable"><tbody><tr id="playerStatRow"></tr></tbody></table><table width="400"><tr><td style="width: 190px; text-align: center; vertical-align: top;"><button id="docsButton" title="Display the language documentation.">Documentation</button></td><td><button id="runButton" class="primary" title="Run the program you wrote."><img src="media/1x1.gif" class="run icon21"> Endesha Programu</button><button id="resetButton" class="primary" style="display: none" title="Stop the program and reset the level."><img src="media/1x1.gif" class="stop icon21"> Seti upya</button></td></tr></table><div id="dialogDocs"><img src="media/1x1.gif" class="close icon21" id="closeDocs"><iframe id="frameDocs"></iframe></div><div id="editor"></div>\n<div id="playerTarget" style="display: none">\n</div>\n\n<div id="playerRabbit" style="display: none">\n/* rabbit */\n// rabbit runs around the field, randomly and never fires; use as a target.\n\n/* go - go to the point specified */\nfunction go (dest_x, dest_y) {\n  var course = plot_course(dest_x, dest_y);\n  while (distance(loc_x(), loc_y(), dest_x, dest_y) > 5) {\n    drive(course, 25);\n  }\n  while (speed() > 0) {\n    drive(course, 0);\n  }\n}\n\n/* distance forumula. */\nfunction distance(x1, y1, x2, y2) {\n  var x = x1 - x2;\n  var y = y1 - y2;\n  return Math.sqrt((x * x) + (y * y));\n}\n\n/* plot_course - figure out which heading to go. */\nfunction plot_course(xx, yy) {\n  var d;\n  var curx = loc_x();\n  var cury = loc_y();\n  var x = curx - xx;\n  var y = cury - yy;\n\n  if (x == 0) {\n    if (yy > cury) {\n      d = 90;\n    } else {\n      d = 270;\n    }\n  } else {\n    if (yy < cury) {\n      if (xx > curx) {\n        d = 360 + Math.atan_deg(y / x);\n      } else {\n        d = 180 + Math.atan_deg(y / x);\n      }\n    } else {\n      if (xx > curx) {\n        d = Math.atan_deg(y / x);\n      } else {\n        d = 180 + Math.atan_deg(y / x);\n      }\n    }\n  }\n  return d;\n}\n\nwhile (true) {\n  // Go somewhere in the field.\n  var x = Math.random() * 100;\n  var y = Math.random() * 100;\n  go(x, y);\n}\n</div>\n\n<div id="playerCounter" style="display: none">\n/* counter */\n/* scan in a counter-clockwise direction (increasing degrees) */\n/* moves when hit */\n\nvar range;\nvar last_dir = 0;\n\nvar res = 2;\nvar d = damage();\nvar angle = Math.random() * 360;\nwhile (true) {\n  while ((range = scan(angle, res)) != Infinity) {\n    if (range > 70) { /* out of range, head toward it */\n      drive(angle, 50);\n      var i = 1;\n      while (i++ < 50) /* use a counter to limit move time */\n        ;\n      drive (angle, 0);\n      if (d != damage()) {\n        d = damage();\n        run();\n      }\n      angle -= 3;\n    } else {\n      while (!cannon(angle, range))\n        ;\n      if (d != damage()) {\n        d = damage();\n        run();\n      }\n      angle -= 15;\n    }\n  }\n  if (d != damage()) {\n    d = damage();\n    run();\n  }\n  angle += res;\n  angle %= 360;\n}\n\n/* run moves around the center of the field */\nfunction run() {\n  var i = 0;\n  var x = loc_x();\n  var y = loc_y();\n\n  if (last_dir == 0) {\n    last_dir = 1;\n    if (y > 51) {\n      drive(270, 100);\n      while (y - 10 < loc_y() && i++ < 50)\n        ;\n      drive(270, 0);\n    } else {\n      drive(90, 100);\n      while (y + 10 > loc_y() && i++ < 50)\n        ;\n      drive(90, 0);\n    }\n  } else {\n    last_dir = 0;\n    if (x > 51) {\n      drive(180, 100);\n      while (x - 10 < loc_x() && i++ < 50)\n        ;\n      drive(180, 0);\n    } else {\n      drive(0, 100);\n      while (x + 10 > loc_x() && i++ < 50)\n        ;\n      drive(0, 0);\n    }\n  }\n}\n</div>\n\n<div id="playerRook" style="display: none">\n/* rook.r  -  scans the battlefield like a rook, i.e., only 0,90,180,270 */\n/* move horizontally only, but looks horz and vertically */\n\n/* move to center of board */\nif (loc_y() < 50) {\n  while (loc_y() < 40)        /* stop near center */\n    drive(90, 100);           /* start moving */\n} else {\n  while (loc_y() > 60)        /* stop near center */\n    drive(270, 100);          /* start moving */\n}\ndrive(0, 0);\nwhile (speed() > 0)\n  ;\n\n/* initialize starting parameters */\nvar d = damage();\nvar course = 0;\nvar boundary = 99;\ndrive(course, 30);\n\n/* main loop */\nwhile(true) {\n  /* look all directions */\n  look(0);\n  look(90);\n  look(180);\n  look(270);\n\n  /* if near end of battlefield, change directions */\n  if (course == 0) {\n    if (loc_x() > boundary || speed() == 0)\n      change();\n  }\n  else {\n    if (loc_x() < boundary || speed() == 0)\n      change();\n  }\n}\n\n/* look somewhere, and fire cannon repeatedly at in-range target */\nfunction look(deg) {\n  var range;\n  while ((range = scan(deg, 4)) <= 70)  {\n    drive(course, 0);\n    cannon(deg, range);\n    if (d + 20 != damage()) {\n      d = damage();\n      change();\n    }\n  }\n}\n\nfunction change() {\n  if (course == 0) {\n    boundary = 1;\n    course = 180;\n  } else {\n    boundary = 99;\n    course = 0;\n  }\n  drive(course, 30);\n}\n</div>\n\n<div id="playerSniper" style="display: none">\n/* sniper */\n/* strategy: since a scan of the entire battlefield can be done in 90 */\n/* degrees from a corner, sniper can scan the field quickly. */\n\n/* external variables, that can be used by any function */\nvar corner = 0;           /* current corner 0, 1, 2, or 2 */\nvar sc = 0;               /* current scan start */\n\nvar range;          /* range to target */\n\n/* initialize the corner info */\n/* x and y location of a corner, and starting scan degree */\nvar c1x = 2,  c1y = 2,  s1 = 0;\nvar c2x = 2,  c2y = 98, s2 = 270;\nvar c3x = 98, c3y = 98, s3 = 180;\nvar c4x = 98, c4y = 2,  s4 = 90;\nvar closest = Infinity;\nnew_corner();       /* start at a random corner */\nvar d = damage();       /* get current damage */\nvar dir = sc;           /* starting scan direction */\n\nwhile (true) {         /* loop is executed forever */\n  while (dir < sc + 90) {  /* scan through 90 degree range */\n    range = scan(dir, 2);   /* look at a direction */\n    if (range <= 70) {\n      while (range > 0) {    /* keep firing while in range */\n        closest = range;     /* set closest flag */\n        cannon(dir, range);   /* fire! */\n        range = scan(dir, 1); /* check target again */\n        if (d + 15 > damage())  /* sustained several hits, */\n          range = 0;            /* goto new corner */\n      }\n      dir -= 10;             /* back up scan, in case */\n    }\n\n    dir += 2;                /* increment scan */\n    if (d != damage()) {     /* check for damage incurred */\n      new_corner();          /* we\'re hit, move now */\n      d = damage();\n      dir = sc;\n    }\n  }\n\n  if (closest == Infinity) {       /* check for any targets in range */\n    new_corner();             /* nothing, move to new corner */\n    d = damage();\n    dir = sc;\n  } else {                     /* targets in range, resume */\n    dir = sc;\n  }\n  closest = Infinity;\n}\n\n/* new corner function to move to a different corner */\nfunction new_corner() {\n  var x, y;\n\n  var rand = Math.floor(Math.random() * 4);           /* pick a random corner */\n  if (rand == corner)       /* but make it different than the */\n    corner = (rand + 1) % 4;/* current corner */\n  else\n    corner = rand;\n  if (corner == 0) {       /* set new x,y and scan start */\n    x = c1x;\n    y = c1y;\n    sc = s1;\n  }\n  if (corner == 1) {\n    x = c2x;\n    y = c2y;\n    sc = s2;\n  }\n  if (corner == 2) {\n    x = c3x;\n    y = c3y;\n    sc = s3;\n  }\n  if (corner == 3) {\n    x = c4x;\n    y = c4y;\n    sc = s4;\n  }\n\n  /* find the heading we need to get to the desired corner */\n  var angle = plot_course(x,y);\n\n  /* start drive train, full speed */\n\n  /* keep traveling until we are within 15 meters */\n  /* speed is checked in case we run into wall, other robot */\n  /* not terribly great, since were are doing nothing while moving */\n\n  while (distance(loc_x(), loc_y(), x, y) > 15)\n    drive(angle, 100);\n\n  /* cut speed, and creep the rest of the way */\n\n  while (distance(loc_x(), loc_y(), x, y) > 1)\n    drive(angle, 20);\n\n  /* stop drive, should coast in the rest of the way */\n  drive(angle, 0);\n}  /* end of new_corner */\n\n/* classical pythagorean distance formula */\nfunction distance(x1, y1, x2, y2) {\n  var x = x1 - x2;\n  var y = y1 - y2;\n  return Math.sqrt((x * x) + (y * y));\n}\n\n/* plot course function, return degree heading to */\n/* reach destination x, y; uses atan() trig function */\nfunction plot_course(xx, yy) {\n  var d;\n  var x,y;\n  var curx, cury;\n\n  curx = loc_x();  /* get current location */\n  cury = loc_y();\n  x = curx - xx;\n  y = cury - yy;\n\n  /* atan only returns -90 to +90, so figure out how to use */\n  /* the atan() value */\n\n  if (x == 0) {      /* x is zero, we either move due north or south */\n    if (yy > cury)\n      d = 90;        /* north */\n    else\n      d = 270;       /* south */\n  } else {\n    if (yy < cury) {\n      if (xx > curx)\n        d = 360 + Math.atan_deg(y / x);  /* south-east, quadrant 4 */\n      else\n        d = 180 + Math.atan_deg(y / x);  /* south-west, quadrant 3 */\n    } else {\n      if (xx > curx)\n        d = Math.atan_deg(y / x);        /* north-east, quadrant 1 */\n      else\n        d = 180 + Math.atan_deg(y / x);  /* north-west, quadrant 2 */\n    }\n  }\n  return d;\n}\n</div>\n\n<div id="playerPendulum" style="display: none">\n/* Slowly moves east and west.  Does not fire. */\nvar west = false;\nwhile (true) {\n  if (west) {\n    if (loc_x() > 15) {\n      drive(180, 25);\n    } else {\n      west = false;\n      drive(0, 0);\n    }\n  } else {\n    if (loc_x() < 75) {\n      drive(0, 25);\n    } else {\n      west = true;\n      drive(0, 0);\n    }\n  }\n}\n</div>\n\n<div id="playerScared" style="display: none">\n/* Moves south-west when hit.  Does not fire. */\nvar d = damage();\nwhile (true) {\n  if (d != damage()) {\n    drive(315, 100);\n    var t = 0;\n    for (var t = 0; t < 100; t++) {}\n    d = damage();\n    drive(0, 0);\n  }\n}\n</div>\n<div id="dialogShadow" class="dialogAnimate"></div><div id="dialogBorder"></div><div id="dialog"></div><div id="dialogDone" class="dialogHiddenContent"><div style="font-size: large; margin: 1em;">Congratulations!</div><div id="dialogLinesText" style="font-size: large; margin: 1em;"></div><pre id="containerCode"></pre><div id="dialogDoneText" style="font-size: large; margin: 1em;"></div><div id="dialogDoneButtons" class="farSide" style="padding: 1ex 3ex 0"><button id="doneCancel">Cancel</button><button id="doneOk" class="secondary">Sawa</button></div></div>'+
('<div id="dialogStorage" class="dialogHiddenContent"><div id="containerStorage"></div>'+qc()+"</div>")+(3==b?'<div id="helpUseScan" class="dialogHiddenContent"><div style="padding-bottom: 0.7ex">Your solution works, but you can do better. Use \'scan\' to tell the cannon how far to shoot.</div>'+qc()+"</div>":"")+'<div id="help" class="dialogHiddenContent"><div style="padding-bottom: 0.7ex">'+(1==b?"Use the 'cannon' command to hit the target. The first parameter is the angle, the second parameter is the range. Find the right combination.<pre>cannon(0, 70);</pre>":
2==b?"This target needs to be hit many times. Use a 'while (true)' loop to do something indefinitely.<pre>while (true) {\n  ...\n}</pre>":3==b?"This opponent moves back and forth, making it hard to hit. The 'scan' expression returns the exact range to the opponent in the specified direction.<pre>scan(0, 5)</pre>This range is exactly what the 'cannon' command needs to fire accurately.":4==b?"This opponent is too far away to use the cannon (which has a limit of 70 meters). Instead, use the 'swim' command to start swimming towards the opponent and crash into it.<pre>swim(0, 50);</pre>":
5==b?"This opponent is also too far away to use the cannon. But you are too weak to survive a collision. Swim towards the opponent while your horizontal location is less than than 50. Then 'stop' and use the cannon.<pre>loc_x() &lt; 50</pre><pre>stop();</pre>":6==b?"This opponent will move away when it is hit. Swim towards it if it is out of range (70 meters).":7==b?"Rabbit runs around randomly. Can you hit it?":8==b?"Rook fights back! But it only looks north, south, east and west.":9==b?"Counter looks in all directions. Can you handle two opponents at once?":
10==b?"Sniper hides in a corner looking for targets. Good luck. Seriously.":"")+"</div>"+qc()+"</div>"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var uc={},H,vc,I,wc,xc,yc,zc,Ac,Bc,Cc,Dc,Ec,Fc,Gc,Hc;/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ic(a){var b;H&&(b=a.Hb().Q);var c=C("xml");a=Jc(a,!0);for(var d=0,e;e=a[d];d++){var g=Kc(e);e=J(e);g.setAttribute("x",H?b-e.x:e.x);g.setAttribute("y",e.y);c.appendChild(g)}return c}
function Kc(a){var b=C("block");b.setAttribute("type",a.type);b.setAttribute("id",a.id);if(a.Mh){var c=a.Mh();c&&b.appendChild(c)}for(var d=0;c=a.T[d];d++)for(var e=0,g;g=c.ta[e];e++)if(g.name&&g.bd){var h=C("field",null,g.wh());h.setAttribute("name",g.name);b.appendChild(h)}a.ya&&(c=C("comment",null,a.ya.Ib()),c.setAttribute("pinned",a.ya.A()),d=a.ya.kc(),c.setAttribute("h",d.height),c.setAttribute("w",d.width),b.appendChild(c));d=!1;for(e=0;c=a.T[e];e++){var k;g=!0;5!=c.type&&(h=K(c.p),1==c.type?
(k=C("value"),d=!0):3==c.type&&(k=C("statement")),h&&(k.appendChild(Kc(h)),g=!1),k.setAttribute("name",c.name),g||b.appendChild(k))}d&&b.setAttribute("inline",a.xd);a.isCollapsed()&&b.setAttribute("collapsed",!0);a.disabled&&b.setAttribute("disabled",!0);a.hc&&!L||b.setAttribute("deletable",!1);a.Mb&&!L||b.setAttribute("movable",!1);a.Kc&&!L||b.setAttribute("editable",!1);if(a=Lc(a))k=C("next",null,Kc(a)),b.appendChild(k);return b}function Mc(a){return(new XMLSerializer).serializeToString(a)}
function Nc(a){a=(new DOMParser).parseFromString(a,"text/xml");if(!a||!a.firstChild||"xml"!=a.firstChild.nodeName.toLowerCase()||a.firstChild!==a.lastChild)throw"Blockly.Xml.textToDom did not obtain a valid XML tree.";return a.firstChild}function Oc(a,b){if(H)var c=a.Hb().Q;for(var d=0,e;e=b.childNodes[d];d++)if("block"==e.nodeName.toLowerCase()){var g=Pc(a,e),h=parseInt(e.getAttribute("x"),10);e=parseInt(e.getAttribute("y"),10);isNaN(h)||isNaN(e)||g.moveBy(H?c-h:h,e)}}
function Pc(a,b,c){var d=null,e=b.getAttribute("type");if(!e)throw"Block type unspecified: \n"+b.outerHTML;var g=b.getAttribute("id");if(c&&g){d=Qc(g,a);if(!d)throw"Couldn't get Block with id: "+g;g=d.getParent();d.s&&d.j(!0,!1,!0);d.fill(a,e);d.wa=g}else d=Rc(a,e);d.i||Sc(d);(g=b.getAttribute("inline"))&&Tc(d,"true"==g);(g=b.getAttribute("disabled"))&&Uc(d,"true"==g);(g=b.getAttribute("deletable"))&&Vc(d,"true"==g);if(g=b.getAttribute("movable"))d.Mb="true"==g;(g=b.getAttribute("editable"))&&Wc(d,
"true"==g);for(var h=null,g=0,k;k=b.childNodes[g];g++)if(3!=k.nodeType||!k.data.match(/^\s*$/)){for(var h=null,l=0,q;q=k.childNodes[l];l++)3==q.nodeType&&q.data.match(/^\s*$/)||(h=q);l=k.getAttribute("name");switch(k.nodeName.toLowerCase()){case "mutation":d.mj&&d.mj(k);break;case "comment":Xc(d,k.textContent);var m=k.getAttribute("pinned");m&&setTimeout(function(){d.ya.I("true"==m)},1);h=parseInt(k.getAttribute("w"),10);k=parseInt(k.getAttribute("h"),10);isNaN(h)||isNaN(k)||d.ya.yc(h,k);break;case "title":case "field":Yc(d,
l).Yc(k.textContent);break;case "value":case "statement":k=Zc(d,l);if(!k)throw"Input "+l+" does not exist in block "+e;if(h&&"block"==h.nodeName.toLowerCase())if(h=Pc(a,h,c),h.K)$c(k.p,h.K);else if(h.C)$c(k.p,h.C);else throw"Child block does not have output or previous statement.";break;case "next":if(h&&"block"==h.nodeName.toLowerCase()){if(!d.J)throw"Next statement does not exist.";if(d.J.o)throw"Next statement is already connected.";h=Pc(a,h,c);if(!h.C)throw"Next block does not have previous statement.";
$c(d.J,h.C)}}}(a=b.getAttribute("collapsed"))&&d.Gd("true"==a);(a=Lc(d))?a.F():d.F();return d}function ad(a){for(var b=0,c;c=a.childNodes[b];b++)if("next"==c.nodeName.toLowerCase()){a.removeChild(c);break}}window.Blockly||(window.Blockly={});window.Blockly.Xml||(window.Blockly.Xml={});window.Blockly.Xml.domToText=Mc;window.Blockly.Xml.domToWorkspace=Oc;window.Blockly.Xml.textToDom=Nc;window.Blockly.Xml.workspaceToDom=Ic;/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function bd(a){this.v=a;this.P=null;this.qd=new cd(a,!0,!0);this.Sd=new cd(a,!1,!0);this.fd=M("rect",{height:N,width:N,style:"fill: #fff"},null);dd(this.fd,a.Zc)}bd.prototype.j=function(){O(this.He);this.He=null;E(this.fd);this.P=this.v=this.fd=null;this.qd.j();this.qd=null;this.Sd.j();this.Sd=null};
bd.prototype.resize=function(){var a=this.v.Hb();if(a){var b=!1,c=!1;this.P&&this.P.Q==a.Q&&this.P.xa==a.xa&&this.P.Za==a.Za&&this.P.Ya==a.Ya?(this.P&&this.P.Ic==a.Ic&&this.P.Ca==a.Ca&&this.P.Cb==a.Cb||(b=!0),this.P&&this.P.Ra==a.Ra&&this.P.Ab==a.Ab&&this.P.cb==a.cb||(c=!0)):c=b=!0;b&&this.qd.resize(a);c&&this.Sd.resize(a);this.P&&this.P.Q==a.Q&&this.P.Ya==a.Ya||this.fd.setAttribute("x",this.Sd.dc);this.P&&this.P.xa==a.xa&&this.P.Za==a.Za||this.fd.setAttribute("y",this.qd.Ze);this.P=a}};
bd.prototype.set=function(a,b){this.qd.set(a);this.Sd.set(b)};function cd(a,b,c){this.v=a;this.Ie=c||!1;this.Aa=b;this.qf();b?(this.Va.setAttribute("height",N),this.ba.setAttribute("height",N-6),this.ba.setAttribute("y",3)):(this.Va.setAttribute("width",N),this.ba.setAttribute("width",N-6),this.ba.setAttribute("x",3));this.Qh=P(this.Va,"mousedown",this,this.$j);this.Rh=P(this.ba,"mousedown",this,this.ak)}var ed,fd,N="ontouchstart"in document.documentElement?25:15;f=cd.prototype;
f.j=function(){this.Ge();this.He&&(O(this.He),this.He=null);O(this.Qh);this.Qh=null;O(this.Rh);this.Rh=null;E(this.g);this.v=this.ba=this.Va=this.g=null};
f.resize=function(a){if(!a&&(a=this.v.Hb(),!a))return;if(this.Aa){var b=a.Q;this.Ie?b-=N:this.I(b<a.Ra);this.Ga=b/a.Ic;if(-Infinity===this.Ga||Infinity===this.Ga||isNaN(this.Ga))this.Ga=0;var c=a.Q*this.Ga,d=(a.Ca-a.Cb)*this.Ga;this.ba.setAttribute("width",Math.max(0,c));this.dc=a.Ya;this.Ie&&H&&(this.dc+=a.Ya+N);this.Ze=a.Za+a.xa-N;this.g.setAttribute("transform","translate("+this.dc+", "+this.Ze+")");this.Va.setAttribute("width",Math.max(0,b));this.ba.setAttribute("x",gd(this,d))}else{b=a.xa;this.Ie?
b-=N:this.I(b<a.Ra);this.Ga=b/a.Ra;if(-Infinity===this.Ga||Infinity===this.Ga||isNaN(this.Ga))this.Ga=0;c=a.xa*this.Ga;d=(a.Ab-a.cb)*this.Ga;this.ba.setAttribute("height",Math.max(0,c));this.dc=a.Ya;H||(this.dc+=a.Q-N);this.Ze=a.Za;this.g.setAttribute("transform","translate("+this.dc+", "+this.Ze+")");this.Va.setAttribute("height",Math.max(0,b));this.ba.setAttribute("y",gd(this,d))}hd(this)};
f.qf=function(){this.g=M("g",{},null);this.Va=M("rect",{"class":"blocklyScrollbarBackground"},this.g);var a=Math.floor((N-6)/2);this.ba=M("rect",{"class":"blocklyScrollbarKnob",rx:a,ry:a},this.g);dd(this.g,this.v.Zc)};f.A=function(){return"none"!=this.g.getAttribute("display")};f.I=function(a){if(a!=this.A()){if(this.Ie)throw"Unable to toggle visibility of paired scrollbars.";a?this.g.setAttribute("display","block"):(this.v.ci({x:0,y:0}),this.g.setAttribute("display","none"))}};
f.$j=function(a){this.Ge();if(!id(a)){var b=jd(a),b=this.Aa?b.x:b.y,c=kd(this.ba),c=this.Aa?c.x:c.y,d=parseFloat(this.ba.getAttribute(this.Aa?"width":"height")),e=parseFloat(this.ba.getAttribute(this.Aa?"x":"y")),g=.95*d;b<=c?e-=g:b>=c+d&&(e+=g);this.ba.setAttribute(this.Aa?"x":"y",gd(this,e));hd(this)}a.stopPropagation()};
f.ak=function(a){this.Ge();id(a)||(this.xk=parseFloat(this.ba.getAttribute(this.Aa?"x":"y")),this.zk=this.Aa?a.clientX:a.clientY,ed=P(document,"mouseup",this,this.Ge),fd=P(document,"mousemove",this,this.ck));a.stopPropagation()};f.ck=function(a){this.ba.setAttribute(this.Aa?"x":"y",gd(this,this.xk+((this.Aa?a.clientX:a.clientY)-this.zk)));hd(this)};f.Ge=function(){ld();md(!0);ed&&(O(ed),ed=null);fd&&(O(fd),fd=null)};
function gd(a,b){if(0>=b||isNaN(b))b=0;else{var c=a.Aa?"width":"height",d=parseFloat(a.Va.getAttribute(c)),c=parseFloat(a.ba.getAttribute(c));b=Math.min(b,d-c)}return b}function hd(a){var b=parseFloat(a.ba.getAttribute(a.Aa?"x":"y")),c=parseFloat(a.Va.getAttribute(a.Aa?"width":"height")),b=b/c;isNaN(b)&&(b=0);c={};a.Aa?c.x=b:c.y=b;a.v.ci(c)}f.set=function(a){this.ba.setAttribute(this.Aa?"x":"y",a*this.Ga);hd(this)};
function dd(a,b){var c=b.nextSibling,d=b.parentNode;if(!d)throw"Reference node has no parent.";c?d.insertBefore(a,c):d.appendChild(a)};function nd(){0!=od&&(pd[ia(this)]=this);this.gd=this.gd;this.Ee=this.Ee}var od=0,pd={};nd.prototype.gd=!1;nd.prototype.j=function(){if(!this.gd&&(this.gd=!0,this.X(),0!=od)){var a=ia(this);delete pd[a]}};nd.prototype.X=function(){if(this.Ee)for(;this.Ee.length;)this.Ee.shift()()};var qd="closure_listenable_"+(1E6*Math.random()|0),rd=0;function sd(a,b,c,d,e){this.qc=a;this.Le=null;this.src=b;this.type=c;this.Yd=!!d;this.re=e;this.key=++rd;this.Vc=this.Xd=!1}function td(a){a.Vc=!0;a.qc=null;a.Le=null;a.src=null;a.re=null};function ud(a){this.src=a;this.Ba={};this.Rd=0}ud.prototype.add=function(a,b,c,d,e){var g=a.toString();a=this.Ba[g];a||(a=this.Ba[g]=[],this.Rd++);var h=vd(a,b,d,e);-1<h?(b=a[h],c||(b.Xd=!1)):(b=new sd(b,this.src,g,!!d,e),b.Xd=c,a.push(b));return b};ud.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.Ba))return!1;var e=this.Ba[a];b=vd(e,b,c,d);return-1<b?(td(e[b]),w.splice.call(e,b,1),0==e.length&&(delete this.Ba[a],this.Rd--),!0):!1};
function wd(a,b){var c=b.type;if(!(c in a.Ba))return!1;var d=Wa(a.Ba[c],b);d&&(td(b),0==a.Ba[c].length&&(delete a.Ba[c],a.Rd--));return d}ud.prototype.Pe=function(a){a=a&&a.toString();var b=0,c;for(c in this.Ba)if(!a||c==a){for(var d=this.Ba[c],e=0;e<d.length;e++)++b,td(d[e]);delete this.Ba[c];this.Rd--}return b};ud.prototype.od=function(a,b,c,d){a=this.Ba[a.toString()];var e=-1;a&&(e=vd(a,b,c,d));return-1<e?a[e]:null};
function vd(a,b,c,d){for(var e=0;e<a.length;++e){var g=a[e];if(!g.Vc&&g.qc==b&&g.Yd==!!c&&g.re==d)return e}return-1};function xd(a,b){this.type=a;this.currentTarget=this.target=b;this.defaultPrevented=this.uc=!1;this.$h=!0}xd.prototype.X=function(){};xd.prototype.j=function(){};xd.prototype.stopPropagation=function(){this.uc=!0};xd.prototype.preventDefault=function(){this.defaultPrevented=!0;this.$h=!1};var yd=!x||x&&9<=Nb,zd=!x||x&&9<=Nb,Ad=x&&!z("9");!y||z("528");Eb&&z("1.9b")||x&&z("8")||Db&&z("9.5")||y&&z("528");Eb&&!z("8")||x&&z("9");var Bd="ontouchstart"in n||!!(n.document&&document.documentElement&&"ontouchstart"in document.documentElement)||!(!n.navigator||!n.navigator.msMaxTouchPoints);function Cd(a){Cd[" "](a);return a}Cd[" "]=ba;function Dd(a,b){xd.call(this,a?a.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.charCode=this.keyCode=this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.cg=!1;this.Gb=null;a&&this.Y(a,b)}u(Dd,xd);var Ed=[1,4,2];
Dd.prototype.Y=function(a,b){var c=this.type=a.type;this.target=a.target||a.srcElement;this.currentTarget=b;var d=a.relatedTarget;if(d){if(Eb){var e;a:{try{Cd(d.nodeName);e=!0;break a}catch(g){}e=!1}e||(d=null)}}else"mouseover"==c?d=a.fromElement:"mouseout"==c&&(d=a.toElement);this.relatedTarget=d;this.offsetX=y||void 0!==a.offsetX?a.offsetX:a.layerX;this.offsetY=y||void 0!==a.offsetY?a.offsetY:a.layerY;this.clientX=void 0!==a.clientX?a.clientX:a.pageX;this.clientY=void 0!==a.clientY?a.clientY:a.pageY;
this.screenX=a.screenX||0;this.screenY=a.screenY||0;this.button=a.button;this.keyCode=a.keyCode||0;this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.cg=Fb?a.metaKey:a.ctrlKey;this.state=a.state;this.Gb=a;a.defaultPrevented&&this.preventDefault()};function Fd(a){return yd?0==a.Gb.button:"click"==a.type?!0:!!(a.Gb.button&Ed[0])}
Dd.prototype.stopPropagation=function(){Dd.n.stopPropagation.call(this);this.Gb.stopPropagation?this.Gb.stopPropagation():this.Gb.cancelBubble=!0};Dd.prototype.preventDefault=function(){Dd.n.preventDefault.call(this);var a=this.Gb;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,Ad)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(b){}};Dd.prototype.X=function(){};var Gd="closure_lm_"+(1E6*Math.random()|0),Hd={},Id=0;function Jd(a,b,c,d,e){if(ea(b)){for(var g=0;g<b.length;g++)Jd(a,b[g],c,d,e);return null}c=Kd(c);if(a&&a[qd])a=a.D(b,c,d,e);else{if(!b)throw Error("Invalid event type");var g=!!d,h=Ld(a);h||(a[Gd]=h=new ud(a));c=h.add(b,c,!1,d,e);c.Le||(d=Md(),c.Le=d,d.src=a,d.qc=c,a.addEventListener?a.addEventListener(b.toString(),d,g):a.attachEvent(Nd(b.toString()),d),Id++);a=c}return a}
function Md(){var a=Od,b=zd?function(c){return a.call(b.src,b.qc,c)}:function(c){c=a.call(b.src,b.qc,c);if(!c)return c};return b}function Pd(a,b,c,d,e){if(ea(b))for(var g=0;g<b.length;g++)Pd(a,b[g],c,d,e);else c=Kd(c),a&&a[qd]?a.Wa(b,c,d,e):a&&(a=Ld(a))&&(b=a.od(b,c,!!d,e))&&Qd(b)}
function Qd(a){if(r(a)||!a||a.Vc)return!1;var b=a.src;if(b&&b[qd])return wd(b.Ub,a);var c=a.type,d=a.Le;b.removeEventListener?b.removeEventListener(c,d,a.Yd):b.detachEvent&&b.detachEvent(Nd(c),d);Id--;(c=Ld(b))?(wd(c,a),0==c.Rd&&(c.src=null,b[Gd]=null)):td(a);return!0}function Nd(a){return a in Hd?Hd[a]:Hd[a]="on"+a}function Rd(a,b,c,d){var e=1;if(a=Ld(a))if(b=a.Ba[b.toString()])for(b=b.concat(),a=0;a<b.length;a++){var g=b[a];g&&g.Yd==c&&!g.Vc&&(e&=!1!==Sd(g,d))}return Boolean(e)}
function Sd(a,b){var c=a.qc,d=a.re||a.src;a.Xd&&Qd(a);return c.call(d,b)}
function Od(a,b){if(a.Vc)return!0;if(!zd){var c=b||aa("window.event"),d=new Dd(c,this),e=!0;if(!(0>c.keyCode||void 0!=c.returnValue)){a:{var g=!1;if(0==c.keyCode)try{c.keyCode=-1;break a}catch(h){g=!0}if(g||void 0==c.returnValue)c.returnValue=!0}c=[];for(g=d.currentTarget;g;g=g.parentNode)c.push(g);for(var g=a.type,k=c.length-1;!d.uc&&0<=k;k--)d.currentTarget=c[k],e&=Rd(c[k],g,!0,d);for(k=0;!d.uc&&k<c.length;k++)d.currentTarget=c[k],e&=Rd(c[k],g,!1,d)}return e}return Sd(a,new Dd(b,this))}
function Ld(a){a=a[Gd];return a instanceof ud?a:null}var Td="__closure_events_fn_"+(1E9*Math.random()>>>0);function Kd(a){if(s(a))return a;a[Td]||(a[Td]=function(b){return a.handleEvent(b)});return a[Td]};function Ud(){nd.call(this);this.Ub=new ud(this);this.Ki=this;this.bg=null}u(Ud,nd);Ud.prototype[qd]=!0;f=Ud.prototype;f.oe=function(){return this.bg};f.og=function(a){this.bg=a};f.addEventListener=function(a,b,c,d){Jd(this,a,b,c,d)};f.removeEventListener=function(a,b,c,d){Pd(this,a,b,c,d)};
f.dispatchEvent=function(a){var b,c=this.oe();if(c)for(b=[];c;c=c.oe())b.push(c);var c=this.Ki,d=a.type||a;if(p(a))a=new xd(a,c);else if(a instanceof xd)a.target=a.target||c;else{var e=a;a=new xd(d,c);kb(a,e)}var e=!0,g;if(b)for(var h=b.length-1;!a.uc&&0<=h;h--)g=a.currentTarget=b[h],e=Vd(g,d,!0,a)&&e;a.uc||(g=a.currentTarget=c,e=Vd(g,d,!0,a)&&e,a.uc||(e=Vd(g,d,!1,a)&&e));if(b)for(h=0;!a.uc&&h<b.length;h++)g=a.currentTarget=b[h],e=Vd(g,d,!1,a)&&e;return e};
f.X=function(){Ud.n.X.call(this);this.Ub&&this.Ub.Pe(void 0);this.bg=null};f.D=function(a,b,c,d){return this.Ub.add(String(a),b,!1,c,d)};f.Wa=function(a,b,c,d){return this.Ub.remove(String(a),b,c,d)};function Vd(a,b,c,d){b=a.Ub.Ba[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,g=0;g<b.length;++g){var h=b[g];if(h&&!h.Vc&&h.Yd==c){var k=h.qc,l=h.re||h.src;h.Xd&&wd(a.Ub,h);e=!1!==k.call(l,d)&&e}}return e&&0!=d.$h}f.od=function(a,b,c,d){return this.Ub.od(String(a),b,c,d)};function Wd(a,b,c){if(s(a))c&&(a=na(a,c));else if(a&&"function"==typeof a.handleEvent)a=na(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<b?-1:n.setTimeout(a,b||0)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Xd(a){this.v=a}f=Xd.prototype;f.ed=47;f.$e=45;f.cd=15;f.xi=35;f.Gg=35;f.Ud=25;f.Lb=!1;f.g=null;f.We=null;f.Uf=0;f.$b=0;f.Ih=0;f.mi=0;
f.H=function(){this.g=M("g",{filter:"url(#blocklyTrashcanShadowFilter)"},null);var a=M("clipPath",{id:"blocklyTrashBodyClipPath"},this.g);M("rect",{width:this.ed,height:this.$e,y:this.cd},a);M("image",{width:Yd,height:Zd,y:-32,"clip-path":"url(#blocklyTrashBodyClipPath)"},this.g).setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",Q+$d);a=M("clipPath",{id:"blocklyTrashLidClipPath"},this.g);M("rect",{width:this.ed,height:this.cd},a);this.We=M("image",{width:Yd,height:Zd,y:-32,"clip-path":"url(#blocklyTrashLidClipPath)"},
this.g);this.We.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",Q+$d);this.kf();return this.g};f.Y=function(){ae(this,!1);this.Cd();P(window,"resize",this,this.Cd)};f.j=function(){this.g&&(E(this.g),this.g=null);this.v=this.We=null;n.clearTimeout(this.Uf)};f.Cd=function(){var a=this.v.Hb();a&&(this.Ih=H?this.Gg:a.Q+a.Ya-this.ed-this.Gg,this.mi=a.xa+a.Za-(this.$e+this.cd)-this.xi,this.g.setAttribute("transform","translate("+this.Ih+","+this.mi+")"))};
function ae(a,b){a.Lb!=b&&(n.clearTimeout(a.Uf),a.Lb=b,a.kf())}f.kf=function(){this.$b+=this.Lb?.2:-.2;this.$b=Sb(this.$b,0,1);var a=45*this.$b;this.We.setAttribute("transform","rotate("+(H?-a:a)+", "+(H?4:this.ed-4)+", "+(this.cd-2)+")");this.g.style.opacity=.2+.2*this.$b;if(0<this.$b||1>this.$b)this.Uf=Wd(this.kf,20,this)};f.close=function(){ae(this,!1)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function be(a,b){this.Hb=a;this.ci=b;this.Gh=!1;this.$c=[];this.Wf=Infinity;var c=[];c[1]=new ce;c[2]=new ce;c[3]=new ce;c[4]=new ce;this.Zi=c}f=be.prototype;f.zf=!1;f.scrollX=0;f.scrollY=0;f.Ia=null;f.Bf=null;f.cc=null;f.H=function(){this.g=M("g",{},null);this.aa=M("g",{},this.g);this.Zc=M("g",{},this.g);de(this);return this.g};f.j=function(){this.g&&(E(this.g),this.g=null);this.Zc=this.aa=null;this.Ia&&(this.Ia.j(),this.Ia=null)};
function ee(){var a=D;if(vc&&!L){a.Ia=new Xd(a);var b=a.Ia.H();a.g.insertBefore(b,a.aa);a.Ia.Y()}}function fe(a,b){a.$c.push(b);ge&&a==D&&-1==he.indexOf(b)&&he.push(b);de(a)}function ie(a,b){for(var c=!1,d,e=0;d=a.$c[e];e++)if(d==b){a.$c.splice(e,1);c=!0;break}if(!c)throw"Block not present in workspace's list of top-most blocks.";ge&&a==D&&he.xl(b);de(a)}
function Jc(a,b){var c=[].concat(a.$c);if(b&&1<c.length){var d=Math.sin(3*Math.PI/180);H&&(d*=-1);c.sort(function(a,b){var c=J(a),k=J(b);return c.y+d*c.x-(k.y+d*k.x)})}return c}function je(a){a=Jc(a,!1);for(var b=0;b<a.length;b++)a.push.apply(a,a[b].lc());return a}f.clear=function(){for(md();this.$c.length;)this.$c[0].j()};f.F=function(){for(var a=je(this),b=0,c;c=a[b];b++)c.lc().length||c.F()};function ke(a,b){for(var c=je(a),d=0,e;e=c[d];d++)if(e.id==b)return e;return null}
function le(a,b){a.Ag=b;a.Bg&&(O(a.Bg),a.Bg=null);b&&(a.Bg=P(a.aa,"blocklySelectChange",a,function(){this.Ag=!1}))}function me(a){var b=D;b.Ag&&0!=ne&&le(b,!1);if(b.Ag){var c=null;if(a&&(c=ke(b,a),!c))return;le(b,!1);c?c.select():R&&oe();setTimeout(function(){le(b,!0)},1)}}function de(a){a.Bf&&window.clearTimeout(a.Bf);var b=a.aa;b&&(a.Bf=window.setTimeout(function(){pe(b,"blocklyWorkspaceChange")},0))}function qe(a){return Infinity==a.Wf?Infinity:a.Wf-je(a).length}be.prototype.clear=be.prototype.clear;function re(a,b,c,d){this.top=a;this.right=b;this.bottom=c;this.left=d}f=re.prototype;f.clone=function(){return new re(this.top,this.right,this.bottom,this.left)};f.toString=function(){return"("+this.top+"t, "+this.right+"r, "+this.bottom+"b, "+this.left+"l)"};f.contains=function(a){return this&&a?a instanceof re?a.left>=this.left&&a.right<=this.right&&a.top>=this.top&&a.bottom<=this.bottom:a.x>=this.left&&a.x<=this.right&&a.y>=this.top&&a.y<=this.bottom:!1};
f.expand=function(a,b,c,d){ga(a)?(this.top-=a.top,this.right+=a.right,this.bottom+=a.bottom,this.left-=a.left):(this.top-=a,this.right+=b,this.bottom+=c,this.left-=d);return this};f.ceil=function(){this.top=Math.ceil(this.top);this.right=Math.ceil(this.right);this.bottom=Math.ceil(this.bottom);this.left=Math.ceil(this.left);return this};f.floor=function(){this.top=Math.floor(this.top);this.right=Math.floor(this.right);this.bottom=Math.floor(this.bottom);this.left=Math.floor(this.left);return this};
f.round=function(){this.top=Math.round(this.top);this.right=Math.round(this.right);this.bottom=Math.round(this.bottom);this.left=Math.round(this.left);return this};f.translate=function(a,b){a instanceof A?(this.left+=a.x,this.right+=a.x,this.top+=a.y,this.bottom+=a.y):(this.left+=a,this.right+=a,r(b)&&(this.top+=b,this.bottom+=b));return this};f.scale=function(a,b){var c=r(b)?b:a;this.left*=a;this.right*=a;this.top*=c;this.bottom*=c;return this};function se(a,b,c,d){this.left=a;this.top=b;this.width=c;this.height=d}f=se.prototype;f.clone=function(){return new se(this.left,this.top,this.width,this.height)};f.toString=function(){return"("+this.left+", "+this.top+" - "+this.width+"w x "+this.height+"h)"};f.contains=function(a){return a instanceof se?this.left<=a.left&&this.left+this.width>=a.left+a.width&&this.top<=a.top&&this.top+this.height>=a.top+a.height:a.x>=this.left&&a.x<=this.left+this.width&&a.y>=this.top&&a.y<=this.top+this.height};
f.vh=function(){return new Ob(this.width,this.height)};f.ceil=function(){this.left=Math.ceil(this.left);this.top=Math.ceil(this.top);this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};f.floor=function(){this.left=Math.floor(this.left);this.top=Math.floor(this.top);this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
f.round=function(){this.left=Math.round(this.left);this.top=Math.round(this.top);this.width=Math.round(this.width);this.height=Math.round(this.height);return this};f.translate=function(a,b){a instanceof A?(this.left+=a.x,this.top+=a.y):(this.left+=a,r(b)&&(this.top+=b));return this};f.scale=function(a,b){var c=r(b)?b:a;this.left*=a;this.width*=a;this.top*=c;this.height*=c;return this};function te(a,b){var c=Xb(a);return c.defaultView&&c.defaultView.getComputedStyle&&(c=c.defaultView.getComputedStyle(a,null))?c[b]||c.getPropertyValue(b)||"":""}function ue(a,b){return te(a,b)||(a.currentStyle?a.currentStyle[b]:null)||a.style&&a.style[b]}function ve(){var a=document,b=a.body,a=a.documentElement;return new A(b.scrollLeft||a.scrollLeft,b.scrollTop||a.scrollTop)}
function we(a){var b;try{b=a.getBoundingClientRect()}catch(c){return{left:0,top:0,right:0,bottom:0}}x&&a.ownerDocument.body&&(a=a.ownerDocument,b.left-=a.documentElement.clientLeft+a.body.clientLeft,b.top-=a.documentElement.clientTop+a.body.clientTop);return b}
function xe(a){if(x&&!(x&&8<=Nb))return a.offsetParent;var b=Xb(a),c=ue(a,"position"),d="fixed"==c||"absolute"==c;for(a=a.parentNode;a&&a!=b;a=a.parentNode)if(c=ue(a,"position"),d=d&&"static"==c&&a!=b.documentElement&&a!=b.body,!d&&(a.scrollWidth>a.clientWidth||a.scrollHeight>a.clientHeight||"fixed"==c||"absolute"==c||"relative"==c))return a;return null}
function ye(a){var b,c=Xb(a),d=ue(a,"position"),e=Eb&&c.getBoxObjectFor&&!a.getBoundingClientRect&&"absolute"==d&&(b=c.getBoxObjectFor(a))&&(0>b.screenX||0>b.screenY),g=new A(0,0),h;b=c?Xb(c):document;(h=!x||x&&9<=Nb)||(h="CSS1Compat"==Vb(b).Fb.compatMode);h=h?b.documentElement:b.body;if(a==h)return g;if(a.getBoundingClientRect)b=we(a),c=Vb(c).Fb,a=y||"CSS1Compat"!=c.compatMode?c.body||c.documentElement:c.documentElement,c=c.parentWindow||c.defaultView,a=x&&z("10")&&c.pageYOffset!=a.scrollTop?new A(a.scrollLeft,
a.scrollTop):new A(c.pageXOffset||a.scrollLeft,c.pageYOffset||a.scrollTop),g.x=b.left+a.x,g.y=b.top+a.y;else if(c.getBoxObjectFor&&!e)b=c.getBoxObjectFor(a),a=c.getBoxObjectFor(h),g.x=b.screenX-a.screenX,g.y=b.screenY-a.screenY;else{b=a;do{g.x+=b.offsetLeft;g.y+=b.offsetTop;b!=a&&(g.x+=b.clientLeft||0,g.y+=b.clientTop||0);if(y&&"fixed"==ue(b,"position")){g.x+=c.body.scrollLeft;g.y+=c.body.scrollTop;break}b=b.offsetParent}while(b&&b!=a);if(Db||y&&"absolute"==d)g.y-=c.body.offsetTop;for(b=a;(b=xe(b))&&
b!=c.body&&b!=h;)g.x-=b.scrollLeft,Db&&"TR"==b.tagName||(g.y-=b.scrollTop)}return g}function ze(a){var b=Ae;if("none"!=ue(a,"display"))return b(a);var c=a.style,d=c.display,e=c.visibility,g=c.position;c.visibility="hidden";c.position="absolute";c.display="inline";a=b(a);c.display=d;c.position=g;c.visibility=e;return a}function Ae(a){var b=a.offsetWidth,c=a.offsetHeight,d=y&&!b&&!c;return(void 0===b||d)&&a.getBoundingClientRect?(a=we(a),new Ob(a.right-a.left,a.bottom-a.top)):new Ob(b,c)}
function Be(a){var b=ye(a);a=ze(a);return new se(b.x,b.y,a.width,a.height)}function Ce(a,b){a.style.display=b?"":"none"}var De=Eb?"MozUserSelect":y?"WebkitUserSelect":null;function Ee(a,b,c){c=c?null:a.getElementsByTagName("*");if(De){if(b=b?"none":"",a.style[De]=b,c){a=0;for(var d;d=c[a];a++)d.style[De]=b}}else if(x||Db)if(b=b?"on":"",a.setAttribute("unselectable",b),c)for(a=0;d=c[a];a++)d.setAttribute("unselectable",b)}var Fe={thin:2,medium:4,thick:6};
function Ge(a,b){if("none"==(a.currentStyle?a.currentStyle[b+"Style"]:null))return 0;var c=a.currentStyle?a.currentStyle[b+"Width"]:null,d;if(c in Fe)d=Fe[c];else if(/^\d+px?$/.test(c))d=parseInt(c,10);else{d=a.style.left;var e=a.runtimeStyle.left;a.runtimeStyle.left=a.currentStyle.left;a.style.left=c;c=a.style.pixelLeft;a.style.left=d;a.runtimeStyle.left=e;d=c}return d}
function He(a){if(x&&!(x&&9<=Nb)){var b=Ge(a,"borderLeft"),c=Ge(a,"borderRight"),d=Ge(a,"borderTop");a=Ge(a,"borderBottom");return new re(d,c,a,b)}b=te(a,"borderLeftWidth");c=te(a,"borderRightWidth");d=te(a,"borderTopWidth");a=te(a,"borderBottomWidth");return new re(parseFloat(d),parseFloat(c),parseFloat(a),parseFloat(b))};function Ie(a){nd.call(this);this.zh=a;this.Ae={}}u(Ie,nd);var Je=[];f=Ie.prototype;f.D=function(a,b,c,d){ea(b)||(b&&(Je[0]=b.toString()),b=Je);for(var e=0;e<b.length;e++){var g=Jd(a,b[e],c||this.handleEvent,d||!1,this.zh||this);if(!g)break;this.Ae[g.key]=g}return this};
f.Wa=function(a,b,c,d,e){if(ea(b))for(var g=0;g<b.length;g++)this.Wa(a,b[g],c,d,e);else c=c||this.handleEvent,e=e||this.zh||this,c=Kd(c),d=!!d,b=a&&a[qd]?a.od(b,c,d,e):a?(a=Ld(a))?a.od(b,c,d,e):null:null,b&&(Qd(b),delete this.Ae[b.key]);return this};f.Pe=function(){ib(this.Ae,Qd);this.Ae={}};f.X=function(){Ie.n.X.call(this);this.Pe()};f.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented");};function Ke(){}ca(Ke);Ke.prototype.Yj=0;function Le(a){Ud.call(this);this.be=a||Vb();this.Se=Me;this.te=null;this.B=!1;this.w=null;this.Wb=void 0;this.Rb=this.R=this.wa=this.Ce=null;this.Mk=!1}u(Le,Ud);Le.prototype.Kj=Ke.Vb();var Me=null;
function Ne(a,b){switch(a){case 1:return b?"disable":"enable";case 2:return b?"highlight":"unhighlight";case 4:return b?"activate":"deactivate";case 8:return b?"select":"unselect";case 16:return b?"check":"uncheck";case 32:return b?"focus":"blur";case 64:return b?"open":"close"}throw Error("Invalid component state");}function Oe(a){return a.te||(a.te=":"+(a.Kj.Yj++).toString(36))}f=Le.prototype;f.h=function(){return this.w};function Pe(a){a.Wb||(a.Wb=new Ie(a));return a.Wb}
f.Na=function(a){if(this==a)throw Error("Unable to set parent component");if(a&&this.wa&&this.te&&Qe(this.wa,this.te)&&this.wa!=a)throw Error("Unable to set parent component");this.wa=a;Le.n.og.call(this,a)};f.getParent=function(){return this.wa};f.og=function(a){if(this.wa&&this.wa!=a)throw Error("Method not supported");Le.n.og.call(this,a)};f.ib=function(){return this.be};f.H=function(){this.w=this.be.createElement("div")};f.F=function(a){this.Fd(a)};
f.Fd=function(a,b){if(this.B)throw Error("Component already rendered");this.w||this.H();a?a.insertBefore(this.w,b||null):this.be.Fb.body.appendChild(this.w);this.wa&&!this.wa.B||this.na()};f.na=function(){this.B=!0;Re(this,function(a){!a.B&&a.h()&&a.na()})};f.Sa=function(){Re(this,function(a){a.B&&a.Sa()});this.Wb&&this.Wb.Pe();this.B=!1};
f.X=function(){this.B&&this.Sa();this.Wb&&(this.Wb.j(),delete this.Wb);Re(this,function(a){a.j()});!this.Mk&&this.w&&E(this.w);this.wa=this.Ce=this.w=this.Rb=this.R=null;Le.n.X.call(this)};f.df=function(a,b){this.Gc(a,Se(this),b)};
f.Gc=function(a,b,c){if(a.B&&(c||!this.B))throw Error("Component already rendered");if(0>b||b>Se(this))throw Error("Child component index out of bounds");this.Rb&&this.R||(this.Rb={},this.R=[]);if(a.getParent()==this){var d=Oe(a);this.Rb[d]=a;Wa(this.R,a)}else{var d=this.Rb,e=Oe(a);if(e in d)throw Error('The object already contains the key "'+e+'"');d[e]=a}a.Na(this);Ya(this.R,b,0,a);a.B&&this.B&&a.getParent()==this?(c=this.hb(),c.insertBefore(a.h(),c.childNodes[b]||null)):c?(this.w||this.H(),b=S(this,
b+1),a.Fd(this.hb(),b?b.w:null)):this.B&&!a.B&&a.w&&a.w.parentNode&&1==a.w.parentNode.nodeType&&a.na()};f.hb=function(){return this.w};function Te(a){null==a.Se&&(a.Se="rtl"==ue(a.B?a.w:a.be.Fb.body,"direction"));return a.Se}f.Id=function(a){if(this.B)throw Error("Component already rendered");this.Se=a};function Ue(a){return!!a.R&&0!=a.R.length}function Se(a){return a.R?a.R.length:0}function Qe(a,b){var c;a.Rb&&b?(c=a.Rb,c=(b in c?c[b]:void 0)||null):c=null;return c}
function S(a,b){return a.R?a.R[b]||null:null}function Re(a,b,c){a.R&&Ra(a.R,b,c)}function Ve(a,b){return a.R&&b?Qa(a.R,b):-1}f.removeChild=function(a,b){if(a){var c=p(a)?a:Oe(a);a=Qe(this,c);if(c&&a){var d=this.Rb;c in d&&delete d[c];Wa(this.R,a);b&&(a.Sa(),a.w&&E(a.w));a.Na(null)}}if(!a)throw Error("Child is not in parent component");return a};f.Zh=function(a){for(var b=[];Ue(this);)b.push(this.removeChild(S(this,0),a));return b};function We(a){if(a.classList)return a.classList;a=a.className;return p(a)&&a.match(/\S+/g)||[]}function Xe(a,b){return a.classList?a.classList.contains(b):Va(We(a),b)}function Ye(a,b){a.classList?a.classList.add(b):Xe(a,b)||(a.className+=0<a.className.length?" "+b:b)}function Ze(a,b){if(a.classList)Ra(b,function(b){Ye(a,b)});else{var c={};Ra(We(a),function(a){c[a]=!0});Ra(b,function(a){c[a]=!0});a.className="";for(var d in c)a.className+=0<a.className.length?" "+d:d}}
function $e(a,b){a.classList?a.classList.remove(b):Xe(a,b)&&(a.className=Sa(We(a),function(a){return a!=b}).join(" "))}function af(a,b){a.classList?Ra(b,function(b){$e(a,b)}):a.className=Sa(We(a),function(a){return!Va(b,a)}).join(" ")};function cf(a,b){if(!a)throw Error("Invalid class name "+a);if(!s(b))throw Error("Invalid decorator function "+b);}var df={};var ef;function ff(a,b){b?a.setAttribute("role",b):a.removeAttribute("role")}function T(a,b,c){ea(c)&&(c=c.join(" "));var d="aria-"+b;""===c||void 0==c?(ef||(ef={atomic:!1,autocomplete:"none",dropeffect:"none",haspopup:!1,live:"off",multiline:!1,multiselectable:!1,orientation:"vertical",readonly:!1,relevant:"additions text",required:!1,sort:"none",busy:!1,disabled:!1,hidden:!1,invalid:"false"}),c=ef,b in c?a.setAttribute(d,c[b]):a.removeAttribute(d)):a.setAttribute(d,c)};function gf(){}var hf;ca(gf);var jf={button:"pressed",checkbox:"checked",menuitem:"selected",menuitemcheckbox:"checked",menuitemradio:"checked",radio:"checked",tab:"selected",treeitem:"selected"};f=gf.prototype;f.ge=function(){};f.H=function(a){var b=a.ib().H("div",this.ke(a).join(" "),a.Db);kf(a,b);return b};f.hb=function(a){return a};f.hd=function(a,b,c){if(a=a.h?a.h():a){var d=[b];x&&!z("7")&&(d=lf(We(a),b),d.push(b));(c?Ze:af)(a,d)}};
f.wd=function(a){Te(a)&&this.Id(a.h(),!0);a.isEnabled()&&this.zc(a,a.A())};function mf(a,b,c){if(a=c||a.ge())c=b.getAttribute("role")||null,a!=c&&ff(b,a)}function kf(a,b){a.A()||T(b,"hidden",!a.A());a.isEnabled()||nf(b,1,!a.isEnabled());a.V&8&&nf(b,8,a.xe());a.V&16&&nf(b,16,!!(a.$&16));a.V&64&&nf(b,64,a.Lb())}f.kg=function(a,b){Ee(a,!b,!x&&!Db)};f.Id=function(a,b){this.hd(a,this.ua()+"-rtl",b)};f.Xb=function(a){var b;return a.V&32&&(b=a.ga())?ic(b)&&jc(b):!1};
f.zc=function(a,b){var c;if(a.V&32&&(c=a.ga())){if(!b&&a.$&32){try{c.blur()}catch(d){}a.$&32&&a.rd(null)}(ic(c)&&jc(c))!=b&&(b?c.tabIndex=0:(c.tabIndex=-1,c.removeAttribute("tabIndex")))}};f.I=function(a,b){Ce(a,b);a&&T(a,"hidden",!b)};f.Ua=function(a,b,c){var d=a.h();if(d){var e=this.je(b);e&&this.hd(a,e,c);nf(d,b,c)}};
function nf(a,b,c){hf||(hf={1:"disabled",8:"selected",16:"checked",64:"expanded"});b=hf[b];var d=a.getAttribute("role")||null;d&&(d=jf[d]||b,b="checked"==b||"selected"==b?d:b);b&&T(a,b,c)}f.ga=function(a){return a.h()};f.ua=function(){return"goog-control"};f.ke=function(a){var b=this.ua(),c=[b],d=this.ua();d!=b&&c.push(d);b=a.$;for(d=[];b;){var e=b&-b;d.push(this.je(e));b&=~e}c.push.apply(c,d);(a=a.ub)&&c.push.apply(c,a);x&&!z("7")&&c.push.apply(c,lf(c));return c};
function lf(a,b){var c=[];b&&(a=a.concat([b]));Ra([],function(d){!Ua(d,oa(Va,a))||b&&!Va(d,b)||c.push(d.join("_"))});return c}f.je=function(a){if(!this.Rg){var b=this.ua();b.replace(/\xa0|\s/g," ");this.Rg={1:b+"-disabled",2:b+"-hover",4:b+"-active",8:b+"-selected",16:b+"-checked",32:b+"-focused",64:b+"-open"}}return this.Rg[a]};function of(a,b,c,d,e){if(!(x||y&&z("525")))return!0;if(Fb&&e)return pf(a);if(e&&!d)return!1;r(b)&&(b=qf(b));if(!c&&(17==b||18==b||Fb&&91==b))return!1;if(y&&d&&c)switch(a){case 220:case 219:case 221:case 192:case 186:case 189:case 187:case 188:case 190:case 191:case 192:case 222:return!1}if(x&&d&&b==a)return!1;switch(a){case 13:return!0;case 27:return!y}return pf(a)}
function pf(a){if(48<=a&&57>=a||96<=a&&106>=a||65<=a&&90>=a||y&&0==a)return!0;switch(a){case 32:case 63:case 107:case 109:case 110:case 111:case 186:case 59:case 189:case 187:case 61:case 188:case 190:case 191:case 192:case 222:case 219:case 220:case 221:return!0;default:return!1}}function qf(a){if(Eb)a=rf(a);else if(Fb&&y)a:switch(a){case 93:a=91;break a}return a}
function rf(a){switch(a){case 61:return 187;case 59:return 186;case 173:return 189;case 224:return 91;case 0:return 224;default:return a}};function sf(a,b){Ud.call(this);a&&tf(this,a,b)}u(sf,Ud);f=sf.prototype;f.w=null;f.ye=null;f.Rf=null;f.ze=null;f.La=-1;f.Zb=-1;f.hf=!1;
var uf={3:13,12:144,63232:38,63233:40,63234:37,63235:39,63236:112,63237:113,63238:114,63239:115,63240:116,63241:117,63242:118,63243:119,63244:120,63245:121,63246:122,63247:123,63248:44,63272:46,63273:36,63275:35,63276:33,63277:34,63289:144,63302:45},vf={Up:38,Down:40,Left:37,Right:39,Enter:13,F1:112,F2:113,F3:114,F4:115,F5:116,F6:117,F7:118,F8:119,F9:120,F10:121,F11:122,F12:123,"U+007F":46,Home:36,End:35,PageUp:33,PageDown:34,Insert:45},wf=x||y&&z("525"),xf=Fb&&Eb;f=sf.prototype;
f.Cj=function(a){y&&(17==this.La&&!a.ctrlKey||18==this.La&&!a.altKey||Fb&&91==this.La&&!a.metaKey)&&(this.Zb=this.La=-1);-1==this.La&&(a.ctrlKey&&17!=a.keyCode?this.La=17:a.altKey&&18!=a.keyCode?this.La=18:a.metaKey&&91!=a.keyCode&&(this.La=91));wf&&!of(a.keyCode,this.La,a.shiftKey,a.ctrlKey,a.altKey)?this.handleEvent(a):(this.Zb=qf(a.keyCode),xf&&(this.hf=a.altKey))};f.Dj=function(a){this.Zb=this.La=-1;this.hf=a.altKey};
f.handleEvent=function(a){var b=a.Gb,c,d,e=b.altKey;x&&"keypress"==a.type?(c=this.Zb,d=13!=c&&27!=c?b.keyCode:0):y&&"keypress"==a.type?(c=this.Zb,d=0<=b.charCode&&63232>b.charCode&&pf(c)?b.charCode:0):Db?(c=this.Zb,d=pf(c)?b.keyCode:0):(c=b.keyCode||this.Zb,d=b.charCode||0,xf&&(e=this.hf),Fb&&63==d&&224==c&&(c=191));var g=c=qf(c),h=b.keyIdentifier;c?63232<=c&&c in uf?g=uf[c]:25==c&&a.shiftKey&&(g=9):h&&h in vf&&(g=vf[h]);a=g==this.La;this.La=g;b=new yf(g,d,a,b);b.altKey=e;this.dispatchEvent(b)};
f.h=function(){return this.w};function tf(a,b,c){a.ze&&a.detach();a.w=b;a.ye=Jd(a.w,"keypress",a,c);a.Rf=Jd(a.w,"keydown",a.Cj,c,a);a.ze=Jd(a.w,"keyup",a.Dj,c,a)}f.detach=function(){this.ye&&(Qd(this.ye),Qd(this.Rf),Qd(this.ze),this.ze=this.Rf=this.ye=null);this.w=null;this.Zb=this.La=-1};f.X=function(){sf.n.X.call(this);this.detach()};function yf(a,b,c,d){Dd.call(this,d);this.type="key";this.keyCode=a;this.charCode=b;this.repeat=c}u(yf,Dd);function U(a,b,c){Le.call(this,c);if(!b){b=this.constructor;for(var d;b;){d=ia(b);if(d=df[d])break;b=b.n?b.n.constructor:null}b=d?s(d.Vb)?d.Vb():new d:null}this.G=b;this.tk(void 0!==a?a:null)}u(U,Le);f=U.prototype;f.Db=null;f.$=0;f.V=39;f.Si=255;f.Nd=0;f.ea=!0;f.ub=null;f.ud=!0;f.gf=!1;f.hk=null;f.ga=function(){return this.G.ga(this)};f.ne=function(){return this.va||(this.va=new sf)};
f.hd=function(a,b){b?a&&(this.ub?Va(this.ub,a)||this.ub.push(a):this.ub=[a],this.G.hd(this,a,!0)):a&&this.ub&&Wa(this.ub,a)&&(0==this.ub.length&&(this.ub=null),this.G.hd(this,a,!1))};f.H=function(){var a=this.G.H(this);this.w=a;mf(this.G,a,this.pe());this.gf||this.G.kg(a,!1);this.A()||this.G.I(a,!1)};f.pe=function(){return this.hk};f.hb=function(){return this.G.hb(this.h())};
f.na=function(){U.n.na.call(this);this.G.wd(this);if(this.V&-2&&(this.ud&&zf(this,!0),this.V&32)){var a=this.ga();if(a){var b=this.ne();tf(b,a);Pe(this).D(b,"key",this.jb).D(a,"focus",this.qe).D(a,"blur",this.rd)}}};
function zf(a,b){var c=Pe(a),d=a.h();b?(c.D(d,"mouseover",a.Mf).D(d,"mousedown",a.td).D(d,"mouseup",a.vd).D(d,"mouseout",a.Lf),a.sd!=ba&&c.D(d,"contextmenu",a.sd),x&&c.D(d,"dblclick",a.xh)):(c.Wa(d,"mouseover",a.Mf).Wa(d,"mousedown",a.td).Wa(d,"mouseup",a.vd).Wa(d,"mouseout",a.Lf),a.sd!=ba&&c.Wa(d,"contextmenu",a.sd),x&&c.Wa(d,"dblclick",a.xh))}f.Sa=function(){U.n.Sa.call(this);this.va&&this.va.detach();this.A()&&this.isEnabled()&&this.G.zc(this,!1)};
f.X=function(){U.n.X.call(this);this.va&&(this.va.j(),delete this.va);delete this.G;this.ub=this.Db=null};f.tk=function(a){this.Db=a};f.Ff=function(){var a=this.Db;if(!a)return"";if(!p(a))if(ea(a))a=Ta(a,kc).join("");else{if(Rb&&"innerText"in a)a=a.innerText.replace(/(\r\n|\r|\n)/g,"\n");else{var b=[];lc(a,b,!0);a=b.join("")}a=a.replace(/ \xAD /g," ").replace(/\xAD/g,"");a=a.replace(/\u200B/g,"");Rb||(a=a.replace(/ +/g," "));" "!=a&&(a=a.replace(/^\s*/,""))}return ua(a)};
f.Id=function(a){U.n.Id.call(this,a);var b=this.h();b&&this.G.Id(b,a)};f.kg=function(a){this.gf=a;var b=this.h();b&&this.G.kg(b,a)};f.A=function(){return this.ea};f.I=function(a,b){if(b||this.ea!=a&&this.dispatchEvent(a?"show":"hide")){var c=this.h();c&&this.G.I(c,a);this.isEnabled()&&this.G.zc(this,a);this.ea=a;return!0}return!1};f.isEnabled=function(){return!(this.$&1)};
f.Hd=function(a){var b=this.getParent();b&&"function"==typeof b.isEnabled&&!b.isEnabled()||!Af(this,1,!a)||(a||(this.setActive(!1),this.mb(!1)),this.A()&&this.G.zc(this,a),this.Ua(1,!a,!0))};f.mb=function(a){Af(this,2,a)&&this.Ua(2,a)};f.Pj=function(){return!!(this.$&4)};f.setActive=function(a){Af(this,4,a)&&this.Ua(4,a)};f.xe=function(){return!!(this.$&8)};f.vk=function(){Af(this,8,!0)&&this.Ua(8,!0)};f.Lb=function(){return!!(this.$&64)};function Bf(a,b){Af(a,64,b)&&a.Ua(64,b)}
f.Ua=function(a,b,c){c||1!=a?this.V&a&&b!=!!(this.$&a)&&(this.G.Ua(this,a,b),this.$=b?this.$|a:this.$&~a):this.Hd(!b)};f.Oa=function(a,b){if(this.B&&this.$&a&&!b)throw Error("Component already rendered");!b&&this.$&a&&this.Ua(a,!1);this.V=b?this.V|a:this.V&~a};function Cf(a,b){return!!(a.Si&b)&&!!(a.V&b)}function Af(a,b,c){return!!(a.V&b)&&!!(a.$&b)!=c&&(!(a.Nd&b)||a.dispatchEvent(Ne(b,c)))&&!a.gd}f.Mf=function(a){!Df(a,this.h())&&this.dispatchEvent("enter")&&this.isEnabled()&&Cf(this,2)&&this.mb(!0)};
f.Lf=function(a){!Df(a,this.h())&&this.dispatchEvent("leave")&&(Cf(this,4)&&this.setActive(!1),Cf(this,2)&&this.mb(!1))};f.sd=ba;function Df(a,b){return!!a.relatedTarget&&fc(b,a.relatedTarget)}f.td=function(a){this.isEnabled()&&(Cf(this,2)&&this.mb(!0),!Fd(a)||y&&Fb&&a.ctrlKey||(Cf(this,4)&&this.setActive(!0),this.G.Xb(this)&&this.ga().focus()));this.gf||!Fd(a)||y&&Fb&&a.ctrlKey||a.preventDefault()};f.vd=function(a){this.isEnabled()&&(Cf(this,2)&&this.mb(!0),this.Pj()&&this.Je(a)&&Cf(this,4)&&this.setActive(!1))};
f.xh=function(a){this.isEnabled()&&this.Je(a)};f.Je=function(a){if(Cf(this,16)){var b=!(this.$&16);Af(this,16,b)&&this.Ua(16,b)}Cf(this,8)&&this.vk();Cf(this,64)&&Bf(this,!this.Lb());b=new xd("action",this);a&&(b.altKey=a.altKey,b.ctrlKey=a.ctrlKey,b.metaKey=a.metaKey,b.shiftKey=a.shiftKey,b.cg=a.cg);return this.dispatchEvent(b)};f.qe=function(){Cf(this,32)&&Af(this,32,!0)&&this.Ua(32,!0)};f.rd=function(){Cf(this,4)&&this.setActive(!1);Cf(this,32)&&Af(this,32,!1)&&this.Ua(32,!1)};
f.jb=function(a){return this.A()&&this.isEnabled()&&this.mc(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};f.mc=function(a){return 13==a.keyCode&&this.Je(a)};if(!s(U))throw Error("Invalid component class "+U);if(!s(gf))throw Error("Invalid renderer class "+gf);var Ef=ia(U);df[Ef]=gf;cf("goog-control",function(){return new U(null)});function Ff(){this.Sg=[]}u(Ff,gf);ca(Ff);function Gf(a,b){var c=a.Sg[b];if(!c){switch(b){case 0:c=a.ua()+"-highlight";break;case 1:c=a.ua()+"-checkbox";break;case 2:c=a.ua()+"-content"}a.Sg[b]=c}return c}f=Ff.prototype;f.ge=function(){return"menuitem"};f.H=function(a){var b=a.ib().H("div",this.ke(a).join(" "),Hf(this,a.Db,a.ib()));If(this,a,b,!!(a.V&8)||!!(a.V&16));return b};f.hb=function(a){return a&&a.firstChild};function Hf(a,b,c){a=Gf(a,2);return c.H("div",a,b)}
f.di=function(a,b,c){a&&b&&If(this,a,b,c)};f.ai=function(a,b,c){a&&b&&If(this,a,b,c)};function If(a,b,c,d){mf(a,c,b.pe());kf(b,c);var e;if(e=a.hb(c)){e=e.firstChild;var g=Gf(a,1);e=!!e&&ga(e)&&1==e.nodeType&&Xe(e,g)}else e=!1;d!=e&&(d?Ye(c,"goog-option"):$e(c,"goog-option"),c=a.hb(c),d?(a=Gf(a,1),c.insertBefore(b.ib().H("div",a),c.firstChild||null)):c.removeChild(c.firstChild))}
f.je=function(a){switch(a){case 2:return Gf(this,0);case 16:case 8:return"goog-option-selected";default:return Ff.n.je.call(this,a)}};f.ua=function(){return"goog-menuitem"};function Jf(a,b,c,d){U.call(this,a,d||Ff.Vb(),c);this.Yc(b)}u(Jf,U);f=Jf.prototype;f.wh=function(){var a=this.Ce;return null!=a?a:this.Ff()};f.Yc=function(a){this.Ce=a};f.Oa=function(a,b){Jf.n.Oa.call(this,a,b);switch(a){case 8:this.$&16&&!b&&Af(this,16,!1)&&this.Ua(16,!1);var c=this.h();c&&this.G.di(this,c,b);break;case 16:(c=this.h())&&this.G.ai(this,c,b)}};f.di=function(a){this.Oa(8,a)};f.ai=function(a){this.Oa(16,a)};
f.Ff=function(){var a=this.Db;return ea(a)?(a=Ta(a,function(a){return ga(a)&&1==a.nodeType&&(Xe(a,"goog-menuitem-accel")||Xe(a,"goog-menuitem-mnemonic-separator"))?"":kc(a)}).join(""),ua(a)):Jf.n.Ff.call(this)};f.vd=function(a){var b=this.getParent();if(b){var c=b.Sh;b.Sh=null;if(b=c&&r(a.clientX))b=new A(a.clientX,a.clientY),b=c==b?!0:c&&b?c.x==b.x&&c.y==b.y:!1;if(b)return}Jf.n.vd.call(this,a)};f.mc=function(a){return a.keyCode==this.Lh&&this.Je(a)?!0:Jf.n.mc.call(this,a)};f.uj=function(){return this.Lh};
cf("goog-menuitem",function(){return new Jf(null)});Jf.prototype.pe=function(){return this.V&16?"menuitemcheckbox":this.V&8?"menuitemradio":Jf.n.pe.call(this)};Jf.prototype.getParent=function(){return U.prototype.getParent.call(this)};Jf.prototype.oe=function(){return U.prototype.oe.call(this)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Kf(a){this.m=a;this.g=M("g",{},null);this.Xe=M("path",{"class":"blocklyPathDark",transform:"translate(1, 1)"},this.g);this.Pb=M("path",{"class":"blocklyPath"},this.g);this.Ye=M("path",{"class":"blocklyPathLight"},this.g);this.Pb.Qa=this.m;Lf(this.Pb);Mf(this)}Kf.prototype.height=0;Kf.prototype.width=0;Kf.prototype.Y=function(){var a=this.m;this.Dc();for(var b=0,c;c=a.T[b];b++)c.Y();a.De&&a.De.cl()};function Mf(a){a.m.Mb&&!L?Nf(a.g,"blocklyDraggable"):Of(a.g,"blocklyDraggable")}
Kf.prototype.oa=function(){return this.g};var Pf=7*(1-Math.SQRT1_2)+1,Qf=9*(1-Math.SQRT1_2)-1,Rf="m "+Pf+","+Pf,Sf="a 9,9 0 0,0 "+(-Qf-1)+","+(8-Qf),Tf="a 9,9 0 0,0 "+(8-Qf)+","+(Qf+1);f=Kf.prototype;f.j=function(){E(this.g);this.m=this.Xe=this.Ye=this.Pb=this.g=null};function Uf(a){var b=(new Date-a.sg)/150;1<b?E(a):(a.setAttribute("transform","translate("+(a.ni+(H?-1:1)*a.Mg.width/2*b+", "+(a.oi+a.Mg.height*b))+") scale("+(1-b)+")"),window.setTimeout(function(){Uf(a)},10))}
function Vf(a){var b=(new Date-a.sg)/150;1<b?E(a):(a.setAttribute("r",25*b),a.style.opacity=1-b,window.setTimeout(function(){Vf(a)},10))}
f.Dc=function(){if(!this.m.disabled){var a=Wf(Xf(this.m.Vg)),b,c;c=a;if(!Yf.test(c))throw Error("'"+c+"' is not a valid hex color");4==c.length&&(c=c.replace(Zf,"#$1$1$2$2$3$3"));c=c.toLowerCase();b=[parseInt(c.substr(1,2),16),parseInt(c.substr(3,2),16),parseInt(c.substr(5,2),16)];c=$f([255,255,255],b,.3);b=$f([0,0,0],b,.4);this.Ye.setAttribute("stroke",Wf(c));this.Xe.setAttribute("fill",Wf(b));this.Pb.setAttribute("fill",a)}};
function ag(a){a.m.disabled||bg(a.m)?(Nf(a.g,"blocklyDisabled"),a.Pb.setAttribute("fill","url(#blocklyDisabledPattern)")):(Of(a.g,"blocklyDisabled"),a.Dc());a=a.m.lc();for(var b=0,c;c=a[b];b++)ag(c.i)}f.ef=function(){Nf(this.g,"blocklySelected");this.g.parentNode.appendChild(this.g)};f.Qe=function(){Of(this.g,"blocklySelected")};
f.F=function(){this.m.N=!0;var a=10;H&&(a=-a);for(var b=cg(this.m),c=0;c<b.length;c++){var d=b[c];d.m.isCollapsed()?d.Fa.setAttribute("display","none"):(d.Fa.setAttribute("display","block"),H&&(a-=16),d.Fa.setAttribute("transform","translate("+a+", 5)"),dg(d),a=H?a-10:a+26)}var e=a+=H?10:-10,g=this.m.T,b=[];b.U=e+20;if(this.m.C||this.m.J)b.U=Math.max(b.U,40);for(var d=c=0,h=!1,k=!1,l=!1,q=void 0,m=this.m.xd&&!this.m.isCollapsed(),t=0,v;v=g[t];t++)if(v.A()){var B;m&&q&&3!=q&&3!=v.type?B=b[b.length-
1]:(q=v.type,B=[],B.type=m&&3!=v.type?-1:v.type,B.height=0,b.push(B));B.push(v);v.wc=25;v.qa=m&&1==v.type?20.5:0;if(v.p&&v.p.o){var ha=eg(K(v.p));v.wc=Math.max(v.wc,ha.height);v.qa=Math.max(v.qa,ha.width)}t==g.length-1&&v.wc--;B.height=Math.max(B.height,v.wc);v.gb=0;1==b.length&&(v.gb+=H?-e:e);for(var ha=!1,bf=0,$a;$a=v.ta[bf];bf++){0!=bf&&(v.gb+=10);var Bh=$a.vh();$a.qa=Bh.width;$a.Re=ha&&$a.bd?10:0;v.gb+=$a.qa+$a.Re;B.height=Math.max(B.height,Bh.height);ha=$a.bd}-1!=B.type&&(3==B.type?(k=!0,d=Math.max(d,
v.gb)):(1==B.type?h=!0:5==B.type&&(l=!0),c=Math.max(c,v.gb)))}for(e=0;B=b[e];e++)if(B.li=!1,-1==B.type)for(g=0;v=B[g];g++)if(1==v.type){B.height+=10;B.li=!0;break}b.Ve=20+d;k&&(b.U=Math.max(b.U,b.Ve+30));h?b.U=Math.max(b.U,c+20+8):l&&(b.U=Math.max(b.U,c+20));b.Hj=h;b.ol=k;b.ll=l;d=a;this.m.K?this.rg=this.Ue=!0:(this.rg=this.Ue=!1,this.m.C&&(a=K(this.m.C))&&Lc(a)==this.m&&(this.Ue=!0),Lc(this.m)&&(this.rg=!0));h=J(this.m);k=[];l=[];a=[];c=[];v=b.U;this.Ue?(k.push("m 0,0"),a.push("m 1,1")):(k.push("m 0,8"),
a.push(H?Rf:"m 1,7"),k.push("A 8,8 0 0,1 8,0"),a.push("A 7,7 0 0,1 8,1"));this.m.C&&(k.push("H",15),a.push("H",15),k.push("l 6,4 3,0 6,-4"),a.push("l 6.5,4 2,0 6.5,-4"),this.m.C.moveTo(h.x+(H?-30:30),h.y));k.push("H",v);a.push("H",v+(H?-1:0));this.width=v;for(B=v=0;e=b[B];B++){m=10;0==B&&(m+=H?-d:d);a.push("M",b.U-1+","+(v+1));if(this.m.isCollapsed())g=e[0],t=v+18,fg(g.ta,m,t),k.push("l 8,0 0,4 8,4 -16,8 8,4"),H?a.push("l 8,0 0,3.8 7,3.2 m -14.5,9 l 8,4"):a.push("h 8"),g=e.height-20,k.push("v",g),
H&&a.push("v",g-2),this.width+=15;else if(-1==e.type){for(q=0;g=e[q];q++)t=v+18,e.li&&(t+=5),m=fg(g.ta,m,t),5!=g.type&&(m+=g.qa+10),1==g.type&&(l.push("M",m-10+","+(v+5)),l.push("h",6-g.qa),l.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),l.push("v",g.wc+1-20),l.push("h",g.qa+2-8),l.push("z"),H?(c.push("M",m-10-3+8-g.qa+","+(v+5+1)),c.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),c.push("v",g.wc-20+3),c.push("h",g.qa-8+1)):(c.push("M",m-10+1+","+(v+5+1)),c.push("v",g.wc+1),c.push("h",
6-g.qa),c.push("M",m-g.qa-10+.8+","+(v+5+20-.4)),c.push("l","3.36,-1.8")),t=H?h.x-m-8+10+g.qa+1:h.x+m+8-10-g.qa-1,ha=h.y+v+5+1,g.p.moveTo(t,ha),g.p.o&&gg(g.p));m=Math.max(m,b.U);this.width=Math.max(this.width,m);k.push("H",m);a.push("H",m+(H?-1:0));k.push("v",e.height);H&&a.push("v",e.height-2)}else 1==e.type?(g=e[0],t=v+18,-1!=g.align&&(q=b.U-g.gb-8-20,1==g.align?m+=q:0==g.align&&(m+=(q+m)/2)),fg(g.ta,m,t),k.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),q=e.height-20,k.push("v",q),H?(a.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),
a.push("v",q)):(a.push("M",b.U-4.2+","+(v+20-.4)),a.push("l","3.36,-1.8")),t=h.x+(H?-b.U-1:b.U+1),ha=h.y+v,g.p.moveTo(t,ha),g.p.o&&(gg(g.p),this.width=Math.max(this.width,b.U+eg(K(g.p)).width-8+1))):5==e.type?(g=e[0],t=v+18,-1!=g.align&&(q=b.U-g.gb-20,b.Hj&&(q-=8),1==g.align?m+=q:0==g.align&&(m+=(q+m)/2)),fg(g.ta,m,t),k.push("v",e.height),H&&a.push("v",e.height-2)):3==e.type&&(g=e[0],0==B&&(k.push("v",10),H&&a.push("v",9),v+=10),t=v+18,-1!=g.align&&(q=b.Ve-g.gb-20,1==g.align?m+=q:0==g.align&&(m+=
(q+m)/2)),fg(g.ta,m,t),m=b.Ve+30,k.push("H",m),k.push("l -6,4 -3,0 -6,-4 h -7 a 8,8 0 0,0 -8,8"),k.push("v",e.height-16),k.push("a 8,8 0 0,0 8,8"),k.push("H",b.U),H?(a.push("M",m-30+Qf+","+(v+Qf)),a.push(Sf),a.push("v",e.height-16),a.push("a 9,9 0 0,0 9,9"),a.push("H",b.U-1)):(a.push("M",m-30+Qf+","+(v+e.height-Qf)),a.push(Tf),a.push("H",b.U)),t=h.x+(H?-m:m),ha=h.y+v+1,g.p.moveTo(t,ha),g.p.o&&(gg(g.p),this.width=Math.max(this.width,b.Ve+eg(K(g.p)).width)),B==b.length-1||3==b[B+1].type)&&(k.push("v",
10),H&&a.push("v",9),v+=10);v+=e.height}b.length||(v=25,k.push("V",v),H&&a.push("V",v-1));b=v;this.height=b+1;this.m.J&&(k.push("H","30 l -6,4 -3,0 -6,-4"),this.m.J.moveTo(H?h.x-30:h.x+30,h.y+b+1),this.m.J.o&&gg(this.m.J),this.height+=4);this.rg?(k.push("H 0"),H||a.push("M","1,"+b)):(k.push("H",8),k.push("a","8,8 0 0,1 -8,-8"),H||(a.push("M",Pf+","+(b-Pf)),a.push("A","7,7 0 0,1 1,"+(b-8))));this.m.K?(this.m.K.moveTo(h.x,h.y),k.push("V",20),k.push("c 0,-10 -8,8 -8,-7.5 s 8,2.5 8,-7.5"),H?(a.push("M",
"-2.4,8.9"),a.push("l","-3.6,-2.1")):(a.push("V",19),a.push("m","-7.36,-1 q -1.52,-5.5 0,-11"),a.push("m","7.36,1 V 1 H 2")),this.width+=8):H||(this.Ue?a.push("V",1):a.push("V",8));k.push("z");b=k.join(" ")+"\n"+l.join(" ");this.Pb.setAttribute("d",b);this.Xe.setAttribute("d",b);b=a.join(" ")+"\n"+c.join(" ");this.Ye.setAttribute("d",b);H&&(this.Pb.setAttribute("transform","scale(-1 1)"),this.Ye.setAttribute("transform","scale(-1 1)"),this.Xe.setAttribute("transform","translate(1,1) scale(-1 1)"));
(b=this.m.getParent())?b.F():pe(window,"resize")};function fg(a,b,c){H&&(b=-b);for(var d=0,e;e=a[d];d++)H?(b-=e.Re+e.qa,e.oa().setAttribute("transform","translate("+b+", "+c+")"),e.qa&&(b-=10)):(e.oa().setAttribute("transform","translate("+(b+e.Re)+", "+c+")"),e.qa&&(b+=e.Re+e.qa+10));return H?-b:b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function hg(a){this.k=null;this.Ka=M("g",{},null);this.nf=M("rect",{rx:4,ry:4,x:-5,y:-12,height:16},this.Ka);this.Pa=M("text",{"class":"blocklyText"},this.Ka);this.Ld={height:25,width:0};this.yb(a);this.ea=!0}f=hg.prototype;f.clone=function(){Ka("There should never be an instance of Field, only its derived classes.")};f.bd=!0;f.Y=function(a){if(this.k)throw"Field has already been initialized once.";this.k=a;this.Ec();ig(a).appendChild(this.Ka);this.Xf=P(this.Ka,"mouseup",this,this.ag);this.yb(null)};
f.j=function(){this.Xf&&(O(this.Xf),this.Xf=null);this.k=null;E(this.Ka);this.nf=this.Pa=this.Ka=null};f.Ec=function(){this.bd&&(this.k.Kc&&!L?(Nf(this.Ka,"blocklyEditableText"),Of(this.Ka,"blocklyNoNEditableText"),this.Ka.style.cursor=this.Qk):(Nf(this.Ka,"blocklyNonEditableText"),Of(this.Ka,"blocklyEditableText"),this.Ka.style.cursor=""))};f.A=function(){return this.ea};f.I=function(a){this.ea=a;this.oa().style.display=a?"block":"none";this.Fd()};f.oa=function(){return this.Ka};
f.Fd=function(){try{var a=this.Pa.getComputedTextLength()}catch(b){a=8*this.Pa.childNodes[0].length}this.nf&&this.nf.setAttribute("width",a+10);this.Ld.width=a};f.vh=function(){this.Ld.width||this.Fd();return this.Ld};f.Ib=function(){return this.ob};f.yb=function(a){null!==a&&a!==this.ob&&(a=this.ob=a,dc(this.Pa),a=a.replace(/\s/g,"\u00a0"),H&&a&&(a+="\u200f"),a||(a="\u00a0"),this.Pa.appendChild(document.createTextNode(a)),this.Ld.width=0,this.k&&this.k.N&&(this.k.F(),this.k.Ja(),de(this.k.s)))};
f.wh=function(){return this.Ib()};f.Yc=function(a){this.yb(a)};f.ag=function(a){if(!Hb&&!Ib||0===a.layerX||0===a.layerY)id(a)||2!=ne&&this.k.Kc&&!L&&this.Fl()};f.Te=function(){};function jg(a){this.Lg=a}ca(jg);f=jg.prototype;f.ge=function(){return this.Lg};function kg(a,b){a&&(a.tabIndex=b?0:-1)}f.H=function(a){return a.ib().H("div",this.ke(a).join(" "))};f.hb=function(a){return a};f.wd=function(a){a=a.h();Ee(a,!0,Eb);x&&(a.hideFocus=!0);var b=this.ge();b&&ff(a,b)};f.ga=function(a){return a.h()};f.ua=function(){return"goog-container"};f.ke=function(a){var b=this.ua(),c=[b,a.Tc==lg?b+"-horizontal":b+"-vertical"];a.isEnabled()||c.push(b+"-disabled");return c};function mg(){}u(mg,gf);ca(mg);mg.prototype.H=function(a){return a.ib().H("div",this.ua())};mg.prototype.ua=function(){return"goog-menuseparator"};function ng(a,b){U.call(this,null,a||mg.Vb(),b);this.Oa(1,!1);this.Oa(2,!1);this.Oa(4,!1);this.Oa(32,!1);this.$=1}u(ng,U);ng.prototype.na=function(){ng.n.na.call(this);var a=this.h();ff(a,"separator")};cf("goog-menuseparator",function(){return new ng});function og(a){this.Lg=a||"menu"}u(og,jg);ca(og);og.prototype.ua=function(){return"goog-menu"};og.prototype.wd=function(a){og.n.wd.call(this,a);a=a.h();T(a,"haspopup","true")};cf("goog-menuseparator",function(){return new ng});function pg(a,b,c){Le.call(this,c);this.G=b||jg.Vb();this.Tc=a||qg}u(pg,Le);var lg="horizontal",qg="vertical";f=pg.prototype;f.Sf=null;f.va=null;f.G=null;f.Tc=null;f.ea=!0;f.ic=!0;f.Df=!0;f.M=-1;f.Z=null;f.Sc=!1;f.Ni=!1;f.ek=!0;f.Bb=null;f.ga=function(){return this.Sf||this.G.ga(this)};f.ne=function(){return this.va||(this.va=new sf(this.ga()))};f.H=function(){this.w=this.G.H(this)};f.hb=function(){return this.G.hb(this.h())};
f.na=function(){pg.n.na.call(this);Re(this,function(a){a.B&&rg(this,a)},this);var a=this.h();this.G.wd(this);this.I(this.ea,!0);Pe(this).D(this,"enter",this.Jf).D(this,"highlight",this.Bj).D(this,"unhighlight",this.Gj).D(this,"open",this.Ej).D(this,"close",this.yj).D(a,"mousedown",this.td).D(Xb(a),"mouseup",this.zj).D(a,["mousedown","mouseup","mouseover","mouseout","contextmenu"],this.xj);this.Xb()&&sg(this,!0)};
function sg(a,b){var c=Pe(a),d=a.ga();b?c.D(d,"focus",a.qe).D(d,"blur",a.rd).D(a.ne(),"key",a.jb):c.Wa(d,"focus",a.qe).Wa(d,"blur",a.rd).Wa(a.ne(),"key",a.jb)}f.Sa=function(){this.Xc(-1);this.Z&&Bf(this.Z,!1);this.Sc=!1;pg.n.Sa.call(this)};f.X=function(){pg.n.X.call(this);this.va&&(this.va.j(),this.va=null);this.G=this.Z=this.Bb=this.Sf=null};f.Jf=function(){return!0};
f.Bj=function(a){var b=Ve(this,a.target);if(-1<b&&b!=this.M){var c=S(this,this.M);c&&c.mb(!1);this.M=b;c=S(this,this.M);this.Sc&&c.setActive(!0);this.ek&&this.Z&&c!=this.Z&&(c.V&64?Bf(c,!0):Bf(this.Z,!1))}b=this.h();null!=a.target.h()&&T(b,"activedescendant",a.target.h().id)};f.Gj=function(a){a.target==S(this,this.M)&&(this.M=-1);this.h().removeAttribute("aria-activedescendant")};f.Ej=function(a){(a=a.target)&&a!=this.Z&&a.getParent()==this&&(this.Z&&Bf(this.Z,!1),this.Z=a)};
f.yj=function(a){a.target==this.Z&&(this.Z=null)};f.td=function(a){this.ic&&(this.Sc=!0);var b=this.ga();b&&ic(b)&&jc(b)?b.focus():a.preventDefault()};f.zj=function(){this.Sc=!1};f.xj=function(a){var b;a:{b=a.target;if(this.Bb)for(var c=this.h();b&&b!==c;){var d=b.id;if(d in this.Bb){b=this.Bb[d];break a}b=b.parentNode}b=null}if(b)switch(a.type){case "mousedown":b.td(a);break;case "mouseup":b.vd(a);break;case "mouseover":b.Mf(a);break;case "mouseout":b.Lf(a);break;case "contextmenu":b.sd(a)}};
f.qe=function(){};f.rd=function(){this.Xc(-1);this.Sc=!1;this.Z&&Bf(this.Z,!1)};f.jb=function(a){return this.isEnabled()&&this.A()&&(0!=Se(this)||this.Sf)&&this.mc(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};
f.mc=function(a){var b=S(this,this.M);if(b&&"function"==typeof b.jb&&b.jb(a)||this.Z&&this.Z!=b&&"function"==typeof this.Z.jb&&this.Z.jb(a))return!0;if(a.shiftKey||a.ctrlKey||a.metaKey||a.altKey)return!1;switch(a.keyCode){case 27:if(this.Xb())this.ga().blur();else return!1;break;case 36:tg(this);break;case 35:ug(this);break;case 38:if(this.Tc==qg)vg(this);else return!1;break;case 37:if(this.Tc==lg)Te(this)?wg(this):vg(this);else return!1;break;case 40:if(this.Tc==qg)wg(this);else return!1;break;case 39:if(this.Tc==
lg)Te(this)?vg(this):wg(this);else return!1;break;default:return!1}return!0};function rg(a,b){var c=b.h(),c=c.id||(c.id=Oe(b));a.Bb||(a.Bb={});a.Bb[c]=b}f.df=function(a,b){pg.n.df.call(this,a,b)};f.Gc=function(a,b,c){a.Nd|=2;a.Nd|=64;!this.Xb()&&this.Ni||a.Oa(32,!1);a.B&&0!=a.ud&&zf(a,!1);a.ud=!1;var d=a.getParent()==this?Ve(this,a):-1;pg.n.Gc.call(this,a,b,c);a.B&&this.B&&rg(this,a);a=d;-1==a&&(a=Se(this));a==this.M?this.M=Math.min(Se(this)-1,b):a>this.M&&b<=this.M?this.M++:a<this.M&&b>this.M&&this.M--};
f.removeChild=function(a,b){if(a=p(a)?Qe(this,a):a){var c=Ve(this,a);-1!=c&&(c==this.M?(a.mb(!1),this.M=-1):c<this.M&&this.M--);var d=a.h();d&&d.id&&this.Bb&&(c=this.Bb,d=d.id,d in c&&delete c[d])}c=a=pg.n.removeChild.call(this,a,b);c.B&&1!=c.ud&&zf(c,!0);c.ud=!0;return a};f.A=function(){return this.ea};
f.I=function(a,b){if(b||this.ea!=a&&this.dispatchEvent(a?"show":"hide")){this.ea=a;var c=this.h();c&&(Ce(c,a),this.Xb()&&kg(this.ga(),this.ic&&this.ea),b||this.dispatchEvent(this.ea?"aftershow":"afterhide"));return!0}return!1};f.isEnabled=function(){return this.ic};
f.Hd=function(a){this.ic!=a&&this.dispatchEvent(a?"enable":"disable")&&(a?(this.ic=!0,Re(this,function(a){a.qi?delete a.qi:a.Hd(!0)})):(Re(this,function(a){a.isEnabled()?a.Hd(!1):a.qi=!0}),this.Sc=this.ic=!1),this.Xb()&&kg(this.ga(),a&&this.ea))};f.Xb=function(){return this.Df};f.zc=function(a){a!=this.Df&&this.B&&sg(this,a);this.Df=a;this.ic&&this.ea&&kg(this.ga(),a)};f.Xc=function(a){(a=S(this,a))?a.mb(!0):-1<this.M&&S(this,this.M).mb(!1)};f.mb=function(a){this.Xc(Ve(this,a))};
function tg(a){xg(a,function(a,c){return(a+1)%c},Se(a)-1)}function ug(a){xg(a,function(a,c){a--;return 0>a?c-1:a},0)}function wg(a){xg(a,function(a,c){return(a+1)%c},a.M)}function vg(a){xg(a,function(a,c){a--;return 0>a?c-1:a},a.M)}function xg(a,b,c){c=0>c?Ve(a,a.Z):c;var d=Se(a);c=b.call(a,c,d);for(var e=0;e<=d;){var g=S(a,c);if(g&&a.Qg(g)){a.Xc(c);break}e++;c=b.call(a,c,d)}}f.Qg=function(a){return a.A()&&a.isEnabled()&&!!(a.V&2)};function yg(){}u(yg,gf);ca(yg);yg.prototype.ua=function(){return"goog-menuheader"};function zg(a,b,c){U.call(this,a,c||yg.Vb(),b);this.Oa(1,!1);this.Oa(2,!1);this.Oa(4,!1);this.Oa(32,!1);this.$=1}u(zg,U);cf("goog-menuheader",function(){return new zg(null)});function Ag(a,b){pg.call(this,qg,b||og.Vb(),a);this.zc(!1)}u(Ag,pg);f=Ag.prototype;f.ff=!0;f.Oi=!1;f.ua=function(){return this.G.ua()};f.removeItem=function(a){(a=this.removeChild(a,!0))&&a.j()};function Bg(a){a.ff=!0;a.zc(!0)}f.I=function(a,b,c){(b=Ag.n.I.call(this,a,b))&&a&&this.B&&this.ff&&this.ga().focus();this.Sh=a&&c&&r(c.clientX)?new A(c.clientX,c.clientY):null;return b};f.Jf=function(a){this.ff&&this.ga().focus();return Ag.n.Jf.call(this,a)};
f.Qg=function(a){return(this.Oi||a.isEnabled())&&a.A()&&!!(a.V&2)};f.mc=function(a){var b=Ag.n.mc.call(this,a);b||Re(this,function(c){!b&&c.uj&&c.Lh==a.keyCode&&(this.isEnabled()&&this.mb(c),b=c.jb(a))},this);return b};
f.Xc=function(a){Ag.n.Xc.call(this,a);if(a=S(this,a)){var b=a.h();a=this.h();var c=ye(b),d=ye(a),e=He(a),g=c.x-d.x-e.left,c=c.y-d.y-e.top,d=a.clientHeight-b.offsetHeight,e=a.scrollLeft,h=a.scrollTop,e=e+Math.min(g,Math.max(g-(a.clientWidth-b.offsetWidth),0)),h=h+Math.min(c,Math.max(c-d,0)),b=new A(e,h);a.scrollLeft=b.x;a.scrollTop=b.y}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Cg(a,b){a.innerHTML=pb(b)};function V(a,b,c){Le.call(this,c);this.ma=b||Dg;this.Nf=a instanceof nb?a:rb(a,null)}u(V,Le);var Eg={};f=V.prototype;f.jg=!1;f.kd=!1;f.Hk=null;f.Mi=xb;f.zd=!0;f.$d=-1;f.X=function(){V.n.X.call(this);this.Cc&&(this.Cc.removeNode(this),this.Cc=null);this.w=null};
f.ve=function(){var a=this.h();if(a){var b=Fg(this);b&&!b.id&&(b.id=Oe(this)+".label");ff(a,"treeitem");T(a,"selected",!1);T(a,"expanded",!1);T(a,"level",this.Lc());b&&T(a,"labelledby",b.id);(a=this.me())&&ff(a,"presentation");(a=this.le())&&ff(a,"presentation");if(a=Gg(this))if(ff(a,"group"),a.hasChildNodes())for(a=Se(this),b=1;b<=a;b++){var c=S(this,b-1).h();T(c,"setsize",a);T(c,"posinset",b)}}};
f.H=function(){var a=this.ib(),b=pb(this.zg());var c=a.Fb,a=c.createElement("div");x?(a.innerHTML="<br>"+b,a.removeChild(a.firstChild)):a.innerHTML=b;if(1==a.childNodes.length)b=a.removeChild(a.firstChild);else for(b=c.createDocumentFragment();a.firstChild;)b.appendChild(a.firstChild);this.w=b};f.na=function(){V.n.na.call(this);Eg[Oe(this)]=this;this.ve()};f.Sa=function(){V.n.Sa.call(this);delete Eg[Oe(this)]};
f.Gc=function(a,b){var c=S(this,b-1),d=S(this,b);V.n.Gc.call(this,a,b);a.tc=c;a.kb=d;c?c.kb=a:this.uh=a;d?d.tc=a:this.Hh=a;var e=this.za();e&&Hg(a,e);Ig(a,this.Lc()+1);if(this.h()&&(this.ad(),this.Ea())){e=Gg(this);a.h()||a.H();var g=a.h(),h=d&&d.h();e.insertBefore(g,h);this.B&&a.na();d||(c?c.ad():(Ce(e,!0),this.Ob(this.Ea())))}};f.add=function(a,b){a.getParent()&&a.getParent().removeChild(a);this.Gc(a,b?Ve(this,b):Se(this));return a};
f.removeChild=function(a){var b=this.za(),c=b?b.Ma:null;if(c==a||a.contains(c))b.hasFocus()?(this.select(),Wd(this.dk,10,this)):this.select();V.n.removeChild.call(this,a);this.Hh==a&&(this.Hh=a.tc);this.uh==a&&(this.uh=a.kb);a.tc&&(a.tc.kb=a.kb);a.kb&&(a.kb.tc=a.tc);c=!a.kb;a.Cc=null;a.$d=-1;if(b&&(b.removeNode(this),this.B)){b=Gg(this);if(a.B){var d=a.h();b.removeChild(d);a.Sa()}c&&(c=S(this,Se(this)-1))&&c.ad();Ue(this)||(b.style.display="none",this.ad(),this.me().className=this.ie())}return a};
f.remove=V.prototype.removeChild;f.dk=function(){this.select()};f.Lc=function(){var a=this.$d;0>a&&(a=(a=this.getParent())?a.Lc()+1:0,Ig(this,a));return a};function Ig(a,b){if(b!=a.$d){a.$d=b;var c=Jg(a);if(c){var d=Kg(a)+"px";Te(a)?c.style.paddingRight=d:c.style.paddingLeft=d}Re(a,function(a){Ig(a,b+1)})}}f.contains=function(a){for(;a;){if(a==this)return!0;a=a.getParent()}return!1};f.lc=function(){var a=[];Re(this,function(b){a.push(b)});return a};f.xe=function(){return this.jg};
f.select=function(){var a=this.za();a&&a.Ac(this)};function Lg(a,b){if(a.jg!=b){a.jg=b;Mg(a);var c=a.h();c&&(T(c,"selected",b),b&&(c=a.za().h(),T(c,"activedescendant",Oe(a))))}}f.Ea=function(){return this.kd};
f.Ob=function(a){var b=a!=this.kd;if(!b||this.dispatchEvent(a?"beforeexpand":"beforecollapse")){var c;this.kd=a;c=this.za();var d=this.h();if(Ue(this)){if(!a&&c&&this.contains(c.Ma)&&this.select(),d){if(c=Gg(this))if(Ce(c,a),a&&this.B&&!c.hasChildNodes()){var e=[];Re(this,function(a){e.push(a.zg())});Cg(c,wb(e));Re(this,function(a){a.na()})}this.ad()}}else(c=Gg(this))&&Ce(c,!1);d&&(this.me().className=this.ie(),T(d,"expanded",a));b&&this.dispatchEvent(a?"expand":"collapse")}};f.toggle=function(){this.Ob(!this.Ea())};
f.expand=function(){this.Ob(!0)};f.collapse=function(){this.Ob(!1)};f.ig=function(){var a=this.getParent();a&&(a.Ob(!0),a.ig())};f.zg=function(){var a=this.za(),b=!a.Kd||a==this.getParent()&&!a.qg?this.ma.Yg:this.ma.Xg,a=this.Ea()&&Ue(this),b={"class":b,style:Ng(this)},c=[];a&&Re(this,function(a){c.push(a.zg())});a=vb("div",b,c);return vb("div",{"class":this.ma.gh,id:Oe(this)},[Og(this),a])};function Kg(a){return Math.max(0,(a.Lc()-1)*a.ma.Qf)}
function Og(a){var b={};b["padding-"+(Te(a)?"right":"left")]=Kg(a)+"px";var b={"class":a.pd(),style:b},c=a.Gf(),d=vb("span",{style:{display:"inline-block"},"class":a.ie()}),e=vb("span",{"class":a.ma.hh,title:a.Hk||null},a.Nf);a=wb(e,vb("span",{},a.Mi));return vb("div",b,[c,d,a])}f.pd=function(){return this.ma.tf+(this.xe()?" "+this.ma.jh:"")};f.Gf=function(){return vb("span",{type:"expand",style:{display:"inline-block"},"class":Pg(this)})};
function Pg(a){var b=a.za(),c=!b.Kd||b==a.getParent()&&!b.qg,d=a.ma,e=new qa;e.append(d.gc," ",d.aj," ");if(Ue(a)){var g=0;b.pg&&a.zd&&(g=a.Ea()?2:1);c||(g=a.kb?g+8:g+4);switch(g){case 1:e.append(d.ej);break;case 2:e.append(d.dj);break;case 4:e.append(d.bh);break;case 5:e.append(d.cj);break;case 6:e.append(d.bj);break;case 8:e.append(d.dh);break;case 9:e.append(d.gj);break;case 10:e.append(d.fj);break;default:e.append(d.ah)}}else c?e.append(d.ah):a.kb?e.append(d.dh):e.append(d.bh);return e.toString()}
function Ng(a){var b=a.Ea()&&Ue(a);return eb({"background-position":Qg(a),display:b?null:"none"})}function Qg(a){return(a.kb?(a.Lc()-1)*a.ma.Qf:"-100")+"px 0"}f.h=function(){var a=V.n.h.call(this);a||(this.w=a=this.ib().h(Oe(this)));return a};function Jg(a){return(a=a.h())?a.firstChild:null}f.le=function(){var a=Jg(this);return a?a.firstChild:null};f.me=function(){var a=Jg(this);return a?a.childNodes[1]:null};function Fg(a){return(a=Jg(a))&&a.lastChild?a.lastChild.previousSibling:null}
function Gg(a){return(a=a.h())?a.lastChild:null}f.yb=function(a){this.Nf=a=qb(a);var b=Fg(this);b&&Cg(b,a);(a=this.za())&&Rg(a,this)};f.Ib=function(){var a=pb(this.Nf);return-1!=a.indexOf("&")?"document"in n?Fa(a):Ha(a):a};function Mg(a){var b=Jg(a);b&&(b.className=a.pd())}f.ad=function(){var a=this.le();a&&(a.className=Pg(this));if(a=Gg(this))a.style.backgroundPosition=Qg(this)};f.Zf=function(a){"expand"==a.target.getAttribute("type")&&Ue(this)?this.zd&&this.toggle():(this.select(),Mg(this))};
f.Oh=function(a){"expand"==a.target.getAttribute("type")&&Ue(this)||this.zd&&this.toggle()};function Sg(a){return a.Ea()&&Ue(a)?Sg(S(a,Se(a)-1)):a}function Hg(a,b){a.Cc!=b&&(a.Cc=b,Rg(b,a),Re(a,function(a){Hg(a,b)}))}
var Dg={Qf:19,ih:"goog-tree-root goog-tree-item",fh:"goog-tree-hide-root",gh:"goog-tree-item",Xg:"goog-tree-children",Yg:"goog-tree-children-nolines",tf:"goog-tree-row",hh:"goog-tree-item-label",gc:"goog-tree-icon",aj:"goog-tree-expand-icon",ej:"goog-tree-expand-icon-plus",dj:"goog-tree-expand-icon-minus",gj:"goog-tree-expand-icon-tplus",fj:"goog-tree-expand-icon-tminus",cj:"goog-tree-expand-icon-lplus",bj:"goog-tree-expand-icon-lminus",dh:"goog-tree-expand-icon-t",bh:"goog-tree-expand-icon-l",ah:"goog-tree-expand-icon-blank",
rf:"goog-tree-expanded-folder-icon",Zg:"goog-tree-collapsed-folder-icon",sf:"goog-tree-file-icon",eh:"goog-tree-expanded-folder-icon",$g:"goog-tree-collapsed-folder-icon",jh:"selected"};function Tg(a,b,c){V.call(this,a,b,c)}u(Tg,V);Tg.prototype.za=function(){if(this.Cc)return this.Cc;var a=this.getParent();return a&&(a=a.za())?(Hg(this,a),a):null};Tg.prototype.ie=function(){var a=this.Ea(),b=this.pj;if(a&&b)return b;b=this.Ij;if(!a&&b)return b;b=this.ma;if(Ue(this)){if(a&&b.rf)return b.gc+" "+b.rf;if(!a&&b.Zg)return b.gc+" "+b.Zg}else if(b.sf)return b.gc+" "+b.sf;return""};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Vg={Zd:null,show:function(a,b){Ug();if(b.length){for(var c=new Ag,d=0,e;e=b[d];d++){var g=new Jf(e.text);c.df(g,!0);g.Hd(e.enabled);e.enabled&&Jd(g,"action",function(a){return function(){a()}}(e.bb))}Jd(c,"action",Vg.Jb);e=$b();g=ve();c.F(Wg);var h=c.h();Nf(h,"blocklyContextMenu");var k=ze(h),d=a.clientX+g.x,l=a.clientY+g.y;a.clientY+k.height>=e.height&&(l-=k.height);H?k.width>=a.clientX&&(d+=k.width):a.clientX+k.width>=e.width&&(d-=k.width);Xg(d,l,e,g);Bg(c);setTimeout(function(){h.focus()},
1);Vg.Zd=null}else Vg.Jb()},Jb:function(){Yg==Vg&&Zg();Vg.Zd=null},al:function(a,b){return function(){var c=Pc(a.s,b),d=J(a);d.x=H?d.x-W:d.x+W;d.y+=2*W;c.moveBy(d.x,d.y);c.select()}}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function $g(a,b,c,d,e,g,h){var k=ah;H&&(k=-k);this.Qi=k*Math.PI/180;this.v=a;this.Db=b;this.ei=c;a.Zc.appendChild(this.qf(b,!(!g||!h)));bh(this,d,e);g&&h||(a=this.Db.getBBox(),g=a.width+2*ch,h=a.height+2*ch);this.yc(g,h);dh(this);eh(this);this.hg=!0;L||(P(this.Wd,"mousedown",this,this.Ui),this.Nb&&P(this.Nb,"mousedown",this,this.pk))}var ch=6,ah=20,fh=null,gh=null;function hh(){fh&&(O(fh),fh=null);gh&&(O(gh),gh=null)}f=$g.prototype;f.hg=!1;f.$a=0;f.jf=0;f.vc=0;f.Ed=0;f.L=0;f.Ta=0;f.mf=!0;
f.qf=function(a,b){this.ab=M("g",{},null);var c=M("g",{filter:"url(#blocklyEmboss)"},this.ab);this.Ng=M("path",{},c);this.Wd=M("rect",{"class":"blocklyDraggable",x:0,y:0,rx:ch,ry:ch},c);b?(this.Nb=M("g",{"class":H?"blocklyResizeSW":"blocklyResizeSE"},this.ab),c=2*ch,M("polygon",{points:"0,x x,x x,0".replace(/x/g,c.toString())},this.Nb),M("line",{"class":"blocklyResizeLine",x1:c/3,y1:c-1,x2:c-1,y2:c/3},this.Nb),M("line",{"class":"blocklyResizeLine",x1:2*c/3,y1:c-1,x2:c-1,y2:2*c/3},this.Nb)):this.Nb=
null;this.ab.appendChild(a);return this.ab};f.Ui=function(a){ih(this);hh();id(a)||jh(a)||(kh(!0),this.ph=H?this.vc+a.clientX:this.vc-a.clientX,this.nj=this.Ed-a.clientY,fh=P(document,"mouseup",this,hh),gh=P(document,"mousemove",this,this.Vi),md(),a.stopPropagation())};f.Vi=function(a){this.mf=!1;this.vc=H?this.ph-a.clientX:this.ph+a.clientX;this.Ed=this.nj+a.clientY;dh(this);eh(this)};
f.pk=function(a){ih(this);hh();id(a)||(kh(!0),this.ok=H?this.L+a.clientX:this.L-a.clientX,this.nk=this.Ta-a.clientY,fh=P(document,"mouseup",this,hh),gh=P(document,"mousemove",this,this.qk),md(),a.stopPropagation())};f.qk=function(a){this.mf=!1;var b=this.ok,c=this.nk+a.clientY,b=H?b-a.clientX:b+a.clientX;this.yc(b,c);H&&dh(this)};function ih(a){a.ab.parentNode.appendChild(a.ab)}function bh(a,b,c){a.$a=b;a.jf=c;a.hg&&dh(a)}
function dh(a){a.ab.setAttribute("transform","translate("+(H?a.$a-a.vc-a.L:a.$a+a.vc)+", "+(a.Ed+a.jf)+")")}f.kc=function(){return{width:this.L,height:this.Ta}};
f.yc=function(a,b){var c=2*ch;a=Math.max(a,c+45);b=Math.max(b,c+18);this.L=a;this.Ta=b;this.Wd.setAttribute("width",a);this.Wd.setAttribute("height",b);this.Nb&&(H?this.Nb.setAttribute("transform","translate("+2*ch+", "+(b-c)+") scale(-1 1)"):this.Nb.setAttribute("transform","translate("+(a-c)+", "+(b-c)+")"));if(this.hg){if(this.mf){var c=-this.L/4,d=-this.Ta-25,e=this.v.Hb();H?this.$a-e.Ca-c-this.L<N?c=this.$a-e.Ca-this.L-N:this.$a-e.Ca-c>e.Q&&(c=this.$a-e.Ca-e.Q):this.$a+c<e.Ca?c=e.Ca-this.$a:
e.Ca+e.Q<this.$a+c+this.L+10+N&&(c=e.Ca+e.Q-this.$a-this.L-N);this.jf+d<e.Ab&&(d=this.ei.getBBox().height);this.vc=c;this.Ed=d}dh(this);eh(this)}pe(this.ab,"resize")};
function eh(a){var b=[],c=a.L/2,d=a.Ta/2,e=-a.vc,g=-a.Ed;if(c==e&&d==g)b.push("M "+c+","+d);else{g-=d;e-=c;H&&(e*=-1);var h=Math.sqrt(g*g+e*e),k=Math.acos(e/h);0>g&&(k=2*Math.PI-k);var l=k+Math.PI/2;l>2*Math.PI&&(l-=2*Math.PI);var q=Math.sin(l),m=Math.cos(l),t=a.kc(),l=(t.width+t.height)/10,l=Math.min(l,t.width,t.height)/2,t=1-8/h,e=c+t*e,g=d+t*g,t=c+l*m,v=d+l*q,c=c-l*m,d=d-l*q,q=k+a.Qi;q>2*Math.PI&&(q-=2*Math.PI);k=Math.sin(q)*h/4;h=Math.cos(q)*h/4;b.push("M"+t+","+v);b.push("C"+(t+h)+","+(v+k)+
" "+e+","+g+" "+e+","+g);b.push("C"+e+","+g+" "+(c+h)+","+(d+k)+" "+c+","+d)}b.push("z");a.Ng.setAttribute("d",b.join(" "))}f.ng=function(a){this.Wd.setAttribute("fill",a);this.Ng.setAttribute("fill",a)};f.j=function(){hh();E(this.ab);this.ei=this.Db=this.v=this.ab=null};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function lh(a){this.m=a}f=lh.prototype;f.ha=null;f.Oc=0;f.Pc=0;f.Jc=function(){this.Fa=M("g",{},null);ig(this.m).appendChild(this.Fa);P(this.Fa,"mouseup",this,this.Jj);this.Ec()};f.j=function(){E(this.Fa);this.Fa=null;this.I(!1);this.m=null};f.Ec=function(){this.m.Yb?Of(this.Fa,"blocklyIconGroup"):Nf(this.Fa,"blocklyIconGroup")};f.A=function(){return!!this.ha};f.Jj=function(){this.m.Yb||this.I(!this.A())};f.Dc=function(){if(this.A()){var a=Wf(Xf(this.m.Vg));this.ha.ng(a)}};
function dg(a){var b=J(a.m),c=mh(a.Fa),d=b.x+c.x+8,b=b.y+c.y+8;if(d!==a.Oc||b!==a.Pc)a.Oc=d,a.Pc=b,a.A()&&bh(a.ha,d,b)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function nh(a,b){this.k=a;this.o=null;this.type=b;this.O=this.pb=0;this.vb=!1;this.Tb=this.k.s.Zi}f=nh.prototype;f.j=function(){if(this.o)throw"Disconnect connection before disposing of it.";this.vb&&oh(this.Tb[this.type],this);this.vb=!1;ph==this&&(ph=null);qh==this&&(qh=null)};function rh(a){return 1==a.type||3==a.type}
function $c(a,b){if(a.k==b.k)throw"Attempted to connect a block to itself.";if(a.k.s!==b.k.s)throw"Blocks are on different workspaces.";if(sh[a.type]!=b.type)throw"Attempt to connect incompatible types.";if(1==a.type||2==a.type){if(a.o)throw"Source connection already connected (value).";if(b.o){var c=K(b);c.Na(null);if(!c.K)throw"Orphan block does not have an output connection.";for(var d=a.k;d=th(d,c);)if(K(d))d=K(d);else{$c(d,c.K);c=null;break}c&&window.setTimeout(function(){uh(c.K,b)},vh)}}else{if(a.o)throw"Source connection already connected (block).";
if(b.o){if(4!=a.type)throw"Can only do a mid-stack connection with the top of a block.";c=K(b);c.Na(null);if(!c.C)throw"Orphan block does not have a previous connection.";for(d=a.k;d.J;)if(d.J.o)d=Lc(d);else{wh(c.C,d.J)&&($c(d.J,c.C),c=null);break}c&&window.setTimeout(function(){uh(c.C,b)},vh)}}var e;rh(a)?(d=a.k,e=b.k):(d=b.k,e=a.k);a.o=b;b.o=a;e.Na(d);d.N&&ag(d.i);e.N&&ag(e.i);d.N&&e.N&&(3==a.type||4==a.type?e.F():d.F())}
function th(a,b){for(var c=!1,d=0;d<a.T.length;d++){var e=a.T[d].p;if(e&&1==e.type&&wh(b.K,e)){if(c)return null;c=e}}return c}f.disconnect=function(){var a=this.o;if(!a)throw"Source connection not connected.";if(a.o!=this)throw"Target connection not connected to source connection.";this.o=a.o=null;var b;rh(this)?(b=this.k,a=a.k):(b=a.k,a=this.k);b.N&&b.F();a.N&&(ag(a.i),a.F())};function K(a){return a.o?a.o.k:null}
function uh(a,b){if(0==ne){var c=xh(a.k);if(!c.Yb){var d=!1;if(!c.Mb||L){c=xh(b.k);if(!c.Mb||L)return;b=a;d=!0}ig(c).parentNode.appendChild(ig(c));var e=b.pb+W-a.pb,g=b.O+W-a.O;d&&(g=-g);H&&(e=-e);c.moveBy(e,g)}}}f.moveTo=function(a,b){this.vb&&oh(this.Tb[this.type],this);this.pb=a;this.O=b;yh(this.Tb[this.type],this)};f.moveBy=function(a,b){this.moveTo(this.pb+a,this.O+b)};
f.Bh=function(){var a;1==this.type||2==this.type?(a=H?-8:8,a="m 0,0 v 5 c 0,10 "+-a+",-8 "+-a+",7.5 s "+a+",-2.5 "+a+",7.5 v 5"):a=H?"m 20,0 h -5 l -6,4 -3,0 -6,-4 h -5":"m -20,0 h 5 l 6,4 3,0 6,-4 h 5";var b=J(this.k);nh.se=M("path",{"class":"blocklyHighlightedConnectionPath",d:a,transform:"translate("+(this.pb-b.x)+", "+(this.O-b.y)+")"},ig(this.k))};
function gg(a){var b=Math.round(a.o.pb-a.pb),c=Math.round(a.o.O-a.O);if(0!=b||0!=c){a=K(a);var d=ig(a);if(!d)throw"block is not rendered.";d=mh(d);ig(a).setAttribute("transform","translate("+(d.x-b)+", "+(d.y-c)+")");zh(a,-b,-c)}}
function Ah(a,b,c,d){function e(a){var c=g[a];if((2==c.type||4==c.type)&&c.o||1==c.type&&c.o&&(!K(c).Mb||L)||!wh(t,c))return!0;c=c.k;do{if(m==c)return!0;c=c.getParent()}while(c);var d=h-g[a].pb,c=k-g[a].O,d=Math.sqrt(d*d+c*c);d<=b&&(q=g[a],b=d);return c<b}if(a.o)return{p:null,Wh:b};var g=a.Tb[sh[a.type]],h=a.pb+c,k=a.O+d;c=0;for(var l=d=g.length-2;c<l;)g[l].O<k?c=l:d=l,l=Math.floor((c+d)/2);d=c=l;var q=null,m=a.k,t=a;if(g.length){for(;0<=c&&e(c);)c--;do d++;while(d<g.length&&e(d))}return{p:q,Wh:b}}
function wh(a,b){if(!a.Hc||!b.Hc)return!0;for(var c=0;c<a.Hc.length;c++)if(-1!=b.Hc.indexOf(a.Hc[c]))return!0;return!1}f.Wc=function(a){a?(ea(a)||(a=[a]),this.Hc=a,this.o&&!wh(this,this.o)&&(rh(this)?K(this).Na(null):this.k.Na(null),this.k.Ja())):this.Hc=null;return this};
function Ch(a){var b=W;function c(a){var c=e-d[a].pb,h=g-d[a].O;Math.sqrt(c*c+h*h)<=b&&l.push(d[a]);return h<b}var d=a.Tb[sh[a.type]],e=a.pb,g=a.O;a=0;for(var h=d.length-2,k=h;a<k;)d[k].O<g?a=k:h=k,k=Math.floor((a+h)/2);var h=a=k,l=[];if(d.length){for(;0<=a&&c(a);)a--;do h++;while(h<d.length&&c(h))}return l}
function Dh(a){a.vb||yh(a.Tb[a.type],a);var b=[];if(1!=a.type&&3!=a.type)return b;if(a=K(a)){var c;a.isCollapsed()?(c=[],a.K&&c.push(a.K),a.J&&c.push(a.J),a.C&&c.push(a.C)):c=Eh(a,!0);for(var d=0;d<c.length;d++)b.push.apply(b,Dh(c[d]));0==b.length&&(b[0]=a)}return b}function ce(){}ce.prototype=[];function yh(a,b){if(b.vb)throw"Connection already in database.";for(var c=0,d=a.length;c<d;){var e=Math.floor((c+d)/2);if(a[e].O<b.O)c=e+1;else if(a[e].O>b.O)d=e;else{c=e;break}}a.splice(c,0,b);b.vb=!0}
function oh(a,b){if(!b.vb)throw"Connection not in database.";b.vb=!1;for(var c=0,d=a.length-2,e=d;c<e;)a[e].O<b.O?c=e:d=e,e=Math.floor((c+d)/2);for(d=c=e;0<=c&&a[c].O==b.O;){if(a[c]==b){a.splice(c,1);return}c--}do{if(a[d]==b){a.splice(d,1);return}d++}while(d<a.length&&a[d].O==b.O);throw"Unable to find connection in connectionDB.";};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Jh={Wk:function(a){var b={Y:function(){var b=this;this.ng(a.bl);this.nc=a.nc;"string"==typeof a.Qa?this.Te(a.Qa):"function"==typeof a.Qa&&this.Te(function(){return a.Qa(b)});"undefined"!=a.fk?Fh(this,a.fk):(Gh(this,"undefined"==typeof a.jk?!0:a.jk),Hh(this,"undefined"==typeof a.Zj?!0:a.Zj));var d=[];d.push(a.text);a.Pi&&a.Pi.forEach(function(a){"undefined"==a.type||1==a.type?d.push([a.name,a.check,"undefined"==typeof a.align?1:a.align]):Ka("addTemplate() can only handle value inputs.")});d.push(1);
a.Oj&&this.Dl(a.Oj);Ih.prototype.yd.apply(this,d)}};b.Mh=a.Hl?function(){var b=a.Wj?a.ul():document.createElement("mutation");b.setAttribute("is_statement",this.isStatement||!1);return b}:a.Wj;Jh[a.$k]=b}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Kh(a){Kh.n.constructor.call(this,a);this.Jc()}u(Kh,lh);f=Kh.prototype;f.ob="";f.L=160;f.Ta=80;f.Jc=function(){lh.prototype.Jc.call(this);M("circle",{"class":"blocklyIconShield",r:8,cx:8,cy:8},this.Fa);this.Of=M("text",{"class":"blocklyIconMark",x:8,y:13},this.Fa);this.Of.appendChild(document.createTextNode("?"))};f.Ec=function(){this.A()&&(this.I(!1),this.I(!0));lh.prototype.Ec.call(this)};
f.lk=function(){var a=this.ha.kc(),b=2*ch;this.md.setAttribute("width",a.width-b);this.md.setAttribute("height",a.height-b);this.Ha.style.width=a.width-b-4+"px";this.Ha.style.height=a.height-b-4+"px"};
f.I=function(a){if(a!=this.A())if((!this.m.Kc||L)&&!this.Ha||x)Lh.prototype.I.call(this,a);else{var b=this.Ib(),c=this.kc();if(a){a=this.m.s;this.md=M("foreignObject",{x:ch,y:ch},null);var d=document.createElementNS("http://www.w3.org/1999/xhtml","body");d.setAttribute("xmlns","http://www.w3.org/1999/xhtml");d.className="blocklyMinimalBody";this.Ha=document.createElementNS("http://www.w3.org/1999/xhtml","textarea");this.Ha.className="blocklyCommentTextarea";this.Ha.setAttribute("dir",H?"RTL":"LTR");
d.appendChild(this.Ha);this.md.appendChild(d);P(this.Ha,"mouseup",this,this.Gk);this.ha=new $g(a,this.md,this.m.i.Pb,this.Oc,this.Pc,this.L,this.Ta);P(this.ha.ab,"resize",this,this.lk);this.Dc();this.ob=null}else this.ha.j(),this.md=this.Ha=this.ha=null;this.yb(b);this.yc(c.width,c.height)}};f.Gk=function(){ih(this.ha);this.Ha.focus()};f.kc=function(){return this.A()?this.ha.kc():{width:this.L,height:this.Ta}};f.yc=function(a,b){this.Ha?this.ha.yc(a,b):(this.L=a,this.Ta=b)};
f.Ib=function(){return this.Ha?this.Ha.value:this.ob};f.yb=function(a){this.Ha?this.Ha.value=a:this.ob=a};f.j=function(){this.m.ya=null;lh.prototype.j.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Mh=!1,Nh=0,Oh=0,Ph={x:0,y:0},Qh=null,Rh=null,Sh=null,Th=null,Uh=null,Vh=null;function Wh(){var a=M("g",{"class":"blocklyHidden"},null);Sh=a;Vh=M("rect",{"class":"blocklyTooltipShadow",x:2,y:2},a);Uh=M("rect",{"class":"blocklyTooltipBackground"},a);Th=M("text",{"class":"blocklyTooltipText"},a);return a}function Lf(a){P(a,"mouseover",null,Xh);P(a,"mouseout",null,Yh);P(a,"mousemove",null,Zh)}
function Xh(a){for(a=a.target;!p(a.Qa)&&!s(a.Qa);)a=a.Qa;Qh!=a&&($h(),Rh=null,Qh=a);window.clearTimeout(Nh)}function Yh(){Nh=window.setTimeout(function(){Rh=Qh=null;$h()},1);window.clearTimeout(Oh)}function Zh(a){Qh&&Qh.Qa&&0==ne&&!Yg&&(Mh?(a=jd(a),10<Math.sqrt(Math.pow(Ph.x-a.x,2)+Math.pow(Ph.y-a.y,2))&&$h()):Rh!=Qh&&(window.clearTimeout(Oh),Ph=jd(a),Oh=window.setTimeout(ai,1E3)))}function $h(){Mh&&(Mh=!1,Sh&&(Sh.style.display="none"));window.clearTimeout(Oh)}
function ai(){Rh=Qh;if(Sh){dc(Th);var a=Qh.Qa;s(a)&&(a=a());var b=a,a=50;if(b.length<=a)a=b;else{for(var c=b.trim().split(/\s+/),d=0;d<c.length;d++)c[d].length>a&&(a=c[d].length);var e,d=-Infinity,g,h=1;do{e=d;g=b;for(var b=[],k=c.length/h,l=1,d=0;d<c.length-1;d++)l<(d+1.5)/k?(l++,b[d]=!0):b[d]=!1;for(var b=bi(c,b,a),d=ci(c,b,a),k=c,l=[],q=0;q<k.length;q++)l.push(k[q]),void 0!==b[q]&&l.push(b[q]?"\n":" ");b=l.join("");h++}while(d>e);a=g}a=a.split("\n");for(c=0;c<a.length;c++)M("tspan",{dy:"1em",x:5},
Th).appendChild(document.createTextNode(a[c]));Mh=!0;Sh.style.display="block";a=Th.getBBox();c=10+a.width;e=a.height;Uh.setAttribute("width",c);Uh.setAttribute("height",e);Vh.setAttribute("width",c);Vh.setAttribute("height",e);if(H)for(e=a.width,g=0;h=Th.childNodes[g];g++)h.setAttribute("text-anchor","end"),h.setAttribute("x",e+5);e=Ph.x;e=H?e-(0+c):e+0;c=Ph.y+10;g=di();c+a.height>g.height&&(c-=a.height+20);H?e=Math.max(5,e):e+a.width>g.width-10&&(e=g.width-a.width-10);Sh.setAttribute("transform",
"translate("+e+","+c+")")}}function ci(a,b,c){for(var d=[0],e=[],g=0;g<a.length;g++)d[d.length-1]+=a[g].length,!0===b[g]?(d.push(0),e.push(a[g].charAt(a[g].length-1))):!1===b[g]&&d[d.length-1]++;a=Math.max.apply(Math,d);for(g=b=0;g<d.length;g++)b-=2*Math.pow(Math.abs(c-d[g]),1.5),b-=Math.pow(a-d[g],1.5),-1!=".?!".indexOf(e[g])?b+=c/3:-1!=",;)]}".indexOf(e[g])&&(b+=c/4);1<d.length&&d[d.length-1]<=d[d.length-2]&&(b+=.5);return b}
function bi(a,b,c){for(var d=ci(a,b,c),e,g=0;g<b.length-1;g++)if(b[g]!=b[g+1]){var h=[].concat(b);h[g]=!h[g];h[g+1]=!h[g+1];var k=ci(a,h,c);k>d&&(d=k,e=h)}return e?bi(a,e,c):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ei(a){this.k=null;this.Pa=M("text",{"class":"blocklyText"},null);this.Ld={height:25,width:0};this.yb(a)}u(ei,hg);f=ei.prototype;f.clone=function(){return new ei(this.Ib())};f.bd=!1;f.Y=function(a){if(this.k)throw"Text has already been initialized once.";this.k=a;ig(a).appendChild(this.Pa);this.Pa.Qa=this.k;Lf(this.Pa)};f.j=function(){E(this.Pa);this.Pa=null};f.oa=function(){return this.Pa};f.Te=function(a){this.Pa.Qa=a};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function fi(a,b,c,d){this.type=a;this.name=b;this.k=c;this.p=d;this.ta=[];this.align=-1;this.ea=!0}function gi(a,b,c){if(b||c)p(b)&&(b=new ei(b)),a.k.i&&b.Y(a.k),b.name=c,b.ik&&gi(a,b.ik),a.ta.push(b),b.Fk&&gi(a,b.Fk),a.k.N&&(a.k.F(),a.k.Ja())}f=fi.prototype;f.A=function(){return this.ea};
f.I=function(a){var b=[];if(this.ea==a)return b;for(var c=(this.ea=a)?"block":"none",d=0,e;e=this.ta[d];d++)e.I(a);if(this.p){if(a)b=Dh(this.p);else if(d=this.p,d.vb&&oh(d.Tb[d.type],d),d.o){e=hi(K(d));for(var g=0;g<e.length;g++){for(var h=e[g],k=Eh(h,!0),l=0;l<k.length;l++){var q=k[l];q.vb&&oh(d.Tb[q.type],q)}h=cg(h);for(k=0;k<h.length;k++)h[k].I(!1)}}if(d=K(this.p))d.i.oa().style.display=c,a||(d.N=!1)}return b};
f.Wc=function(a){if(!this.p)throw"This input does not have a connection.";this.p.Wc(a);return this};function ii(a,b){a.align=b;a.k.N&&a.k.F();return a}f.Y=function(){for(var a=0;a<this.ta.length;a++)this.ta[a].Y(this.k)};f.j=function(){for(var a=0,b;b=this.ta[a];a++)b.j();this.p&&this.p.j();this.k=null};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Lh(a){Lh.n.constructor.call(this,a);this.Jc()}u(Lh,lh);f=Lh.prototype;f.ob="";f.Jc=function(){lh.prototype.Jc.call(this);M("path",{"class":"blocklyIconShield",d:"M 2,15 Q -1,15 0.5,12 L 6.5,1.7 Q 8,-1 9.5,1.7 L 15.5,12 Q 17,15 14,15 z"},this.Fa);this.Of=M("text",{"class":"blocklyIconMark",x:8,y:13},this.Fa);this.Of.appendChild(document.createTextNode("!"))};
f.I=function(a){if(a!=this.A())if(a){var b=this.ob;a=M("text",{"class":"blocklyText blocklyBubbleText",y:ch},null);for(var b=b.split("\n"),c=0;c<b.length;c++)M("tspan",{dy:"1em",x:ch},a).appendChild(document.createTextNode(b[c]));this.ha=new $g(this.m.s,a,this.m.i.Pb,this.Oc,this.Pc,null,null);if(H)for(var b=a.getBBox().width,c=0,d;d=a.childNodes[c];c++)d.setAttribute("text-anchor","end"),d.setAttribute("x",b+ch);this.Dc();a=this.ha.kc();this.ha.yc(a.width,a.height)}else this.ha.j(),this.ha=null};
f.yb=function(a){this.ob!=a&&(this.ob=a,this.A()&&(this.I(!1),this.I(!0)))};f.j=function(){this.m.Td=null;lh.prototype.j.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var ji=0;function Ih(){}function Rc(a,b){if(ge)return ki.create(Ih,a,b);var c=new Ih;c.initialize(a,b);return c}f=Ih.prototype;f.initialize=function(a,b){var c=(++ji).toString();this.id=ge?li(c):c;fe(a,this);this.fill(a,b);s(this.onchange)&&P(a.aa,"blocklyWorkspaceChange",this,this.onchange)};
f.fill=function(a,b){this.C=this.J=this.K=null;this.T=[];this.disabled=this.N=this.xd=!1;this.Qa="";this.contextMenu=!0;this.Uc=null;this.qb=[];this.Kc=this.Mb=this.hc=!0;this.fc=!1;this.s=a;this.Yb=a.Gh;if(b){this.type=b;var c=Jh[b],d;for(d in c)this[d]=c[d]}s(this.Y)&&this.Y()};function Qc(a,b){return ge?mi.get(a):ke(b,a)}f.i=null;f.De=null;f.ya=null;f.Td=null;function cg(a){var b=[];a.De&&b.push(a.De);a.ya&&b.push(a.ya);a.Td&&b.push(a.Td);return b}
function Sc(a){a.i=new Kf(a);a.i.Y();L||P(a.i.oa(),"mousedown",a,a.Fe);a.s.aa.appendChild(a.i.oa())}function ig(a){return a.i&&a.i.oa()}var ne=0,ni=null,oi=null;f=Ih.prototype;f.select=function(){R&&oe();R=this;this.i.ef();pe(this.s.aa,"blocklySelectChange")};function oe(){var a=R;R=null;a.i.Qe();pe(a.s.aa,"blocklySelectChange")}
f.j=function(a,b,c){this.N=!1;var d;d=!1;if(this.K)this.K.o&&this.Na(null);else{var e=null;this.C&&this.C.o&&(e=this.C.o,this.Na(null));var g=Lc(this);a&&g&&(a=this.J.o,g.Na(null),e&&wh(e,a)&&$c(e,a))}d&&this.moveBy(W*(H?-1:1),2*W);b&&this.i&&(d=this.i,pi("delete"),b=kd(d.g),d=d.g.cloneNode(!0),d.ni=b.x,d.oi=b.y,d.setAttribute("transform","translate("+d.ni+","+d.oi+")"),I.appendChild(d),d.Mg=d.getBBox(),d.sg=new Date,Uf(d));this.s&&!c&&(ie(this.s,this),this.s=null);R==this&&(R=null,qi());Vg.Zd==this&&
Vg.Jb();for(c=this.qb.length-1;0<=c;c--)this.qb[c].j(!1);b=cg(this);for(c=0;c<b.length;c++)b[c].j();for(c=0;b=this.T[c];c++)b.j();this.T=[];b=Eh(this,!0);for(c=0;c<b.length;c++)d=b[c],d.o&&d.disconnect(),b[c].j();this.i&&(this.i.j(),this.i=null);if(ge&&!ri)mi["delete"](this.id.toString())};function J(a){var b=0,c=0;if(a.i){var d=a.i.oa();do var e=mh(d),b=b+e.x,c=c+e.y,d=d.parentNode;while(d&&d!=a.s.aa)}return{x:b,y:c}}
f.moveBy=function(a,b){var c=J(this);this.i.oa().setAttribute("transform","translate("+(c.x+a)+", "+(c.y+b)+")");zh(this,a,b);si(this)};function eg(a){var b=a.i.height,c=a.i.width;if(a=Lc(a))a=eg(a),b+=a.height-4,c=Math.max(c,a.width);return{height:b,width:c}}
f.Fe=function(a){if(!this.Yb){ti();qi();this.select();md();if(id(a))ui(this,a);else if(this.Mb&&!L){ld();kh(!0);var b=J(this);this.ii=b.x;this.ji=b.y;this.ug=a.clientX;this.vg=a.clientY;ne=1;ni=P(document,"mouseup",this,this.ag);oi=P(document,"mousemove",this,this.$f);this.ce=[];for(var b=hi(this),c=0,d;d=b[c];c++){d=cg(d);for(var e=0;e<d.length;e++){var g;g=d[e];g={x:g.Oc,y:g.Pc};g.Ti=d[e];this.ce.push(g)}}}else return;a.stopPropagation()}};
f.ag=function(){var a=this;vi(function(){qi();if(R&&ph){$c(qh,ph);if(a.i){var b=(rh(qh)?ph:qh).k.i;pi("click");var c=kd(b.g);b.m.K?(c.x+=H?3:-3,c.y+=13):b.m.C&&(c.x+=H?-23:23,c.y+=3);b=M("circle",{cx:c.x,cy:c.y,r:0,fill:"none",stroke:"#888","stroke-width":10},I);b.sg=new Date;Vf(b)}a.s.Ia&&a.s.Ia.Lb&&a.s.Ia.close()}else a.s.Ia&&a.s.Ia.Lb&&(b=a.s.Ia,Wd(b.close,100,b),R.j(!1,!0),pe(window,"resize"));ph&&(E(nh.se),delete nh.se,ph=null)})};
function ui(a,b){if(!L&&a.contextMenu){var c=[];if(a.hc&&!L&&a.Mb&&!L&&!a.Yb){var d={text:wi,enabled:!0,bb:function(){var b=Kc(a);ad(b);var b=Pc(a.s,b),c=J(a);c.x=H?c.x-W:c.x+W;c.y+=2*W;b.moveBy(c.x,c.y);b.select()}};hi(a).length>qe(a.s)&&(d.enabled=!1);c.push(d);a.Kc&&!L&&!a.fc&&wc&&(d={enabled:!0},a.ya?(d.text=xi,d.bb=function(){Xc(a,null)}):(d.text=yi,d.bb=function(){Xc(a,"")}),c.push(d));if(!a.fc)for(d=0;d<a.T.length;d++)if(1==a.T[d].type){d={enabled:!0};d.text=a.xd?zi:Ai;d.bb=function(){Tc(a,
!a.xd)};c.push(d);break}xc&&(a.fc?(d={enabled:!0},d.text=Bi,d.bb=function(){a.Gd(!1)}):(d={enabled:!0},d.text=Ci,d.bb=function(){a.Gd(!0)}),c.push(d));yc&&(d={text:a.disabled?Di:Ei,enabled:!bg(a),bb:function(){Uc(a,!a.disabled)}},c.push(d));var d=hi(a).length,e=Lc(a);e&&(d-=hi(e).length);d={text:1==d?Fi:Gi.replace("%1",String(d)),enabled:!0,bb:function(){a.j(!0,!0)}};c.push(d)}d={enabled:!(s(a.nc)?!a.nc():!a.nc)};d.text=Hi;d.bb=function(){var b=s(a.nc)?a.nc():a.nc;b&&window.open(b)};c.push(d);a.hj&&
!a.Yb&&a.hj(c);Vg.show(b,c);Vg.Zd=a}}function Eh(a,b){var c=[];if(b||a.N)if(a.K&&c.push(a.K),a.J&&c.push(a.J),a.C&&c.push(a.C),b||!a.fc)for(var d=0,e;e=a.T[d];d++)e.p&&c.push(e.p);return c}function zh(a,b,c){if(a.N){for(var d=Eh(a,!1),e=0;e<d.length;e++)d[e].moveBy(b,c);d=cg(a);for(e=0;e<d.length;e++)dg(d[e]);for(e=0;e<a.qb.length;e++)zh(a.qb[e],b,c)}}function Ii(a,b){b?Nf(a.i.g,"blocklyDragging"):Of(a.i.g,"blocklyDragging");for(var c=0;c<a.qb.length;c++)Ii(a.qb[c],b)}
f.$f=function(a){var b=this;vi(function(){if(!("mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button)){ld();var c=a.clientX-b.ug,d=a.clientY-b.vg;1==ne&&Math.sqrt(Math.pow(c,2)+Math.pow(d,2))>Ji&&(ne=2,b.Na(null),Ii(b,!0));if(2==ne){b.i.oa().setAttribute("transform","translate("+(b.ii+c)+", "+(b.ji+d)+")");for(var e=0;e<b.ce.length;e++){var g=b.ce[e],h=g.Ti,k=g.x+c,g=g.y+d;h.Oc=k;h.Pc=g;h.A()&&bh(h.ha,k,g)}for(var h=Eh(b,!1),g=k=null,l=W,e=0;e<h.length;e++){var q=h[e],m=Ah(q,l,c,d);m.p&&(k=
m.p,g=q,l=m.Wh)}ph&&ph!=k&&(E(nh.se),delete nh.se,qh=ph=null);k&&k!=ph&&(k.Bh(),ph=k,qh=g);b.s.Ia&&b.hc&&!L&&(c=b.s.Ia,c.g&&(d=jd(a),e=kd(c.g),d=d.x>e.x-c.Ud&&d.x<e.x+c.ed+c.Ud&&d.y>e.y-c.Ud&&d.y<e.y+c.$e+c.cd+c.Ud,c.Lb!=d&&ae(c,d)))}}a.stopPropagation()})};f.Ja=function(){if(0==ne){var a=xh(this);if(!a.Yb)for(var b=Eh(this,!1),c=0;c<b.length;c++){var d=b[c];d.o&&rh(d)&&K(d).Ja();for(var e=Ch(d),g=0;g<e.length;g++){var h=e[g];d.o&&h.o||xh(h.k)!=a&&(rh(d)?uh(h,d):uh(d,h))}}}};f.getParent=function(){return this.Uc};
function Lc(a){return a.J&&K(a.J)}function xh(a){var b=a;do a=b,b=a.Uc;while(b);return a}f.lc=function(){return this.qb};
f.Na=function(a){if(this.Uc){for(var b=this.Uc.qb,c,d=0;c=b[d];d++)if(c==this){b.splice(d,1);break}b=J(this);this.s.aa.appendChild(this.i.oa());this.i.oa().setAttribute("transform","translate("+b.x+", "+b.y+")");this.Uc=null;this.C&&this.C.o&&this.C.disconnect();this.K&&this.K.o&&this.K.disconnect()}else Va(Jc(this.s,!1),this)&&ie(this.s,this);(this.Uc=a)?(a.qb.push(this),b=J(this),a.i&&this.i&&a.i.oa().appendChild(this.i.oa()),a=J(this),zh(this,a.x-b.x,a.y-b.y)):fe(this.s,this)};
function hi(a){for(var b=[a],c,d=0;c=a.qb[d];d++)b.push.apply(b,hi(c));return b}function Vc(a,b){a.hc=b;a.i&&Mf(a.i)}function Wc(a,b){a.Kc=b;for(var c=0,d;d=a.T[c];c++)for(var e=0,g;g=d.ta[e];e++)g.Ec();d=cg(a);for(c=0;c<d.length;c++)d[c].Ec()}f.ng=function(a){this.Vg=a;this.i&&this.i.Dc();var b=cg(this);for(a=0;a<b.length;a++)b[a].Dc();if(this.N){for(a=0;b=this.T[a];a++)for(var c=0,d;d=b.ta[c];c++)d.yb(null);this.F()}};
function Yc(a,b){for(var c=0,d;d=a.T[c];c++)for(var e=0,g;g=d.ta[e];e++)if(g.name===b)return g;return null}f.Te=function(a){this.Qa=a};function Gh(a,b){var c;a.C&&(a.C.j(),a.C=null);b&&(void 0===c&&(c=null),a.C=new nh(a,4),a.C.Wc(c));a.N&&(a.F(),a.Ja())}function Hh(a,b){var c;a.J&&(a.J.j(),a.J=null);b&&(void 0===c&&(c=null),a.J=new nh(a,3),a.J.Wc(c));a.N&&(a.F(),a.Ja())}function Fh(a,b){a.K&&(a.K.j(),a.K=null);void 0===b&&(b=null);a.K=new nh(a,2);a.K.Wc(b);a.N&&(a.F(),a.Ja())}
function Tc(a,b){a.xd=b;a.N&&(a.F(),a.Ja(),de(a.s))}function Uc(a,b){a.disabled!=b&&(a.disabled=b,ag(a.i),de(a.s))}function bg(a){for(;;){a:for(;;){do{var b=a;a=a.getParent();if(!a){a=null;break a}}while(Lc(a)==b);break a}if(!a)return!1;if(a.disabled)return!0}}f.isCollapsed=function(){return this.fc};
f.Gd=function(a){if(this.fc!=a){this.fc=a;for(var b=[],c=0,d;d=this.T[c];c++)b.push.apply(b,d.I(!a));if(a){a=cg(this);for(c=0;c<a.length;c++)a[c].I(!1);c=this.toString(Ki);gi(Li(this,5,"_TEMP_COLLAPSED_INPUT"),c)}else a:{for(c=0;a=this.T[c];c++)if("_TEMP_COLLAPSED_INPUT"==a.name){a.p&&a.p.o&&K(a.p).Na(null);a.j();this.T.splice(c,1);this.N&&(this.F(),this.Ja());break a}Ka('Input "%s" not found.',"_TEMP_COLLAPSED_INPUT")}b.length||(b[0]=this);if(this.N){for(c=0;a=b[c];c++)a.F();this.Ja()}}};
f.toString=function(a){for(var b=[],c=0,d;d=this.T[c];c++){for(var e=0,g;g=d.ta[e];e++)b.push(g.Ib());d.p&&((d=K(d.p))?b.push(d.toString()):b.push("?"))}b=va(b.join(" "))||"???";a&&b.length>a&&(b=b.substring(0,a-3)+"...");return b};
f.yd=function(a,b){function c(a){a instanceof hg?gi(this,a):gi(this,a[1],a[0])}var d=arguments[arguments.length-1];--arguments.length;for(var e=a.split(this.yd.Di),g=[],h=0;h<e.length;h+=2){var k=va(e[h]),l=void 0;k&&g.push(new ei(k));if((k=e[h+1])&&"%"==k.charAt(0)){var k=parseInt(k.substring(1),10),q=arguments[k];q[1]instanceof hg?g.push([q[0],q[1]]):l=ii(Li(this,1,q[0]).Wc(q[1]),q[2]);arguments[k]=null}else"\n"==k&&g.length&&(l=Li(this,5,""));l&&g.length&&(g.forEach(c,l),g=[])}g.length&&(l=ii(Li(this,
5,""),d),g.forEach(c,l));for(h=1;h<arguments.length-1;h++);Tc(this,!a.match(this.yd.wi))};f.yd.Di=/(%\d+|\n)/;f.yd.wi=/%1\s*$/;function Li(a,b,c){var d=null;if(1==b||3==b)d=new nh(a,b);b=new fi(b,c,a,d);a.T.push(b);a.N&&(a.F(),a.Ja());return b}function Zc(a,b){for(var c=0,d;d=a.T[c];c++)if(d.name==b)return d;return null}function Xc(a,b){var c=!1;p(b)?(a.ya||(a.ya=new Kh(a),c=!0),a.ya.yb(b)):a.ya&&(a.ya.j(),c=!0);a.N&&(a.F(),c&&a.Ja())}f.F=function(){this.i.F();si(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Mi(){var a=this;this.v=new be(function(){return Ni(a)},function(b){var c=Ni(a);c&&(r(b.y)&&(a.v.scrollY=-c.Ra*b.y-c.cb),a.v.aa.setAttribute("transform","translate(0,"+(a.v.scrollY+c.Za)+")"))});this.v.Gh=!0;this.qh=[];this.Ta=this.L=0;this.of=[];this.wb=[]}var Oi,Pi,Qi,Ri,Si,Ti;f=Mi.prototype;f.Vd=!0;f.ra=8;f.H=function(){this.g=M("g",{},null);this.Va=M("path",{"class":"blocklyFlyoutBackground"},this.g);this.g.appendChild(this.v.H());return this.g};
f.j=function(){this.Jb();O(this.qh);this.qh.length=0;this.xc&&(this.xc.j(),this.xc=null);this.v=null;this.g&&(E(this.g),this.g=null);this.Pd=this.Va=null};function Ni(a){if(!a.A())return null;var b=a.Ta-2*a.ra,c=a.L;try{var d=a.v.aa.getBBox()}catch(e){d={height:0,y:0}}return{xa:b,Q:c,Ra:d.height+d.y,Ab:-a.v.scrollY,cb:0,Za:a.ra,Ya:0}}
f.Y=function(a){this.Pd=a;this.xc=new cd(this.v,!1,!1);this.Jb();P(window,"resize",this,this.Cd);this.Cd();P(this.g,"wheel",this,this.ri);P(this.g,"mousewheel",this,this.ri);P(this.Pd.aa,"blocklyWorkspaceChange",this,this.Af);P(this.g,"mousedown",this,this.Fe)};
f.Cd=function(){if(this.A()){var a=this.Pd.Hb();if(a){var b=this.L-this.ra;H&&(b*=-1);var c=["M "+(H?this.L:0)+",0"];c.push("h",b);c.push("a",this.ra,this.ra,0,0,H?0:1,H?-this.ra:this.ra,this.ra);c.push("v",Math.max(0,a.xa-2*this.ra));c.push("a",this.ra,this.ra,0,0,H?0:1,H?this.ra:-this.ra,this.ra);c.push("h",-b);c.push("z");this.Va.setAttribute("d",c.join(" "));b=a.Ya;H&&(b+=a.Q,b-=this.L);this.g.setAttribute("transform","translate("+b+","+a.Za+")");this.Ta=a.xa;this.xc&&this.xc.resize()}}};
f.ri=function(a){var b=a.deltaY||-a.wheelDeltaY;if(b){Eb&&(b*=10);var c=Ni(this),b=c.Ab+b,b=Math.min(b,c.Ra-c.xa),b=Math.max(b,0);this.xc.set(b);a.preventDefault()}};f.A=function(){return this.g&&"block"==this.g.style.display};f.Jb=function(){if(this.A()){this.g.style.display="none";for(var a=0,b;b=this.wb[a];a++)O(b);this.wb.length=0;this.gg&&(O(this.gg),this.gg=null)}};
f.show=function(a){this.Jb();for(var b=Jc(this.v,!1),c=0,d;d=b[c];c++)d.s==this.v&&d.j(!1,!1);for(var c=0,e;e=this.of[c];c++)E(e);this.of.length=0;var g=this.ra;this.g.style.display="block";var b=[],h=[];if(a==Ui)Vi(b,h,g,this.v);else if(a==Wi)Xi(b,h,g,this.v);else for(var k=0;d=a[k];k++)d.tagName&&"BLOCK"==d.tagName.toUpperCase()&&(d=Pc(this.v,d),b.push(d),h.push(3*g));a=g;for(k=0;d=b[k];k++){c=hi(d);e=0;for(var l;l=c[e];e++)l.Yb=!0,Xc(l,null);d.F();l=ig(d);e=eg(d);c=H?0:g+8;d.moveBy(c,a);a+=e.height+
h[k];e=M("rect",{"fill-opacity":0},null);this.v.aa.insertBefore(e,ig(d));d.ld=e;this.of[k]=e;this.Vd?this.wb.push(P(l,"mousedown",null,Yi(this,d))):this.wb.push(P(l,"mousedown",null,Zi(this,d)));this.wb.push(P(l,"mouseover",d.i,d.i.ef));this.wb.push(P(l,"mouseout",d.i,d.i.Qe));this.wb.push(P(e,"mousedown",null,Yi(this,d)));this.wb.push(P(e,"mouseover",d.i,d.i.ef));this.wb.push(P(e,"mouseout",d.i,d.i.Qe))}this.wb.push(P(this.Va,"mouseover",this,function(){for(var a=Jc(this.v,!1),b=0,c;c=a[b];b++)c.i.Qe()}));
this.L=0;this.Xh();this.Af();$i(window,"resize");this.gg=P(this.v.aa,"blocklyWorkspaceChange",this,this.Xh);de(this.v)};
f.Xh=function(){for(var a=0,b=this.ra,c=Jc(this.v,!1),d=0,e;e=c[d];d++)var g=eg(e),a=Math.max(a,g.width);a+=b+8+b/2+N;if(this.L!=a){for(d=0;e=c[d];d++){var g=eg(e),h=J(e);if(H){var k=a-b-8-h.x;e.moveBy(k,0);h.x+=k}e.ld&&(e.ld.setAttribute("width",g.width),e.ld.setAttribute("height",g.height),e.ld.setAttribute("x",H?h.x-g.width:h.x),e.ld.setAttribute("y",h.y))}this.L=a;pe(window,"resize")}};
Ih.prototype.moveTo=function(a,b){var c=J(this);this.i.oa().setAttribute("transform","translate("+a+", "+b+")");zh(this,a-c.x,b-c.y)};function Zi(a,b){return function(c){qi();md();id(c)?ui(b,c):(ld(),kh(!0),Oi=c,Pi=b,Qi=a,Ri=P(document,"mouseup",this,qi),Si=P(document,"mousemove",this,a.bk));c.stopPropagation()}}Mi.prototype.Fe=function(a){id(a)||(md(!0),aj(),this.gi=a.clientY,Ti=P(document,"mousemove",this,this.$f),Ri=P(document,"mouseup",this,aj),a.preventDefault(),a.stopPropagation())};
Mi.prototype.$f=function(a){var b=a.clientY-this.gi;this.gi=a.clientY;a=Ni(this);b=a.Ab-b;b=Math.min(b,a.Ra-a.xa);b=Math.max(b,0);this.xc.set(b)};Mi.prototype.bk=function(a){"mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button?a.stopPropagation():(ld(),Math.sqrt(Math.pow(a.clientX-Oi.clientX,2)+Math.pow(a.clientY-Oi.clientY,2))>Ji&&Yi(Qi,Pi)(Oi))};
function Yi(a,b){return function(c){if(!id(c)&&!b.disabled){var d=Kc(b),d=Pc(a.Pd,d),e=ig(b);if(!e)throw"originBlock is not rendered.";var e=kd(e),g=ig(d);if(!g)throw"block is not rendered.";g=kd(g);d.moveBy(e.x-g.x,e.y-g.y);a.Vd?a.Jb():a.Af();d.Fe(c)}}}Mi.prototype.Af=function(){for(var a=qe(this.Pd),b=Jc(this.v,!1),c=0,d;d=b[c];c++){var e=hi(d).length>a;Uc(d,e)}};function aj(){Ri&&(O(Ri),Ri=null);Si&&(O(Si),Si=null);Ti&&(O(Ti),Ti=null);Ri&&(O(Ri),Ri=null);Qi=Pi=Oi=null};function bj(a){if("function"==typeof a.If)return a.If();if(p(a))return a.split("");if(fa(a)){for(var b=[],c=a.length,d=0;d<c;d++)b.push(a[d]);return b}b=[];c=0;for(d in a)b[c++]=a[d];return b};function cj(a){this.zb=void 0;this.sa={};if(a){var b;if("function"==typeof a.Hf)b=a.Hf();else if("function"!=typeof a.If)if(fa(a)||p(a)){b=[];for(var c=a.length,d=0;d<c;d++)b.push(d)}else for(d in b=[],c=0,a)b[c++]=d;else b=void 0;a=bj(a);for(c=0;c<b.length;c++)this.set(b[c],a[c])}}f=cj.prototype;f.set=function(a,b){dj(this,a,b,!1)};f.add=function(a,b){dj(this,a,b,!0)};
function dj(a,b,c,d){for(var e=0;e<b.length;e++){var g=b.charAt(e);a.sa[g]||(a.sa[g]=new cj);a=a.sa[g]}if(d&&void 0!==a.zb)throw Error('The collection already contains the key "'+b+'"');a.zb=c}f.get=function(a){a:{for(var b=this,c=0;c<a.length;c++)if(b=b.sa[a.charAt(c)],!b){a=void 0;break a}a=b}return a?a.zb:void 0};f.If=function(){var a=[];ej(this,a);return a};function ej(a,b){void 0!==a.zb&&b.push(a.zb);for(var c in a.sa)ej(a.sa[c],b)}
f.Hf=function(a){var b=[];if(a){for(var c=this,d=0;d<a.length;d++){var e=a.charAt(d);if(!c.sa[e])return[];c=c.sa[e]}fj(c,a,b)}else fj(this,"",b);return b};function fj(a,b,c){void 0!==a.zb&&c.push(b);for(var d in a.sa)fj(a.sa[d],b+d,c)}f.clear=function(){this.sa={};this.zb=void 0};
f.remove=function(a){for(var b=this,c=[],d=0;d<a.length;d++){var e=a.charAt(d);if(!b.sa[e])throw Error('The collection does not have the key "'+a+'"');c.push([b,e]);b=b.sa[e]}a=b.zb;for(delete b.zb;0<c.length;)if(e=c.pop(),b=e[0],e=e[1],b.sa[e].Fh())delete b.sa[e];else break;return a};f.clone=function(){return new cj(this)};f.Fh=function(){var a;if(a=void 0===this.zb)a:{a=this.sa;for(var b in a){a=!1;break a}a=!0}return a};function gj(){this.rc=new cj}f=gj.prototype;f.W="";f.Vf=null;f.Be=null;f.Bd=0;f.Rc=0;function hj(a,b){var c=!1,d=a.rc.Hf(b);d&&d.length&&(a.Rc=0,a.Bd=0,c=a.rc.get(d[0]),c=ij(a,c))&&(a.Vf=d);return c}function ij(a,b){var c;b&&(a.Rc<b.length&&(c=b[a.Rc],a.Be=b),c&&(c.ig(),c.select()));return!!c}f.clear=function(){this.W=""};function jj(a){var b;b||(b=kj(a||arguments.callee.caller,[]));return b}
function kj(a,b){var c=[];if(Va(b,a))c.push("[...circular reference...]");else if(a&&50>b.length){c.push(lj(a)+"(");for(var d=a.arguments,e=0;d&&e<d.length;e++){0<e&&c.push(", ");var g;g=d[e];switch(typeof g){case "object":g=g?"object":"null";break;case "string":break;case "number":g=String(g);break;case "boolean":g=g?"true":"false";break;case "function":g=(g=lj(g))?g:"[fn]";break;default:g=typeof g}40<g.length&&(g=g.substr(0,40)+"...");c.push(g)}b.push(a);c.push(")\n");try{c.push(kj(a.caller,b))}catch(h){c.push("[exception trying to get caller]\n")}}else a?
c.push("[...long stack...]"):c.push("[end]");return c.join("")}function lj(a){if(mj[a])return mj[a];a=String(a);if(!mj[a]){var b=/function ([^\(]+)/.exec(a);mj[a]=b?b[1]:"[Anonymous]"}return mj[a]}var mj={};function nj(a,b,c,d,e){this.reset(a,b,c,d,e)}nj.prototype.sh=null;nj.prototype.rh=null;var oj=0;nj.prototype.reset=function(a,b,c,d,e){"number"==typeof e||oj++;d||pa();this.Ad=a;this.Vj=b;delete this.sh;delete this.rh};nj.prototype.bi=function(a){this.Ad=a};function pj(a){this.Nh=a;this.Ah=this.R=this.Ad=this.wa=null}function qj(a,b){this.name=a;this.value=b}qj.prototype.toString=function(){return this.name};var rj=new qj("WARNING",900),sj=new qj("INFO",800),tj=new qj("CONFIG",700),uj=new qj("FINE",500);f=pj.prototype;f.getName=function(){return this.Nh};f.getParent=function(){return this.wa};f.lc=function(){this.R||(this.R={});return this.R};f.bi=function(a){this.Ad=a};
function vj(a){if(a.Ad)return a.Ad;if(a.wa)return vj(a.wa);Ka("Root logger has no level set.");return null}f.log=function(a,b,c){if(a.value>=vj(this).value)for(s(b)&&(b=b()),a=this.tj(a,b,c,pj.prototype.log),b="log:"+a.Vj,n.console&&(n.console.timeStamp?n.console.timeStamp(b):n.console.markTimeline&&n.console.markTimeline(b)),n.msWriteProfilerMark&&n.msWriteProfilerMark(b),b=this;b;){c=b;var d=a;if(c.Ah)for(var e=0,g=void 0;g=c.Ah[e];e++)g(d);b=b.getParent()}};
f.tj=function(a,b,c,d){var e=new nj(a,String(b),this.Nh);if(c){var g;g=d||arguments.callee.caller;e.sh=c;var h;try{var k;var l=aa("window.location.href");if(p(c))k={message:c,name:"Unknown error",lineNumber:"Not available",fileName:l,stack:"Not available"};else{var q,m,t=!1;try{q=c.lineNumber||c.sl||"Not available"}catch(v){q="Not available",t=!0}try{m=c.fileName||c.filename||c.sourceURL||n.$googDebugFname||l}catch(B){m="Not available",t=!0}k=!t&&c.lineNumber&&c.fileName&&c.stack&&c.message&&c.name?
c:{message:c.message||"Not available",name:c.name||"UnknownError",lineNumber:q,fileName:m,stack:c.stack||"Not available"}}h="Message: "+xa(k.message)+'\nUrl: <a href="view-source:'+k.fileName+'" target="_new">'+k.fileName+"</a>\nLine: "+k.lineNumber+"\n\nBrowser stack:\n"+xa(k.stack+"-> ")+"[end]\n\nJS stack traversal:\n"+xa(jj(g)+"-> ")}catch(ha){h="Exception trying to expose exception! You win, we lose. "+ha}e.rh=h}return e};f.Td=function(a,b){this.log(rj,a,b)};
f.info=function(a,b){this.log(sj,a,b)};var wj={},xj=null;function yj(a){xj||(xj=new pj(""),wj[""]=xj,xj.bi(tj));var b;if(!(b=wj[a])){b=new pj(a);var c=a.lastIndexOf("."),d=a.substr(c+1),c=yj(a.substr(0,c));c.lc()[d]=b;b.wa=c;wj[a]=b}return b};function zj(a){Ud.call(this);this.w=a;a=x?"focusout":"blur";this.Sj=Jd(this.w,x?"focusin":"focus",this,!x);this.Tj=Jd(this.w,a,this,!x)}u(zj,Ud);zj.prototype.handleEvent=function(a){var b=new Dd(a.Gb);b.type="focusin"==a.type||"focus"==a.type?"focusin":"focusout";this.dispatchEvent(b)};zj.prototype.X=function(){zj.n.X.call(this);Qd(this.Sj);Qd(this.Tj);delete this.w};function Aj(a,b,c){V.call(this,a,b,c);this.kd=!0;Lg(this,!0);this.Ma=this;this.Qd=new gj;if(x)try{document.execCommand("BackgroundImageCache",!1,!0)}catch(d){(a=this.Kh)&&a.Td("Failed to enable background image cache",void 0)}}u(Aj,V);f=Aj.prototype;f.va=null;f.Cf=null;f.Kh=yj("goog.ui.tree.TreeControl");f.Ef=!1;f.qj=null;f.Kd=!0;f.pg=!0;f.Bc=!0;f.qg=!0;f.za=function(){return this};f.Lc=function(){return 0};f.ig=function(){};f.Aj=function(){this.Ef=!0;Ye(this.h(),"focused");this.Ma&&this.Ma.select()};
f.wj=function(){this.Ef=!1;$e(this.h(),"focused")};f.hasFocus=function(){return this.Ef};f.Ea=function(){return!this.Bc||Aj.n.Ea.call(this)};f.Ob=function(a){this.Bc?Aj.n.Ob.call(this,a):this.kd=a};f.Gf=function(){return xb};f.me=function(){var a=Jg(this);return a?a.firstChild:null};f.le=function(){return null};f.ad=function(){};f.pd=function(){return Aj.n.pd.call(this)+(this.Bc?"":" "+this.ma.fh)};
f.ie=function(){var a=this.Ea(),b=this.pj;if(a&&b)return b;b=this.Ij;if(!a&&b)return b;b=this.ma;return a&&b.eh?b.gc+" "+b.eh:!a&&b.$g?b.gc+" "+b.$g:""};f.Ac=function(a){if(this.Ma!=a){var b=!1;this.Ma&&(b=this.Ma==this.qj,Lg(this.Ma,!1));if(this.Ma=a)Lg(a,!0),b&&a.select();this.dispatchEvent("change")}};function Bj(a){function b(a){var h=Gg(a);if(h){var k=!d||c==a.getParent()&&!e?a.ma.Yg:a.ma.Xg;h.className=k;if(h=a.le())h.className=Pg(a)}Re(a,b)}var c=a,d=c.Kd,e=c.qg;b(a)}
f.ve=function(){Aj.n.ve.call(this);var a=this.h();ff(a,"tree");T(a,"labelledby",Fg(this).id)};f.na=function(){Aj.n.na.call(this);var a=this.h();a.className=this.ma.ih;a.setAttribute("hideFocus","true");a=this.h();a.tabIndex=0;var b=this.va=new sf(a),c=this.Cf=new zj(a);Pe(this).D(c,"focusout",this.wj).D(c,"focusin",this.Aj).D(b,"key",this.jb).D(a,"mousedown",this.Kf).D(a,"click",this.Kf).D(a,"dblclick",this.Kf);this.ve()};
f.Sa=function(){Aj.n.Sa.call(this);this.va.j();this.va=null;this.Cf.j();this.Cf=null};f.Kf=function(a){var b=this.Kh;b&&b.log(uj,"Received event "+a.type,void 0);if(b=Cj(this,a))switch(a.type){case "mousedown":b.Zf(a);break;case "click":a.preventDefault();break;case "dblclick":b.Oh(a)}};
f.jb=function(a){var b=!1,b=this.Qd,c=!1;switch(a.keyCode){case 40:case 38:if(a.ctrlKey){var c=40==a.keyCode?1:-1,d=b.Vf;if(d){var e=null,g=!1;if(b.Be){var h=b.Rc+c;0<=h&&h<b.Be.length?(b.Rc=h,e=b.Be):g=!0}e||(h=b.Bd+c,0<=h&&h<d.length&&(b.Bd=h),d.length>b.Bd&&(e=b.rc.get(d[b.Bd])),e&&e.length&&g&&(b.Rc=-1==c?e.length-1:0));ij(b,e)&&(b.Vf=d)}c=!0}break;case 8:d=b.W.length-1;c=!0;0<d?(b.W=b.W.substring(0,d),hj(b,b.W)):0==d?b.W="":c=!1;break;case 27:b.W="",c=!0}if(!(b=c)&&(b=this.Ma)){b=this.Ma;c=!0;
switch(a.keyCode){case 39:if(a.altKey)break;Ue(b)&&(b.Ea()?S(b,0).select():b.Ob(!0));break;case 37:if(a.altKey)break;Ue(b)&&b.Ea()&&b.zd?b.Ob(!1):(d=b.getParent(),e=b.za(),d&&(e.Bc||d!=e)&&d.select());break;case 40:a:if(Ue(b)&&b.Ea())d=S(b,0);else{for(d=b;d!=b.za();){e=d.kb;if(null!=e){d=e;break a}d=d.getParent()}d=null}d&&d.select();break;case 38:d=b.tc;null!=d?d=Sg(d):(d=b.getParent(),e=b.za(),d=!e.Bc&&d==e||b==e?null:d);d&&d.select();break;default:c=!1}c&&(a.preventDefault(),(e=b.za())&&e.Qd.clear());
b=c}b||(b=this.Qd,c=!1,a.ctrlKey||a.altKey||(d=String.fromCharCode(a.charCode||a.keyCode).toLowerCase(),(1==d.length&&" "<=d&&"~">=d||"\u0080"<=d&&"\ufffd">=d)&&(" "!=d||b.W)&&(b.W+=d,c=hj(b,b.W))),b=c);b&&a.preventDefault();return b};function Cj(a,b){for(var c=null,d=b.target;null!=d;){if(c=Eg[d.id])return c;if(d==a.h())break;d=d.parentNode}return null}f.createNode=function(a){return new Tg(a||xb,this.ma,this.ib())};
function Rg(a,b){var c=a.Qd,d=b.Ib();if(d&&!/^[\s\xa0]*$/.test(null==d?"":String(d))){var d=d.toLowerCase(),e=c.rc.get(d);e?e.push(b):c.rc.set(d,[b])}}f.removeNode=function(a){var b=this.Qd,c=a.Ib();if(c&&!/^[\s\xa0]*$/.test(null==c?"":String(c))){var c=c.toLowerCase(),d=b.rc.get(c);d&&(Wa(d,a),d.length&&b.rc.remove(c))}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Dj,Ej,Fj,Gj=0,Hj={Qf:19,ih:"blocklyTreeRoot",fh:"blocklyHidden",gh:"",tf:"blocklyTreeRow",hh:"blocklyTreeLabel",gc:"blocklyTreeIcon",rf:"blocklyTreeIconOpen",sf:"blocklyTreeIconNone",jh:"blocklyTreeSelected"};function Ij(a,b){Dj=C("div","blocklyToolboxDiv");Dj.setAttribute("dir",H?"RTL":"LTR");b.appendChild(Dj);Ej=new Mi;a.appendChild(Ej.H());P(Dj,"mousedown",null,function(a){id(a)||a.target==Dj?md(!1):md(!0)})}
function Jj(){Hj.cleardotPath=Q+"1x1.gif";Hj.cssCollapsedFolderIcon="blocklyTreeIconClosed"+(H?"Rtl":"Ltr");var a=new Kj(xb,Hj);Fj=a;if(0!=a.Bc){a.Bc=!1;if(a.B){var b=Jg(a);b&&(b.className=a.pd())}a.Ma==a&&S(a,0)&&a.Ac(S(a,0))}0!=a.Kd&&(a.Kd=!1,a.B&&Bj(a));0!=a.pg&&(a.pg=!1,a.B&&Bj(a));a.Ac(null);Dj.style.display="block";Ej.Y(D);Lj();a.F(Dj);Jd(window,"resize",Mj);Mj()}
function Mj(){var a=Dj,b=He(I),c=di();H?(b=Nj(0,0,!1),a.style.left=b.x+c.width-a.offsetWidth+"px"):a.style.marginLeft=b.left;a.style.height=c.height+1+"px";Gj=a.offsetWidth;H||--Gj}
function Lj(){function a(c,d){for(var e=0,g;g=c.childNodes[e];e++)if(g.tagName){var h=g.tagName.toUpperCase();if("CATEGORY"==h){h=b.createNode(g.getAttribute("name"));h.ec=[];d.add(h);var k=g.getAttribute("custom");k?h.ec=k:a(g,h)}else"HR"==h?d.add(new Oj):"BLOCK"==h&&d.ec.push(g)}}var b=Fj;b.Zh();b.ec=[];a(zc,Fj);if(b.ec.length)throw"Toolbox cannot have both blocks and categories in the root level.";pe(window,"resize")}function Kj(a,b,c){Aj.call(this,a,b,c)}u(Kj,Aj);
Kj.prototype.na=function(){Kj.n.na.call(this);if(Bd){var a=this.h();P(a,"touchstart",this,this.Fj)}};Kj.prototype.Fj=function(a){a.preventDefault();var b=Cj(this,a);b&&"touchstart"===a.type&&window.setTimeout(function(){b.Zf(a)},1)};Kj.prototype.createNode=function(a){return new Pj(a?qb(a):xb,this.ma,this.ib())};Kj.prototype.Ac=function(a){this.Ma!=a&&(Aj.prototype.Ac.call(this,a),a&&a.ec&&a.ec.length?Ej.show(a.ec):Ej.Jb())};
function Pj(a,b,c){function d(){pe(window,"resize")}V.call(this,a,b,c);Jd(Fj,"expand",d);Jd(Fj,"collapse",d)}u(Pj,Tg);V.prototype.Gf=function(){return vb("span")};Pj.prototype.Zf=function(){Ue(this)&&this.zd?(this.toggle(),this.select()):this.xe()?this.za().Ac(null):this.select();Mg(this)};Pj.prototype.Oh=function(){};function Oj(){Pj.call(this,"",Qj)}u(Oj,Pj);var Qj={tf:"blocklyTreeSeparator"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Ui="VARIABLE";
function Vi(a,b,c,d){var e;e=je(D);for(var g=Object.create(null),h=0;h<e.length;h++){var k=e[h].vj;if(k)for(var k=k.call(e[h]),l=0;l<k.length;l++){var q=k[l];q&&(g[q.toLowerCase()]=q)}}e=[];for(var m in g)e.push(g[m]);e.sort(wa);e.unshift(null);g=void 0;for(m=0;m<e.length;m++)e[m]!==g&&((h=Jh.variables_get?Rc(d,"variables_get"):null)&&Sc(h),(k=Jh.variables_set?Rc(d,"variables_set"):null)&&Sc(k),null===e[m]?g=(h||k).vj()[0]:(h&&Yc(h,"VAR").Yc(e[m]),k&&Yc(k,"VAR").Yc(e[m])),k&&a.push(k),h&&a.push(h),
h&&k?b.push(c,3*c):b.push(2*c))};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Wi="PROCEDURE";function Rj(){for(var a=je(D),b=[],c=[],d=0;d<a.length;d++){var e=a[d].kl;e&&(e=e.call(a[d]))&&(e[2]?b.push(e):c.push(e))}c.sort(Sj);b.sort(Sj);return[c,b]}function Sj(a,b){var c=a[0].toLowerCase(),d=b[0].toLowerCase();return c>d?1:c<d?-1:0}
function Xi(a,b,c,d){function e(e,g){for(var l=0;l<e.length;l++){var q=Rc(d,g);Yc(q,"NAME").Yc(e[l][0]);for(var m=[],t=0;t<e[l][1].length;t++)m[t]="ARG"+t;q.El(e[l][1],m);Sc(q);a.push(q);b.push(2*c)}}if(Jh.procedures_defnoreturn){var g=Rc(d,"procedures_defnoreturn");Sc(g);a.push(g);b.push(2*c)}Jh.procedures_defreturn&&(g=Rc(d,"procedures_defreturn"),Sc(g),a.push(g),b.push(2*c));Jh.procedures_ifreturn&&(g=Rc(d,"procedures_ifreturn"),Sc(g),a.push(g),b.push(2*c));b.length&&(b[b.length-1]=3*c);g=Rj();
e(g[0],"procedures_callnoreturn");e(g[1],"procedures_callreturn")};var Zf=/#(.)(.)(.)/;function Wf(a){var b=a[0],c=a[1];a=a[2];b=Number(b);c=Number(c);a=Number(a);if(isNaN(b)||0>b||255<b||isNaN(c)||0>c||255<c||isNaN(a)||0>a||255<a)throw Error('"('+b+","+c+","+a+'") is not a valid RGB color');b=Tj(b.toString(16));c=Tj(c.toString(16));a=Tj(a.toString(16));return"#"+b+c+a}var Yf=/^#(?:[0-9a-f]{3}){1,2}$/i;function Tj(a){return 1==a.length?"0"+a:a}
function Xf(a){var b=0,c=0,d=0,e=Math.floor(a/60),g=a/60-e;a=166.4*.55;var h=166.4*(1-.45*g),g=166.4*(1-.45*(1-g));switch(e){case 1:b=h;c=166.4;d=a;break;case 2:b=a;c=166.4;d=g;break;case 3:b=a;c=h;d=166.4;break;case 4:b=g;c=a;d=166.4;break;case 5:b=166.4;c=a;d=h;break;case 6:case 0:b=166.4,c=g,d=a}return[Math.floor(b),Math.floor(c),Math.floor(d)]}function $f(a,b,c){c=Sb(c,0,1);return[Math.round(c*a[0]+(1-c)*b[0]),Math.round(c*a[1]+(1-c)*b[1]),Math.round(c*a[2]+(1-c)*b[2])]};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Nf(a,b){var c=a.getAttribute("class")||"";-1==(" "+c+" ").indexOf(" "+b+" ")&&(c&&(c+=" "),a.setAttribute("class",c+b))}function Of(a,b){var c=a.getAttribute("class");if(-1!=(" "+c+" ").indexOf(" "+b+" ")){for(var c=c.split(/\s+/),d=0;d<c.length;d++)c[d]&&c[d]!=b||(c.splice(d,1),d--);c.length?a.setAttribute("class",c.join(" ")):a.removeAttribute("class")}}
function P(a,b,c,d){function e(a){d.apply(c,arguments)}a.addEventListener(b,e,!1);var g=[[a,b,e]];if(b in Uj)for(var e=function(a){if(1==a.changedTouches.length){var b=a.changedTouches[0];a.clientX=b.clientX;a.clientY=b.clientY}d.apply(c,arguments);a.preventDefault()},h=0,k;k=Uj[b][h];h++)a.addEventListener(k,e,!1),g.push([a,k,e]);return g}var Uj={};"ontouchstart"in document.documentElement&&(Uj={mousedown:["touchstart"],mousemove:["touchmove"],mouseup:["touchend","touchcancel"]});
function O(a){for(;a.length;){var b=a.pop();b[0].removeEventListener(b[1],b[2],!1)}}function $i(a,b){var c=document;if(c.createEvent)c=c.createEvent("UIEvents"),c.initEvent(b,!0,!0),a.dispatchEvent(c);else if(c.createEventObject)c=c.createEventObject(),a.fireEvent("on"+b,c);else throw"FireEvent: No event creation mechanism.";}function pe(a,b){setTimeout(function(){$i(a,b)},0)}
function mh(a){var b={x:0,y:0},c=a.getAttribute("x");c&&(b.x=parseInt(c,10));if(c=a.getAttribute("y"))b.y=parseInt(c,10);if(a=(a=a.getAttribute("transform"))&&a.match(/translate\(\s*([-\d.]+)([ ,]\s*([-\d.]+)\s*\))?/))b.x+=parseInt(a[1],10),a[3]&&(b.y+=parseInt(a[3],10));return b}function kd(a){var b=0,c=0;do{var d=mh(a),b=b+d.x,c=c+d.y;a=a.parentNode}while(a&&a!=I);return{x:b,y:c}}
function M(a,b,c){a=document.createElementNS("http://www.w3.org/2000/svg",a);for(var d in b)a.setAttribute(d,b[d]);document.body.runtimeStyle&&(a.runtimeStyle=a.currentStyle=a.style);c&&c.appendChild(a);return a}function id(a){return 2==a.button||a.ctrlKey}
function Nj(a,b,c){c&&(a-=window.scrollX||window.pageXOffset,b-=window.scrollY||window.pageYOffset);var d=I.createSVGPoint();d.x=a;d.y=b;a=I.getScreenCTM();c&&(a=a.inverse());d=d.matrixTransform(a);c||(d.x+=window.scrollX||window.pageXOffset,d.y+=window.scrollY||window.pageYOffset);return d}function jd(a){return Nj(a.clientX+(window.scrollX||window.pageXOffset),a.clientY+(window.scrollY||window.pageYOffset),!0)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Vj(){function a(a){a=a.slice(1).split("&");for(var c=0;c<a.length;c++){var g=a[c].split("=");b[decodeURIComponent(g[0])]=decodeURIComponent(g[1])}}var b={},c=window.location.hash;c&&a(c);(c=window.location.search)&&a(c);return b}var Wj=Vj();function X(a,b,c){if(a.hasOwnProperty(b))return a[b];void 0===c&&console.error(b+" should be present in the options.");return c}
function Xj(a){this.Xi=X(a,"clientId");this.Cg=Wj.userId;document.getElementById(X(a,"authButtonElementId"));document.getElementById(X(a,"authDivElementId"))}Xj.prototype.start=function(){gapi.load("auth:client,drive-realtime,drive-share",function(){})};
function Yj(a,b,c,d){function e(c){gapi.Sb.S.files.we({resource:{mimeType:b,title:a,parents:[{id:c}]}}).jc(d)}function g(){function a(b){gapi.Sb.S.kk.we({fileId:"appdata",resource:{key:"folderId",value:b}}).jc(function(){e(b)})}function b(){gapi.Sb.S.files.we({resource:{mimeType:"application/vnd.google-apps.folder",title:c}}).jc(function(b){a(b.id)})}gapi.Sb.S.kk.get({fileId:"appdata",propertyKey:"folderId"}).jc(function(d){if(d.error)c?b():a("root");else{var g=d.result.value;gapi.Sb.S.files.get({fileId:g}).jc(function(a){a.error||
a.labels.Il?b():e(g)})}})}gapi.Sb.load("drive","v2",function(){g()})}function Zj(a){this.Ph=X(a,"onFileLoaded");this.Xj=X(a,"newFileMimeType","application/vnd.google-apps.drive-sdk");this.Ch=X(a,"initializeModel");this.Yh=X(a,"registerTypes",function(){});this.Jg=X(a,"afterAuth",function(){});this.Ri=X(a,"autoCreate",!1);this.jj=X(a,"defaultTitle","New Realtime File");this.ij=X(a,"defaultFolderTitle","");this.Kg=X(a,"afterCreate",function(){});this.lf=new Xj(a)}
function ak(a,b,c){var d=[];b&&d.push("fileIds="+b.join(","));c&&d.push("userId="+c);c=0==d.length?window.location.pathname:window.location.pathname+"#"+d.join("&");window.history&&window.history.replaceState?window.history.replaceState("Google Drive Realtime API Playground","Google Drive Realtime API Playground",c):window.location.href=c;Wj=Vj();for(var e in b)gapi.S.xb.load(b[e],a.Ph,a.Ch,a.yh)}Zj.prototype.start=function(){var a=this;this.lf.start(function(){a.Yh&&a.Yh();a.Jg&&a.Jg();a.load()})};
Zj.prototype.yh=function(a){a.type!=gapi.S.xb.Fg.Uk&&(a.type==gapi.S.xb.Fg.Nk?(alert("An Error happened: "+a.message),window.location.href="/"):a.type==gapi.S.xb.Fg.Sk&&(alert("The file was not found. It does not exist or you do not have read access to the file."),window.location.href="/"))};
Zj.prototype.load=function(){var a=Wj.fileIds;a&&(a=a.split(","));var b=this.lf.Cg,b=Wj.state;if(a)for(var c in a)gapi.S.xb.load(a[c],this.Ph,this.Ch,this.yh);else{if(b){var d;try{d=JSON.parse(b)}catch(e){d=null}if("open"==d.action){a=d.ql;b=d.Cg;ak(this,a,b);return}}this.Ri&&bk(this)}};function bk(a){Yj(a.jj,a.Xj,a.ij,function(b){b.id?(a.Kg&&a.Kg(b.id),ak(a,[b.id],a.lf.Cg)):(console.error("Error creating file."),console.error(b))})};/*

 Visual Blocks Editor

 Copyright 2014 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var he,ck,ge=!1,dk=null,ki=null,ek=null,fk=null,mi=null,ri=!1,gk=null,hk=null,ik=null;function jk(a){var b=a.oj;a=a.oj.length;for(var c=0;c<a;c++){var d=b[c];if(!d.Qj){var e=d.target;"value_changed"==d.type&&("xmlDom"==d.Vh?kk(function(){lk(e,!1);mk(e)}):"relativeX"!=d.Vh&&"relativeY"!=d.Vh||kk(function(){e.i||lk(e,!1);mk(e)}))}}}function nk(a){if(!a.Qj){var b=a.newValue;b?lk(b,!a.oldValue):(b=a.oldValue,ok(b))}}function kk(a){if(ri)a();else try{ri=!0,a()}finally{ri=!1}}
function lk(a,b){kk(function(){var c=Nc(a.Dg).firstChild;if(c=Pc(D,c,!0))b&&fe(c.s,c),(b||Va(he,c))&&mk(c)})}function mk(a){if(!isNaN(a.Ne)&&!isNaN(a.Oe)){var b=di().width,c=J(a),d=a.Ne-c.x;a.moveBy(H?b-d:d,a.Oe-c.y)}}function ok(a){kk(function(){a.j(!0,!0,!0)})}function si(a){if(a.s==D&&ge&&!ri){a=xh(a);var b=J(a),c=!1,d=Kc(a);d.setAttribute("id",a.id);var e=C("xml");e.appendChild(d);d=Mc(e);d!=a.Dg&&(c=!0,a.Dg=d);if(a.Ne!=b.x||a.Oe!=b.y)a.Ne=b.x,a.Oe=b.y,c=!0;c&&mi.set(a.id.toString(),a)}}
function pk(a,b){gapi.Sb.S.Th.list({fileId:a}).jc(function(a){for(var d=0;d<a.items.length;d++){var e=a.items[d];if("owner"==e.yl){b(e.domain);break}}})}
var tk={clientId:null,authButtonElementId:"authorizeButton",authDivElementId:"authButtonDiv",initializeModel:function(a){ki=a;var b=a.fl();a.Mc().set("blocks",b);b=a.dl();a.Mc().set("topBlocks",b);hk&&a.Mc().set(hk,a.hl(ik))},autoCreate:!0,defaultTitle:"Realtime Blockly File",defaultFolderTitle:"Realtime Blockly Folder",newFileMimeType:null,onFileLoaded:function(a){dk=a;a:{for(var b=a.sj(),c=0;c<b.length;c++){var d=b[c];if(d.Rj){ek=d.Bl;break a}}ek=void 0}ki=a.Ce;mi=ki.Mc().get("blocks");he=ki.Mc().get("topBlocks");
ki.Mc().addEventListener(gapi.S.xb.cf.Tk,jk);mi.addEventListener(gapi.S.xb.cf.Vk,nk);fk();a.addEventListener(gapi.S.xb.cf.Ok,qk);a.addEventListener(gapi.S.xb.cf.Pk,rk);sk();a=he;for(b=0;b<a.length;b++)c=a.get(b),lk(c,!0)},registerTypes:function(){var a=gapi.S.xb.il;a.wl(Ih,"Block");Ih.prototype.id=a.pf("id");Ih.prototype.Dg=a.pf("xmlDom");Ih.prototype.Ne=a.pf("relativeX");Ih.prototype.Oe=a.pf("relativeY");a.Cl(Ih,Ih.prototype.initialize)},afterAuth:function(){window.setTimeout(function(){},18E5)},
afterCreate:function(a){var b=gapi.Sb.S.Th.we({fileId:a,resource:{type:"anyone",role:"writer",value:"default",withLink:!0}});b.jc(function(c){c.error&&pk(a,function(c){b=gapi.Sb.S.Th.we({fileId:a,resource:{type:"domain",role:"writer",value:c,withLink:!0}});b.jc(function(){})})})}};function uk(){var a=Bc,b=X(a,"chatbox");b&&(hk=X(b,"elementId"),ik=X(b,"initText",vk));tk.Xi=X(a,"clientId");ck=X(a,"collabElementId")}
function wk(a,b){uk();ge=!0;xk(b);fk=function(){a();if(hk){var b=ki.Mc().get(hk),d=document.getElementById(hk);gapi.S.xb.jl.Zk(b,d);d.disabled=!1}};gk=new Zj(tk);gk.start()}
function xk(a){a.style.background="url("+Q+"progress.gif) no-repeat center center";var b=Be(a),c=C("div");c.id=tk.authDivElementId;var d=C("p",null,yk);c.appendChild(d);d=C("button",null,"Authorize");d.id=tk.Xk;c.appendChild(d);a.appendChild(c);c.style.display="none";c.style.position="relative";c.style.textAlign="center";c.style.border="1px solid";c.style.backgroundColor="#f6f9ff";c.style.borderRadius="15px";c.style.boxShadow="10px 10px 5px #888";c.style.width=b.width/3+"px";a=Be(c);c.style.left=
(b.width-a.width)/3+"px";c.style.top=(b.height-a.height)/4+"px"}function sk(){if(ck){var a;a=ck;a=p(a)?document.getElementById(a):a;dc(a);for(var b=dk.sj(),c=0;c<b.length;c++){var d=b[c],e=C("img",{src:d.vl||Q+"anon.jpeg",alt:d.displayName,title:d.displayName+(d.Rj?" ("+zk+")":"")});e.style.backgroundColor=d.color;a.appendChild(e)}}}function qk(){sk()}function rk(){sk()}function li(a){var b=ek+"-"+a;return mi.has(b)?li("-"+a):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ak(){var a=Bk.join("\n"),b=Q.replace(/[\\\/]$/,""),a=a.replace(/<<<PATH>>>/g,b),b=document,c=b.createElement("style");c.type="text/css";b.getElementsByTagName("head")[0].appendChild(c);c.styleSheet?c.styleSheet.cssText=a:c.appendChild(b.createTextNode(a))}
var Bk=[".blocklySvg {","  background-color: #fff;","  border: 1px solid #ddd;","  overflow: hidden;","}",".blocklyWidgetDiv {","  position: absolute;","  display: none;","  z-index: 999;","}",".blocklyDraggable {","  cursor: url(<<<PATH>>>/handopen.cur) 8 5, auto;","}",".blocklyResizeSE {","  fill: #aaa;","  cursor: se-resize;","}",".blocklyResizeSW {","  fill: #aaa;","  cursor: sw-resize;","}",".blocklyResizeLine {","  stroke-width: 1;","  stroke: #888;","}",".blocklyHighlightedConnectionPath {",
"  stroke-width: 4px;","  stroke: #fc3;","  fill: none;","}",".blocklyPathLight {","  fill: none;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklySelected>.blocklyPath {","  stroke-width: 3px;","  stroke: #fc3;","}",".blocklySelected>.blocklyPathLight {","  display: none;","}",".blocklyDragging>.blocklyPath,",".blocklyDragging>.blocklyPathLight {","  fill-opacity: .8;","  stroke-opacity: .8;","}",".blocklyDragging>.blocklyPathDark {","  display: none;","}",".blocklyDisabled>.blocklyPath {",
"  fill-opacity: .5;","  stroke-opacity: .5;","}",".blocklyDisabled>.blocklyPathLight,",".blocklyDisabled>.blocklyPathDark {","  display: none;","}",".blocklyText {","  cursor: default;","  font-family: sans-serif;","  font-size: 11pt;","  fill: #fff;","}",".blocklyNonEditableText>text {","  pointer-events: none;","}",".blocklyNonEditableText>rect,",".blocklyEditableText>rect {","  fill: #fff;","  fill-opacity: .6;","}",".blocklyNonEditableText>text,",".blocklyEditableText>text {","  fill: #000;",
"}",".blocklyEditableText:hover>rect {","  stroke-width: 2;","  stroke: #fff;","}",".blocklyBubbleText {","  fill: #000;","}",".blocklySvg text {","  -moz-user-select: none;","  -webkit-user-select: none;","  user-select: none;","  cursor: inherit;","}",".blocklyHidden {","  display: none;","}",".blocklyFieldDropdown:not(.blocklyHidden) {","  display: block;","}",".blocklyTooltipBackground {","  fill: #ffffc7;","  stroke-width: 1px;","  stroke: #d8d8d8;","}",".blocklyTooltipShadow,",".blocklyDropdownMenuShadow {",
"  fill: #bbb;","  filter: url(#blocklyShadowFilter);","}",".blocklyTooltipText {","  font-family: sans-serif;","  font-size: 9pt;","  fill: #000;","}",".blocklyIconShield {","  cursor: default;","  fill: #00c;","  stroke-width: 1px;","  stroke: #ccc;","}",".blocklyIconGroup:hover>.blocklyIconShield {","  fill: #00f;","  stroke: #fff;","}",".blocklyIconGroup:hover>.blocklyIconMark {","  fill: #fff;","}",".blocklyIconMark {","  cursor: default !important;","  font-family: sans-serif;","  font-size: 9pt;",
"  font-weight: bold;","  fill: #ccc;","  text-anchor: middle;","}",".blocklyWarningBody {","}",".blocklyMinimalBody {","  margin: 0;","  padding: 0;","}",".blocklyCommentTextarea {","  margin: 0;","  padding: 2px;","  border: 0;","  resize: none;","  background-color: #ffc;","}",".blocklyHtmlInput {","  font-family: sans-serif;","  font-size: 11pt;","  border: none;","  outline: none;","  width: 100%","}",".blocklyMutatorBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #ddd;","}",".blocklyFlyoutBackground {",
"  fill: #ddd;","  fill-opacity: .8;","}",".blocklyColourBackground {","  fill: #666;","}",".blocklyScrollbarBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #e4e4e4;","}",".blocklyScrollbarKnob {","  fill: #ccc;","}",".blocklyScrollbarBackground:hover+.blocklyScrollbarKnob,",".blocklyScrollbarKnob:hover {","  fill: #bbb;","}",".blocklyInvalidInput {","  background: #faa;","}",".blocklyAngleCircle {","  stroke: #444;","  stroke-width: 1;","  fill: #ddd;","  fill-opacity: .8;","}",".blocklyAngleMarks {",
"  stroke: #444;","  stroke-width: 1;","}",".blocklyAngleGauge {","  fill: #f88;","  fill-opacity: .8;  ","}",".blocklyAngleLine {","  stroke: #f00;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklyContextMenu {","  border-radius: 4px;","}",".blocklyDropdownMenu {","  padding: 0 !important;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(<<<PATH>>>/sprites.png) no-repeat -48px -16px !important;",
"}",".blocklyToolboxDiv {","  background-color: #ddd;","  display: none;","  overflow-x: visible;","  overflow-y: auto;","  position: absolute;","}",".blocklyTreeRoot {","  padding: 4px 0;","}",".blocklyTreeRoot:focus {","  outline: none;","}",".blocklyTreeRow {","  line-height: 22px;","  height: 22px;","  padding-right: 1em;","  white-space: nowrap;","}",'.blocklyToolboxDiv[dir="RTL"] .blocklyTreeRow {',"  padding-right: 0;","  padding-left: 1em !important;","}",".blocklyTreeRow:hover {","  background-color: #e4e4e4;",
"}",".blocklyTreeSeparator {","  height: 0px;","  border-bottom: solid #e5e5e5 1px;","  margin: 5px 0;","}",".blocklyTreeIcon {","  height: 16px;","  width: 16px;","  vertical-align: middle;","  background-image: url(<<<PATH>>>/sprites.png);","}",".blocklyTreeIconClosedLtr {","  background-position: -32px -1px;","}",".blocklyTreeIconClosedRtl {","  background-position: 0px -1px;","}",".blocklyTreeIconOpen {","  background-position: -16px -1px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedLtr {",
"  background-position: -32px -17px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedRtl {","  background-position: 0px -17px;","}",".blocklyTreeSelected>.blocklyTreeIconOpen {","  background-position: -16px -17px;","}",".blocklyTreeIconNone,",".blocklyTreeSelected>.blocklyTreeIconNone {","  background-position: -48px -1px;","}",".blocklyTreeLabel {","  cursor: default;","  font-family: sans-serif;","  font-size: 16px;","  padding: 0 3px;","  vertical-align: middle;","}",".blocklyTreeSelected  {",
"  background-color: #57e !important;","}",".blocklyTreeSelected .blocklyTreeLabel {","  color: #fff;","}",".blocklyWidgetDiv .goog-palette {","  outline: none;","  cursor: default;","}",".blocklyWidgetDiv .goog-palette-table {","  border: 1px solid #666;","  border-collapse: collapse;","}",".blocklyWidgetDiv .goog-palette-cell {","  height: 13px;","  width: 15px;","  margin: 0;","  border: 0;","  text-align: center;","  vertical-align: middle;","  border-right: 1px solid #666;","  font-size: 1px;",
"}",".blocklyWidgetDiv .goog-palette-colorswatch {","  position: relative;","  height: 13px;","  width: 15px;","  border: 1px solid #666;","}",".blocklyWidgetDiv .goog-palette-cell-hover .goog-palette-colorswatch {","  border: 1px solid #FFF;","}",".blocklyWidgetDiv .goog-palette-cell-selected .goog-palette-colorswatch {","  border: 1px solid #000;","  color: #fff;","}",".blocklyWidgetDiv .goog-menu {","  background: #fff;","  border-color: #ccc #666 #666 #ccc;","  border-style: solid;","  border-width: 1px;",
"  cursor: default;","  font: normal 13px Arial, sans-serif;","  margin: 0;","  outline: none;","  padding: 4px 0;","  position: absolute;","  z-index: 20000;","}",".blocklyWidgetDiv .goog-menuitem {","  color: #000;","  font: normal 13px Arial, sans-serif;","  list-style: none;","  margin: 0;","  padding: 4px 7em 4px 28px;","  white-space: nowrap;","}",".blocklyWidgetDiv .goog-menuitem.goog-menuitem-rtl {","  padding-left: 7em;","  padding-right: 28px;","}",".blocklyWidgetDiv .goog-menu-nocheckbox .goog-menuitem,",
".blocklyWidgetDiv .goog-menu-noicon .goog-menuitem {","  padding-left: 12px;","}",".blocklyWidgetDiv .goog-menu-noaccel .goog-menuitem {","  padding-right: 20px;","}",".blocklyWidgetDiv .goog-menuitem-content {","  color: #000;","  font: normal 13px Arial, sans-serif;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-accel,",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-content {","  color: #ccc !important;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-icon {",
"  opacity: 0.3;","  -moz-opacity: 0.3;","  filter: alpha(opacity=30);","}",".blocklyWidgetDiv .goog-menuitem-highlight,",".blocklyWidgetDiv .goog-menuitem-hover {","  background-color: #d6e9f8;","  border-color: #d6e9f8;","  border-style: dotted;","  border-width: 1px 0;","  padding-bottom: 3px;","  padding-top: 3px;","}",".blocklyWidgetDiv .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-icon {","  background-repeat: no-repeat;","  height: 16px;","  left: 6px;","  position: absolute;",
"  right: auto;","  vertical-align: middle;","  width: 16px;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-icon {","  left: auto;","  right: 6px;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(//ssl.gstatic.com/editor/editortoolbar.png) no-repeat -512px 0;","}",".blocklyWidgetDiv .goog-menuitem-accel {","  color: #999;",
"  direction: ltr;","  left: auto;","  padding: 0 6px;","  position: absolute;","  right: 0;","  text-align: right;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-accel {","  left: 0;","  right: auto;","  text-align: left;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-hint {","  text-decoration: underline;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-separator {","  color: #999;","  font-size: 12px;","  padding-left: 4px;","}",".blocklyWidgetDiv .goog-menuseparator {","  border-top: 1px solid #ccc;",
"  margin: 4px 0;","  padding: 0;","}",""];/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ck(a){function b(){Dk(a);Ek()}var c={media:"media/",readOnly:!0,zl:-1!=Fk.indexOf(sc),scrollbars:!1};if(!fc(document,a))throw"Error: container is not in current document.";c&&Gk(c);if(Ac){if(c=document.getElementById("realtime"))c.style.display="block";wk(b,a)}else b()}
function Gk(a){var b=!!a.readOnly;if(b)var c=!1,d=!1,e=!1,g=!1,h=!1,k=null;else(c=a.toolbox)?("string"!=typeof c&&"undefined"==typeof XSLTProcessor&&(c=c.outerHTML),"string"==typeof c&&(c=Nc(c))):c=null,k=c,c=Boolean(k&&k.getElementsByTagName("category").length),d=a.trashcan,void 0===d&&(d=c),e=a.collapse,void 0===e&&(e=c),g=a.comments,void 0===g&&(g=c),h=a.disable,void 0===h&&(h=c);if(k&&!c)var l=!1;else l=a.scrollbars,void 0===l&&(l=!0);var q=a.sounds;void 0===q&&(q=!0);var m=!!a.realtime,t=m?a.realtimeOptions:
void 0;H=!!a.rtl;xc=e;wc=g;yc=h;L=b;Cc=a.maxBlocks||Infinity;a.media?Q=a.media:a.path&&(Q=a.path+"media/");Dc=c;Ec=l;vc=d;Fc=q;zc=k;Ac=m;Bc=t}
function Dk(a){a.setAttribute("dir","LTR");Me=H;Ak();var b=M("svg",{xmlns:"http://www.w3.org/2000/svg","xmlns:html":"http://www.w3.org/1999/xhtml","xmlns:xlink":"http://www.w3.org/1999/xlink",version:"1.1","class":"blocklySvg"},null),c=M("defs",{},b),d,e;d=M("filter",{id:"blocklyEmboss"},c);M("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:1,result:"blur"},d);e=M("feSpecularLighting",{"in":"blur",surfaceScale:1,specularConstant:.5,specularExponent:10,"lighting-color":"white",result:"specOut"},d);
M("fePointLight",{x:-5E3,y:-1E4,z:2E4},e);M("feComposite",{"in":"specOut",in2:"SourceAlpha",operator:"in",result:"specOut"},d);M("feComposite",{"in":"SourceGraphic",in2:"specOut",operator:"arithmetic",k1:0,k2:1,k3:1,k4:0},d);d=M("filter",{id:"blocklyTrashcanShadowFilter"},c);M("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:2,result:"blur"},d);M("feOffset",{"in":"blur",dx:1,dy:1,result:"offsetBlur"},d);d=M("feMerge",{},d);M("feMergeNode",{"in":"offsetBlur"},d);M("feMergeNode",{"in":"SourceGraphic"},
d);d=M("filter",{id:"blocklyShadowFilter"},c);M("feGaussianBlur",{stdDeviation:2},d);c=M("pattern",{id:"blocklyDisabledPattern",patternUnits:"userSpaceOnUse",width:10,height:10},c);M("rect",{width:10,height:10,fill:"#aaa"},c);M("path",{d:"M 0 0 L 10 10 M 10 0 L 0 10",stroke:"#cc0"},c);D=new be(Hk,Ik);b.appendChild(D.H());D.Wf=Cc;L||(Dc?Ij(b,a):(D.fe=new Mi,c=D.fe,d=c.H(),c.Vd=!1,ec(d),Jk(function(){if(0==ne){var a=D.Hb();if(0>a.cb||a.cb+a.Ra>a.xa+a.Ab||a.Cb<(H?a.Ca:0)||a.Cb+a.Ic>(H?a.Q:a.Q+a.Ca))for(var b=
Jc(D,!1),c=0,d;d=b[c];c++){var e=J(d),m=eg(d),t=a.Ab+25-m.height-e.y;0<t&&d.moveBy(0,t);t=a.Ab+a.xa-25-e.y;0>t&&d.moveBy(0,t);t=25+a.Ca-e.x-(H?0:m.width);0<t&&d.moveBy(t,0);t=a.Ca+a.Q-25-e.x+(H?m.width:0);0>t&&d.moveBy(t,0);d.hc&&!L&&50<(H?e.x-a.Q:-e.x)&&d.j(!1,!0)}}})));b.appendChild(Wh());a.appendChild(b);I=b;ti();Wg=C("div","blocklyWidgetDiv");Wg.style.direction=H?"rtl":"ltr";document.body.appendChild(Wg)}
function Ek(){P(I,"mousedown",null,Kk);P(I,"contextmenu",null,Lk);P(Wg,"contextmenu",null,Lk);Gc||(P(window,"resize",document,ti),P(document,"keydown",null,Mk),document.addEventListener("mouseup",Nk,!1),Ib&&P(window,"orientationchange",document,function(){pe(window,"resize")}),Gc=!0);if(zc)if(Dc)Jj();else{D.fe.Y(D);D.fe.show(zc.childNodes);D.scrollX=D.fe.L;H&&(D.scrollX*=-1);var a="translate("+D.scrollX+", 0)";D.aa.setAttribute("transform",a);D.Zc.setAttribute("transform",a)}Ec&&(D.cc=new bd(D),D.cc.resize());
ee();if(Fc){Ok([Q+"click.mp3",Q+"click.wav",Q+"click.ogg"],"click");Ok([Q+"delete.mp3",Q+"delete.ogg",Q+"delete.wav"],"delete");var b=[],a=function(){for(;b.length;)O(b.pop());for(var a in Pk){var d=Pk[a];d.volume=.01;d.play();d.pause();if(Ib||Hb)break}};b.push(P(document,"mousemove",null,a));b.push(P(document,"touchstart",null,a))}};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Wg=null,Yg=null,Qk=null;function Ug(){var a=Vg;Zg();Yg=a;Qk=null;Wg.style.display="block"}function Zg(){Yg&&(Wg.style.display="none",Qk&&Qk(),Qk=Yg=null,dc(Wg))}function Xg(a,b,c,d){b<d.y&&(b=d.y);H?a>c.width+d.x&&(a=c.width+d.x):a<d.x&&(a=d.x);Wg.style.left=a+"px";Wg.style.top=b+"px"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Q="https://blockly-demo.appspot.com/static/media/",Yd=64,Zd=92,$d="sprites.png",sh=[,2,1,4,3],Pk=Object.create(null),R=null,L=!1,ph=null,qh=null,Ji=5,W=20,vh=250,Ki=30,D=null,Rk=null,Sk=null;function di(){return{width:I.Pg,height:I.Og}}function ti(){var a=I,b=a.parentNode,c=b.offsetWidth,b=b.offsetHeight;a.Pg!=c&&(a.setAttribute("width",c+"px"),a.Pg=c);a.Og!=b&&(a.setAttribute("height",b+"px"),a.Og=b);D.cc&&D.cc.resize()}
function Kk(a){ti();qi();md();var b=a.target&&a.target.nodeName&&"svg"==a.target.nodeName.toLowerCase();!L&&R&&b&&oe();a.target==I&&id(a)?Tk(a):(L||b)&&D.cc&&(D.zf=!0,D.ug=a.clientX,D.vg=a.clientY,D.yk=D.Hb(),D.Ak=D.scrollX,D.Bk=D.scrollY,"mouseup"in Uj&&(Sk=P(document,"mouseup",null,Nk)),Hc=P(document,"mousemove",null,Uk))}function Nk(){kh(!1);D.zf=!1;Sk&&(O(Sk),Sk=null);Hc&&(O(Hc),Hc=null)}
function Uk(a){if(D.zf){ld();var b=D.yk,c=D.Ak+(a.clientX-D.ug),d=D.Bk+(a.clientY-D.vg),c=Math.min(c,-b.Cb),d=Math.min(d,-b.cb),c=Math.max(c,b.Q-b.Cb-b.Ic),d=Math.max(d,b.xa-b.cb-b.Ra);D.cc.set(-c-b.Cb,-d-b.cb);a.stopPropagation()}}
function Mk(a){if(!jh(a))if(27==a.keyCode)md();else if(8==a.keyCode||46==a.keyCode)try{R&&R.hc&&!L&&(md(),R.j(!0,!0))}finally{a.preventDefault()}else if(a.altKey||a.ctrlKey||a.metaKey)if(R&&R.hc&&!L&&R.Mb&&!L&&R.s==D&&(md(),67==a.keyCode?Vk():88==a.keyCode&&(Vk(),R.j(!0,!0))),86==a.keyCode&&Rk){a=D;var b=Rk;if(!(b.getElementsByTagName("block").length>=qe(a))){var c=Pc(a,b),d=parseInt(b.getAttribute("x"),10),b=parseInt(b.getAttribute("y"),10);if(!isNaN(d)&&!isNaN(b)){H&&(d=-d);do for(var e=!1,g=je(a),
h=0,k;k=g[h];h++)k=J(k),1>=Math.abs(d-k.x)&&1>=Math.abs(b-k.y)&&(d=H?d-W:d+W,b+=2*W,e=!0);while(e);c.moveBy(d,b)}c.select()}}}function qi(){ni&&(O(ni),ni=null);oi&&(O(oi),oi=null);var a=R;if(2==ne&&a){var b=J(a);zh(a,b.x-a.ii,b.y-a.ji);delete a.ce;Ii(a,!1);a.F();Wd(a.Ja,vh,a);pe(window,"resize")}a&&de(a.s);ne=0;aj()}function Vk(){var a=R,b=Kc(a);ad(b);a=J(a);b.setAttribute("x",H?-a.x:a.x);b.setAttribute("y",a.y);Rk=b}
function Tk(a){if(!L){var b=[];if(xc){for(var c=!1,d=!1,e=Jc(D,!1),g=0;g<e.length;g++)for(var h=e[g];h;)h.isCollapsed()?c=!0:d=!0,h=Lc(h);d={enabled:d};d.text=Wk;d.bb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Gd.bind(c,!0),a),c=Lc(c),a+=10};b.push(d);c={enabled:c};c.text=Xk;c.bb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Gd.bind(c,!1),a),c=Lc(c),a+=10};b.push(c)}Vg.show(a,b)}}function Lk(a){jh(a)||a.preventDefault()}
function md(a){$h();Zg();!a&&Ej&&Ej.Vd&&Fj.Ac(null)}function ld(){if(window.getSelection){var a=window.getSelection();a&&a.removeAllRanges&&(a.removeAllRanges(),window.setTimeout(function(){try{window.getSelection().removeAllRanges()}catch(a){}},0))}}function jh(a){return"textarea"==a.target.type||"text"==a.target.type}
function Ok(a,b){if(window.Audio&&a.length){for(var c,d=new window.Audio,e=0;e<a.length;e++){var g=a[e],h=g.match(/\.(\w+)$/);if(h&&d.canPlayType("audio/"+h[1])){c=new window.Audio(g);break}}c&&c.play&&(Pk[b]=c)}}function pi(a,b){var c=Pk[a];c&&(c=Nb&&9===Nb||Ib||Gb?c:c.cloneNode(),c.volume=void 0===b?1:b,c.play())}function kh(a){if(!L){var b="";a&&(b="url("+Q+"handclosed.cur) 7 3, auto");R&&(ig(R).style.cursor=b);I.style.cursor=b}}
function Hk(){var a=di();a.width-=Gj;var b=a.width-N,c=a.height-N;try{var d=D.aa.getBBox()}catch(e){return null}if(D.cc)var g=Math.min(d.x-b/2,d.x+d.width-b),b=Math.max(d.x+d.width+b/2,d.x+b),h=Math.min(d.y-c/2,d.y+d.height-c),c=Math.max(d.y+d.height+c/2,d.y+c);else g=d.x,b=g+d.width,h=d.y,c=h+d.height;return{xa:a.height,Q:a.width,Ra:c-h,Ic:b-g,Ab:-D.scrollY,Ca:-D.scrollX,cb:h,Cb:g,Za:0,Ya:H?0:Gj}}
function Ik(a){if(!D.cc)throw"Attempt to set main workspace scroll without scrollbars.";var b=Hk();r(a.x)&&(D.scrollX=-b.Ic*a.x-b.Cb);r(a.y)&&(D.scrollY=-b.Ra*a.y-b.cb);a="translate("+(D.scrollX+b.Ya)+","+(D.scrollY+b.Za)+")";D.aa.setAttribute("transform",a);D.Zc.setAttribute("transform",a)}function vi(a){a()}function Jk(a){return P(D.aa,"blocklyWorkspaceChange",null,a)}window.Blockly||(window.Blockly={});window.Blockly.getMainWorkspace=function(){return D};window.Blockly.addChangeListener=Jk;
window.Blockly.removeChangeListener=function(a){O(a)};var yi="Add Comment",yk="Please authorize this app to enable your work to be saved and to allow it to be shared by you.",vk="Chat with your collaborator by typing in this box!",Wk="Collapse Blocks",Ci="Collapse Block",Fi="Delete Block",Gi="Delete %1 Blocks",Ei="Disable Block",wi="Duplicate",Di="Enable Block",Xk="Expand Blocks",Bi="Expand Block",zi="External Inputs",Hi="Help",Ai="Inline Inputs",zk="Me",xi="Remove Comment";function Yk(a,b){var c;c=a.className;for(var d=c=p(c)&&c.match(/\S+/g)||[],e=Za(arguments,1),g=0;g<e.length;g++)Va(d,e[g])||d.push(e[g]);a.className=c.join(" ")};var Zk={ace:"\u0628\u0647\u0633\u0627 \u0627\u0686\u064a\u0647",af:"Afrikaans",ar:"\u0627\u0644\u0639\u0631\u0628\u064a\u0629",az:"Az\u0259rbaycanca","be-tarask":"Tara\u0161kievica",br:"Brezhoneg",ca:"Catal\u00e0",cdo:"\u95a9\u6771\u8a9e",cs:"\u010cesky",da:"Dansk",de:"Deutsch",el:"\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac",en:"English",es:"Espa\u00f1ol",eu:"Euskara",fa:"\u0641\u0627\u0631\u0633\u06cc",fi:"Suomi",fo:"F\u00f8royskt",fr:"Fran\u00e7ais",frr:"Frasch",gl:"Galego",hak:"\u5ba2\u5bb6\u8a71",
he:"\u05e2\u05d1\u05e8\u05d9\u05ea",hi:"\u0939\u093f\u0928\u094d\u0926\u0940",hrx:"Hunsrik",hu:"Magyar",ia:"Interlingua",id:"Bahasa Indonesia",is:"\u00cdslenska",it:"Italiano",ja:"\u65e5\u672c\u8a9e",ka:"\u10e5\u10d0\u10e0\u10d7\u10e3\u10da\u10d8",km:"\u1797\u17b6\u179f\u17b6\u1781\u17d2\u1798\u17c2\u179a",ko:"\ud55c\uad6d\uc5b4",ksh:"Ripoar\u0117sch",ky:"\u041a\u044b\u0440\u0433\u044b\u0437\u0447\u0430",la:"Latine",lb:"L\u00ebtzebuergesch",lt:"Lietuvi\u0173",lv:"Latvie\u0161u",mg:"Malagasy",ml:"\u0d2e\u0d32\u0d2f\u0d3e\u0d33\u0d02",
mk:"\u041c\u0430\u043a\u0435\u0434\u043e\u043d\u0441\u043a\u0438",mr:"\u092e\u0930\u093e\u0920\u0940",ms:"Bahasa Melayu",mzn:"\u0645\u0627\u0632\u0650\u0631\u0648\u0646\u06cc",nb:"Norsk Bokm\u00e5l",nl:"Nederlands, Vlaams",oc:"Lenga d'\u00f2c",pa:"\u092a\u0902\u091c\u093e\u092c\u0940",pl:"Polski",pms:"Piemont\u00e8is",ps:"\u067e\u069a\u062a\u0648",pt:"Portugu\u00eas","pt-br":"Portugu\u00eas Brasileiro",ro:"Rom\u00e2n\u0103",ru:"\u0420\u0443\u0441\u0441\u043a\u0438\u0439",sc:"Sardu",sco:"Scots",si:"\u0dc3\u0dd2\u0d82\u0dc4\u0dbd",
sk:"Sloven\u010dina",sr:"\u0421\u0440\u043f\u0441\u043a\u0438",sv:"Svenska",sw:"Kishwahili",th:"\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22",tl:"Tagalog",tlh:"tlhIngan Hol",tr:"T\u00fcrk\u00e7e",uk:"\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430",vi:"Ti\u1ebfng Vi\u1ec7t","zh-hans":"\u7c21\u9ad4\u4e2d\u6587","zh-hant":"\u6b63\u9ad4\u4e2d\u6587"},Fk="ace ar fa he mzn ps".split(" "),sc=window.BlocklyGamesLang,$k=window.BlocklyGamesLanguages,tc=!!window.location.pathname.match(/\.html$/);
function al(a,b){var c=window.location.search.match(new RegExp("[?&]"+a+"=([^&]+)"));return c?decodeURIComponent(c[1].replace(/\+/g,"%20")):b}var G,bl=Number(al("level","NaN"));G=isNaN(bl)?1:Sb(1,bl,10);
function cl(){document.title=document.getElementById("title").textContent;document.head.parentElement.setAttribute("dir",-1!=Fk.indexOf(sc)?"rtl":"ltr");document.head.parentElement.setAttribute("lang",sc);for(var a=[],b=0;b<$k.length;b++){var c=$k[b];a.push([Zk[c],c])}a.sort(function(a,b){return a[0]>b[0]?1:a[0]<b[0]?-1:0});for(var d=document.getElementById("languageMenu"),b=d.options.length=0;b<a.length;b++){var e=a[b],c=e[1],e=new Option(e[0],c);c==sc&&(e.selected=!0);d.options.add(e)}1>=d.options.length&&
(d.style.display="none");for(b=1;10>=b;b++)a=document.getElementById("level"+b),c=!!dl(b),a&&c&&Yk(a,"level_done");(b=document.querySelector('meta[name="viewport"]'))&&725>screen.availWidth&&b.setAttribute("content","width=725, initial-scale=.35, user-scalable=no");setTimeout(el,1)}function dl(a){var b=fl,c;try{c=window.localStorage[b+a]}catch(d){}return c}
function gl(a){var b;(b=document.getElementById(a))?(b=b.textContent,b=b.replace(/\\n/g,"\n")):b=null;return null===b?"[Unknown message: "+a+"]":b}function hl(a,b){"string"==typeof a&&(a=document.getElementById(a));a.addEventListener("click",b,!0);a.addEventListener("touchend",b,!0)}
function el(){if(!tc){window.GoogleAnalyticsObject="GoogleAnalyticsFunction";var a=function(){(a.q=a.q||[]).push(arguments)};window.GoogleAnalyticsFunction=a;a.l=1*new Date;var b=document.createElement("script");b.async=1;b.src="//www.google-analytics.com/analytics.js";document.head.appendChild(b);a("create","UA-50448074-1","auto");a("send","pageview")}};var Y={sb:null,Y:function(){cl();var a=document.getElementById("linkButton");"BlocklyStorage"in window?(BlocklyStorage.HTTPREQUEST_ERROR=gl("Games_httpRequestError"),BlocklyStorage.LINK_ALERT=gl("Games_linkAlert"),BlocklyStorage.HASH_ERROR=gl("Games_hashError"),BlocklyStorage.XML_ERROR=gl("Games_xmlError"),BlocklyStorage.alert=pc.Dk,a&&hl(a,BlocklyStorage.link)):a&&(a.style.display="none");document.getElementById("languageMenu").addEventListener("change",Y.Wi,!0)},rl:function(a){document.body.innerHTML=
a;a=document.getElementById("blockly");a.style.height=window.innerHeight+"px";Ck(a);a=al("xml","");Y.lg("<xml>"+a+"</xml>")},Uj:function(a,b){if("BlocklyStorage"in window&&1<window.location.hash.length)BlocklyStorage.retrieveXml(window.location.hash.substring(1));else{var c=null;try{c=window.sessionStorage.Jh}catch(d){}c&&delete window.sessionStorage.Jh;var e=dl(G),g=b&&dl(G-1);(c=c||e||g||a)&&Y.lg(c)}},lg:function(a){Y.sb?Y.sb.setValue(a,-1):(a=Nc(a),Oc(D,a))},rk:function(){if(void 0!=typeof uc&&
window.localStorage){var a=fl+G;if(Y.sb)var b=Y.sb.getValue();else b=Ic(D),b=Mc(b);window.localStorage[a]=b}},ue:function(){window.location=(tc?"index.html":"./")+"?lang="+sc},Wi:function(){if(window.sessionStorage){if(Y.sb)var a=Y.sb.getValue();else a=Ic(D),a=Mc(a);window.sessionStorage.Jh=a}var a=document.getElementById("languageMenu"),a=encodeURIComponent(a.options[a.selectedIndex].value),b=window.location.search,b=1>=b.length?"?lang="+a:b.match(/[?&]lang=[^&]*/)?b.replace(/([?&]lang=)[^&]*/,"$1"+
a):b.replace(/\?/,"?lang="+a+"&");window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+b},Bh:function(a){if(a){var b=a.match(/^block_id_(\d+)$/);b&&(a=b[1])}me(a)},Ek:function(a){return a.replace(/(,\s*)?'block_id_\d+'\)/g,")").trimRight()},tb:function(a){if("click"==a.type&&"touchend"==Y.tb.eg&&Y.tb.dg+2E3>Date.now()||Y.tb.eg==a.type&&Y.tb.dg+400>Date.now())return a.preventDefault(),a.stopPropagation(),!0;Y.tb.eg=a.type;Y.tb.dg=Date.now();return!1}};
Y.tb.eg=null;Y.tb.dg=0;Y.Lj=function(){var a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","js-read-only/JS-Interpreter/compiled.js");document.head.appendChild(a)};
Y.Mj=function(){var a=document.createElement("link");a.setAttribute("rel","stylesheet");a.setAttribute("type","text/css");a.setAttribute("href","common/prettify.css");document.head.appendChild(a);a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","common/prettify.js");document.head.appendChild(a)};window.BlocklyInterface=Y;Y.setCode=Y.lg;var Z={pc:!1,lh:null,ae:null,Jd:function(a,b,c,d,e,g){function h(){Z.pc&&(k.style.visibility="visible",k.style.zIndex=10,l.style.visibility="hidden")}Z.pc&&Z.Kb(!1);md(!0);Z.pc=!0;Z.lh=b;Z.ae=g;var k=document.getElementById("dialog");g=document.getElementById("dialogShadow");var l=document.getElementById("dialogBorder"),q;for(q in e)k.style[q]=e[q];d&&(g.style.visibility="visible",g.style.opacity=.3,g.style.zIndex=9,d=document.createElement("div"),d.id="dialogHeader",k.appendChild(d),Z.uf=P(d,"mousedown",
null,Z.kj));k.appendChild(a);a.className=a.className.replace("dialogHiddenContent","");c&&b?(Z.ac(b,!1,.2),Z.ac(k,!0,.8),setTimeout(h,175)):h()},mh:0,nh:0,kj:function(a){Z.xf();if(!id(a)){var b=document.getElementById("dialog");Z.mh=b.offsetLeft-a.clientX;Z.nh=b.offsetTop-a.clientY;Z.wf=P(document,"mouseup",null,Z.xf);Z.vf=P(document,"mousemove",null,Z.lj);a.stopPropagation()}},lj:function(a){var b=document.getElementById("dialog"),c=Z.mh+a.clientX;a=Z.nh+a.clientY;a=Math.max(a,0);a=Math.min(a,window.innerHeight-
b.offsetHeight);c=Math.max(c,0);c=Math.min(c,window.innerWidth-b.offsetWidth);b.style.left=c+"px";b.style.top=a+"px"},xf:function(){Z.wf&&(O(Z.wf),Z.wf=null);Z.vf&&(O(Z.vf),Z.vf=null)},Kb:function(a){function b(){d.style.zIndex=-1;d.style.visibility="hidden";document.getElementById("dialogBorder").style.visibility="hidden"}if(Z.pc){Z.xf();Z.uf&&(O(Z.uf),Z.uf=null);Z.pc=!1;Z.ae&&Z.ae();Z.ae=null;var c=!1===a?null:Z.lh;a=document.getElementById("dialog");var d=document.getElementById("dialogShadow");
d.style.opacity=0;c?(Z.ac(a,!1,.8),Z.ac(c,!0,.2),setTimeout(b,175)):b();a.style.visibility="hidden";a.style.zIndex=-1;for((c=document.getElementById("dialogHeader"))&&c.parentNode.removeChild(c);a.firstChild;)c=a.firstChild,c.className+=" dialogHiddenContent",document.body.appendChild(c)}},ac:function(a,b,c){function d(){e.style.width=g.width+"px";e.style.height=g.height+"px";e.style.left=g.x+"px";e.style.top=g.y+"px";e.style.opacity=c}if(a){var e=document.getElementById("dialogBorder"),g=Z.rj(a);
b?(e.className="dialogAnimate",setTimeout(d,1)):(e.className="",d());e.style.visibility="visible"}},rj:function(a){if(a.getBBox){var b=a.getBBox(),c=b.height,b=b.width;a=kd(a);a=Nj(a.x,a.y,!1);var d=a.x,e=a.y}else{c=a.offsetHeight;b=a.offsetWidth;e=d=0;do d+=a.offsetLeft,e+=a.offsetTop,a=a.offsetParent;while(a)}return{height:c,width:b,x:d,y:e}},Dk:function(a){var b=document.getElementById("containerStorage");b.textContent="";a=a.split("\n");for(var c=0;c<a.length;c++){var d=document.createElement("p");
d.appendChild(document.createTextNode(a[c]));b.appendChild(d)}b=document.getElementById("dialogStorage");a=document.getElementById("linkButton");Z.Jd(b,a,!0,!0,{width:"50%",left:"25%",top:"5em"},Z.wg);Z.tg()},Ji:function(){if(!dl(G))if(Z.pc||0!=ne)setTimeout(Z.Ji,15E3);else{var a=document.getElementById("dialogAbort"),b=document.getElementById("abortCancel");b.addEventListener("click",Z.Kb,!0);b.addEventListener("touchend",Z.Kb,!0);b=document.getElementById("abortOk");b.addEventListener("click",Y.ue,
!0);b.addEventListener("touchend",Y.ue,!0);Z.Jd(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},function(){document.body.removeEventListener("keydown",Z.Ig,!0)});document.body.addEventListener("keydown",Z.Ig,!0)}},Yi:function(){var a=document.getElementById("dialogDone");if(D){var b=document.getElementById("dialogLinesText");b.textContent="";var c=uc.Rk.Jl(),c=Y.Ek(c),d=c.split("\n").length,e=document.getElementById("containerCode");e.textContent=c;"function"==typeof prettyPrintOne&&(c=e.innerHTML,
c=prettyPrintOne(c,"js"),e.innerHTML=c);c=1==d?gl("Games_linesOfCode1"):gl("Games_linesOfCode2").replace("%1",d);b.appendChild(document.createTextNode(c))}c=10>G?gl("Games_nextLevel").replace("%1",G+1):gl("Games_finalLevel");b=document.getElementById("doneCancel");b.addEventListener("click",Z.Kb,!0);b.addEventListener("touchend",Z.Kb,!0);b=document.getElementById("doneOk");b.addEventListener("click",Y.Yf,!0);b.addEventListener("touchend",Y.Yf,!0);Z.Jd(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},
function(){document.body.removeEventListener("keydown",Z.Wg,!0)});document.body.addEventListener("keydown",Z.Wg,!0);document.getElementById("dialogDoneText").textContent=c},kh:function(a){!Z.pc||13!=a.keyCode&&27!=a.keyCode&&32!=a.keyCode||(Z.Kb(!0),a.stopPropagation(),a.preventDefault())},tg:function(){document.body.addEventListener("keydown",Z.kh,!0)},wg:function(){document.body.removeEventListener("keydown",Z.kh,!0)},Wg:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)Z.Kb(!0),a.stopPropagation(),
a.preventDefault(),27!=a.keyCode&&Y.Yf()},Ig:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)Z.Kb(!0),a.stopPropagation(),a.preventDefault(),27!=a.keyCode&&Y.ue()}};window.BlocklyDialogs=Z;Z.hideDialog=Z.Kb;yj("goog.net.XhrIo");function il(a,b,c,d,e){this.name=a;this.Ug=b;this.ki=c;this.wk=d||0;this.Qb=e;this.u=new A;this.reset();console.log(this+" loaded.")}f=il.prototype;f.Ck=!1;f.fb=!1;f.t=0;f.Eb=0;f.facing=0;f.speed=0;f.rb=0;f.u=null;f.Tf=0;f.toString=function(){return"["+this.name+"]"};
f.reset=function(){delete this.Ck;delete this.fb;delete this.speed;delete this.rb;delete this.Tf;this.t=this.wk;this.u.x=this.ki.x;this.u.y=this.ki.y;this.facing=this.Eb=Tb(180*Math.atan2(50-this.u.y,50-this.u.x)/Math.PI);var a=this.Ug;if(s(a))a=a();else if(!p(a))throw"Player "+this.name+" has invalid code: "+a;this.Eh="Interpreter"in window?new Interpreter(a,this.Qb.Nj):null};function jl(a,b){a.t+=b;100<=a.t&&kl(a)}
function kl(a){a.speed=0;a.fb=!0;a.t=100;a.Qb.dd.unshift(a);a.Qb.Xa.push({type:"DIE",player:a});console.log(a+" dies.")}
function ll(a,b){var c=$.eb,d;d=void 0===b||null===b?5:b;if(!r(a)||isNaN(a)||!r(d)||isNaN(d))throw TypeError;a=Tb(a);d=Sb(d,0,20);c.Qb.Xa.push({type:"SCAN",player:c,degree:a,resolution:d});var e=Tb(a-d/2);d=Tb(a+d/2);e>d&&(d+=360);for(var g=c.u.x,h=c.u.y,k=Infinity,l=0,q;q=c.Qb.Da[l];l++)if(q!=c&&!q.fb){var m=q.u.x,t=q.u.y;q=Math.sqrt((t-h)*(t-h)+(m-g)*(m-g));q>=k||(m=Math.atan2(t-h,m-g),m=Tb(180*m/Math.PI),m<e&&(m+=360),e<=m&&m<=d&&(k=q))}return k}
f.S=function(a,b){var c;c=void 0===b||null===b?50:b;if(!r(a)||isNaN(a)||!r(c)||isNaN(c))throw TypeError;this.Eb!=Tb(a)&&(50>=this.speed?this.facing=this.Eb=Tb(a):c=0);0==this.speed&&0<c&&(this.speed=.1);this.rb=Sb(c,0,100)};f.stop=function(){this.rb=0};
function ml(a,b){var c=$.eb;if(!r(a)||isNaN(a)||!r(b)||isNaN(b))throw TypeError;var d=Date.now();if(c.Tf+1E3*c.Qb.zi>d)return!1;c.Tf=d;d=c.u.clone();a=Tb(a);c.facing=a;b=Sb(b,0,70);d={gk:c,Md:d,Eb:a,Me:b,jd:new A(d.x+b*Math.cos(a*Math.PI/180),d.y+b*Math.sin(a*Math.PI/180)),Dd:0};c.Qb.Fc.push(d);c.Qb.Xa.push({type:"BANG",player:c,degree:d.Eb});return!0};var $={Da:[],dd:[],Xa:[],Fc:[],ui:50,Fi:100,zi:.5,eb:null,yi:1,Hg:3,Eg:5,ti:5,bf:3,Uh:0,ee:0,yg:0,Hi:3E5,yf:null};$.Ei=[new A(10,90),new A(90,10),new A(10,10),new A(90,90),new A(50,99),new A(50,1),new A(1,50),new A(99,50),new A(50,49)];$.reset=function(){clearTimeout($.Uh);$.Xa.length=0;$.Fc.length=0;$.dd.length=0;for(var a=$.yg=0,b;b=$.Da[a];a++)b.reset()};$.Li=function(a,b,c,d){c||(c=$.Ei[$.Da.length]);a=new il(a,b,c,d,$);$.Da.push(a)};
$.start=function(a){$.yf=a;$.ee=Date.now()+$.Hi;console.log("Starting battle with "+$.Da.length+" players.");$.update()};$.update=function(){$.Ik();$.Jk();$.Kk();$.Da.length<=$.dd.length+1&&($.ee=Math.min($.ee,Date.now()+1E3));Date.now()>$.ee?$.stop():$.Uh=setTimeout($.update,1E3/$.ui)};$.stop=function(){for(var a=[],b=0,c;c=$.Da[b];b++)c.fb||a.push(c);b=a.length;for(a.sort(function(a,b){return a.t-b.t});a.length;)$.dd.unshift(a.pop());$.yf&&$.yf(b)};
$.Jk=function(){for(var a=$.Fc.length-1;0<=a;a--){var b=$.Fc[a];b.Dd+=$.Hg;var c=0;if(b.Me-b.Dd<$.Hg/2){$.Fc.splice(a,1);for(var d=0,e;e=$.Da[d];d++)if(!e.fb){var g=10*(1-Ub(e.u,b.jd)/4);0<g&&(jl(e,g),c=Math.max(c,g))}$.Xa.push({type:"BOOM",damage:c,x:b.jd.x,y:b.jd.y})}}};
$.Kk=function(){for(var a=0,b;b=$.Da[a];a++)if(!b.fb&&(b.speed<b.rb?b.speed=Math.min(b.speed+$.Eg,b.rb):b.speed>b.rb&&(b.speed=Math.max(b.speed-$.Eg,b.rb)),0<b.speed)){var c=$.Tg(b),d=c[1],e=b.Eb*Math.PI/180,g=b.speed/100*$.yi,h=Math.cos(e)*g,g=Math.sin(e)*g;b.u.x+=h;b.u.y+=g;0>b.u.x||100<b.u.x||0>b.u.y||100<b.u.y?(b.u.x=Sb(b.u.x,0,100),b.u.y=Sb(b.u.y,0,100),d=b.speed/100*$.bf,jl(b,d),b.speed=0,b.rb=0,$.Xa.push({type:"CRASH",player:b,damage:d})):(c=$.Tg(b),e=c[0],c=c[1],c<$.ti&&d>c&&(b.u.x-=h,b.u.y-=
g,d=Math.max(b.speed,e.speed)/100*$.bf,jl(b,d),b.speed=0,b.rb=0,jl(e,d),e.speed=0,e.rb=0,$.Xa.push({type:"CRASH",player:b,damage:d}),$.Xa.push({type:"CRASH",player:e,damage:d})))}};$.Ik=function(){for(var a=0;a<$.Fi;a++){$.yg++;for(var b=0,c;c=$.Da[b];b++)if(!c.fb){$.eb=c;try{c.Eh.step()}catch(d){console.log(c+" throws an error: "+d),console.dir(c.Eh.Gl),kl(c)}$.eb=null}}};
$.Nj=function(a,b){var c;c=function(b,c){return a.createPrimitive(ll(b&&b.valueOf(),c&&c.valueOf()))};a.setProperty(b,"scan",a.createNativeFunction(c));c=function(b,c){return a.createPrimitive(ml(b&&b.valueOf(),c&&c.valueOf()))};a.setProperty(b,"cannon",a.createNativeFunction(c));c=function(a,b){$.eb.S(a&&a.valueOf(),b&&b.valueOf())};a.setProperty(b,"drive",a.createNativeFunction(c));a.setProperty(b,"swim",a.createNativeFunction(c));a.setProperty(b,"stop",a.createNativeFunction(function(){$.eb.stop()}));
a.setProperty(b,"damage",a.createNativeFunction(function(){return a.createPrimitive($.eb.t)}));a.setProperty(b,"health",a.createNativeFunction(function(){return a.createPrimitive(100-$.eb.t)}));a.setProperty(b,"speed",a.createNativeFunction(function(){return a.createPrimitive($.eb.speed)}));a.setProperty(b,"loc_x",a.createNativeFunction(function(){return a.createPrimitive($.eb.u.x)}));a.setProperty(b,"loc_y",a.createNativeFunction(function(){return a.createPrimitive($.eb.u.y)}));var d=a.getProperty(b,
"Math");d!=a.UNDEFINED&&(c=function(b){return a.createPrimitive(Math.sin((b&&b.valueOf())/180*Math.PI))},a.setProperty(d,"sin_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.cos((b&&b.valueOf())/180*Math.PI))},a.setProperty(d,"cos_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.tan((b&&b.valueOf())/180*Math.PI))},a.setProperty(d,"tan_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.asin(b&&b.valueOf())/Math.PI*180)},
a.setProperty(d,"asin_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.acos(b&&b.valueOf())/Math.PI*180)},a.setProperty(d,"acos_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.atan(b&&b.valueOf())/Math.PI*180)},a.setProperty(d,"atan_deg",a.createNativeFunction(c)))};$.Tg=function(a){for(var b=null,c=Infinity,d=0,e;e=$.Da[d];d++)if(!e.fb&&a!=e){var g=Math.min(c,Ub(a.u,e.u));g<c&&(c=g,b=e)}return[b,c]};var nl,ol,pl,ql={},rl=[],sl=new Image;sl.src="pond/sprites.png";var tl=["#ff8b00","#c90015","#166c0b","#11162a"],ul=0;function vl(){nl=document.getElementById("scratch").getContext("2d");var a=document.getElementById("display").getContext("2d");ol=a;pl=a.canvas.width;a.globalCompositeOperation="copy";Ok(["pond/whack.mp3","pond/whack.ogg"],"whack");Ok(["pond/boom.mp3","pond/boom.ogg"],"boom");Ok(["pond/splash.mp3","pond/splash.ogg"],"splash")}
function wl(){clearTimeout(ul);rl.length=0;var a=document.getElementById("playerStatRow");a.innerHTML="";for(var b=[],c=[],d=0,e;e=$.Da[d];d++){var g=tl[d%tl.length];e.pi=d;var h=document.createElement("td");h.style.borderColor=g;var k=document.createElement("div");k.className="playerStatHealth";k.style.background=g;e.Lk=k;c[d]=k;h.appendChild(k);k=document.createElement("div");k.className="playerStatName";e=document.createTextNode(e.name);k.appendChild(e);b[d]=k;h.appendChild(k);k=document.createElement("div");
e=document.createTextNode("\u00a0");k.appendChild(e);h.appendChild(k);a.appendChild(h)}for(d=0;k=b[d];d++)k.style.width=k.parentNode.offsetWidth-2+"px";for(d=0;k=c[d];d++)k.style.height=k.parentNode.offsetHeight-2+"px";xl()}var yl=0,zl=0;function Al(){xl();var a=Date.now(),b=Math.max(1,1E3/36-(a-yl-zl));ul=setTimeout(Al,b);yl=a;zl=b}function Bl(a){return a/100*(pl-35)+17.5}
function xl(){var a=nl;a.beginPath();a.rect(0,0,a.canvas.width,a.canvas.height);a.fillStyle="#527dbf";a.fill();for(var b=[],c=0,d;d=$.Da[c];c++)d.fb&&b.push(d);for(c=0;d=$.Da[c];c++)d.fb||b.push(d);for(c=0;d=b[c];c++){a.save();var e=Bl(d.u.x),g=Bl(100-d.u.y);a.translate(e,g);var h=d.pi%tl.length*35;d.fb&&(a.globalAlpha=.25);0<d.speed&&(a.save(),e=50<d.speed?0:25<d.speed?35:70,a.rotate(-d.Eb/180*Math.PI),a.drawImage(sl,455,e,35,35,-45.5,-17.5,35,35),a.restore());a.drawImage(sl,0,h,35,35,-17.5,-17.5,
35,35);e=d.facing/180*Math.PI;a.translate(12*Math.cos(e),12*-Math.sin(e)-2);e=(14-Math.round(d.facing/360*12))%12+1;d=d.facing%30;15<=d&&(d-=30);d/=1.5;a.rotate(-d/180*Math.PI);a.drawImage(sl,35*e,h,35,35,-15.5,-15.5,35,35);a.restore()}for(c=0;d=$.Fc[c];c++){a.save();var g=d.Dd/d.Me,h=(d.jd.y-d.Md.y)*-g,e=d.Me/2,k=.15*d.Me,e=k-Math.pow((d.Dd-e)/Math.sqrt(k)*k/e,2),g=Bl(d.Md.x+(d.jd.x-d.Md.x)*g),k=Bl(100-d.Md.y+h-e),h=Bl(100-d.Md.y+h);a.beginPath();a.arc(g,h,5*Math.max(0,1-e/10),0,2*Math.PI,!0);a.closePath();
a.fillStyle="rgba(128, 128, 128, "+Math.max(0,1-e/10)+")";a.fill();a.beginPath();a.arc(g,k,5,0,2*Math.PI,!0);a.closePath();a.fillStyle=tl[d.gk.pi%tl.length];a.fill()}for(c=0;c<$.Xa.length;c++)if(e=$.Xa[c],d=e.player,"CRASH"==e.type){if(h=ql[d.id],!h||h+1E3<pa())pi("whack",e.damage/$.bf),ql[d.id]=pa()}else"SCAN"==e.type?(g=Math.max(e.resolution/2,.5),h=-((e.degree+g)*Math.PI/180),k=-((e.degree-g)*Math.PI/180),a.beginPath(),e=Bl(d.u.x),g=Bl(100-d.u.y),a.moveTo(e,g),a.lineTo(e+200*Math.cos(h),g+200*
Math.sin(h)),a.arc(e,g,200,h,k),a.lineTo(e,g),d=a.createRadialGradient(e,g,17.5,e,g,200),d.addColorStop(0,"rgba(255, 255, 255, 0.3)"),d.addColorStop(1,"rgba(255, 255, 255, 0)"),a.fillStyle=d,a.fill()):"BANG"!=e.type&&("BOOM"==e.type?(e.damage&&pi("boom",e.damage/10),rl.push({x:e.x,y:e.y,Od:0})):"DIE"==e.type&&pi("splash"));$.Xa.length=0;for(c=rl.length-1;0<=c;c--)d=rl[c],e=Bl(d.x),g=Bl(100-d.y),a.beginPath(),a.arc(e,g,d.Od+1,0,2*Math.PI,!0),a.closePath(),a.lineWidth=5,a.strokeStyle="rgba(255, 255, 255, "+
(1-d.Od/10)+")",a.stroke(),d.Od+=2,10<d.Od&&rl.splice(c,1);ol.drawImage(a.canvas,0,0);for(c=0;d=b[c];c++)a=d.Lk,a.parentNode.title=Math.round(100-d.t)+"%",a.style.width=Math.max(0,a.parentNode.offsetWidth*(1-d.t/100)-2)+"px"};var Cl=null,Dl=!1;function El(){function a(){c.style.visibility="visible";document.getElementById("dialogBorder").style.visibility="hidden"}if(!Dl){var b=document.getElementById("docsButton"),c=document.getElementById("dialogDocs"),d=document.getElementById("frameDocs");d.src||(d.src="pond/docs.html?lang="+sc+"&app="+fl+"&level="+G);Dl=!0;Z.ac(b,!1,.2);Z.ac(c,!0,.8);setTimeout(a,175)}}
function Fl(){var a=document.getElementById("docsButton"),b=document.getElementById("dialogDocs");Dl=!1;Z.ac(b,!1,.8);Z.ac(a,!0,.2);setTimeout(function(){document.getElementById("dialogBorder").style.visibility="hidden"},175);b.style.visibility="hidden"}function Gl(a){if(!Y.tb(a)){a=document.getElementById("runButton");var b=document.getElementById("resetButton");b.style.minWidth||(b.style.minWidth=a.offsetWidth+"px");a.style.display="none";b.style.display="inline";Hl()}}
function Il(a){Y.tb(a)||(document.getElementById("runButton").style.display="inline",document.getElementById("resetButton").style.display="none",$.reset(),wl())}function Hl(){"Interpreter"in window?($.reset(),wl(),$.start(Cl),Al()):setTimeout(Hl,250)}function Jl(){var a=document.getElementById("help"),b=document.getElementById("helpButton");Z.Jd(a,b,!0,!0,{width:"50%",left:"25%",top:"5em"},Z.wg);Z.tg()};Y.Yf=function(){10>G?window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+"?lang="+sc+"&level="+(G+1):Y.ue()};
var Kl=[void 0,[{start:new A(50,30),t:0,name:"Pond_playerName",code:null},{start:new A(50,70),t:99,name:"Pond_targetName",code:"playerTarget"}],[{start:new A(20,20),t:0,name:"Pond_playerName",code:null},{start:new A(62.4264,62.4264),t:0,name:"Pond_targetName",code:"playerTarget"}],[{start:new A(90,50),t:0,name:"Pond_playerName",code:null},{start:new A(50,50),t:0,name:"Pond_pendulumName",code:"playerPendulum"}],[{start:new A(20,80),t:0,name:"Pond_playerName",code:null},{start:new A(80,20),t:99,name:"Pond_targetName",
code:"playerTarget"}],[{start:new A(5,50),t:99,name:"Pond_playerName",code:null},{start:new A(95,50),t:0,name:"Pond_targetName",code:"playerTarget"}],[{start:new A(10,90),t:50,name:"Pond_playerName",code:null},{start:new A(40,60),t:0,name:"Pond_scaredName",code:"playerScared"}],[{start:new A(50,50),t:0,name:"Pond_playerName",code:null},{start:new A(50,20),t:0,name:"Pond_rabbitName",code:"playerRabbit"}],[{start:new A(20,80),t:0,name:"Pond_playerName",code:null},{start:new A(50,50),t:0,name:"Pond_rookName",
code:"playerRook"}],[{start:new A(20,80),t:0,name:"Pond_playerName",code:null},{start:new A(80,20),t:0,name:"Pond_rookName",code:"playerRook"},{start:new A(20,20),t:0,name:"Pond_counterName",code:"playerCounter"}],[{start:new A(20,80),t:0,name:"Pond_playerName",code:null},{start:new A(80,20),t:0,name:"Pond_rookName",code:"playerRook"},{start:new A(20,20),t:0,name:"Pond_counterName",code:"playerCounter"},{start:new A(80,80),t:0,name:"Pond_sniperName",code:"playerSniper"}]][G],Cl=function(a){clearTimeout(ul);
0!=a&&1==a&&"function"==typeof $.dd[0].Ug&&(3==G&&2E5<$.yg?(a=document.getElementById("helpUseScan"),Z.Jd(a,null,!1,!0,{width:"30%",left:"35%",top:"12em"},Z.wg),Z.tg()):(Y.rk(),Z.Yi()))};var fl="pond-advanced";
window.addEventListener("load",function(){function a(){var a=e.offsetTop,b=document.getElementById("editor");b.style.top=Math.max(10,a-window.pageYOffset)+"px";b.style.left=d?"10px":"420px";b.style.width=window.innerWidth-440+"px"}document.body.innerHTML=rc();Y.Y();vl();hl("runButton",Gl);hl("resetButton",Il);hl("docsButton",El);hl("closeDocs",Fl);setTimeout(Y.Lj,1);setTimeout(Y.Mj,1);hl("helpButton",Jl);2>location.hash.length&&!dl(G)&&setTimeout(Jl,1E3);var b=document.getElementById("containerCode");b.parentNode.removeChild(b);
b=4==G?"swim(0, 50);":"cannon(0, 70);";Y.sb=window.ace.edit("editor");Y.sb.setTheme("ace/theme/chrome");var c=Y.sb.getSession();c.setMode("ace/mode/javascript");c.setTabSize(2);c.setUseSoftTabs(!0);Y.Uj(b+"\n",4!=G);var d=-1!=Fk.indexOf(sc),e=document.getElementById("visualization");window.addEventListener("scroll",a);window.addEventListener("resize",a);a();for(c=0;b=Kl[c];c++){var g=b.code?document.getElementById(b.code).textContent:function(){return Y.sb.getValue()},h=gl(b.name);$.Li(h,g,b.start,
b.t)}$.reset();wl()});
