// Automatically generated file.  Do not edit!
goog.provide('BlocklyGames.Msg');
goog.require('Blockly.Msg.hu');
