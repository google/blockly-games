// Automatically generated file.  Do not edit!
'use strict';var f,n=this;function aa(a){a=a.split(".");for(var b=n,c;c=a.shift();)if(null!=b[c])b=b[c];else return null;return b}function ba(){}function ca(a){a.Ob=function(){return a.qh?a.qh:a.qh=new a}}
function da(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;var c=Object.prototype.toString.call(a);if("[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==b&&"undefined"==typeof a.call)return"object";return b}function ea(a){return"array"==da(a)}function fa(a){var b=da(a);return"array"==b||"object"==b&&"number"==typeof a.length}function q(a){return"string"==typeof a}function s(a){return"number"==typeof a}function u(a){return"function"==da(a)}function ga(a){var b=typeof a;return"object"==b&&null!=a||"function"==b}function ha(a){return a[ia]||(a[ia]=++ka)}var ia="closure_uid_"+(1E9*Math.random()>>>0),ka=0;
function la(a,b,c){return a.call.apply(a.bind,arguments)}function ma(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var c=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(c,d);return a.apply(b,c)}}return function(){return a.apply(b,arguments)}}function na(a,b,c){na=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?la:ma;return na.apply(null,arguments)}
function oa(a,b){var c=Array.prototype.slice.call(arguments,1);return function(){var b=c.slice();b.push.apply(b,arguments);return a.apply(this,b)}}var pa=Date.now||function(){return+new Date};function v(a,b){function c(){}c.prototype=b.prototype;a.m=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.hk=function(a,c,g){return b.prototype[c].apply(a,Array.prototype.slice.call(arguments,2))}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var qa={},w,ra,x,sa,ta,ua,va,wa,xa,ya,za,Aa,Ba,Ca,Da;/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ea(a){var b;w&&(b=a.qb().O);var c=y("xml");a=Fa(a,!0);for(var d=0,e;e=a[d];d++){var g=Ga(e);e=z(e);g.setAttribute("x",w?b-e.x:e.x);g.setAttribute("y",e.y);c.appendChild(g)}return c}
function Ga(a){var b=y("block");b.setAttribute("type",a.type);b.setAttribute("id",a.id);if(a.Nc){var c=a.Nc();c&&b.appendChild(c)}for(var d=0;c=a.R[d];d++)for(var e=0,g;g=c.ua[e];e++)if(g.name&&g.xc){var h=y("field",null,g.Gc());h.setAttribute("name",g.name);b.appendChild(h)}a.za&&(c=y("comment",null,a.za.rb()),c.setAttribute("pinned",a.za.v()),d=a.za.dc(),c.setAttribute("h",d.height),c.setAttribute("w",d.width),b.appendChild(c));d=!1;for(e=0;c=a.R[e];e++){var k;g=!0;5!=c.type&&(h=B(c.p),1==c.type?
(k=y("value"),d=!0):3==c.type&&(k=y("statement")),h&&(k.appendChild(Ga(h)),g=!1),k.setAttribute("name",c.name),g||b.appendChild(k))}d&&b.setAttribute("inline",a.rd);a.isCollapsed()&&b.setAttribute("collapsed",!0);a.disabled&&b.setAttribute("disabled",!0);a.ac&&!C||b.setAttribute("deletable",!1);a.Fb&&!C||b.setAttribute("movable",!1);a.Cc&&!C||b.setAttribute("editable",!1);if(a=Ha(a))k=y("next",null,Ga(a)),b.appendChild(k);return b}function Ia(a){return(new XMLSerializer).serializeToString(a)}
function Ja(a){a=(new DOMParser).parseFromString(a,"text/xml");if(!a||!a.firstChild||"xml"!=a.firstChild.nodeName.toLowerCase()||a.firstChild!==a.lastChild)throw"Blockly.Xml.textToDom did not obtain a valid XML tree.";return a.firstChild}function Ka(a,b){if(w)var c=a.qb().O;for(var d=0,e;e=b.childNodes[d];d++)if("block"==e.nodeName.toLowerCase()){var g=La(a,e),h=parseInt(e.getAttribute("x"),10);e=parseInt(e.getAttribute("y"),10);isNaN(h)||isNaN(e)||g.moveBy(w?c-h:h,e)}}
function La(a,b,c){var d=null,e=b.getAttribute("type");if(!e)throw"Block type unspecified: \n"+b.outerHTML;var g=b.getAttribute("id");if(c&&g){d=Ma(g,a);if(!d)throw"Couldn't get Block with id: "+g;g=d.getParent();d.s&&d.k(!0,!1,!0);d.fill(a,e);d.xa=g}else d=Na(a,e);d.j||Oa(d);(g=b.getAttribute("inline"))&&Pa(d,"true"==g);(g=b.getAttribute("disabled"))&&Qa(d,"true"==g);(g=b.getAttribute("deletable"))&&Ra(d,"true"==g);if(g=b.getAttribute("movable"))d.Fb="true"==g;(g=b.getAttribute("editable"))&&Sa(d,
"true"==g);for(var h=null,g=0,k;k=b.childNodes[g];g++)if(3!=k.nodeType||!k.data.match(/^\s*$/)){for(var h=null,l=0,m;m=k.childNodes[l];l++)3==m.nodeType&&m.data.match(/^\s*$/)||(h=m);l=k.getAttribute("name");switch(k.nodeName.toLowerCase()){case "mutation":d.dd&&d.dd(k);break;case "comment":Ta(d,k.textContent);var p=k.getAttribute("pinned");p&&setTimeout(function(){d.za.H("true"==p)},1);h=parseInt(k.getAttribute("w"),10);k=parseInt(k.getAttribute("h"),10);isNaN(h)||isNaN(k)||d.za.pc(h,k);break;case "title":case "field":Ua(d,
l).Sa(k.textContent);break;case "value":case "statement":k=Va(d,l);if(!k)throw"Input "+l+" does not exist in block "+e;if(h&&"block"==h.nodeName.toLowerCase())if(h=La(a,h,c),h.J)Wa(k.p,h.J);else if(h.C)Wa(k.p,h.C);else throw"Child block does not have output or previous statement.";break;case "next":if(h&&"block"==h.nodeName.toLowerCase()){if(!d.I)throw"Next statement does not exist.";if(d.I.o)throw"Next statement is already connected.";h=La(a,h,c);if(!h.C)throw"Next block does not have previous statement.";
Wa(d.I,h.C)}}}(a=b.getAttribute("collapsed"))&&d.Ad("true"==a);(a=Ha(d))?a.w():d.w();return d}function Xa(a){for(var b=0,c;c=a.childNodes[b];b++)if("next"==c.nodeName.toLowerCase()){a.removeChild(c);break}}window.Blockly||(window.Blockly={});window.Blockly.Xml||(window.Blockly.Xml={});window.Blockly.Xml.domToText=Ia;window.Blockly.Xml.domToWorkspace=Ka;window.Blockly.Xml.textToDom=Ja;window.Blockly.Xml.workspaceToDom=Ea;function Ya(a,b){for(var c=a.split("%s"),d="",e=Array.prototype.slice.call(arguments,1);e.length&&1<c.length;)d+=c.shift()+e.shift();return d+c.join("%s")}function Za(a){return a.replace(/[\t\r\n ]+/g," ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g,"")}var ab=String.prototype.trim?function(a){return a.trim()}:function(a){return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g,"")};function bb(a,b){var c=String(a).toLowerCase(),d=String(b).toLowerCase();return c<d?-1:c==d?0:1}
function cb(a){if(!db.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(eb,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(fb,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(gb,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(hb,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(ib,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(jb,"&#0;"));return a}var eb=/&/g,fb=/</g,gb=/>/g,hb=/"/g,ib=/'/g,jb=/\x00/g,db=/[\x00&<>"']/;
function kb(a){var b={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"'},c;c=n.document.createElement("div");return a.replace(lb,function(a,e){var g=b[a];if(g)return g;if("#"==e.charAt(0)){var h=Number("0"+e.substr(1));isNaN(h)||(g=String.fromCharCode(h))}g||(c.innerHTML=a+" ",g=c.firstChild.nodeValue.slice(0,-1));return b[a]=g})}
function mb(a){return a.replace(/&([^;]+);/g,function(a,c){switch(c){case "amp":return"&";case "lt":return"<";case "gt":return">";case "quot":return'"';default:if("#"==c.charAt(0)){var d=Number("0"+c.substr(1));if(!isNaN(d))return String.fromCharCode(d)}return a}})}var lb=/&([^;\s<&]+);?/g;function D(a,b){return-1!=a.indexOf(b)}function nb(a,b){return a<b?-1:a>b?1:0};var ob;a:{var pb=n.navigator;if(pb){var qb=pb.userAgent;if(qb){ob=qb;break a}}ob=""};function rb(a,b){for(var c in a)b.call(void 0,a[c],c,a)}var sb="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function tb(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var g=0;g<sb.length;g++)c=sb[g],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}}
function ub(a){var b=arguments.length;if(1==b&&ea(arguments[0]))return ub.apply(null,arguments[0]);for(var c={},d=0;d<b;d++)c[arguments[d]]=!0;return c};var vb;function wb(a){if(Error.captureStackTrace)Error.captureStackTrace(this,wb);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}v(wb,Error);wb.prototype.name="CustomError";function xb(a,b){b.unshift(a);wb.call(this,Ya.apply(null,b));b.shift()}v(xb,wb);xb.prototype.name="AssertionError";function yb(a,b){throw new xb("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var E=Array.prototype,zb=E.indexOf?function(a,b,c){return E.indexOf.call(a,b,c)}:function(a,b,c){c=null==c?0:0>c?Math.max(0,a.length+c):c;if(q(a))return q(b)&&1==b.length?a.indexOf(b,c):-1;for(;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},Ab=E.forEach?function(a,b,c){E.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=q(a)?a.split(""):a,g=0;g<d;g++)g in e&&b.call(c,e[g],g,a)},Bb=E.filter?function(a,b,c){return E.filter.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=[],g=0,h=q(a)?
a.split(""):a,k=0;k<d;k++)if(k in h){var l=h[k];b.call(c,l,k,a)&&(e[g++]=l)}return e},Cb=E.map?function(a,b,c){return E.map.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=Array(d),g=q(a)?a.split(""):a,h=0;h<d;h++)h in g&&(e[h]=b.call(c,g[h],h,a));return e},Db=E.every?function(a,b,c){return E.every.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=q(a)?a.split(""):a,g=0;g<d;g++)if(g in e&&!b.call(c,e[g],g,a))return!1;return!0};function Eb(a,b){return 0<=zb(a,b)}
function Fb(a,b){var c=zb(a,b),d;(d=0<=c)&&E.splice.call(a,c,1);return d}function Gb(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]}function Hb(a,b,c,d){E.splice.apply(a,Ib(arguments,1))}function Ib(a,b,c){return 2>=arguments.length?E.slice.call(a,b):E.slice.call(a,b,c)};var Jb,Kb,Lb,Mb,Nb=D(ob,"Opera")||D(ob,"OPR"),F=D(ob,"Trident")||D(ob,"MSIE"),Ob=D(ob,"Gecko")&&!D(ob.toLowerCase(),"webkit")&&!(D(ob,"Trident")||D(ob,"MSIE")),G=D(ob.toLowerCase(),"webkit"),Pb=n.navigator||null;Jb=D(Pb&&Pb.platform||"","Mac");var Qb=ob;Kb=!!Qb&&D(Qb,"Android");Lb=!!Qb&&D(Qb,"iPhone");Mb=!!Qb&&D(Qb,"iPad");function Rb(){var a=n.document;return a?a.documentMode:void 0}
var Sb=function(){var a="",b;if(Nb&&n.opera)return a=n.opera.version,u(a)?a():a;Ob?b=/rv\:([^\);]+)(\)|;)/:F?b=/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/:G&&(b=/WebKit\/(\S+)/);b&&(a=(a=b.exec(ob))?a[1]:"");return F&&(b=Rb(),b>parseFloat(a))?String(b):a}(),Tb={};
function H(a){var b;if(!(b=Tb[a])){b=0;for(var c=ab(String(Sb)).split("."),d=ab(String(a)).split("."),e=Math.max(c.length,d.length),g=0;0==b&&g<e;g++){var h=c[g]||"",k=d[g]||"",l=/(\d*)(\D*)/g,m=/(\d*)(\D*)/g;do{var p=l.exec(h)||["","",""],r=m.exec(k)||["","",""];if(0==p[0].length&&0==r[0].length)break;b=nb(0==p[1].length?0:parseInt(p[1],10),0==r[1].length?0:parseInt(r[1],10))||nb(0==p[2].length,0==r[2].length)||nb(p[2],r[2])}while(0==b)}b=Tb[a]=0<=b}return b}
var Ub=n.document,Vb=Ub&&F?Rb()||("CSS1Compat"==Ub.compatMode?parseInt(Sb,10):5):void 0;/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Wb(a){this.t=a;this.P=null;this.ld=new Xb(a,!0,!0);this.Jd=new Xb(a,!1,!0);this.bd=I("rect",{height:J,width:J,style:"fill: #fff"},null);Yb(this.bd,a.Wc)}Wb.prototype.k=function(){K(this.Fe);this.Fe=null;L(this.bd);this.P=this.t=this.bd=null;this.ld.k();this.ld=null;this.Jd.k();this.Jd=null};
Wb.prototype.resize=function(){var a=this.t.qb();if(a){var b=!1,c=!1;this.P&&this.P.O==a.O&&this.P.ra==a.ra&&this.P.Za==a.Za&&this.P.Ya==a.Ya?(this.P&&this.P.Ac==a.Ac&&this.P.Fa==a.Fa&&this.P.yb==a.yb||(b=!0),this.P&&this.P.Ua==a.Ua&&this.P.wb==a.wb&&this.P.cb==a.cb||(c=!0)):c=b=!0;b&&this.ld.resize(a);c&&this.Jd.resize(a);this.P&&this.P.O==a.O&&this.P.Ya==a.Ya||this.bd.setAttribute("x",this.Jd.Xb);this.P&&this.P.ra==a.ra&&this.P.Za==a.Za||this.bd.setAttribute("y",this.ld.Ve);this.P=a}};
Wb.prototype.set=function(a,b){this.ld.set(a);this.Jd.set(b)};function Xb(a,b,c){this.t=a;this.Ge=c||!1;this.Ba=b;this.kf();b?(this.Wa.setAttribute("height",J),this.aa.setAttribute("height",J-6),this.aa.setAttribute("y",3)):(this.Wa.setAttribute("width",J),this.aa.setAttribute("width",J-6),this.aa.setAttribute("x",3));this.Ch=M(this.Wa,"mousedown",this,this.vj);this.Dh=M(this.aa,"mousedown",this,this.wj)}var Zb,$b,J="ontouchstart"in document.documentElement?25:15;f=Xb.prototype;
f.k=function(){this.Ee();this.Fe&&(K(this.Fe),this.Fe=null);K(this.Ch);this.Ch=null;K(this.Dh);this.Dh=null;L(this.g);this.t=this.aa=this.Wa=this.g=null};
f.resize=function(a){if(!a&&(a=this.t.qb(),!a))return;if(this.Ba){var b=a.O;this.Ge?b-=J:this.H(b<a.Ua);this.Ja=b/a.Ac;if(-Infinity===this.Ja||Infinity===this.Ja||isNaN(this.Ja))this.Ja=0;var c=a.O*this.Ja,d=(a.Fa-a.yb)*this.Ja;this.aa.setAttribute("width",Math.max(0,c));this.Xb=a.Ya;this.Ge&&w&&(this.Xb+=a.Ya+J);this.Ve=a.Za+a.ra-J;this.g.setAttribute("transform","translate("+this.Xb+", "+this.Ve+")");this.Wa.setAttribute("width",Math.max(0,b));this.aa.setAttribute("x",ac(this,d))}else{b=a.ra;this.Ge?
b-=J:this.H(b<a.Ua);this.Ja=b/a.Ua;if(-Infinity===this.Ja||Infinity===this.Ja||isNaN(this.Ja))this.Ja=0;c=a.ra*this.Ja;d=(a.wb-a.cb)*this.Ja;this.aa.setAttribute("height",Math.max(0,c));this.Xb=a.Ya;w||(this.Xb+=a.O-J);this.Ve=a.Za;this.g.setAttribute("transform","translate("+this.Xb+", "+this.Ve+")");this.Wa.setAttribute("height",Math.max(0,b));this.aa.setAttribute("y",ac(this,d))}bc(this)};
f.kf=function(){this.g=I("g",{},null);this.Wa=I("rect",{"class":"blocklyScrollbarBackground"},this.g);var a=Math.floor((J-6)/2);this.aa=I("rect",{"class":"blocklyScrollbarKnob",rx:a,ry:a},this.g);Yb(this.g,this.t.Wc)};f.v=function(){return"none"!=this.g.getAttribute("display")};f.H=function(a){if(a!=this.v()){if(this.Ge)throw"Unable to toggle visibility of paired scrollbars.";a?this.g.setAttribute("display","block"):(this.t.Nh({x:0,y:0}),this.g.setAttribute("display","none"))}};
f.vj=function(a){this.Ee();if(!cc(a)){var b=dc(a),b=this.Ba?b.x:b.y,c=ec(this.aa),c=this.Ba?c.x:c.y,d=parseFloat(this.aa.getAttribute(this.Ba?"width":"height")),e=parseFloat(this.aa.getAttribute(this.Ba?"x":"y")),g=.95*d;b<=c?e-=g:b>=c+d&&(e+=g);this.aa.setAttribute(this.Ba?"x":"y",ac(this,e));bc(this)}a.stopPropagation()};
f.wj=function(a){this.Ee();cc(a)||(this.Oj=parseFloat(this.aa.getAttribute(this.Ba?"x":"y")),this.Qj=this.Ba?a.clientX:a.clientY,Zb=M(document,"mouseup",this,this.Ee),$b=M(document,"mousemove",this,this.yj));a.stopPropagation()};f.yj=function(a){this.aa.setAttribute(this.Ba?"x":"y",ac(this,this.Oj+((this.Ba?a.clientX:a.clientY)-this.Qj)));bc(this)};f.Ee=function(){fc();N(!0);Zb&&(K(Zb),Zb=null);$b&&(K($b),$b=null)};
function ac(a,b){if(0>=b||isNaN(b))b=0;else{var c=a.Ba?"width":"height",d=parseFloat(a.Wa.getAttribute(c)),c=parseFloat(a.aa.getAttribute(c));b=Math.min(b,d-c)}return b}function bc(a){var b=parseFloat(a.aa.getAttribute(a.Ba?"x":"y")),c=parseFloat(a.Wa.getAttribute(a.Ba?"width":"height")),b=b/c;isNaN(b)&&(b=0);c={};a.Ba?c.x=b:c.y=b;a.t.Nh(c)}f.set=function(a){this.aa.setAttribute(this.Ba?"x":"y",a*this.Ja);bc(this)};
function Yb(a,b){var c=b.nextSibling,d=b.parentNode;if(!d)throw"Reference node has no parent.";c?d.insertBefore(a,c):d.appendChild(a)};function gc(){0!=hc&&(ic[ha(this)]=this);this.cd=this.cd;this.Ce=this.Ce}var hc=0,ic={};gc.prototype.cd=!1;gc.prototype.k=function(){if(!this.cd&&(this.cd=!0,this.V(),0!=hc)){var a=ha(this);delete ic[a]}};gc.prototype.V=function(){if(this.Ce)for(;this.Ce.length;)this.Ce.shift()()};var jc="closure_listenable_"+(1E6*Math.random()|0),kc=0;function lc(a,b,c,d,e){this.gc=a;this.Ie=null;this.src=b;this.type=c;this.Rd=!!d;this.le=e;this.key=++kc;this.Qc=this.Qd=!1}function mc(a){a.Qc=!0;a.gc=null;a.Ie=null;a.src=null;a.le=null};function nc(a){this.src=a;this.Ca={};this.Id=0}nc.prototype.add=function(a,b,c,d,e){var g=a.toString();a=this.Ca[g];a||(a=this.Ca[g]=[],this.Id++);var h=oc(a,b,d,e);-1<h?(b=a[h],c||(b.Qd=!1)):(b=new lc(b,this.src,g,!!d,e),b.Qd=c,a.push(b));return b};nc.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.Ca))return!1;var e=this.Ca[a];b=oc(e,b,c,d);return-1<b?(mc(e[b]),E.splice.call(e,b,1),0==e.length&&(delete this.Ca[a],this.Id--),!0):!1};
function pc(a,b){var c=b.type;if(!(c in a.Ca))return!1;var d=Fb(a.Ca[c],b);d&&(mc(b),0==a.Ca[c].length&&(delete a.Ca[c],a.Id--));return d}nc.prototype.Me=function(a){a=a&&a.toString();var b=0,c;for(c in this.Ca)if(!a||c==a){for(var d=this.Ca[c],e=0;e<d.length;e++)++b,mc(d[e]);delete this.Ca[c];this.Id--}return b};nc.prototype.jd=function(a,b,c,d){a=this.Ca[a.toString()];var e=-1;a&&(e=oc(a,b,c,d));return-1<e?a[e]:null};
function oc(a,b,c,d){for(var e=0;e<a.length;++e){var g=a[e];if(!g.Qc&&g.gc==b&&g.Rd==!!c&&g.le==d)return e}return-1};function qc(a,b){this.type=a;this.currentTarget=this.target=b;this.defaultPrevented=this.kc=!1;this.Lh=!0}qc.prototype.V=function(){};qc.prototype.k=function(){};qc.prototype.stopPropagation=function(){this.kc=!0};qc.prototype.preventDefault=function(){this.defaultPrevented=!0;this.Lh=!1};var rc=!F||F&&9<=Vb,sc=!F||F&&9<=Vb,tc=F&&!H("9");!G||H("528");Ob&&H("1.9b")||F&&H("8")||Nb&&H("9.5")||G&&H("528");Ob&&!H("8")||F&&H("9");var uc="ontouchstart"in n||!!(n.document&&document.documentElement&&"ontouchstart"in document.documentElement)||!(!n.navigator||!n.navigator.msMaxTouchPoints);function vc(a){vc[" "](a);return a}vc[" "]=ba;function wc(a,b){qc.call(this,a?a.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.charCode=this.keyCode=this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.Tf=!1;this.Bb=null;a&&this.M(a,b)}v(wc,qc);var xc=[1,4,2];
wc.prototype.M=function(a,b){var c=this.type=a.type;this.target=a.target||a.srcElement;this.currentTarget=b;var d=a.relatedTarget;if(d){if(Ob){var e;a:{try{vc(d.nodeName);e=!0;break a}catch(g){}e=!1}e||(d=null)}}else"mouseover"==c?d=a.fromElement:"mouseout"==c&&(d=a.toElement);this.relatedTarget=d;this.offsetX=G||void 0!==a.offsetX?a.offsetX:a.layerX;this.offsetY=G||void 0!==a.offsetY?a.offsetY:a.layerY;this.clientX=void 0!==a.clientX?a.clientX:a.pageX;this.clientY=void 0!==a.clientY?a.clientY:a.pageY;
this.screenX=a.screenX||0;this.screenY=a.screenY||0;this.button=a.button;this.keyCode=a.keyCode||0;this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.Tf=Jb?a.metaKey:a.ctrlKey;this.state=a.state;this.Bb=a;a.defaultPrevented&&this.preventDefault()};function yc(a){return rc?0==a.Bb.button:"click"==a.type?!0:!!(a.Bb.button&xc[0])}
wc.prototype.stopPropagation=function(){wc.m.stopPropagation.call(this);this.Bb.stopPropagation?this.Bb.stopPropagation():this.Bb.cancelBubble=!0};wc.prototype.preventDefault=function(){wc.m.preventDefault.call(this);var a=this.Bb;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,tc)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(b){}};wc.prototype.V=function(){};var zc="closure_lm_"+(1E6*Math.random()|0),Ac={},Bc=0;function O(a,b,c,d,e){if(ea(b)){for(var g=0;g<b.length;g++)O(a,b[g],c,d,e);return null}c=Cc(c);if(a&&a[jc])a=a.B(b,c,d,e);else{if(!b)throw Error("Invalid event type");var g=!!d,h=Dc(a);h||(a[zc]=h=new nc(a));c=h.add(b,c,!1,d,e);c.Ie||(d=Ec(),c.Ie=d,d.src=a,d.gc=c,a.addEventListener?a.addEventListener(b.toString(),d,g):a.attachEvent(Fc(b.toString()),d),Bc++);a=c}return a}
function Ec(){var a=Gc,b=sc?function(c){return a.call(b.src,b.gc,c)}:function(c){c=a.call(b.src,b.gc,c);if(!c)return c};return b}function Hc(a,b,c,d,e){if(ea(b))for(var g=0;g<b.length;g++)Hc(a,b[g],c,d,e);else c=Cc(c),a&&a[jc]?a.Xa(b,c,d,e):a&&(a=Dc(a))&&(b=a.jd(b,c,!!d,e))&&Ic(b)}
function Ic(a){if(s(a)||!a||a.Qc)return!1;var b=a.src;if(b&&b[jc])return pc(b.Nb,a);var c=a.type,d=a.Ie;b.removeEventListener?b.removeEventListener(c,d,a.Rd):b.detachEvent&&b.detachEvent(Fc(c),d);Bc--;(c=Dc(b))?(pc(c,a),0==c.Id&&(c.src=null,b[zc]=null)):mc(a);return!0}function Fc(a){return a in Ac?Ac[a]:Ac[a]="on"+a}function Jc(a,b,c,d){var e=1;if(a=Dc(a))if(b=a.Ca[b.toString()])for(b=b.concat(),a=0;a<b.length;a++){var g=b[a];g&&g.Rd==c&&!g.Qc&&(e&=!1!==Kc(g,d))}return Boolean(e)}
function Kc(a,b){var c=a.gc,d=a.le||a.src;a.Qd&&Ic(a);return c.call(d,b)}
function Gc(a,b){if(a.Qc)return!0;if(!sc){var c=b||aa("window.event"),d=new wc(c,this),e=!0;if(!(0>c.keyCode||void 0!=c.returnValue)){a:{var g=!1;if(0==c.keyCode)try{c.keyCode=-1;break a}catch(h){g=!0}if(g||void 0==c.returnValue)c.returnValue=!0}c=[];for(g=d.currentTarget;g;g=g.parentNode)c.push(g);for(var g=a.type,k=c.length-1;!d.kc&&0<=k;k--)d.currentTarget=c[k],e&=Jc(c[k],g,!0,d);for(k=0;!d.kc&&k<c.length;k++)d.currentTarget=c[k],e&=Jc(c[k],g,!1,d)}return e}return Kc(a,new wc(b,this))}
function Dc(a){a=a[zc];return a instanceof nc?a:null}var Lc="__closure_events_fn_"+(1E9*Math.random()>>>0);function Cc(a){if(u(a))return a;a[Lc]||(a[Lc]=function(b){return a.handleEvent(b)});return a[Lc]};function Mc(){gc.call(this);this.Nb=new nc(this);this.ki=this;this.Sf=null}v(Mc,gc);Mc.prototype[jc]=!0;f=Mc.prototype;f.ge=function(){return this.Sf};f.dg=function(a){this.Sf=a};f.addEventListener=function(a,b,c,d){O(this,a,b,c,d)};f.removeEventListener=function(a,b,c,d){Hc(this,a,b,c,d)};
f.dispatchEvent=function(a){var b,c=this.ge();if(c)for(b=[];c;c=c.ge())b.push(c);var c=this.ki,d=a.type||a;if(q(a))a=new qc(a,c);else if(a instanceof qc)a.target=a.target||c;else{var e=a;a=new qc(d,c);tb(a,e)}var e=!0,g;if(b)for(var h=b.length-1;!a.kc&&0<=h;h--)g=a.currentTarget=b[h],e=Nc(g,d,!0,a)&&e;a.kc||(g=a.currentTarget=c,e=Nc(g,d,!0,a)&&e,a.kc||(e=Nc(g,d,!1,a)&&e));if(b)for(h=0;!a.kc&&h<b.length;h++)g=a.currentTarget=b[h],e=Nc(g,d,!1,a)&&e;return e};
f.V=function(){Mc.m.V.call(this);this.Nb&&this.Nb.Me(void 0);this.Sf=null};f.B=function(a,b,c,d){return this.Nb.add(String(a),b,!1,c,d)};f.Xa=function(a,b,c,d){return this.Nb.remove(String(a),b,c,d)};function Nc(a,b,c,d){b=a.Nb.Ca[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,g=0;g<b.length;++g){var h=b[g];if(h&&!h.Qc&&h.Rd==c){var k=h.gc,l=h.le||h.src;h.Qd&&pc(a.Nb,h);e=!1!==k.call(l,d)&&e}}return e&&0!=d.Lh}f.jd=function(a,b,c,d){return this.Nb.jd(String(a),b,c,d)};function Oc(a,b,c){if(u(a))c&&(a=na(a,c));else if(a&&"function"==typeof a.handleEvent)a=na(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<b?-1:n.setTimeout(a,b||0)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Pc(a){this.t=a}f=Pc.prototype;f.$c=47;f.We=45;f.Zc=15;f.bi=35;f.vg=35;f.Ld=25;f.tb=!1;f.g=null;f.Se=null;f.Lf=0;f.Ub=0;f.vh=0;f.Uh=0;
f.G=function(){this.g=I("g",{filter:"url(#blocklyTrashcanShadowFilter)"},null);var a=I("clipPath",{id:"blocklyTrashBodyClipPath"},this.g);I("rect",{width:this.$c,height:this.We,y:this.Zc},a);I("image",{width:Qc,height:Rc,y:-32,"clip-path":"url(#blocklyTrashBodyClipPath)"},this.g).setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",Sc+Tc);a=I("clipPath",{id:"blocklyTrashLidClipPath"},this.g);I("rect",{width:this.$c,height:this.Zc},a);this.Se=I("image",{width:Qc,height:Rc,y:-32,"clip-path":"url(#blocklyTrashLidClipPath)"},
this.g);this.Se.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",Sc+Tc);return this.g};f.M=function(){Uc(this,!1);this.xd();M(window,"resize",this,this.xd)};f.k=function(){this.g&&(L(this.g),this.g=null);this.t=this.Se=null;n.clearTimeout(this.Lf)};f.xd=function(){var a=this.t.qb();a&&(this.vh=w?this.vg:a.O+a.Ya-this.$c-this.vg,this.Uh=a.ra+a.Za-(this.We+this.Zc)-this.bi,this.g.setAttribute("transform","translate("+this.vh+","+this.Uh+")"))};
function Uc(a,b){a.tb!=b&&(n.clearTimeout(a.Lf),a.tb=b,a.zg())}f.zg=function(){this.Ub+=this.tb?10:-10;this.Ub=Math.max(0,this.Ub);this.Se.setAttribute("transform","rotate("+(w?-this.Ub:this.Ub)+", "+(w?4:this.$c-4)+", "+(this.Zc-2)+")");if(this.tb?45>this.Ub:0<this.Ub)this.Lf=Oc(this.zg,5,this)};f.close=function(){Uc(this,!1)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Vc(a,b){this.qb=a;this.Nh=b;this.sh=!1;this.Xc=[];this.Nf=Infinity;var c=[];c[1]=new Wc;c[2]=new Wc;c[3]=new Wc;c[4]=new Wc;this.zi=c}f=Vc.prototype;f.rf=!1;f.scrollX=0;f.scrollY=0;f.Ma=null;f.tf=null;f.Wb=null;f.G=function(){this.g=I("g",{},null);this.$=I("g",{},this.g);this.Wc=I("g",{},this.g);Xc(this);return this.g};f.k=function(){this.g&&(L(this.g),this.g=null);this.Wc=this.$=null;this.Ma&&(this.Ma.k(),this.Ma=null)};
function Yc(){var a=P;if(ra&&!C){a.Ma=new Pc(a);var b=a.Ma.G();a.g.insertBefore(b,a.$);a.Ma.M()}}function Zc(a,b){a.Xc.push(b);$c&&a==P&&-1==ad.indexOf(b)&&ad.push(b);Xc(a)}function bd(a,b){for(var c=!1,d,e=0;d=a.Xc[e];e++)if(d==b){a.Xc.splice(e,1);c=!0;break}if(!c)throw"Block not present in workspace's list of top-most blocks.";$c&&a==P&&ad.Kk(b);Xc(a)}
function Fa(a,b){var c=[].concat(a.Xc);if(b&&1<c.length){var d=Math.sin(3/180*Math.PI);w&&(d*=-1);c.sort(function(a,b){var c=z(a),k=z(b);return c.y+d*c.x-(k.y+d*k.x)})}return c}function cd(a){a=Fa(a,!1);for(var b=0;b<a.length;b++)a.push.apply(a,a[b].ec());return a}f.clear=function(){for(N();this.Xc.length;)this.Xc[0].k()};f.w=function(){for(var a=cd(this),b=0,c;c=a[b];b++)c.ec().length||c.w()};function dd(a,b){for(var c=cd(a),d=0,e;e=c[d];d++)if(e.id==b)return e;return null}
function ed(a,b){a.qg=b;a.rg&&(K(a.rg),a.rg=null);b&&(a.rg=M(a.$,"blocklySelectChange",a,function(){this.qg=!1}))}function fd(a){var b=P;b.qg&&0!=gd&&ed(b,!1);if(b.qg){var c=null;if(a&&(c=dd(b,a),!c))return;ed(b,!1);c?c.select():Q&&hd(Q);setTimeout(function(){ed(b,!0)},1)}}function Xc(a){a.tf&&window.clearTimeout(a.tf);var b=a.$;b&&(a.tf=window.setTimeout(function(){id(b,"blocklyWorkspaceChange")},0))}function jd(a){return Infinity==a.Nf?Infinity:a.Nf-cd(a).length}Vc.prototype.clear=Vc.prototype.clear;function kd(a,b){this.x=void 0!==a?a:0;this.y=void 0!==b?b:0}f=kd.prototype;f.clone=function(){return new kd(this.x,this.y)};f.toString=function(){return"("+this.x+", "+this.y+")"};f.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};f.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};f.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};
f.translate=function(a,b){a instanceof kd?(this.x+=a.x,this.y+=a.y):(this.x+=a,s(b)&&(this.y+=b));return this};f.scale=function(a,b){var c=s(b)?b:a;this.x*=a;this.y*=c;return this};function ld(a,b,c,d){this.top=a;this.right=b;this.bottom=c;this.left=d}f=ld.prototype;f.clone=function(){return new ld(this.top,this.right,this.bottom,this.left)};f.toString=function(){return"("+this.top+"t, "+this.right+"r, "+this.bottom+"b, "+this.left+"l)"};f.contains=function(a){return this&&a?a instanceof ld?a.left>=this.left&&a.right<=this.right&&a.top>=this.top&&a.bottom<=this.bottom:a.x>=this.left&&a.x<=this.right&&a.y>=this.top&&a.y<=this.bottom:!1};
f.expand=function(a,b,c,d){ga(a)?(this.top-=a.top,this.right+=a.right,this.bottom+=a.bottom,this.left-=a.left):(this.top-=a,this.right+=b,this.bottom+=c,this.left-=d);return this};f.ceil=function(){this.top=Math.ceil(this.top);this.right=Math.ceil(this.right);this.bottom=Math.ceil(this.bottom);this.left=Math.ceil(this.left);return this};f.floor=function(){this.top=Math.floor(this.top);this.right=Math.floor(this.right);this.bottom=Math.floor(this.bottom);this.left=Math.floor(this.left);return this};
f.round=function(){this.top=Math.round(this.top);this.right=Math.round(this.right);this.bottom=Math.round(this.bottom);this.left=Math.round(this.left);return this};f.translate=function(a,b){a instanceof kd?(this.left+=a.x,this.right+=a.x,this.top+=a.y,this.bottom+=a.y):(this.left+=a,this.right+=a,s(b)&&(this.top+=b,this.bottom+=b));return this};f.scale=function(a,b){var c=s(b)?b:a;this.left*=a;this.right*=a;this.top*=c;this.bottom*=c;return this};function md(a,b){this.width=a;this.height=b}f=md.prototype;f.clone=function(){return new md(this.width,this.height)};f.toString=function(){return"("+this.width+" x "+this.height+")"};f.rh=function(){return!(this.width*this.height)};f.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};f.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
f.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};f.scale=function(a,b){var c=s(b)?b:a;this.width*=a;this.height*=c;return this};function nd(a,b,c,d){this.left=a;this.top=b;this.width=c;this.height=d}f=nd.prototype;f.clone=function(){return new nd(this.left,this.top,this.width,this.height)};f.toString=function(){return"("+this.left+", "+this.top+" - "+this.width+"w x "+this.height+"h)"};f.contains=function(a){return a instanceof nd?this.left<=a.left&&this.left+this.width>=a.left+a.width&&this.top<=a.top&&this.top+this.height>=a.top+a.height:a.x>=this.left&&a.x<=this.left+this.width&&a.y>=this.top&&a.y<=this.top+this.height};
f.ih=function(){return new md(this.width,this.height)};f.ceil=function(){this.left=Math.ceil(this.left);this.top=Math.ceil(this.top);this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};f.floor=function(){this.left=Math.floor(this.left);this.top=Math.floor(this.top);this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
f.round=function(){this.left=Math.round(this.left);this.top=Math.round(this.top);this.width=Math.round(this.width);this.height=Math.round(this.height);return this};f.translate=function(a,b){a instanceof kd?(this.left+=a.x,this.top+=a.y):(this.left+=a,s(b)&&(this.top+=b));return this};f.scale=function(a,b){var c=s(b)?b:a;this.left*=a;this.width*=a;this.top*=c;this.height*=c;return this};var od=!F||F&&9<=Vb,pd=!Ob&&!F||F&&F&&9<=Vb||Ob&&H("1.9.1"),qd=F&&!H("9");function rd(a){return a?new sd(td(a)):vb||(vb=new sd)}function ud(a,b){rb(b,function(b,d){"style"==d?a.style.cssText=b:"class"==d?a.className=b:"for"==d?a.htmlFor=b:d in vd?a.setAttribute(vd[d],b):0==d.lastIndexOf("aria-",0)||0==d.lastIndexOf("data-",0)?a.setAttribute(d,b):a[d]=b})}var vd={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};
function wd(){var a=window.document,a="CSS1Compat"==a.compatMode?a.documentElement:a.body;return new md(a.clientWidth,a.clientHeight)}function y(a,b,c){return xd(document,arguments)}
function xd(a,b){var c=b[0],d=b[1];if(!od&&d&&(d.name||d.type)){c=["<",c];d.name&&c.push(' name="',cb(d.name),'"');if(d.type){c.push(' type="',cb(d.type),'"');var e={};tb(e,d);delete e.type;d=e}c.push(">");c=c.join("")}c=a.createElement(c);d&&(q(d)?c.className=d:ea(d)?c.className=d.join(" "):ud(c,d));2<b.length&&yd(a,c,b,2);return c}
function yd(a,b,c,d){function e(c){c&&b.appendChild(q(c)?a.createTextNode(c):c)}for(;d<c.length;d++){var g=c[d];!fa(g)||ga(g)&&0<g.nodeType?e(g):Ab(zd(g)?Gb(g):g,e)}}function Ad(a){for(var b;b=a.firstChild;)a.removeChild(b)}function Bd(a){var b=P.g;b.parentNode&&b.parentNode.insertBefore(a,b)}function L(a){return a&&a.parentNode?a.parentNode.removeChild(a):null}
function Cd(a,b){if(a.contains&&1==b.nodeType)return a==b||a.contains(b);if("undefined"!=typeof a.compareDocumentPosition)return a==b||Boolean(a.compareDocumentPosition(b)&16);for(;b&&a!=b;)b=b.parentNode;return b==a}function td(a){return 9==a.nodeType?a:a.ownerDocument||a.document}var Dd={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1},Ed={IMG:" ",BR:"\n"};function Fd(a){a=a.getAttributeNode("tabindex");return null!=a&&a.specified}function Gd(a){a=a.tabIndex;return s(a)&&0<=a&&32768>a}
function Hd(a){var b=[];Id(a,b,!1);return b.join("")}function Id(a,b,c){if(!(a.nodeName in Dd))if(3==a.nodeType)c?b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g,"")):b.push(a.nodeValue);else if(a.nodeName in Ed)b.push(Ed[a.nodeName]);else for(a=a.firstChild;a;)Id(a,b,c),a=a.nextSibling}function zd(a){if(a&&"number"==typeof a.length){if(ga(a))return"function"==typeof a.item||"string"==typeof a.item;if(u(a))return"function"==typeof a.item}return!1}
function sd(a){this.Ab=a||n.document||document}f=sd.prototype;f.gb=rd;f.i=function(a){return q(a)?this.Ab.getElementById(a):a};f.G=function(a,b,c){return xd(this.Ab,arguments)};f.createElement=function(a){return this.Ab.createElement(a)};f.createTextNode=function(a){return this.Ab.createTextNode(String(a))};f.appendChild=function(a,b){a.appendChild(b)};f.append=function(a,b){yd(td(a),a,arguments,1)};f.canHaveChildren=function(a){if(1!=a.nodeType)return!1;switch(a.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case "SCRIPT":case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
f.Kh=Ad;f.removeNode=L;f.ec=function(a){return pd&&void 0!=a.children?a.children:Bb(a.childNodes,function(a){return 1==a.nodeType})};f.contains=Cd;f.Rb=function(a){var b;(b="A"==a.tagName||"INPUT"==a.tagName||"TEXTAREA"==a.tagName||"SELECT"==a.tagName||"BUTTON"==a.tagName?!a.disabled&&(!Fd(a)||Gd(a)):Fd(a)&&Gd(a))&&F?(a=u(a.getBoundingClientRect)?a.getBoundingClientRect():{height:a.offsetHeight,width:a.offsetWidth},a=null!=a&&0<a.height&&0<a.width):a=b;return a};function Jd(a,b){var c=td(a);return c.defaultView&&c.defaultView.getComputedStyle&&(c=c.defaultView.getComputedStyle(a,null))?c[b]||c.getPropertyValue(b)||"":""}function Kd(a,b){return Jd(a,b)||(a.currentStyle?a.currentStyle[b]:null)||a.style&&a.style[b]}function Ld(){var a=document,b=a.body,a=a.documentElement;return new kd(b.scrollLeft||a.scrollLeft,b.scrollTop||a.scrollTop)}
function Md(a){var b;try{b=a.getBoundingClientRect()}catch(c){return{left:0,top:0,right:0,bottom:0}}F&&a.ownerDocument.body&&(a=a.ownerDocument,b.left-=a.documentElement.clientLeft+a.body.clientLeft,b.top-=a.documentElement.clientTop+a.body.clientTop);return b}
function Nd(a){if(F&&!(F&&8<=Vb))return a.offsetParent;var b=td(a),c=Kd(a,"position"),d="fixed"==c||"absolute"==c;for(a=a.parentNode;a&&a!=b;a=a.parentNode)if(c=Kd(a,"position"),d=d&&"static"==c&&a!=b.documentElement&&a!=b.body,!d&&(a.scrollWidth>a.clientWidth||a.scrollHeight>a.clientHeight||"fixed"==c||"absolute"==c||"relative"==c))return a;return null}
function Od(a){var b,c=td(a),d=Kd(a,"position"),e=Ob&&c.getBoxObjectFor&&!a.getBoundingClientRect&&"absolute"==d&&(b=c.getBoxObjectFor(a))&&(0>b.screenX||0>b.screenY),g=new kd(0,0),h;b=c?td(c):document;(h=!F||F&&9<=Vb)||(h="CSS1Compat"==rd(b).Ab.compatMode);h=h?b.documentElement:b.body;if(a==h)return g;if(a.getBoundingClientRect)b=Md(a),c=rd(c).Ab,a=G||"CSS1Compat"!=c.compatMode?c.body||c.documentElement:c.documentElement,c=c.parentWindow||c.defaultView,a=F&&H("10")&&c.pageYOffset!=a.scrollTop?new kd(a.scrollLeft,
a.scrollTop):new kd(c.pageXOffset||a.scrollLeft,c.pageYOffset||a.scrollTop),g.x=b.left+a.x,g.y=b.top+a.y;else if(c.getBoxObjectFor&&!e)b=c.getBoxObjectFor(a),a=c.getBoxObjectFor(h),g.x=b.screenX-a.screenX,g.y=b.screenY-a.screenY;else{b=a;do{g.x+=b.offsetLeft;g.y+=b.offsetTop;b!=a&&(g.x+=b.clientLeft||0,g.y+=b.clientTop||0);if(G&&"fixed"==Kd(b,"position")){g.x+=c.body.scrollLeft;g.y+=c.body.scrollTop;break}b=b.offsetParent}while(b&&b!=a);if(Nb||G&&"absolute"==d)g.y-=c.body.offsetTop;for(b=a;(b=Nd(b))&&
b!=c.body&&b!=h;)g.x-=b.scrollLeft,Nb&&"TR"==b.tagName||(g.y-=b.scrollTop)}return g}function Pd(a){var b=Qd;if("none"!=Kd(a,"display"))return b(a);var c=a.style,d=c.display,e=c.visibility,g=c.position;c.visibility="hidden";c.position="absolute";c.display="inline";a=b(a);c.display=d;c.position=g;c.visibility=e;return a}function Qd(a){var b=a.offsetWidth,c=a.offsetHeight,d=G&&!b&&!c;return(void 0===b||d)&&a.getBoundingClientRect?(a=Md(a),new md(a.right-a.left,a.bottom-a.top)):new md(b,c)}
function Rd(a){var b=Od(a);a=Pd(a);return new nd(b.x,b.y,a.width,a.height)}function Sd(a,b){a.style.display=b?"":"none"}var Td=Ob?"MozUserSelect":G?"WebkitUserSelect":null;function Ud(a,b,c){c=c?null:a.getElementsByTagName("*");if(Td){if(b=b?"none":"",a.style[Td]=b,c){a=0;for(var d;d=c[a];a++)d.style[Td]=b}}else if(F||Nb)if(b=b?"on":"",a.setAttribute("unselectable",b),c)for(a=0;d=c[a];a++)d.setAttribute("unselectable",b)}var Vd={thin:2,medium:4,thick:6};
function Wd(a,b){if("none"==(a.currentStyle?a.currentStyle[b+"Style"]:null))return 0;var c=a.currentStyle?a.currentStyle[b+"Width"]:null,d;if(c in Vd)d=Vd[c];else if(/^\d+px?$/.test(c))d=parseInt(c,10);else{d=a.style.left;var e=a.runtimeStyle.left;a.runtimeStyle.left=a.currentStyle.left;a.style.left=c;c=a.style.pixelLeft;a.style.left=d;a.runtimeStyle.left=e;d=c}return d}
function Xd(a){if(F&&!(F&&9<=Vb)){var b=Wd(a,"borderLeft"),c=Wd(a,"borderRight"),d=Wd(a,"borderTop");a=Wd(a,"borderBottom");return new ld(d,c,a,b)}b=Jd(a,"borderLeftWidth");c=Jd(a,"borderRightWidth");d=Jd(a,"borderTopWidth");a=Jd(a,"borderBottomWidth");return new ld(parseFloat(d),parseFloat(c),parseFloat(a),parseFloat(b))};function Yd(a){gc.call(this);this.lh=a;this.we={}}v(Yd,gc);var Zd=[];f=Yd.prototype;f.B=function(a,b,c,d){ea(b)||(b&&(Zd[0]=b.toString()),b=Zd);for(var e=0;e<b.length;e++){var g=O(a,b[e],c||this.handleEvent,d||!1,this.lh||this);if(!g)break;this.we[g.key]=g}return this};
f.Xa=function(a,b,c,d,e){if(ea(b))for(var g=0;g<b.length;g++)this.Xa(a,b[g],c,d,e);else c=c||this.handleEvent,e=e||this.lh||this,c=Cc(c),d=!!d,b=a&&a[jc]?a.jd(b,c,d,e):a?(a=Dc(a))?a.jd(b,c,d,e):null:null,b&&(Ic(b),delete this.we[b.key]);return this};f.Me=function(){rb(this.we,Ic);this.we={}};f.V=function(){Yd.m.V.call(this);this.Me()};f.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented");};function $d(){}ca($d);$d.prototype.tj=0;function ae(a){Mc.call(this);this.Vd=a||rd();this.Pe=be;this.ne=null;this.A=!1;this.u=null;this.Pb=void 0;this.Jb=this.Q=this.xa=this.Ae=null;this.Xj=!1}v(ae,Mc);ae.prototype.jj=$d.Ob();var be=null;
function ce(a,b){switch(a){case 1:return b?"disable":"enable";case 2:return b?"highlight":"unhighlight";case 4:return b?"activate":"deactivate";case 8:return b?"select":"unselect";case 16:return b?"check":"uncheck";case 32:return b?"focus":"blur";case 64:return b?"open":"close"}throw Error("Invalid component state");}function de(a){return a.ne||(a.ne=":"+(a.jj.tj++).toString(36))}f=ae.prototype;f.i=function(){return this.u};function ee(a){a.Pb||(a.Pb=new Yd(a));return a.Pb}
f.Qa=function(a){if(this==a)throw Error("Unable to set parent component");if(a&&this.xa&&this.ne&&fe(this.xa,this.ne)&&this.xa!=a)throw Error("Unable to set parent component");this.xa=a;ae.m.dg.call(this,a)};f.getParent=function(){return this.xa};f.dg=function(a){if(this.xa&&this.xa!=a)throw Error("Method not supported");ae.m.dg.call(this,a)};f.gb=function(){return this.Vd};f.G=function(){this.u=this.Vd.createElement("div")};f.w=function(a){this.zd(a)};
f.zd=function(a,b){if(this.A)throw Error("Component already rendered");this.u||this.G();a?a.insertBefore(this.u,b||null):this.Vd.Ab.body.appendChild(this.u);this.xa&&!this.xa.A||this.na()};f.na=function(){this.A=!0;R(this,function(a){!a.A&&a.i()&&a.na()})};f.Va=function(){R(this,function(a){a.A&&a.Va()});this.Pb&&this.Pb.Me();this.A=!1};
f.V=function(){this.A&&this.Va();this.Pb&&(this.Pb.k(),delete this.Pb);R(this,function(a){a.k()});!this.Xj&&this.u&&L(this.u);this.xa=this.Ae=this.u=this.Jb=this.Q=null;ae.m.V.call(this)};f.Md=function(a,b){this.yc(a,ge(this),b)};
f.yc=function(a,b,c){if(a.A&&(c||!this.A))throw Error("Component already rendered");if(0>b||b>ge(this))throw Error("Child component index out of bounds");this.Jb&&this.Q||(this.Jb={},this.Q=[]);if(a.getParent()==this){var d=de(a);this.Jb[d]=a;Fb(this.Q,a)}else{var d=this.Jb,e=de(a);if(e in d)throw Error('The object already contains the key "'+e+'"');d[e]=a}a.Qa(this);Hb(this.Q,b,0,a);a.A&&this.A&&a.getParent()==this?(c=this.fb(),c.insertBefore(a.i(),c.childNodes[b]||null)):c?(this.u||this.G(),b=S(this,
b+1),a.zd(this.fb(),b?b.u:null)):this.A&&!a.A&&a.u&&a.u.parentNode&&1==a.u.parentNode.nodeType&&a.na()};f.fb=function(){return this.u};function he(a){null==a.Pe&&(a.Pe="rtl"==Kd(a.A?a.u:a.Vd.Ab.body,"direction"));return a.Pe}f.Cd=function(a){if(this.A)throw Error("Component already rendered");this.Pe=a};function ie(a){return!!a.Q&&0!=a.Q.length}function ge(a){return a.Q?a.Q.length:0}function fe(a,b){var c;a.Jb&&b?(c=a.Jb,c=(b in c?c[b]:void 0)||null):c=null;return c}
function S(a,b){return a.Q?a.Q[b]||null:null}function R(a,b,c){a.Q&&Ab(a.Q,b,c)}function je(a,b){return a.Q&&b?zb(a.Q,b):-1}f.removeChild=function(a,b){if(a){var c=q(a)?a:de(a);a=fe(this,c);if(c&&a){var d=this.Jb;c in d&&delete d[c];Fb(this.Q,a);b&&(a.Va(),a.u&&L(a.u));a.Qa(null)}}if(!a)throw Error("Child is not in parent component");return a};f.Kh=function(a){for(var b=[];ie(this);)b.push(this.removeChild(S(this,0),a));return b};function ke(a){if(a.classList)return a.classList;a=a.className;return q(a)&&a.match(/\S+/g)||[]}function le(a,b){return a.classList?a.classList.contains(b):Eb(ke(a),b)}function me(a,b){a.classList?a.classList.add(b):le(a,b)||(a.className+=0<a.className.length?" "+b:b)}function ne(a,b){if(a.classList)Ab(b,function(b){me(a,b)});else{var c={};Ab(ke(a),function(a){c[a]=!0});Ab(b,function(a){c[a]=!0});a.className="";for(var d in c)a.className+=0<a.className.length?" "+d:d}}
function oe(a,b){a.classList?a.classList.remove(b):le(a,b)&&(a.className=Bb(ke(a),function(a){return a!=b}).join(" "))}function pe(a,b){a.classList?Ab(b,function(b){oe(a,b)}):a.className=Bb(ke(a),function(a){return!Eb(b,a)}).join(" ")};function qe(a,b){if(!a)throw Error("Invalid class name "+a);if(!u(b))throw Error("Invalid decorator function "+b);}var re={};var se;function te(a,b){b?a.setAttribute("role",b):a.removeAttribute("role")}function T(a,b,c){ea(c)&&(c=c.join(" "));var d="aria-"+b;""===c||void 0==c?(se||(se={atomic:!1,autocomplete:"none",dropeffect:"none",haspopup:!1,live:"off",multiline:!1,multiselectable:!1,orientation:"vertical",readonly:!1,relevant:"additions text",required:!1,sort:"none",busy:!1,disabled:!1,hidden:!1,invalid:"false"}),c=se,b in c?a.setAttribute(d,c[b]):a.removeAttribute(d)):a.setAttribute(d,c)};function ue(){}var ve;ca(ue);var we={button:"pressed",checkbox:"checked",menuitem:"selected",menuitemcheckbox:"checked",menuitemradio:"checked",radio:"checked",tab:"selected",treeitem:"selected"};f=ue.prototype;f.Yd=function(){};f.G=function(a){var b=a.gb().G("div",this.ae(a).join(" "),a.zb);xe(a,b);return b};f.fb=function(a){return a};f.ed=function(a,b,c){if(a=a.i?a.i():a){var d=[b];F&&!H("7")&&(d=ye(ke(a),b),d.push(b));(c?ne:pe)(a,d)}};
f.qd=function(a){he(a)&&this.Cd(a.i(),!0);a.isEnabled()&&this.qc(a,a.v())};function ze(a,b,c){if(a=c||a.Yd())c=b.getAttribute("role")||null,a!=c&&te(b,a)}function xe(a,b){a.v()||T(b,"hidden",!a.v());a.isEnabled()||Ae(b,1,!a.isEnabled());a.T&8&&Ae(b,8,a.te());a.T&16&&Ae(b,16,!!(a.Z&16));a.T&64&&Ae(b,64,a.tb())}f.ag=function(a,b){Ud(a,!b,!F&&!Nb)};f.Cd=function(a,b){this.ed(a,this.va()+"-rtl",b)};f.Rb=function(a){var b;return a.T&32&&(b=a.ga())?Fd(b)&&Gd(b):!1};
f.qc=function(a,b){var c;if(a.T&32&&(c=a.ga())){if(!b&&a.Z&32){try{c.blur()}catch(d){}a.Z&32&&a.md(null)}(Fd(c)&&Gd(c))!=b&&(b?c.tabIndex=0:(c.tabIndex=-1,c.removeAttribute("tabIndex")))}};f.H=function(a,b){Sd(a,b);a&&T(a,"hidden",!b)};f.kb=function(a,b,c){var d=a.i();if(d){var e=this.$d(b);e&&this.ed(a,e,c);Ae(d,b,c)}};
function Ae(a,b,c){ve||(ve={1:"disabled",8:"selected",16:"checked",64:"expanded"});b=ve[b];var d=a.getAttribute("role")||null;d&&(d=we[d]||b,b="checked"==b||"selected"==b?d:b);b&&T(a,b,c)}f.ga=function(a){return a.i()};f.va=function(){return"goog-control"};f.ae=function(a){var b=this.va(),c=[b],d=this.va();d!=b&&c.push(d);b=a.Z;for(d=[];b;){var e=b&-b;d.push(this.$d(e));b&=~e}c.push.apply(c,d);(a=a.pb)&&c.push.apply(c,a);F&&!H("7")&&c.push.apply(c,ye(c));return c};
function ye(a,b){var c=[];b&&(a=a.concat([b]));Ab([],function(d){!Db(d,oa(Eb,a))||b&&!Eb(d,b)||c.push(d.join("_"))});return c}f.$d=function(a){if(!this.Hg){var b=this.va();b.replace(/\xa0|\s/g," ");this.Hg={1:b+"-disabled",2:b+"-hover",4:b+"-active",8:b+"-selected",16:b+"-checked",32:b+"-focused",64:b+"-open"}}return this.Hg[a]};function Be(a,b,c,d,e){if(!(F||G&&H("525")))return!0;if(Jb&&e)return Ce(a);if(e&&!d)return!1;s(b)&&(b=De(b));if(!c&&(17==b||18==b||Jb&&91==b))return!1;if(G&&d&&c)switch(a){case 220:case 219:case 221:case 192:case 186:case 189:case 187:case 188:case 190:case 191:case 192:case 222:return!1}if(F&&d&&b==a)return!1;switch(a){case 13:return!0;case 27:return!G}return Ce(a)}
function Ce(a){if(48<=a&&57>=a||96<=a&&106>=a||65<=a&&90>=a||G&&0==a)return!0;switch(a){case 32:case 63:case 107:case 109:case 110:case 111:case 186:case 59:case 189:case 187:case 61:case 188:case 190:case 191:case 192:case 222:case 219:case 220:case 221:return!0;default:return!1}}function De(a){if(Ob)a=Ee(a);else if(Jb&&G)a:switch(a){case 93:a=91;break a}return a}
function Ee(a){switch(a){case 61:return 187;case 59:return 186;case 173:return 189;case 224:return 91;case 0:return 224;default:return a}};function Fe(a,b){Mc.call(this);a&&Ge(this,a,b)}v(Fe,Mc);f=Fe.prototype;f.u=null;f.ue=null;f.Jf=null;f.ve=null;f.Oa=-1;f.Tb=-1;f.bf=!1;
var He={3:13,12:144,63232:38,63233:40,63234:37,63235:39,63236:112,63237:113,63238:114,63239:115,63240:116,63241:117,63242:118,63243:119,63244:120,63245:121,63246:122,63247:123,63248:44,63272:46,63273:36,63275:35,63276:33,63277:34,63289:144,63302:45},Ie={Up:38,Down:40,Left:37,Right:39,Enter:13,F1:112,F2:113,F3:114,F4:115,F5:116,F6:117,F7:118,F8:119,F9:120,F10:121,F11:122,F12:123,"U+007F":46,Home:36,End:35,PageUp:33,PageDown:34,Insert:45},Je=F||G&&H("525"),Ke=Jb&&Ob;f=Fe.prototype;
f.bj=function(a){G&&(17==this.Oa&&!a.ctrlKey||18==this.Oa&&!a.altKey||Jb&&91==this.Oa&&!a.metaKey)&&(this.Tb=this.Oa=-1);-1==this.Oa&&(a.ctrlKey&&17!=a.keyCode?this.Oa=17:a.altKey&&18!=a.keyCode?this.Oa=18:a.metaKey&&91!=a.keyCode&&(this.Oa=91));Je&&!Be(a.keyCode,this.Oa,a.shiftKey,a.ctrlKey,a.altKey)?this.handleEvent(a):(this.Tb=De(a.keyCode),Ke&&(this.bf=a.altKey))};f.cj=function(a){this.Tb=this.Oa=-1;this.bf=a.altKey};
f.handleEvent=function(a){var b=a.Bb,c,d,e=b.altKey;F&&"keypress"==a.type?(c=this.Tb,d=13!=c&&27!=c?b.keyCode:0):G&&"keypress"==a.type?(c=this.Tb,d=0<=b.charCode&&63232>b.charCode&&Ce(c)?b.charCode:0):Nb?(c=this.Tb,d=Ce(c)?b.keyCode:0):(c=b.keyCode||this.Tb,d=b.charCode||0,Ke&&(e=this.bf),Jb&&63==d&&224==c&&(c=191));var g=c=De(c),h=b.keyIdentifier;c?63232<=c&&c in He?g=He[c]:25==c&&a.shiftKey&&(g=9):h&&h in Ie&&(g=Ie[h]);a=g==this.Oa;this.Oa=g;b=new Le(g,d,a,b);b.altKey=e;this.dispatchEvent(b)};
f.i=function(){return this.u};function Ge(a,b,c){a.ve&&a.detach();a.u=b;a.ue=O(a.u,"keypress",a,c);a.Jf=O(a.u,"keydown",a.bj,c,a);a.ve=O(a.u,"keyup",a.cj,c,a)}f.detach=function(){this.ue&&(Ic(this.ue),Ic(this.Jf),Ic(this.ve),this.ve=this.Jf=this.ue=null);this.u=null;this.Tb=this.Oa=-1};f.V=function(){Fe.m.V.call(this);this.detach()};function Le(a,b,c,d){wc.call(this,d);this.type="key";this.keyCode=a;this.charCode=b;this.repeat=c}v(Le,wc);function U(a,b,c){ae.call(this,c);if(!b){b=this.constructor;for(var d;b;){d=ha(b);if(d=re[d])break;b=b.m?b.m.constructor:null}b=d?u(d.Ob)?d.Ob():new d:null}this.F=b;this.Lj(void 0!==a?a:null)}v(U,ae);f=U.prototype;f.zb=null;f.Z=0;f.T=39;f.ri=255;f.Fd=0;f.ba=!0;f.pb=null;f.od=!0;f.$e=!1;f.Cj=null;f.ga=function(){return this.F.ga(this)};f.fe=function(){return this.wa||(this.wa=new Fe)};
f.ed=function(a,b){b?a&&(this.pb?Eb(this.pb,a)||this.pb.push(a):this.pb=[a],this.F.ed(this,a,!0)):a&&this.pb&&Fb(this.pb,a)&&(0==this.pb.length&&(this.pb=null),this.F.ed(this,a,!1))};f.G=function(){var a=this.F.G(this);this.u=a;ze(this.F,a,this.ie());this.$e||this.F.ag(a,!1);this.v()||this.F.H(a,!1)};f.ie=function(){return this.Cj};f.fb=function(){return this.F.fb(this.i())};
f.na=function(){U.m.na.call(this);this.F.qd(this);if(this.T&-2&&(this.od&&Me(this,!0),this.T&32)){var a=this.ga();if(a){var b=this.fe();Ge(b,a);ee(this).B(b,"key",this.hb).B(a,"focus",this.ke).B(a,"blur",this.md)}}};
function Me(a,b){var c=ee(a),d=a.i();b?(c.B(d,"mouseover",a.Ef).B(d,"mousedown",a.Hc).B(d,"mouseup",a.pd).B(d,"mouseout",a.Df),a.nd!=ba&&c.B(d,"contextmenu",a.nd),F&&c.B(d,"dblclick",a.jh)):(c.Xa(d,"mouseover",a.Ef).Xa(d,"mousedown",a.Hc).Xa(d,"mouseup",a.pd).Xa(d,"mouseout",a.Df),a.nd!=ba&&c.Xa(d,"contextmenu",a.nd),F&&c.Xa(d,"dblclick",a.jh))}f.Va=function(){U.m.Va.call(this);this.wa&&this.wa.detach();this.v()&&this.isEnabled()&&this.F.qc(this,!1)};
f.V=function(){U.m.V.call(this);this.wa&&(this.wa.k(),delete this.wa);delete this.F;this.pb=this.zb=null};f.Lj=function(a){this.zb=a};f.xf=function(){var a=this.zb;if(!a)return"";if(!q(a))if(ea(a))a=Cb(a,Hd).join("");else{if(qd&&"innerText"in a)a=a.innerText.replace(/(\r\n|\r|\n)/g,"\n");else{var b=[];Id(a,b,!0);a=b.join("")}a=a.replace(/ \xAD /g," ").replace(/\xAD/g,"");a=a.replace(/\u200B/g,"");qd||(a=a.replace(/ +/g," "));" "!=a&&(a=a.replace(/^\s*/,""))}return Za(a)};
f.Cd=function(a){U.m.Cd.call(this,a);var b=this.i();b&&this.F.Cd(b,a)};f.ag=function(a){this.$e=a;var b=this.i();b&&this.F.ag(b,a)};f.v=function(){return this.ba};f.H=function(a,b){if(b||this.ba!=a&&this.dispatchEvent(a?"show":"hide")){var c=this.i();c&&this.F.H(c,a);this.isEnabled()&&this.F.qc(this,a);this.ba=a;return!0}return!1};f.isEnabled=function(){return!(this.Z&1)};
f.Bd=function(a){var b=this.getParent();b&&"function"==typeof b.isEnabled&&!b.isEnabled()||!Ne(this,1,!a)||(a||(this.setActive(!1),this.jb(!1)),this.v()&&this.F.qc(this,a),this.kb(1,!a,!0))};f.jb=function(a){Ne(this,2,a)&&this.kb(2,a)};f.setActive=function(a){Ne(this,4,a)&&this.kb(4,a)};f.te=function(){return!!(this.Z&8)};f.Mj=function(){Ne(this,8,!0)&&this.kb(8,!0)};function Oe(a,b){Ne(a,16,b)&&a.kb(16,b)}f.tb=function(){return!!(this.Z&64)};function Pe(a,b){Ne(a,64,b)&&a.kb(64,b)}
f.kb=function(a,b,c){c||1!=a?this.T&a&&b!=!!(this.Z&a)&&(this.F.kb(this,a,b),this.Z=b?this.Z|a:this.Z&~a):this.Bd(!b)};f.Ra=function(a,b){if(this.A&&this.Z&a&&!b)throw Error("Component already rendered");!b&&this.Z&a&&this.kb(a,!1);this.T=b?this.T|a:this.T&~a};function Qe(a,b){return!!(a.ri&b)&&!!(a.T&b)}function Ne(a,b,c){return!!(a.T&b)&&!!(a.Z&b)!=c&&(!(a.Fd&b)||a.dispatchEvent(ce(b,c)))&&!a.cd}f.Ef=function(a){!Re(a,this.i())&&this.dispatchEvent("enter")&&this.isEnabled()&&Qe(this,2)&&this.jb(!0)};
f.Df=function(a){!Re(a,this.i())&&this.dispatchEvent("leave")&&(Qe(this,4)&&this.setActive(!1),Qe(this,2)&&this.jb(!1))};f.nd=ba;function Re(a,b){return!!a.relatedTarget&&Cd(b,a.relatedTarget)}f.Hc=function(a){this.isEnabled()&&(Qe(this,2)&&this.jb(!0),!yc(a)||G&&Jb&&a.ctrlKey||(Qe(this,4)&&this.setActive(!0),this.F.Rb(this)&&this.ga().focus()));this.$e||!yc(a)||G&&Jb&&a.ctrlKey||a.preventDefault()};f.pd=function(a){this.isEnabled()&&(Qe(this,2)&&this.jb(!0),this.Z&4&&this.wd(a)&&Qe(this,4)&&this.setActive(!1))};
f.jh=function(a){this.isEnabled()&&this.wd(a)};f.wd=function(a){Qe(this,16)&&Oe(this,!(this.Z&16));Qe(this,8)&&this.Mj();Qe(this,64)&&Pe(this,!this.tb());var b=new qc("action",this);a&&(b.altKey=a.altKey,b.ctrlKey=a.ctrlKey,b.metaKey=a.metaKey,b.shiftKey=a.shiftKey,b.Tf=a.Tf);return this.dispatchEvent(b)};f.ke=function(){Qe(this,32)&&Ne(this,32,!0)&&this.kb(32,!0)};f.md=function(){Qe(this,4)&&this.setActive(!1);Qe(this,32)&&Ne(this,32,!1)&&this.kb(32,!1)};
f.hb=function(a){return this.v()&&this.isEnabled()&&this.fc(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};f.fc=function(a){return 13==a.keyCode&&this.wd(a)};if(!u(U))throw Error("Invalid component class "+U);if(!u(ue))throw Error("Invalid renderer class "+ue);var Se=ha(U);re[Se]=ue;qe("goog-control",function(){return new U(null)});function Te(){this.Ig=[]}v(Te,ue);ca(Te);function Ue(a,b){var c=a.Ig[b];if(!c){switch(b){case 0:c=a.va()+"-highlight";break;case 1:c=a.va()+"-checkbox";break;case 2:c=a.va()+"-content"}a.Ig[b]=c}return c}f=Te.prototype;f.Yd=function(){return"menuitem"};f.G=function(a){var b=a.gb().G("div",this.ae(a).join(" "),Ve(this,a.zb,a.gb()));We(this,a,b,!!(a.T&8)||!!(a.T&16));return b};f.fb=function(a){return a&&a.firstChild};function Ve(a,b,c){a=Ue(a,2);return c.G("div",a,b)}
f.Oh=function(a,b,c){a&&b&&We(this,a,b,c)};f.bg=function(a,b,c){a&&b&&We(this,a,b,c)};function We(a,b,c,d){ze(a,c,b.ie());xe(b,c);var e;if(e=a.fb(c)){e=e.firstChild;var g=Ue(a,1);e=!!e&&ga(e)&&1==e.nodeType&&le(e,g)}else e=!1;d!=e&&(d?me(c,"goog-option"):oe(c,"goog-option"),c=a.fb(c),d?(a=Ue(a,1),c.insertBefore(b.gb().G("div",a),c.firstChild||null)):c.removeChild(c.firstChild))}
f.$d=function(a){switch(a){case 2:return Ue(this,0);case 16:case 8:return"goog-option-selected";default:return Te.m.$d.call(this,a)}};f.va=function(){return"goog-menuitem"};function Xe(a,b,c,d){U.call(this,a,d||Te.Ob(),c);this.Sa(b)}v(Xe,U);f=Xe.prototype;f.Gc=function(){var a=this.Ae;return null!=a?a:this.xf()};f.Sa=function(a){this.Ae=a};f.Ra=function(a,b){Xe.m.Ra.call(this,a,b);switch(a){case 8:this.Z&16&&!b&&Oe(this,!1);var c=this.i();c&&this.F.Oh(this,c,b);break;case 16:(c=this.i())&&this.F.bg(this,c,b)}};f.Oh=function(a){this.Ra(8,a)};f.bg=function(a){this.Ra(16,a)};
f.xf=function(){var a=this.zb;return ea(a)?(a=Cb(a,function(a){return ga(a)&&1==a.nodeType&&(le(a,"goog-menuitem-accel")||le(a,"goog-menuitem-mnemonic-separator"))?"":Hd(a)}).join(""),Za(a)):Xe.m.xf.call(this)};f.pd=function(a){var b=this.getParent();if(b){var c=b.Eh;b.Eh=null;if(b=c&&s(a.clientX))b=new kd(a.clientX,a.clientY),b=c==b?!0:c&&b?c.x==b.x&&c.y==b.y:!1;if(b)return}Xe.m.pd.call(this,a)};f.fc=function(a){return a.keyCode==this.xh&&this.wd(a)?!0:Xe.m.fc.call(this,a)};f.Ui=function(){return this.xh};
qe("goog-menuitem",function(){return new Xe(null)});Xe.prototype.ie=function(){return this.T&16?"menuitemcheckbox":this.T&8?"menuitemradio":Xe.m.ie.call(this)};Xe.prototype.getParent=function(){return U.prototype.getParent.call(this)};Xe.prototype.ge=function(){return U.prototype.ge.call(this)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ye(a){this.n=a;this.g=I("g",{},null);this.Te=I("path",{"class":"blocklyPathDark",transform:"translate(1, 1)"},this.g);this.Ib=I("path",{"class":"blocklyPath"},this.g);this.Ue=I("path",{"class":"blocklyPathLight"},this.g);this.Ib.Ea=this.n;Ze(this.Ib);af(this)}Ye.prototype.height=0;Ye.prototype.width=0;Ye.prototype.M=function(){var a=this.n;this.vc();for(var b=0,c;c=a.R[b];b++)c.M();a.Be&&a.Be.qk()};function af(a){a.n.Fb&&!C?bf(a.g,"blocklyDraggable"):cf(a.g,"blocklyDraggable")}
Ye.prototype.X=function(){return this.g};var df=7*(1-Math.SQRT1_2)+1,ef=9*(1-Math.SQRT1_2)-1,ff="m "+df+","+df,gf="a 9,9 0 0,0 "+(-ef-1)+","+(8-ef),hf="a 9,9 0 0,0 "+(8-ef)+","+(ef+1);f=Ye.prototype;f.k=function(){L(this.g);this.n=this.Te=this.Ue=this.Ib=this.g=null};function jf(a){var b=(new Date-a.hg)/150;1<b?L(a):(a.setAttribute("transform","translate("+(a.Wh+(w?-1:1)*a.Bg.width/2*b+", "+(a.Xh+a.Bg.height*b))+") scale("+(1-b)+")"),window.setTimeout(function(){jf(a)},10))}
function kf(a){var b=(new Date-a.hg)/150;1<b?L(a):(a.setAttribute("r",25*b),a.style.opacity=1-b,window.setTimeout(function(){kf(a)},10))}
f.vc=function(){if(!this.n.disabled){var a=lf(mf(this.n.jf)),b,c;c=a;if(!nf.test(c))throw Error("'"+c+"' is not a valid hex color");4==c.length&&(c=c.replace(of,"#$1$1$2$2$3$3"));c=c.toLowerCase();b=[parseInt(c.substr(1,2),16),parseInt(c.substr(3,2),16),parseInt(c.substr(5,2),16)];c=pf([255,255,255],b,.3);b=pf([0,0,0],b,.4);this.Ue.setAttribute("stroke",lf(c));this.Te.setAttribute("fill",lf(b));this.Ib.setAttribute("fill",a)}};
function qf(a){a.n.disabled||rf(a.n)?(bf(a.g,"blocklyDisabled"),a.Ib.setAttribute("fill","url(#blocklyDisabledPattern)")):(cf(a.g,"blocklyDisabled"),a.vc());a=a.n.ec();for(var b=0,c;c=a[b];b++)qf(c.j)}f.Ye=function(){bf(this.g,"blocklySelected");this.g.parentNode.appendChild(this.g)};f.Ne=function(){cf(this.g,"blocklySelected")};
f.w=function(){this.n.K=!0;var a=10;w&&(a=-a);for(var b=sf(this.n),c=0;c<b.length;c++){var d=b[c];d.n.isCollapsed()?d.Ia.setAttribute("display","none"):(d.Ia.setAttribute("display","block"),w&&(a-=16),d.Ia.setAttribute("transform","translate("+a+", 5)"),tf(d),a=w?a-10:a+26)}var e=a+=w?10:-10,g=this.n.R,b=[];b.S=e+20;if(this.n.C||this.n.I)b.S=Math.max(b.S,40);for(var d=c=0,h=!1,k=!1,l=!1,m=void 0,p=this.n.rd&&!this.n.isCollapsed(),r=0,t;t=g[r];r++)if(t.v()){var A;p&&m&&3!=m&&3!=t.type?A=b[b.length-
1]:(m=t.type,A=[],A.type=p&&3!=t.type?-1:t.type,A.height=0,b.push(A));A.push(t);t.mc=25;t.qa=p&&1==t.type?20.5:0;if(t.p&&t.p.o){var ja=uf(B(t.p));t.mc=Math.max(t.mc,ja.height);t.qa=Math.max(t.qa,ja.width)}r==g.length-1&&t.mc--;A.height=Math.max(A.height,t.mc);t.eb=0;1==b.length&&(t.eb+=w?-e:e);for(var ja=!1,$e=0,$a;$a=t.ua[$e];$e++){0!=$e&&(t.eb+=10);var qh=$a.ih();$a.qa=qh.width;$a.Oe=ja&&$a.xc?10:0;t.eb+=$a.qa+$a.Oe;A.height=Math.max(A.height,qh.height);ja=$a.xc}-1!=A.type&&(3==A.type?(k=!0,d=Math.max(d,
t.eb)):(1==A.type?h=!0:5==A.type&&(l=!0),c=Math.max(c,t.eb)))}for(e=0;A=b[e];e++)if(A.Th=!1,-1==A.type)for(g=0;t=A[g];g++)if(1==t.type){A.height+=10;A.Th=!0;break}b.Re=20+d;k&&(b.S=Math.max(b.S,b.Re+30));h?b.S=Math.max(b.S,c+20+8):l&&(b.S=Math.max(b.S,c+20));b.gj=h;b.Bk=k;b.Ak=l;d=a;this.n.J?this.gg=this.Qe=!0:(this.gg=this.Qe=!1,this.n.C&&(a=B(this.n.C))&&Ha(a)==this.n&&(this.Qe=!0),Ha(this.n)&&(this.gg=!0));h=z(this.n);k=[];l=[];a=[];c=[];t=b.S;this.Qe?(k.push("m 0,0"),a.push("m 1,1")):(k.push("m 0,8"),
a.push(w?ff:"m 1,7"),k.push("A 8,8 0 0,1 8,0"),a.push("A 7,7 0 0,1 8,1"));this.n.C&&(k.push("H",15),a.push("H",15),k.push("l 6,4 3,0 6,-4"),a.push("l 6.5,4 2,0 6.5,-4"),this.n.C.moveTo(h.x+(w?-30:30),h.y));k.push("H",t);a.push("H",t+(w?-1:0));this.width=t;for(A=t=0;e=b[A];A++){p=10;0==A&&(p+=w?-d:d);a.push("M",b.S-1+","+(t+1));if(this.n.isCollapsed())g=e[0],r=t+18,vf(g.ua,p,r),k.push("l 8,0 0,4 8,4 -16,8 8,4"),w?a.push("l 8,0 0,3.8 7,3.2 m -14.5,9 l 8,4"):a.push("h 8"),g=e.height-20,k.push("v",g),
w&&a.push("v",g-2),this.width+=15;else if(-1==e.type){for(m=0;g=e[m];m++)r=t+18,e.Th&&(r+=5),p=vf(g.ua,p,r),5!=g.type&&(p+=g.qa+10),1==g.type&&(l.push("M",p-10+","+(t+5)),l.push("h",6-g.qa),l.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),l.push("v",g.mc+1-20),l.push("h",g.qa+2-8),l.push("z"),w?(c.push("M",p-10-3+8-g.qa+","+(t+5+1)),c.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),c.push("v",g.mc-20+3),c.push("h",g.qa-8+1)):(c.push("M",p-10+1+","+(t+5+1)),c.push("v",g.mc+1),c.push("h",
6-g.qa),c.push("M",p-g.qa-10+.8+","+(t+5+20-.4)),c.push("l","3.36,-1.8")),r=w?h.x-p-8+10+g.qa+1:h.x+p+8-10-g.qa-1,ja=h.y+t+5+1,g.p.moveTo(r,ja),g.p.o&&wf(g.p));p=Math.max(p,b.S);this.width=Math.max(this.width,p);k.push("H",p);a.push("H",p+(w?-1:0));k.push("v",e.height);w&&a.push("v",e.height-2)}else 1==e.type?(g=e[0],r=t+18,-1!=g.align&&(m=b.S-g.eb-8-20,1==g.align?p+=m:0==g.align&&(p+=(m+p)/2)),vf(g.ua,p,r),k.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),m=e.height-20,k.push("v",m),w?(a.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),
a.push("v",m)):(a.push("M",b.S-4.2+","+(t+20-.4)),a.push("l","3.36,-1.8")),r=h.x+(w?-b.S-1:b.S+1),ja=h.y+t,g.p.moveTo(r,ja),g.p.o&&(wf(g.p),this.width=Math.max(this.width,b.S+uf(B(g.p)).width-8+1))):5==e.type?(g=e[0],r=t+18,-1!=g.align&&(m=b.S-g.eb-20,b.gj&&(m-=8),1==g.align?p+=m:0==g.align&&(p+=(m+p)/2)),vf(g.ua,p,r),k.push("v",e.height),w&&a.push("v",e.height-2)):3==e.type&&(g=e[0],0==A&&(k.push("v",10),w&&a.push("v",9),t+=10),r=t+18,-1!=g.align&&(m=b.Re-g.eb-20,1==g.align?p+=m:0==g.align&&(p+=
(m+p)/2)),vf(g.ua,p,r),p=b.Re+30,k.push("H",p),k.push("l -6,4 -3,0 -6,-4 h -7 a 8,8 0 0,0 -8,8"),k.push("v",e.height-16),k.push("a 8,8 0 0,0 8,8"),k.push("H",b.S),w?(a.push("M",p-30+ef+","+(t+ef)),a.push(gf),a.push("v",e.height-16),a.push("a 9,9 0 0,0 9,9"),a.push("H",b.S-1)):(a.push("M",p-30+ef+","+(t+e.height-ef)),a.push(hf),a.push("H",b.S)),r=h.x+(w?-p:p),ja=h.y+t+1,g.p.moveTo(r,ja),g.p.o&&(wf(g.p),this.width=Math.max(this.width,b.Re+uf(B(g.p)).width)),A==b.length-1||3==b[A+1].type)&&(k.push("v",
10),w&&a.push("v",9),t+=10);t+=e.height}b.length||(t=25,k.push("V",t),w&&a.push("V",t-1));b=t;this.height=b+1;this.n.I&&(k.push("H","30 l -6,4 -3,0 -6,-4"),this.n.I.moveTo(w?h.x-30:h.x+30,h.y+b+1),this.n.I.o&&wf(this.n.I),this.height+=4);this.gg?(k.push("H 0"),w||a.push("M","1,"+b)):(k.push("H",8),k.push("a","8,8 0 0,1 -8,-8"),w||(a.push("M",df+","+(b-df)),a.push("A","7,7 0 0,1 1,"+(b-8))));this.n.J?(this.n.J.moveTo(h.x,h.y),k.push("V",20),k.push("c 0,-10 -8,8 -8,-7.5 s 8,2.5 8,-7.5"),w?(a.push("M",
"-2.4,8.9"),a.push("l","-3.6,-2.1")):(a.push("V",19),a.push("m","-7.36,-1 q -1.52,-5.5 0,-11"),a.push("m","7.36,1 V 1 H 2")),this.width+=8):w||(this.Qe?a.push("V",1):a.push("V",8));k.push("z");b=k.join(" ")+"\n"+l.join(" ");this.Ib.setAttribute("d",b);this.Te.setAttribute("d",b);b=a.join(" ")+"\n"+c.join(" ");this.Ue.setAttribute("d",b);w&&(this.Ib.setAttribute("transform","scale(-1 1)"),this.Ue.setAttribute("transform","scale(-1 1)"),this.Te.setAttribute("transform","translate(1,1) scale(-1 1)"));
(b=this.n.getParent())?b.w():id(window,"resize")};function vf(a,b,c){w&&(b=-b);for(var d=0,e;e=a[d];d++)w?(b-=e.Oe+e.qa,e.X().setAttribute("transform","translate("+b+", "+c+")"),e.qa&&(b-=10)):(e.X().setAttribute("transform","translate("+(b+e.Oe)+", "+c+")"),e.qa&&(b+=e.Oe+e.qa+10));return w?-b:b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function xf(a){this.h=null;this.W=I("g",{},null);this.ad=I("rect",{rx:4,ry:4,x:-5,y:-12,height:16},this.W);this.ya=I("text",{"class":"blocklyText"},this.W);this.Vc={height:25,width:0};this.Ka(a);this.ba=!0}f=xf.prototype;f.clone=function(){yb("There should never be an instance of Field, only its derived classes.")};f.xc=!0;f.M=function(a){if(this.h)throw"Field has already been initialized once.";this.h=a;this.wc();yf(a).appendChild(this.W);this.Of=M(this.W,"mouseup",this,this.Rf);this.Ka(null)};
f.k=function(){this.Of&&(K(this.Of),this.Of=null);this.h=null;L(this.W);this.ad=this.ya=this.W=null};f.wc=function(){this.xc&&(this.h.Cc&&!C?(bf(this.W,"blocklyEditableText"),cf(this.W,"blocklyNoNEditableText"),this.W.style.cursor=this.$h):(bf(this.W,"blocklyNonEditableText"),cf(this.W,"blocklyEditableText"),this.W.style.cursor=""))};f.v=function(){return this.ba};f.H=function(a){this.ba=a;this.X().style.display=a?"block":"none";this.zd()};f.X=function(){return this.W};
f.zd=function(){try{var a=this.ya.getComputedTextLength()}catch(b){a=8*this.ya.childNodes[0].length}this.ad&&this.ad.setAttribute("width",a+10);this.Vc.width=a};f.ih=function(){this.Vc.width||this.zd();return this.Vc};f.rb=function(){return this.Da};f.Ka=function(a){null!==a&&a!==this.Da&&(this.Da=a,zf(this),this.h&&this.h.K&&(this.h.w(),this.h.Ga(),Xc(this.h.s)))};
function zf(a){var b=a.Da;Ad(a.ya);b=b.replace(/\s/g,"\u00a0");w&&b&&(b+="\u200f");b||(b="\u00a0");a.ya.appendChild(document.createTextNode(b));a.Vc.width=0}f.Gc=function(){return this.rb()};f.Sa=function(a){this.Ka(a)};f.Rf=function(a){if(!Lb&&!Mb||0===a.layerX||0===a.layerY)cc(a)||2!=gd&&this.h.Cc&&!C&&Af(this)};f.Uc=function(){};function Bf(a){this.Ag=a}ca(Bf);f=Bf.prototype;f.Yd=function(){return this.Ag};function Cf(a,b){a&&(a.tabIndex=b?0:-1)}f.G=function(a){return a.gb().G("div",this.ae(a).join(" "))};f.fb=function(a){return a};f.qd=function(a){a=a.i();Ud(a,!0,Ob);F&&(a.hideFocus=!0);var b=this.Yd();b&&te(a,b)};f.ga=function(a){return a.i()};f.va=function(){return"goog-container"};f.ae=function(a){var b=this.va(),c=[b,a.Oc==Df?b+"-horizontal":b+"-vertical"];a.isEnabled()||c.push(b+"-disabled");return c};function Ef(){}v(Ef,ue);ca(Ef);Ef.prototype.G=function(a){return a.gb().G("div",this.va())};Ef.prototype.va=function(){return"goog-menuseparator"};function Ff(a,b){U.call(this,null,a||Ef.Ob(),b);this.Ra(1,!1);this.Ra(2,!1);this.Ra(4,!1);this.Ra(32,!1);this.Z=1}v(Ff,U);Ff.prototype.na=function(){Ff.m.na.call(this);var a=this.i();te(a,"separator")};qe("goog-menuseparator",function(){return new Ff});function Gf(a){this.Ag=a||"menu"}v(Gf,Bf);ca(Gf);Gf.prototype.va=function(){return"goog-menu"};Gf.prototype.qd=function(a){Gf.m.qd.call(this,a);a=a.i();T(a,"haspopup","true")};qe("goog-menuseparator",function(){return new Ff});function Hf(a,b,c){ae.call(this,c);this.F=b||Bf.Ob();this.Oc=a||If}v(Hf,ae);var Df="horizontal",If="vertical";f=Hf.prototype;f.Kf=null;f.wa=null;f.F=null;f.Oc=null;f.ba=!0;f.bc=!0;f.vf=!0;f.L=-1;f.Y=null;f.Mc=!1;f.mi=!1;f.Aj=!0;f.xb=null;f.ga=function(){return this.Kf||this.F.ga(this)};f.fe=function(){return this.wa||(this.wa=new Fe(this.ga()))};f.G=function(){this.u=this.F.G(this)};f.fb=function(){return this.F.fb(this.i())};
f.na=function(){Hf.m.na.call(this);R(this,function(a){a.A&&Jf(this,a)},this);var a=this.i();this.F.qd(this);this.H(this.ba,!0);ee(this).B(this,"enter",this.Bf).B(this,"highlight",this.aj).B(this,"unhighlight",this.fj).B(this,"open",this.dj).B(this,"close",this.Yi).B(a,"mousedown",this.Hc).B(td(a),"mouseup",this.Zi).B(a,["mousedown","mouseup","mouseover","mouseout","contextmenu"],this.Xi);this.Rb()&&Kf(this,!0)};
function Kf(a,b){var c=ee(a),d=a.ga();b?c.B(d,"focus",a.ke).B(d,"blur",a.md).B(a.fe(),"key",a.hb):c.Xa(d,"focus",a.ke).Xa(d,"blur",a.md).Xa(a.fe(),"key",a.hb)}f.Va=function(){this.Tc(-1);this.Y&&Pe(this.Y,!1);this.Mc=!1;Hf.m.Va.call(this)};f.V=function(){Hf.m.V.call(this);this.wa&&(this.wa.k(),this.wa=null);this.F=this.Y=this.xb=this.Kf=null};f.Bf=function(){return!0};
f.aj=function(a){var b=je(this,a.target);if(-1<b&&b!=this.L){var c=S(this,this.L);c&&c.jb(!1);this.L=b;c=S(this,this.L);this.Mc&&c.setActive(!0);this.Aj&&this.Y&&c!=this.Y&&(c.T&64?Pe(c,!0):Pe(this.Y,!1))}b=this.i();null!=a.target.i()&&T(b,"activedescendant",a.target.i().id)};f.fj=function(a){a.target==S(this,this.L)&&(this.L=-1);this.i().removeAttribute("aria-activedescendant")};f.dj=function(a){(a=a.target)&&a!=this.Y&&a.getParent()==this&&(this.Y&&Pe(this.Y,!1),this.Y=a)};
f.Yi=function(a){a.target==this.Y&&(this.Y=null)};f.Hc=function(a){this.bc&&(this.Mc=!0);var b=this.ga();b&&Fd(b)&&Gd(b)?b.focus():a.preventDefault()};f.Zi=function(){this.Mc=!1};f.Xi=function(a){var b=Lf(this,a.target);if(b)switch(a.type){case "mousedown":b.Hc(a);break;case "mouseup":b.pd(a);break;case "mouseover":b.Ef(a);break;case "mouseout":b.Df(a);break;case "contextmenu":b.nd(a)}};
function Lf(a,b){if(a.xb)for(var c=a.i();b&&b!==c;){var d=b.id;if(d in a.xb)return a.xb[d];b=b.parentNode}return null}f.ke=function(){};f.md=function(){this.Tc(-1);this.Mc=!1;this.Y&&Pe(this.Y,!1)};f.hb=function(a){return this.isEnabled()&&this.v()&&(0!=ge(this)||this.Kf)&&this.fc(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};
f.fc=function(a){var b=S(this,this.L);if(b&&"function"==typeof b.hb&&b.hb(a)||this.Y&&this.Y!=b&&"function"==typeof this.Y.hb&&this.Y.hb(a))return!0;if(a.shiftKey||a.ctrlKey||a.metaKey||a.altKey)return!1;switch(a.keyCode){case 27:if(this.Rb())this.ga().blur();else return!1;break;case 36:Mf(this);break;case 35:Nf(this);break;case 38:if(this.Oc==If)Of(this);else return!1;break;case 37:if(this.Oc==Df)he(this)?Pf(this):Of(this);else return!1;break;case 40:if(this.Oc==If)Pf(this);else return!1;break;case 39:if(this.Oc==
Df)he(this)?Of(this):Pf(this);else return!1;break;default:return!1}return!0};function Jf(a,b){var c=b.i(),c=c.id||(c.id=de(b));a.xb||(a.xb={});a.xb[c]=b}f.Md=function(a,b){Hf.m.Md.call(this,a,b)};f.yc=function(a,b,c){a.Fd|=2;a.Fd|=64;!this.Rb()&&this.mi||a.Ra(32,!1);a.A&&0!=a.od&&Me(a,!1);a.od=!1;var d=a.getParent()==this?je(this,a):-1;Hf.m.yc.call(this,a,b,c);a.A&&this.A&&Jf(this,a);a=d;-1==a&&(a=ge(this));a==this.L?this.L=Math.min(ge(this)-1,b):a>this.L&&b<=this.L?this.L++:a<this.L&&b>this.L&&this.L--};
f.removeChild=function(a,b){if(a=q(a)?fe(this,a):a){var c=je(this,a);-1!=c&&(c==this.L?(a.jb(!1),this.L=-1):c<this.L&&this.L--);var d=a.i();d&&d.id&&this.xb&&(c=this.xb,d=d.id,d in c&&delete c[d])}c=a=Hf.m.removeChild.call(this,a,b);c.A&&1!=c.od&&Me(c,!0);c.od=!0;return a};f.v=function(){return this.ba};
f.H=function(a,b){if(b||this.ba!=a&&this.dispatchEvent(a?"show":"hide")){this.ba=a;var c=this.i();c&&(Sd(c,a),this.Rb()&&Cf(this.ga(),this.bc&&this.ba),b||this.dispatchEvent(this.ba?"aftershow":"afterhide"));return!0}return!1};f.isEnabled=function(){return this.bc};f.Bd=function(a){this.bc!=a&&this.dispatchEvent(a?"enable":"disable")&&(a?(this.bc=!0,R(this,function(a){a.Yh?delete a.Yh:a.Bd(!0)})):(R(this,function(a){a.isEnabled()?a.Bd(!1):a.Yh=!0}),this.Mc=this.bc=!1),this.Rb()&&Cf(this.ga(),a&&this.ba))};
f.Rb=function(){return this.vf};f.qc=function(a){a!=this.vf&&this.A&&Kf(this,a);this.vf=a;this.bc&&this.ba&&Cf(this.ga(),a)};f.Tc=function(a){(a=S(this,a))?a.jb(!0):-1<this.L&&S(this,this.L).jb(!1)};f.jb=function(a){this.Tc(je(this,a))};function Mf(a){Qf(a,function(a,c){return(a+1)%c},ge(a)-1)}function Nf(a){Qf(a,function(a,c){a--;return 0>a?c-1:a},0)}function Pf(a){Qf(a,function(a,c){return(a+1)%c},a.L)}function Of(a){Qf(a,function(a,c){a--;return 0>a?c-1:a},a.L)}
function Qf(a,b,c){c=0>c?je(a,a.Y):c;var d=ge(a);c=b.call(a,c,d);for(var e=0;e<=d;){var g=S(a,c);if(g&&a.Gg(g)){a.Tc(c);break}e++;c=b.call(a,c,d)}}f.Gg=function(a){return a.v()&&a.isEnabled()&&!!(a.T&2)};function Rf(){}v(Rf,ue);ca(Rf);Rf.prototype.va=function(){return"goog-menuheader"};function Sf(a,b,c){U.call(this,a,c||Rf.Ob(),b);this.Ra(1,!1);this.Ra(2,!1);this.Ra(4,!1);this.Ra(32,!1);this.Z=1}v(Sf,U);qe("goog-menuheader",function(){return new Sf(null)});function Tf(a,b){Hf.call(this,If,b||Gf.Ob(),a);this.qc(!1)}v(Tf,Hf);f=Tf.prototype;f.Ze=!0;f.ni=!1;f.va=function(){return this.F.va()};f.removeItem=function(a){(a=this.removeChild(a,!0))&&a.k()};function Uf(a){a.Ze=!0;a.qc(!0)}f.H=function(a,b,c){(b=Tf.m.H.call(this,a,b))&&a&&this.A&&this.Ze&&this.ga().focus();this.Eh=a&&c&&s(c.clientX)?new kd(c.clientX,c.clientY):null;return b};f.Bf=function(a){this.Ze&&this.ga().focus();return Tf.m.Bf.call(this,a)};
f.Gg=function(a){return(this.ni||a.isEnabled())&&a.v()&&!!(a.T&2)};f.fc=function(a){var b=Tf.m.fc.call(this,a);b||R(this,function(c){!b&&c.Ui&&c.xh==a.keyCode&&(this.isEnabled()&&this.jb(c),b=c.hb(a))},this);return b};
f.Tc=function(a){Tf.m.Tc.call(this,a);if(a=S(this,a)){var b=a.i();a=this.i();var c=Od(b),d=Od(a),e=Xd(a),g=c.x-d.x-e.left,c=c.y-d.y-e.top,d=a.clientHeight-b.offsetHeight,e=a.scrollLeft,h=a.scrollTop,e=e+Math.min(g,Math.max(g-(a.clientWidth-b.offsetWidth),0)),h=h+Math.min(c,Math.max(c-d,0)),b=new kd(e,h);a.scrollLeft=b.x;a.scrollTop=b.y}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Vf(a,b){this.Lc=a;this.gf=b;Wf(this);var c=Xf(this)[0];this.Na=c[1];this.Nd=I("tspan",{},null);this.Nd.appendChild(document.createTextNode(w?Yf+" ":" "+Yf));Vf.m.constructor.call(this,c[0])}v(Vf,xf);var Yf=Kb?"\u25bc":"\u25be";f=Vf.prototype;f.clone=function(){return new Vf(this.Lc,this.gf)};f.$h="default";
function Af(a){Zf(a);for(var b=new Tf,c=Xf(a),d=0;d<c.length;d++){var e=c[d][1],g=new Xe(c[d][0]);g.Sa(e);g.bg(!0);b.Md(g,!0);Oe(g,e==a.Na)}O(b,"action",function(b){if(b=b.target){b=b.Gc();if(a.gf){var c=a.gf(b);void 0!==c&&(b=c)}null!==b&&a.Sa(b)}$f==a&&ag()});ee(b).B(b.i(),"touchstart",function(a){Lf(this,a.target).Hc(a)});ee(b).B(b.i(),"touchend",function(a){Lf(this,a.target).wd(a)});c=wd();d=Ld();e=bg(a.ad);g=a.ad.getBBox();b.w(cg);var h=b.i();bf(h,"blocklyDropdownMenu");var k=Pd(h);e.y=e.y+k.height+
g.height>=c.height+d.y?e.y-k.height:e.y+g.height;w?(e.x+=g.width,e.x+=25,e.x<d.x+k.width&&(e.x=d.x+k.width)):(e.x-=25,e.x>c.width+d.x-k.width&&(e.x=c.width+d.x-k.width));dg(e.x,e.y,c,d);Uf(b);h.focus()}
function Wf(a){a.Uf=null;a.og=null;var b=a.Lc;if(ea(b)&&!(2>b.length)){var c=b.map(function(a){return a[0]}),d=eg(c),e=fg(c,d),g=gg(c,d);if((e||g)&&!(d<=e+g)){e&&(a.Uf=c[0].substring(0,e-1));g&&(a.og=c[0].substr(1-g));c=[];for(d=0;d<b.length;d++){var h=b[d][0],k=b[d][1],h=h.substring(e,h.length-g);c[d]=[h,k]}a.Lc=c}}}function Xf(a){return u(a.Lc)?a.Lc.call(a):a.Lc}f.Gc=function(){return this.Na};f.Sa=function(a){this.Na=a;for(var b=Xf(this),c=0;c<b.length;c++)if(b[c][1]==a){this.Ka(b[c][0]);return}this.Ka(a)};
f.Ka=function(a){this.h&&(this.Nd.style.fill=lf(mf(this.h.jf)));null!==a&&a!==this.Da&&(this.Da=a,zf(this),w?this.ya.insertBefore(this.Nd,this.ya.firstChild):this.ya.appendChild(this.Nd),this.h&&this.h.K&&(this.h.w(),this.h.Ga(),Xc(this.h.s)))};f.k=function(){$f==this&&ag();Vf.m.k.call(this)};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function hg(a,b){null!=a&&this.append.apply(this,arguments)}f=hg.prototype;f.U="";f.set=function(a){this.U=""+a};f.append=function(a,b,c){this.U+=a;if(null!=b)for(var d=1;d<arguments.length;d++)this.U+=arguments[d];return this};f.clear=function(){this.U=""};f.toString=function(){return this.U};function ig(){this.ng="";this.ii=jg}ig.prototype.pe=!0;ig.prototype.je=function(){return this.ng};ig.prototype.toString=function(){return"Const{"+this.ng+"}"};function kg(a){if(a instanceof ig&&a.constructor===ig&&a.ii===jg)return a.ng;yb("expected object of type Const, got '"+a+"'");return"type_error:Const"}var jg={};function lg(){this.Vb="";this.ei=mg}f=lg.prototype;f.pe=!0;f.je=function(){return this.Vb};f.oh=!0;f.be=function(){return 1};f.toString=function(){return"SafeUrl{"+this.Vb+"}"};var mg={};var ng=ub("area base br col command embed hr img input keygen link meta param source track wbr".split(" "));function og(){this.He="";this.di=pg}og.prototype.pe=!0;var pg={};og.prototype.je=function(){return this.He};og.prototype.toString=function(){return"SafeStyle{"+this.He+"}"};function qg(a){var b=new og;b.He=a;return b}var rg=qg("");
function sg(a){var b="",c;for(c in a){if(!/^[-_a-zA-Z0-9]+$/.test(c))throw Error("Name allows only [-_a-zA-Z0-9], got: "+c);var d=a[c];null!=d&&(d instanceof ig?d=kg(d):tg.test(d)||(yb("String value allows only [-.%_!# a-zA-Z0-9], got: "+d),d="zClosurez"),b+=c+":"+d+";")}return b?qg(b):rg}var tg=/^[-.%_!# a-zA-Z0-9]+$/;function ug(){this.Vb="";this.ci=vg;this.bh=null}f=ug.prototype;f.oh=!0;f.be=function(){return this.bh};f.pe=!0;f.je=function(){return this.Vb};f.toString=function(){return"SafeHtml{"+this.Vb+"}"};function wg(a){if(a instanceof ug&&a.constructor===ug&&a.ci===vg)return a.Vb;yb("expected object of type SafeHtml, got '"+a+"'");return"type_error:SafeHtml"}function xg(a){if(a instanceof ug)return a;var b=null;a.oh&&(b=a.be());return yg(cb(a.pe?a.je():String(a)),b)}
var zg=/^[a-zA-Z0-9-]+$/,Ag=ub("action","cite","data","formaction","href","manifest","poster","src"),Bg=ub("link","script","style");
function Cg(a,b,c){if(!zg.test(a))throw Error("Invalid tag name <"+a+">.");if(a.toLowerCase()in Bg)throw Error("Tag name <"+a+"> is not allowed for SafeHtml.");var d=null,e="<"+a;if(b)for(var g in b){if(!zg.test(g))throw Error('Invalid attribute name "'+g+'".');var h=b[g];if(null!=h){if(h instanceof ig)h=kg(h);else if("style"==g.toLowerCase()){if(!ga(h))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof h+" given: "+h);h instanceof og||(h=sg(h));h instanceof
og&&h.constructor===og&&h.di===pg?h=h.He:(yb("expected object of type SafeStyle, got '"+h+"'"),h="type_error:SafeStyle")}else{if(/^on/i.test(g))throw Error('Attribute "'+g+'" requires goog.string.Const value, "'+h+'" given.');if(h instanceof lg)h instanceof lg&&h.constructor===lg&&h.ei===mg?h=h.Vb:(yb("expected object of type SafeUrl, got '"+h+"'"),h="type_error:SafeUrl");else if(g.toLowerCase()in Ag)throw Error('Attribute "'+g+'" requires goog.string.Const or goog.html.SafeUrl value, "'+h+'" given.');
}e+=" "+g+'="'+cb(String(h))+'"'}}void 0!==c?ea(c)||(c=[c]):c=[];!0===ng[a.toLowerCase()]?e+=">":(d=Dg(c),e+=">"+wg(d)+"</"+a+">",d=d.be());(a=b&&b.dir)&&(d=/^(ltr|rtl|auto)$/i.test(a)?0:null);return yg(e,d)}function Dg(a){function b(a){ea(a)?Ab(a,b):(a=xg(a),d+=wg(a),a=a.be(),0==c?c=a:0!=a&&c!=a&&(c=null))}var c=0,d="";Ab(arguments,b);return yg(d,c)}var vg={};function yg(a,b){var c=new ug;c.Vb=a;c.bh=b;return c}var Eg=yg("",0);function Fg(a,b){a.innerHTML=wg(b)};function V(a,b,c){ae.call(this,c);this.ma=b||Gg;this.Ff=a instanceof ug?a:yg(a,null)}v(V,ae);var Hg={};f=V.prototype;f.$f=!1;f.fd=!1;f.Wj=null;f.li=Eg;f.td=!0;f.Td=-1;f.V=function(){V.m.V.call(this);this.uc&&(this.uc.removeNode(this),this.uc=null);this.u=null};
f.re=function(){var a=this.i();if(a){var b=Ig(this);b&&!b.id&&(b.id=de(this)+".label");te(a,"treeitem");T(a,"selected",!1);T(a,"expanded",!1);T(a,"level",this.Ec());b&&T(a,"labelledby",b.id);(a=this.ee())&&te(a,"presentation");(a=this.ce())&&te(a,"presentation");if(a=Jg(this))if(te(a,"group"),a.hasChildNodes())for(a=ge(this),b=1;b<=a;b++){var c=S(this,b-1).i();T(c,"setsize",a);T(c,"posinset",b)}}};
f.G=function(){var a=this.gb(),b=wg(this.pg());var c=a.Ab,a=c.createElement("div");F?(a.innerHTML="<br>"+b,a.removeChild(a.firstChild)):a.innerHTML=b;if(1==a.childNodes.length)b=a.removeChild(a.firstChild);else for(b=c.createDocumentFragment();a.firstChild;)b.appendChild(a.firstChild);this.u=b};f.na=function(){V.m.na.call(this);Hg[de(this)]=this;this.re()};f.Va=function(){V.m.Va.call(this);delete Hg[de(this)]};
f.yc=function(a,b){var c=S(this,b-1),d=S(this,b);V.m.yc.call(this,a,b);a.jc=c;a.ib=d;c?c.ib=a:this.hh=a;d?d.jc=a:this.uh=a;var e=this.Aa();e&&Kg(a,e);Lg(a,this.Ec()+1);if(this.i()&&(this.Yc(),this.Ha())){e=Jg(this);a.i()||a.G();var g=a.i(),h=d&&d.i();e.insertBefore(g,h);this.A&&a.na();d||(c?c.Yc():(Sd(e,!0),this.Hb(this.Ha())))}};f.add=function(a,b){a.getParent()&&a.getParent().removeChild(a);this.yc(a,b?je(this,b):ge(this));return a};
f.removeChild=function(a){var b=this.Aa(),c=b?b.Pa:null;if(c==a||a.contains(c))b.hasFocus()?(this.select(),Oc(this.zj,10,this)):this.select();V.m.removeChild.call(this,a);this.uh==a&&(this.uh=a.jc);this.hh==a&&(this.hh=a.ib);a.jc&&(a.jc.ib=a.ib);a.ib&&(a.ib.jc=a.jc);c=!a.ib;a.uc=null;a.Td=-1;if(b&&(b.removeNode(this),this.A)){b=Jg(this);if(a.A){var d=a.i();b.removeChild(d);a.Va()}c&&(c=S(this,ge(this)-1))&&c.Yc();ie(this)||(b.style.display="none",this.Yc(),this.ee().className=this.Zd())}return a};
f.remove=V.prototype.removeChild;f.zj=function(){this.select()};f.Ec=function(){var a=this.Td;0>a&&(a=(a=this.getParent())?a.Ec()+1:0,Lg(this,a));return a};function Lg(a,b){if(b!=a.Td){a.Td=b;var c=Mg(a);if(c){var d=Ng(a)+"px";he(a)?c.style.paddingRight=d:c.style.paddingLeft=d}R(a,function(a){Lg(a,b+1)})}}f.contains=function(a){for(;a;){if(a==this)return!0;a=a.getParent()}return!1};f.ec=function(){var a=[];R(this,function(b){a.push(b)});return a};f.te=function(){return this.$f};
f.select=function(){var a=this.Aa();a&&a.rc(this)};function Og(a,b){if(a.$f!=b){a.$f=b;Pg(a);var c=a.i();c&&(T(c,"selected",b),b&&(c=a.Aa().i(),T(c,"activedescendant",de(a))))}}f.Ha=function(){return this.fd};
f.Hb=function(a){var b=a!=this.fd;if(!b||this.dispatchEvent(a?"beforeexpand":"beforecollapse")){var c;this.fd=a;c=this.Aa();var d=this.i();if(ie(this)){if(!a&&c&&this.contains(c.Pa)&&this.select(),d){if(c=Jg(this))if(Sd(c,a),a&&this.A&&!c.hasChildNodes()){var e=[];R(this,function(a){e.push(a.pg())});Fg(c,Dg(e));R(this,function(a){a.na()})}this.Yc()}}else(c=Jg(this))&&Sd(c,!1);d&&(this.ee().className=this.Zd(),T(d,"expanded",a));b&&this.dispatchEvent(a?"expand":"collapse")}};f.toggle=function(){this.Hb(!this.Ha())};
f.expand=function(){this.Hb(!0)};f.collapse=function(){this.Hb(!1)};f.Zf=function(){var a=this.getParent();a&&(a.Hb(!0),a.Zf())};f.pg=function(){var a=this.Aa(),b=!a.Ed||a==this.getParent()&&!a.fg?this.ma.Lg:this.ma.Kg,a=this.Ha()&&ie(this),b={"class":b,style:Qg(this)},c=[];a&&R(this,function(a){c.push(a.pg())});a=Cg("div",b,c);return Cg("div",{"class":this.ma.Tg,id:de(this)},[Rg(this),a])};function Ng(a){return Math.max(0,(a.Ec()-1)*a.ma.Hf)}
function Rg(a){var b={};b["padding-"+(he(a)?"right":"left")]=Ng(a)+"px";var b={"class":a.kd(),style:b},c=a.yf(),d=Cg("span",{style:{display:"inline-block"},"class":a.Zd()}),e=Cg("span",{"class":a.ma.Ug,title:a.Wj||null},a.Ff);a=Dg(e,Cg("span",{},a.li));return Cg("div",b,[c,d,a])}f.kd=function(){return this.ma.Xg+(this.te()?" "+this.ma.Wg:"")};f.yf=function(){return Cg("span",{type:"expand",style:{display:"inline-block"},"class":Sg(this)})};
function Sg(a){var b=a.Aa(),c=!b.Ed||b==a.getParent()&&!b.fg,d=a.ma,e=new hg;e.append(d.$b," ",d.Bi," ");if(ie(a)){var g=0;b.eg&&a.td&&(g=a.Ha()?2:1);c||(g=a.ib?g+8:g+4);switch(g){case 1:e.append(d.Fi);break;case 2:e.append(d.Ei);break;case 4:e.append(d.Pg);break;case 5:e.append(d.Di);break;case 6:e.append(d.Ci);break;case 8:e.append(d.Qg);break;case 9:e.append(d.Hi);break;case 10:e.append(d.Gi);break;default:e.append(d.Og)}}else c?e.append(d.Og):a.ib?e.append(d.Qg):e.append(d.Pg);return e.toString()}
function Qg(a){var b=a.Ha()&&ie(a);return sg({"background-position":Tg(a),display:b?null:"none"})}function Tg(a){return(a.ib?(a.Ec()-1)*a.ma.Hf:"-100")+"px 0"}f.i=function(){var a=V.m.i.call(this);a||(this.u=a=this.gb().i(de(this)));return a};function Mg(a){return(a=a.i())?a.firstChild:null}f.ce=function(){var a=Mg(this);return a?a.firstChild:null};f.ee=function(){var a=Mg(this);return a?a.childNodes[1]:null};function Ig(a){return(a=Mg(a))&&a.lastChild?a.lastChild.previousSibling:null}
function Jg(a){return(a=a.i())?a.lastChild:null}f.Ka=function(a){this.Ff=a=xg(a);var b=Ig(this);b&&Fg(b,a);(a=this.Aa())&&Ug(a,this)};f.rb=function(){var a=wg(this.Ff);return D(a,"&")?"document"in n?kb(a):mb(a):a};function Pg(a){var b=Mg(a);b&&(b.className=a.kd())}f.Yc=function(){var a=this.ce();a&&(a.className=Sg(this));if(a=Jg(this))a.style.backgroundPosition=Tg(this)};f.Pf=function(a){"expand"==a.target.getAttribute("type")&&ie(this)?this.td&&this.toggle():(this.select(),Pg(this))};
f.Ah=function(a){"expand"==a.target.getAttribute("type")&&ie(this)||this.td&&this.toggle()};function Vg(a){return a.Ha()&&ie(a)?Vg(S(a,ge(a)-1)):a}function Kg(a,b){a.uc!=b&&(a.uc=b,Ug(b,a),R(a,function(a){Kg(a,b)}))}
var Gg={Hf:19,Vg:"goog-tree-root goog-tree-item",Sg:"goog-tree-hide-root",Tg:"goog-tree-item",Kg:"goog-tree-children",Lg:"goog-tree-children-nolines",Xg:"goog-tree-row",Ug:"goog-tree-item-label",$b:"goog-tree-icon",Bi:"goog-tree-expand-icon",Fi:"goog-tree-expand-icon-plus",Ei:"goog-tree-expand-icon-minus",Hi:"goog-tree-expand-icon-tplus",Gi:"goog-tree-expand-icon-tminus",Di:"goog-tree-expand-icon-lplus",Ci:"goog-tree-expand-icon-lminus",Qg:"goog-tree-expand-icon-t",Pg:"goog-tree-expand-icon-l",Og:"goog-tree-expand-icon-blank",
lf:"goog-tree-expanded-folder-icon",Mg:"goog-tree-collapsed-folder-icon",mf:"goog-tree-file-icon",Rg:"goog-tree-expanded-folder-icon",Ng:"goog-tree-collapsed-folder-icon",Wg:"selected"};function Wg(a,b,c){V.call(this,a,b,c)}v(Wg,V);Wg.prototype.Aa=function(){if(this.uc)return this.uc;var a=this.getParent();return a&&(a=a.Aa())?(Kg(this,a),a):null};Wg.prototype.Zd=function(){var a=this.Ha(),b=this.Pi;if(a&&b)return b;b=this.hj;if(!a&&b)return b;b=this.ma;if(ie(this)){if(a&&b.lf)return b.$b+" "+b.lf;if(!a&&b.Mg)return b.$b+" "+b.Mg}else if(b.mf)return b.$b+" "+b.mf;return""};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Xg={Sd:null,show:function(a,b){Zf(Xg);if(b.length){for(var c=new Tf,d=0,e;e=b[d];d++){var g=new Xe(e.text);c.Md(g,!0);g.Bd(e.enabled);e.enabled&&O(g,"action",function(a){return function(){a()}}(e.bb))}O(c,"action",Xg.Cb);e=wd();g=Ld();c.w(cg);var h=c.i();bf(h,"blocklyContextMenu");var k=Pd(h),d=a.clientX+g.x,l=a.clientY+g.y;a.clientY+k.height>=e.height&&(l-=k.height);w?k.width>=a.clientX&&(d+=k.width):a.clientX+k.width>=e.width&&(d-=k.width);dg(d,l,e,g);Uf(c);setTimeout(function(){h.focus()},
1);Xg.Sd=null}else Xg.Cb()},Cb:function(){$f==Xg&&ag();Xg.Sd=null},nk:function(a,b){return function(){var c=La(a.s,b),d=z(a);d.x=w?d.x-W:d.x+W;d.y+=2*W;c.moveBy(d.x,d.y);c.select()}}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Yg(a,b,c,d,e,g,h){var k=Zg;w&&(k=-k);this.pi=k/360*Math.PI*2;this.t=a;this.zb=b;this.Ph=c;a.Wc.appendChild(this.kf(b,!(!g||!h)));$g(this,d,e);g&&h||(a=this.zb.getBBox(),g=a.width+2*ah,h=a.height+2*ah);this.pc(g,h);bh(this);ch(this);this.Yf=!0;C||(M(this.Pd,"mousedown",this,this.ui),this.Gb&&M(this.Gb,"mousedown",this,this.Ij))}var ah=6,Zg=20,dh=null,eh=null;function fh(){dh&&(K(dh),dh=null);eh&&(K(eh),eh=null)}f=Yg.prototype;f.Yf=!1;f.$a=0;f.cf=0;f.lc=0;f.yd=0;f.D=0;f.oa=0;f.ef=!0;
f.kf=function(a,b){this.ab=I("g",{},null);var c=I("g",{filter:"url(#blocklyEmboss)"},this.ab);this.Cg=I("path",{},c);this.Pd=I("rect",{"class":"blocklyDraggable",x:0,y:0,rx:ah,ry:ah},c);b?(this.Gb=I("g",{"class":w?"blocklyResizeSW":"blocklyResizeSE"},this.ab),c=2*ah,I("polygon",{points:"0,x x,x x,0".replace(/x/g,c.toString())},this.Gb),I("line",{"class":"blocklyResizeLine",x1:c/3,y1:c-1,x2:c-1,y2:c/3},this.Gb),I("line",{"class":"blocklyResizeLine",x1:2*c/3,y1:c-1,x2:c-1,y2:2*c/3},this.Gb)):this.Gb=
null;this.ab.appendChild(a);return this.ab};f.ui=function(a){gh(this);fh();cc(a)||hh(a)||(ih(!0),this.dh=w?this.lc+a.clientX:this.lc-a.clientX,this.Ni=this.yd-a.clientY,dh=M(document,"mouseup",this,fh),eh=M(document,"mousemove",this,this.wi),N(),a.stopPropagation())};f.wi=function(a){this.ef=!1;this.lc=w?this.dh-a.clientX:this.dh+a.clientX;this.yd=this.Ni+a.clientY;bh(this);ch(this)};
f.Ij=function(a){gh(this);fh();cc(a)||(ih(!0),this.Hj=w?this.D+a.clientX:this.D-a.clientX,this.Gj=this.oa-a.clientY,dh=M(document,"mouseup",this,fh),eh=M(document,"mousemove",this,this.Jj),N(),a.stopPropagation())};f.Jj=function(a){this.ef=!1;var b=this.Hj,c=this.Gj+a.clientY,b=w?b-a.clientX:b+a.clientX;this.pc(b,c);w&&bh(this)};function gh(a){a.ab.parentNode.appendChild(a.ab)}function $g(a,b,c){a.$a=b;a.cf=c;a.Yf&&bh(a)}
function bh(a){a.ab.setAttribute("transform","translate("+(w?a.$a-a.lc-a.D:a.$a+a.lc)+", "+(a.yd+a.cf)+")")}f.dc=function(){return{width:this.D,height:this.oa}};
f.pc=function(a,b){var c=2*ah;a=Math.max(a,c+45);b=Math.max(b,c+18);this.D=a;this.oa=b;this.Pd.setAttribute("width",a);this.Pd.setAttribute("height",b);this.Gb&&(w?this.Gb.setAttribute("transform","translate("+2*ah+", "+(b-c)+") scale(-1 1)"):this.Gb.setAttribute("transform","translate("+(a-c)+", "+(b-c)+")"));if(this.Yf){if(this.ef){var c=-this.D/4,d=-this.oa-25,e=this.t.qb();w?this.$a-e.Fa-c-this.D<J?c=this.$a-e.Fa-this.D-J:this.$a-e.Fa-c>e.O&&(c=this.$a-e.Fa-e.O):this.$a+c<e.Fa?c=e.Fa-this.$a:
e.Fa+e.O<this.$a+c+this.D+10+J&&(c=e.Fa+e.O-this.$a-this.D-J);this.cf+d<e.wb&&(d=this.Ph.getBBox().height);this.lc=c;this.yd=d}bh(this);ch(this)}id(this.ab,"resize")};
function ch(a){var b=[],c=a.D/2,d=a.oa/2,e=-a.lc,g=-a.yd;if(c==e&&d==g)b.push("M "+c+","+d);else{g-=d;e-=c;w&&(e*=-1);var h=Math.sqrt(g*g+e*e),k=Math.acos(e/h);0>g&&(k=2*Math.PI-k);var l=k+Math.PI/2;l>2*Math.PI&&(l-=2*Math.PI);var m=Math.sin(l),p=Math.cos(l),r=a.dc(),l=(r.width+r.height)/10,l=Math.min(l,r.width,r.height)/2,r=1-8/h,e=c+r*e,g=d+r*g,r=c+l*p,t=d+l*m,c=c-l*p,d=d-l*m,m=k+a.pi;m>2*Math.PI&&(m-=2*Math.PI);k=Math.sin(m)*h/4;h=Math.cos(m)*h/4;b.push("M"+r+","+t);b.push("C"+(r+h)+","+(t+k)+
" "+e+","+g+" "+e+","+g);b.push("C"+e+","+g+" "+(c+h)+","+(d+k)+" "+c+","+d)}b.push("z");a.Cg.setAttribute("d",b.join(" "))}f.Sc=function(a){this.Pd.setAttribute("fill",a);this.Cg.setAttribute("fill",a)};f.k=function(){fh();L(this.ab);this.Ph=this.zb=this.t=this.ab=null};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function jh(a){this.n=a}f=jh.prototype;f.ha=null;f.Ic=0;f.Jc=0;f.Bc=function(){this.Ia=I("g",{},null);yf(this.n).appendChild(this.Ia);M(this.Ia,"mouseup",this,this.ij);this.wc()};f.k=function(){L(this.Ia);this.Ia=null;this.H(!1);this.n=null};f.wc=function(){this.n.Sb?cf(this.Ia,"blocklyIconGroup"):bf(this.Ia,"blocklyIconGroup")};f.v=function(){return!!this.ha};f.ij=function(){this.n.Sb||this.H(!this.v())};f.vc=function(){if(this.v()){var a=lf(mf(this.n.jf));this.ha.Sc(a)}};
function tf(a){var b=z(a.n),c=kh(a.Ia),d=b.x+c.x+8,b=b.y+c.y+8;if(d!==a.Ic||b!==a.Jc)a.Ic=d,a.Jc=b,a.v()&&$g(a.ha,d,b)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function lh(a,b){this.h=a;this.o=null;this.type=b;this.N=this.mb=0;this.sb=!1;this.Lb=this.h.s.zi}f=lh.prototype;f.k=function(){if(this.o)throw"Disconnect connection before disposing of it.";this.sb&&mh(this.Lb[this.type],this);this.sb=!1;nh==this&&(nh=null);oh==this&&(oh=null)};function ph(a){return 1==a.type||3==a.type}
function Wa(a,b){if(a.h==b.h)throw"Attempted to connect a block to itself.";if(a.h.s!==b.h.s)throw"Blocks are on different workspaces.";if(rh[a.type]!=b.type)throw"Attempt to connect incompatible types.";if(1==a.type||2==a.type){if(a.o)throw"Source connection already connected (value).";if(b.o){var c=B(b);c.Qa(null);if(!c.J)throw"Orphan block does not have an output connection.";for(var d=a.h;d=sh(d,c);)if(B(d))d=B(d);else{Wa(d,c.J);c=null;break}c&&window.setTimeout(function(){th(c.J,b)},uh)}}else{if(a.o)throw"Source connection already connected (block).";
if(b.o){if(4!=a.type)throw"Can only do a mid-stack connection with the top of a block.";c=B(b);c.Qa(null);if(!c.C)throw"Orphan block does not have a previous connection.";for(d=a.h;d.I;)if(d.I.o)d=Ha(d);else{vh(c.C,d.I)&&(Wa(d.I,c.C),c=null);break}c&&window.setTimeout(function(){th(c.C,b)},uh)}}var e;ph(a)?(d=a.h,e=b.h):(d=b.h,e=a.h);a.o=b;b.o=a;e.Qa(d);d.K&&qf(d.j);e.K&&qf(e.j);d.K&&e.K&&(3==a.type||4==a.type?e.w():d.w())}
function sh(a,b){for(var c=!1,d=0;d<a.R.length;d++){var e=a.R[d].p;if(e&&1==e.type&&vh(b.J,e)){if(c)return null;c=e}}return c}f.disconnect=function(){var a=this.o;if(!a)throw"Source connection not connected.";if(a.o!=this)throw"Target connection not connected to source connection.";this.o=a.o=null;var b;ph(this)?(b=this.h,a=a.h):(b=a.h,a=this.h);b.K&&b.w();a.K&&(qf(a.j),a.w())};function B(a){return a.o?a.o.h:null}
function th(a,b){if(0==gd){var c=wh(a.h);if(!c.Sb){var d=!1;if(!c.Fb||C){c=wh(b.h);if(!c.Fb||C)return;b=a;d=!0}yf(c).parentNode.appendChild(yf(c));var e=b.mb+W-a.mb,g=b.N+W-a.N;d&&(g=-g);w&&(e=-e);c.moveBy(e,g)}}}f.moveTo=function(a,b){this.sb&&mh(this.Lb[this.type],this);this.mb=a;this.N=b;xh(this.Lb[this.type],this)};f.moveBy=function(a,b){this.moveTo(this.mb+a,this.N+b)};
f.nh=function(){var a;1==this.type||2==this.type?(a=w?-8:8,a="m 0,0 v 5 c 0,10 "+-a+",-8 "+-a+",7.5 s "+a+",-2.5 "+a+",7.5 v 5"):a=w?"m 20,0 h -5 l -6,4 -3,0 -6,-4 h -5":"m -20,0 h 5 l 6,4 3,0 6,-4 h 5";var b=z(this.h);lh.me=I("path",{"class":"blocklyHighlightedConnectionPath",d:a,transform:"translate("+(this.mb-b.x)+", "+(this.N-b.y)+")"},yf(this.h))};
function wf(a){var b=Math.round(a.o.mb-a.mb),c=Math.round(a.o.N-a.N);if(0!=b||0!=c){a=B(a);var d=yf(a);if(!d)throw"block is not rendered.";d=kh(d);yf(a).setAttribute("transform","translate("+(d.x-b)+", "+(d.y-c)+")");yh(a,-b,-c)}}
function zh(a,b,c,d){function e(a){var c=g[a];if((2==c.type||4==c.type)&&c.o||1==c.type&&c.o&&(!B(c).Fb||C)||!vh(r,c))return!0;c=c.h;do{if(p==c)return!0;c=c.getParent()}while(c);var d=h-g[a].mb,c=k-g[a].N,d=Math.sqrt(d*d+c*c);d<=b&&(m=g[a],b=d);return c<b}if(a.o)return{p:null,Hh:b};var g=a.Lb[rh[a.type]],h=a.mb+c,k=a.N+d;c=0;for(var l=d=g.length-2;c<l;)g[l].N<k?c=l:d=l,l=Math.floor((c+d)/2);d=c=l;var m=null,p=a.h,r=a;if(g.length){for(;0<=c&&e(c);)c--;do d++;while(d<g.length&&e(d))}return{p:m,Hh:b}}
function vh(a,b){if(!a.zc||!b.zc)return!0;for(var c=0;c<a.zc.length;c++)if(-1!=b.zc.indexOf(a.zc[c]))return!0;return!1}f.Rc=function(a){a?(ea(a)||(a=[a]),this.zc=a,this.o&&!vh(this,this.o)&&(ph(this)?B(this).Qa(null):this.h.Qa(null),this.h.Ga())):this.zc=null;return this};
function Ah(a){var b=W;function c(a){var c=e-d[a].mb,h=g-d[a].N;Math.sqrt(c*c+h*h)<=b&&l.push(d[a]);return h<b}var d=a.Lb[rh[a.type]],e=a.mb,g=a.N;a=0;for(var h=d.length-2,k=h;a<k;)d[k].N<g?a=k:h=k,k=Math.floor((a+h)/2);var h=a=k,l=[];if(d.length){for(;0<=a&&c(a);)a--;do h++;while(h<d.length&&c(h))}return l}
function Bh(a){a.sb||xh(a.Lb[a.type],a);var b=[];if(1!=a.type&&3!=a.type)return b;if(a=B(a)){var c;a.isCollapsed()?(c=[],a.J&&c.push(a.J),a.I&&c.push(a.I),a.C&&c.push(a.C)):c=Ch(a,!0);for(var d=0;d<c.length;d++)b.push.apply(b,Bh(c[d]));0==b.length&&(b[0]=a)}return b}function Wc(){}Wc.prototype=[];function xh(a,b){if(b.sb)throw"Connection already in database.";for(var c=0,d=a.length;c<d;){var e=Math.floor((c+d)/2);if(a[e].N<b.N)c=e+1;else if(a[e].N>b.N)d=e;else{c=e;break}}a.splice(c,0,b);b.sb=!0}
function mh(a,b){if(!b.sb)throw"Connection not in database.";b.sb=!1;for(var c=0,d=a.length-2,e=d;c<e;)a[e].N<b.N?c=e:d=e,e=Math.floor((c+d)/2);for(d=c=e;0<=c&&a[c].N==b.N;){if(a[c]==b){a.splice(c,1);return}c--}do{if(a[d]==b){a.splice(d,1);return}d++}while(d<a.length&&a[d].N==b.N);throw"Unable to find connection in connectionDB.";};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Hh={fk:function(a){var b={M:function(){var b=this;this.Sc(a.ok);this.Qb=a.Qb;"string"==typeof a.Ea?this.Uc(a.Ea):"function"==typeof a.Ea&&this.Uc(function(){return a.Ea(b)});"undefined"!=a.Bj?Dh(this,a.Bj):(Eh(this,"undefined"==typeof a.Dj?!0:a.Dj),Fh(this,"undefined"==typeof a.uj?!0:a.uj));var d=[];d.push(a.text);a.oi&&a.oi.forEach(function(a){"undefined"==a.type||1==a.type?d.push([a.name,a.check,"undefined"==typeof a.align?1:a.align]):yb("addTemplate() can only handle value inputs.")});d.push(1);
a.lj&&this.Qk(a.lj);Gh.prototype.sd.apply(this,d)}};b.Nc=a.Sk?function(){var b=a.rj?a.Hk():document.createElement("mutation");b.setAttribute("is_statement",this.isStatement||!1);return b}:a.rj;Hh[a.jk]=b}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ih(a){Ih.m.constructor.call(this,a);this.Bc()}v(Ih,jh);f=Ih.prototype;f.Da="";f.D=160;f.oa=80;f.Bc=function(){jh.prototype.Bc.call(this);I("circle",{"class":"blocklyIconShield",r:8,cx:8,cy:8},this.Ia);this.Gf=I("text",{"class":"blocklyIconMark",x:8,y:13},this.Ia);this.Gf.appendChild(document.createTextNode("?"))};f.wc=function(){this.v()&&(this.H(!1),this.H(!0));jh.prototype.wc.call(this)};
f.Fj=function(){var a=this.ha.dc(),b=2*ah;this.hd.setAttribute("width",a.width-b);this.hd.setAttribute("height",a.height-b);this.La.style.width=a.width-b-4+"px";this.La.style.height=a.height-b-4+"px"};
f.H=function(a){if(a!=this.v())if((!this.n.Cc||C)&&!this.La||F)Jh.prototype.H.call(this,a);else{var b=this.rb(),c=this.dc();if(a){a=this.n.s;this.hd=I("foreignObject",{x:ah,y:ah},null);var d=document.createElementNS("http://www.w3.org/1999/xhtml","body");d.setAttribute("xmlns","http://www.w3.org/1999/xhtml");d.className="blocklyMinimalBody";this.La=document.createElementNS("http://www.w3.org/1999/xhtml","textarea");this.La.className="blocklyCommentTextarea";this.La.setAttribute("dir",w?"RTL":"LTR");
d.appendChild(this.La);this.hd.appendChild(d);M(this.La,"mouseup",this,this.Vj);this.ha=new Yg(a,this.hd,this.n.j.Ib,this.Ic,this.Jc,this.D,this.oa);M(this.ha.ab,"resize",this,this.Fj);this.vc();this.Da=null}else this.ha.k(),this.hd=this.La=this.ha=null;this.Ka(b);this.pc(c.width,c.height)}};f.Vj=function(){gh(this.ha);this.La.focus()};f.dc=function(){return this.v()?this.ha.dc():{width:this.D,height:this.oa}};f.pc=function(a,b){this.La?this.ha.pc(a,b):(this.D=a,this.oa=b)};
f.rb=function(){return this.La?this.La.value:this.Da};f.Ka=function(a){this.La?this.La.value=a:this.Da=a};f.k=function(){this.n.za=null;jh.prototype.k.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Kh=!1,Lh=0,Mh=0,Nh={x:0,y:0},Oh=null,Ph=null,Qh=null,Rh=null,Sh=null,Th=null;function Uh(){var a=I("g",{"class":"blocklyHidden"},null);Qh=a;Th=I("rect",{"class":"blocklyTooltipShadow",x:2,y:2},a);Sh=I("rect",{"class":"blocklyTooltipBackground"},a);Rh=I("text",{"class":"blocklyTooltipText"},a);return a}function Ze(a){M(a,"mouseover",null,Vh);M(a,"mouseout",null,Wh);M(a,"mousemove",null,Xh)}
function Vh(a){for(a=a.target;!q(a.Ea)&&!u(a.Ea);)a=a.Ea;Oh!=a&&(Yh(),Ph=null,Oh=a);window.clearTimeout(Lh)}function Wh(){Lh=window.setTimeout(function(){Ph=Oh=null;Yh()},1);window.clearTimeout(Mh)}function Xh(a){Oh&&Oh.Ea&&0==gd&&!$f&&(Kh?(a=dc(a),10<Math.sqrt(Math.pow(Nh.x-a.x,2)+Math.pow(Nh.y-a.y,2))&&Yh()):Ph!=Oh&&(window.clearTimeout(Mh),Nh=dc(a),Mh=window.setTimeout(Zh,1E3)))}function Yh(){Kh&&(Kh=!1,Qh&&(Qh.style.display="none"));window.clearTimeout(Mh)}
function Zh(){Ph=Oh;if(Qh){Ad(Rh);var a=Oh.Ea;u(a)&&(a=a());var b=a,a=50;if(b.length<=a)a=b;else{for(var c=b.trim().split(/\s+/),d=0;d<c.length;d++)c[d].length>a&&(a=c[d].length);var e,d=-Infinity,g,h=1;do{e=d;g=b;for(var b=[],k=c.length/h,l=1,d=0;d<c.length-1;d++)l<(d+1.5)/k?(l++,b[d]=!0):b[d]=!1;for(var b=$h(c,b,a),d=ai(c,b,a),k=c,l=[],m=0;m<k.length;m++)l.push(k[m]),void 0!==b[m]&&l.push(b[m]?"\n":" ");b=l.join("");h++}while(d>e);a=g}a=a.split("\n");for(c=0;c<a.length;c++)I("tspan",{dy:"1em",x:5},
Rh).appendChild(document.createTextNode(a[c]));Kh=!0;Qh.style.display="block";a=Rh.getBBox();c=10+a.width;e=a.height;Sh.setAttribute("width",c);Sh.setAttribute("height",e);Th.setAttribute("width",c);Th.setAttribute("height",e);if(w)for(e=a.width,g=0;h=Rh.childNodes[g];g++)h.setAttribute("text-anchor","end"),h.setAttribute("x",e+5);e=Nh.x;e=w?e-(0+c):e+0;c=Nh.y+10;g=bi();c+a.height>g.height&&(c-=a.height+20);w?e=Math.max(5,e):e+a.width>g.width-10&&(e=g.width-a.width-10);Qh.setAttribute("transform",
"translate("+e+","+c+")")}}function ai(a,b,c){for(var d=[0],e=[],g=0;g<a.length;g++)d[d.length-1]+=a[g].length,!0===b[g]?(d.push(0),e.push(a[g].charAt(a[g].length-1))):!1===b[g]&&d[d.length-1]++;a=Math.max.apply(Math,d);for(g=b=0;g<d.length;g++)b-=2*Math.pow(Math.abs(c-d[g]),1.5),b-=Math.pow(a-d[g],1.5),-1!=".?!".indexOf(e[g])?b+=c/3:-1!=",;)]}".indexOf(e[g])&&(b+=c/4);1<d.length&&d[d.length-1]<=d[d.length-2]&&(b+=.5);return b}
function $h(a,b,c){for(var d=ai(a,b,c),e,g=0;g<b.length-1;g++)if(b[g]!=b[g+1]){var h=[].concat(b);h[g]=!h[g];h[g+1]=!h[g+1];var k=ai(a,h,c);k>d&&(d=k,e=h)}return e?$h(a,e,c):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ci(a){this.h=null;this.ya=I("text",{"class":"blocklyText"},null);this.Vc={height:25,width:0};this.Ka(a)}v(ci,xf);f=ci.prototype;f.clone=function(){return new ci(this.rb())};f.xc=!1;f.M=function(a){if(this.h)throw"Text has already been initialized once.";this.h=a;yf(a).appendChild(this.ya);this.ya.Ea=this.h;Ze(this.ya)};f.k=function(){L(this.ya);this.ya=null};f.X=function(){return this.ya};f.Uc=function(a){this.ya.Ea=a};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function di(a,b,c,d){this.type=a;this.name=b;this.h=c;this.p=d;this.ua=[];this.align=-1;this.ba=!0}function ei(a,b,c){if(!b&&!c)return a;q(b)&&(b=new ci(b));a.h.j&&b.M(a.h);b.name=c;b.Uf&&ei(a,b.Uf);a.ua.push(b);b.og&&ei(a,b.og);a.h.K&&(a.h.w(),a.h.Ga());return a}f=di.prototype;f.v=function(){return this.ba};
f.H=function(a){var b=[];if(this.ba==a)return b;for(var c=(this.ba=a)?"block":"none",d=0,e;e=this.ua[d];d++)e.H(a);if(this.p){if(a)b=Bh(this.p);else if(d=this.p,d.sb&&mh(d.Lb[d.type],d),d.o){e=fi(B(d));for(var g=0;g<e.length;g++){for(var h=e[g],k=Ch(h,!0),l=0;l<k.length;l++){var m=k[l];m.sb&&mh(d.Lb[m.type],m)}h=sf(h);for(k=0;k<h.length;k++)h[k].H(!1)}}if(d=B(this.p))d.j.X().style.display=c,a||(d.K=!1)}return b};
f.Rc=function(a){if(!this.p)throw"This input does not have a connection.";this.p.Rc(a);return this};function gi(a,b){a.align=b;a.h.K&&a.h.w();return a}f.M=function(){for(var a=0;a<this.ua.length;a++)this.ua[a].M(this.h)};f.k=function(){for(var a=0,b;b=this.ua[a];a++)b.k();this.p&&this.p.k();this.h=null};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Jh(a){Jh.m.constructor.call(this,a);this.Bc()}v(Jh,jh);f=Jh.prototype;f.Da="";f.Bc=function(){jh.prototype.Bc.call(this);I("path",{"class":"blocklyIconShield",d:"M 2,15 Q -1,15 0.5,12 L 6.5,1.7 Q 8,-1 9.5,1.7 L 15.5,12 Q 17,15 14,15 z"},this.Ia);this.Gf=I("text",{"class":"blocklyIconMark",x:8,y:13},this.Ia);this.Gf.appendChild(document.createTextNode("!"))};
f.H=function(a){if(a!=this.v())if(a){var b=this.Da;a=I("text",{"class":"blocklyText blocklyBubbleText",y:ah},null);for(var b=b.split("\n"),c=0;c<b.length;c++)I("tspan",{dy:"1em",x:ah},a).appendChild(document.createTextNode(b[c]));this.ha=new Yg(this.n.s,a,this.n.j.Ib,this.Ic,this.Jc,null,null);if(w)for(var b=a.getBBox().width,c=0,d;d=a.childNodes[c];c++)d.setAttribute("text-anchor","end"),d.setAttribute("x",b+ah);this.vc();a=this.ha.dc();this.ha.pc(a.width,a.height)}else this.ha.k(),this.ha=null};
f.Ka=function(a){this.Da!=a&&(this.Da=a,this.v()&&(this.H(!1),this.H(!0)))};f.k=function(){this.n.Kd=null;jh.prototype.k.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var hi=0;function Gh(){}function Na(a,b){if($c)return ii.create(Gh,a,b);var c=new Gh;c.initialize(a,b);return c}f=Gh.prototype;f.initialize=function(a,b){var c=(++hi).toString();this.id=$c?ji(c):c;Zc(a,this);this.fill(a,b);u(this.onchange)&&M(a.$,"blocklyWorkspaceChange",this,this.onchange)};
f.fill=function(a,b){this.C=this.I=this.J=null;this.R=[];this.disabled=this.K=this.rd=!1;this.Ea="";this.contextMenu=!0;this.Pc=null;this.ob=[];this.Cc=this.Fb=this.ac=!0;this.Zb=!1;this.s=a;this.Sb=a.sh;if(b){this.type=b;var c=Hh[b],d;for(d in c)this[d]=c[d]}u(this.M)&&this.M()};function Ma(a,b){return $c?ki.get(a):dd(b,a)}f.j=null;f.Be=null;f.za=null;f.Kd=null;function sf(a){var b=[];a.Be&&b.push(a.Be);a.za&&b.push(a.za);a.Kd&&b.push(a.Kd);return b}
function Oa(a){a.j=new Ye(a);a.j.M();C||M(a.j.X(),"mousedown",a,a.De);a.s.$.appendChild(a.j.X())}function yf(a){return a.j&&a.j.X()}var gd=0,li=null,mi=null;f=Gh.prototype;f.select=function(){Q&&hd(Q);Q=this;this.j.Ye();id(this.s.$,"blocklySelectChange")};function hd(a){Q=null;a.j.Ne();id(a.s.$,"blocklySelectChange")}
f.k=function(a,b,c){this.K=!1;var d;d=!1;if(this.J)this.J.o&&this.Qa(null);else{var e=null;this.C&&this.C.o&&(e=this.C.o,this.Qa(null));var g=Ha(this);a&&g&&(a=this.I.o,g.Qa(null),e&&Wa(e,a))}d&&this.moveBy(W*(w?-1:1),2*W);b&&this.j&&(d=this.j,ni("delete"),b=ec(d.g),d=d.g.cloneNode(!0),d.Wh=b.x,d.Xh=b.y,d.setAttribute("transform","translate("+d.Wh+","+d.Xh+")"),x.appendChild(d),d.Bg=d.getBBox(),d.hg=new Date,jf(d));this.s&&!c&&(bd(this.s,this),this.s=null);Q==this&&(Q=null,oi());Xg.Sd==this&&Xg.Cb();
for(c=this.ob.length-1;0<=c;c--)this.ob[c].k(!1);b=sf(this);for(c=0;c<b.length;c++)b[c].k();for(c=0;b=this.R[c];c++)b.k();this.R=[];b=Ch(this,!0);for(c=0;c<b.length;c++)d=b[c],d.o&&d.disconnect(),b[c].k();this.j&&(this.j.k(),this.j=null);if($c&&!pi)ki["delete"](this.id.toString())};function z(a){var b=0,c=0;if(a.j){var d=a.j.X();do var e=kh(d),b=b+e.x,c=c+e.y,d=d.parentNode;while(d&&d!=a.s.$)}return{x:b,y:c}}
f.moveBy=function(a,b){var c=z(this);this.j.X().setAttribute("transform","translate("+(c.x+a)+", "+(c.y+b)+")");yh(this,a,b);qi(this)};function uf(a){var b=a.j.height,c=a.j.width;if(a=Ha(a))a=uf(a),b+=a.height-4,c=Math.max(c,a.width);return{height:b,width:c}}
f.De=function(a){if(!this.Sb){ri();oi();this.select();N();if(cc(a))si(this,a);else if(this.Fb&&!C){fc();ih(!0);var b=z(this);this.Rh=b.x;this.Sh=b.y;this.jg=a.clientX;this.kg=a.clientY;gd=1;li=M(document,"mouseup",this,this.Rf);mi=M(document,"mousemove",this,this.Qf);this.Wd=[];for(var b=fi(this),c=0,d;d=b[c];c++){d=sf(d);for(var e=0;e<d.length;e++){var g;g=d[e];g={x:g.Ic,y:g.Jc};g.ti=d[e];this.Wd.push(g)}}}else return;a.stopPropagation()}};
f.Rf=function(){var a=this;ti(function(){oi();if(Q&&nh){Wa(oh,nh);if(a.j){var b=(ph(oh)?nh:oh).h.j;ni("click");var c=ec(b.g);b.n.J?(c.x+=w?3:-3,c.y+=13):b.n.C&&(c.x+=w?-23:23,c.y+=3);b=I("circle",{cx:c.x,cy:c.y,r:0,fill:"none",stroke:"#888","stroke-width":10},x);b.hg=new Date;kf(b)}a.s.Ma&&a.s.Ma.tb&&a.s.Ma.close()}else a.s.Ma&&a.s.Ma.tb&&(b=a.s.Ma,Oc(b.close,100,b),Q.k(!1,!0),id(window,"resize"));nh&&(L(lh.me),delete lh.me,nh=null)})};
function si(a,b){if(!C&&a.contextMenu){var c=[];if(a.ac&&!C&&a.Fb&&!C&&!a.Sb){var d={text:ui,enabled:!0,bb:function(){var b=Ga(a);Xa(b);var b=La(a.s,b),c=z(a);c.x=w?c.x-W:c.x+W;c.y+=2*W;b.moveBy(c.x,c.y);b.select()}};fi(a).length>jd(a.s)&&(d.enabled=!1);c.push(d);a.Cc&&!C&&!a.Zb&&sa&&(d={enabled:!0},a.za?(d.text=vi,d.bb=function(){Ta(a,null)}):(d.text=wi,d.bb=function(){Ta(a,"")}),c.push(d));if(!a.Zb)for(d=0;d<a.R.length;d++)if(1==a.R[d].type){d={enabled:!0};d.text=a.rd?xi:yi;d.bb=function(){Pa(a,
!a.rd)};c.push(d);break}ta&&(a.Zb?(d={enabled:!0},d.text=zi,d.bb=function(){a.Ad(!1)}):(d={enabled:!0},d.text=Ai,d.bb=function(){a.Ad(!0)}),c.push(d));ua&&(d={text:a.disabled?Bi:Ci,enabled:!rf(a),bb:function(){Qa(a,!a.disabled)}},c.push(d));var d=fi(a).length,e=Ha(a);e&&(d-=fi(e).length);d={text:1==d?Di:Ei.replace("%1",String(d)),enabled:!0,bb:function(){a.k(!0,!0)}};c.push(d)}d={enabled:!(u(a.Qb)?!a.Qb():!a.Qb)};d.text=Fi;d.bb=function(){var b=u(a.Qb)?a.Qb():a.Qb;b&&window.open(b)};c.push(d);a.Ii&&
!a.Sb&&a.Ii(c);Xg.show(b,c);Xg.Sd=a}}function Ch(a,b){var c=[];if(b||a.K)if(a.J&&c.push(a.J),a.I&&c.push(a.I),a.C&&c.push(a.C),b||!a.Zb)for(var d=0,e;e=a.R[d];d++)e.p&&c.push(e.p);return c}function yh(a,b,c){if(a.K){for(var d=Ch(a,!1),e=0;e<d.length;e++)d[e].moveBy(b,c);d=sf(a);for(e=0;e<d.length;e++)tf(d[e]);for(e=0;e<a.ob.length;e++)yh(a.ob[e],b,c)}}function Gi(a,b){b?bf(a.j.g,"blocklyDragging"):cf(a.j.g,"blocklyDragging");for(var c=0;c<a.ob.length;c++)Gi(a.ob[c],b)}
f.Qf=function(a){var b=this;ti(function(){if(!("mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button)){fc();var c=a.clientX-b.jg,d=a.clientY-b.kg;1==gd&&Math.sqrt(Math.pow(c,2)+Math.pow(d,2))>Hi&&(gd=2,b.Qa(null),Gi(b,!0));if(2==gd){b.j.X().setAttribute("transform","translate("+(b.Rh+c)+", "+(b.Sh+d)+")");for(var e=0;e<b.Wd.length;e++){var g=b.Wd[e],h=g.ti,k=g.x+c,g=g.y+d;h.Ic=k;h.Jc=g;h.v()&&$g(h.ha,k,g)}for(var h=Ch(b,!1),g=k=null,l=W,e=0;e<h.length;e++){var m=h[e],p=zh(m,l,c,d);p.p&&(k=
p.p,g=m,l=p.Hh)}nh&&nh!=k&&(L(lh.me),delete lh.me,oh=nh=null);k&&k!=nh&&(k.nh(),nh=k,oh=g);b.s.Ma&&b.ac&&!C&&(c=b.s.Ma,c.g&&(d=dc(a),e=ec(c.g),d=d.x>e.x-c.Ld&&d.x<e.x+c.$c+c.Ld&&d.y>e.y-c.Ld&&d.y<e.y+c.We+c.Zc+c.Ld,c.tb!=d&&Uc(c,d)))}}a.stopPropagation()})};f.Ga=function(){if(0==gd){var a=wh(this);if(!a.Sb)for(var b=Ch(this,!1),c=0;c<b.length;c++){var d=b[c];d.o&&ph(d)&&B(d).Ga();for(var e=Ah(d),g=0;g<e.length;g++){var h=e[g];d.o&&h.o||wh(h.h)!=a&&(ph(d)?th(h,d):th(d,h))}}}};f.getParent=function(){return this.Pc};
function Ii(a){for(;;){do{var b=a;a=a.getParent();if(!a)return null}while(Ha(a)==b);return a}}function Ha(a){return a.I&&B(a.I)}function wh(a){var b=a;do a=b,b=a.Pc;while(b);return a}f.ec=function(){return this.ob};
f.Qa=function(a){if(this.Pc){for(var b=this.Pc.ob,c,d=0;c=b[d];d++)if(c==this){b.splice(d,1);break}b=z(this);this.s.$.appendChild(this.j.X());this.j.X().setAttribute("transform","translate("+b.x+", "+b.y+")");this.Pc=null;this.C&&this.C.o&&this.C.disconnect();this.J&&this.J.o&&this.J.disconnect()}else Eb(Fa(this.s,!1),this)&&bd(this.s,this);(this.Pc=a)?(a.ob.push(this),b=z(this),a.j&&this.j&&a.j.X().appendChild(this.j.X()),a=z(this),yh(this,a.x-b.x,a.y-b.y)):Zc(this.s,this)};
function fi(a){for(var b=[a],c,d=0;c=a.ob[d];d++)b.push.apply(b,fi(c));return b}function Ra(a,b){a.ac=b;a.j&&af(a.j)}function Sa(a,b){a.Cc=b;for(var c=0,d;d=a.R[c];c++)for(var e=0,g;g=d.ua[e];e++)g.wc();d=sf(a);for(c=0;c<d.length;c++)d[c].wc()}f.Sc=function(a){this.jf=a;this.j&&this.j.vc();var b=sf(this);for(a=0;a<b.length;a++)b[a].vc();if(this.K){for(a=0;b=this.R[a];a++)for(var c=0,d;d=b.ua[c];c++)d.Ka(null);this.w()}};
function Ua(a,b){for(var c=0,d;d=a.R[c];c++)for(var e=0,g;g=d.ua[e];e++)if(g.name===b)return g;return null}f.Uc=function(a){this.Ea=a};function Eh(a,b){var c;a.C&&(a.C.k(),a.C=null);b&&(void 0===c&&(c=null),a.C=new lh(a,4),a.C.Rc(c));a.K&&(a.w(),a.Ga())}function Fh(a,b){var c;a.I&&(a.I.k(),a.I=null);b&&(void 0===c&&(c=null),a.I=new lh(a,3),a.I.Rc(c));a.K&&(a.w(),a.Ga())}function Dh(a,b){a.J&&(a.J.k(),a.J=null);void 0===b&&(b=null);a.J=new lh(a,2);a.J.Rc(b);a.K&&(a.w(),a.Ga())}
function Pa(a,b){a.rd=b;a.K&&(a.w(),a.Ga(),Xc(a.s))}function Qa(a,b){a.disabled!=b&&(a.disabled=b,qf(a.j),Xc(a.s))}function rf(a){for(;;){a=Ii(a);if(!a)return!1;if(a.disabled)return!0}}f.isCollapsed=function(){return this.Zb};
f.Ad=function(a){if(this.Zb!=a){this.Zb=a;for(var b=[],c=0,d;d=this.R[c];c++)b.push.apply(b,d.H(!a));if(a){a=sf(this);for(c=0;c<a.length;c++)a[c].H(!1);c=this.toString(Ji);ei(Ki(this,5,"_TEMP_COLLAPSED_INPUT"),c)}else a:{for(c=0;a=this.R[c];c++)if("_TEMP_COLLAPSED_INPUT"==a.name){a.p&&a.p.o&&B(a.p).Qa(null);a.k();this.R.splice(c,1);this.K&&(this.w(),this.Ga());break a}yb('Input "%s" not found.',"_TEMP_COLLAPSED_INPUT")}b.length||(b[0]=this);if(this.K){for(c=0;a=b[c];c++)a.w();this.Ga()}}};
f.toString=function(a){for(var b=[],c=0,d;d=this.R[c];c++){for(var e=0,g;g=d.ua[e];e++)b.push(g.rb());d.p&&((d=B(d.p))?b.push(d.toString()):b.push("?"))}b=ab(b.join(" "))||"???";a&&b.length>a&&(b=b.substring(0,a-3)+"...");return b};
f.sd=function(a,b){function c(a){a instanceof xf?ei(this,a):ei(this,a[1],a[0])}var d=arguments[arguments.length-1];--arguments.length;for(var e=a.split(this.sd.gi),g=[],h=0;h<e.length;h+=2){var k=ab(e[h]),l=void 0;k&&g.push(new ci(k));if((k=e[h+1])&&"%"==k.charAt(0)){var k=parseInt(k.substring(1),10),m=arguments[k];m[1]instanceof xf?g.push([m[0],m[1]]):l=gi(Ki(this,1,m[0]).Rc(m[1]),m[2]);arguments[k]=null}else"\n"==k&&g.length&&(l=Ki(this,5,""));l&&g.length&&(g.forEach(c,l),g=[])}g.length&&(l=gi(Ki(this,
5,""),d),g.forEach(c,l));for(h=1;h<arguments.length-1;h++);Pa(this,!a.match(this.sd.ai))};f.sd.gi=/(%\d+|\n)/;f.sd.ai=/%1\s*$/;function Ki(a,b,c){var d=null;if(1==b||3==b)d=new lh(a,b);b=new di(b,c,a,d);a.R.push(b);a.K&&(a.w(),a.Ga());return b}function Va(a,b){for(var c=0,d;d=a.R[c];c++)if(d.name==b)return d;return null}function Ta(a,b){var c=!1;q(b)?(a.za||(a.za=new Ih(a),c=!0),a.za.Ka(b)):a.za&&(a.za.k(),c=!0);a.K&&(a.w(),c&&a.Ga())}f.w=function(){this.j.w();qi(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Li(){var a=this;this.t=new Vc(function(){return Mi(a)},function(b){var c=Mi(a);c&&(s(b.y)&&(a.t.scrollY=-c.Ua*b.y-c.cb),a.t.$.setAttribute("transform","translate(0,"+(a.t.scrollY+c.Za)+")"))});this.t.sh=!0;this.eh=[];this.oa=this.D=0;this.ff=[];this.ub=[]}var Ni,Oi,Pi,Qi,Ri,Si;f=Li.prototype;f.Od=!0;f.sa=8;f.G=function(){this.g=I("g",{},null);this.Wa=I("path",{"class":"blocklyFlyoutBackground"},this.g);this.g.appendChild(this.t.G());return this.g};
f.k=function(){this.Cb();K(this.eh);this.eh.length=0;this.nc&&(this.nc.k(),this.nc=null);this.t=null;this.g&&(L(this.g),this.g=null);this.Gd=this.Wa=null};function Mi(a){if(!a.v())return null;var b=a.oa-2*a.sa,c=a.D;try{var d=a.t.$.getBBox()}catch(e){d={height:0,y:0}}return{ra:b,O:c,Ua:d.height+d.y,wb:-a.t.scrollY,cb:0,Za:a.sa,Ya:0}}
f.M=function(a){this.Gd=a;this.nc=new Xb(this.t,!1,!1);this.Cb();M(window,"resize",this,this.xd);this.xd();M(this.g,"wheel",this,this.Zh);M(this.g,"mousewheel",this,this.Zh);M(this.Gd.$,"blocklyWorkspaceChange",this,this.sf);M(this.g,"mousedown",this,this.De)};
f.xd=function(){if(this.v()){var a=this.Gd.qb();if(a){var b=this.D-this.sa;w&&(b*=-1);var c=["M "+(w?this.D:0)+",0"];c.push("h",b);c.push("a",this.sa,this.sa,0,0,w?0:1,w?-this.sa:this.sa,this.sa);c.push("v",Math.max(0,a.ra-2*this.sa));c.push("a",this.sa,this.sa,0,0,w?0:1,w?this.sa:-this.sa,this.sa);c.push("h",-b);c.push("z");this.Wa.setAttribute("d",c.join(" "));b=a.Ya;w&&(b+=a.O,b-=this.D);this.g.setAttribute("transform","translate("+b+","+a.Za+")");this.oa=a.ra;this.nc&&this.nc.resize()}}};
f.Zh=function(a){var b=a.deltaY||-a.wheelDeltaY;if(b){Ob&&(b*=10);var c=Mi(this),b=c.wb+b,b=Math.min(b,c.Ua-c.ra),b=Math.max(b,0);this.nc.set(b);a.preventDefault()}};f.v=function(){return this.g&&"block"==this.g.style.display};f.Cb=function(){if(this.v()){this.g.style.display="none";for(var a=0,b;b=this.ub[a];a++)K(b);this.ub.length=0;this.Xf&&(K(this.Xf),this.Xf=null)}};
f.show=function(a){this.Cb();for(var b=Fa(this.t,!1),c=0,d;d=b[c];c++)d.s==this.t&&d.k(!1,!1);for(var c=0,e;e=this.ff[c];c++)L(e);this.ff.length=0;var g=this.sa;this.g.style.display="block";var b=[],h=[];if(a==Ti)Ui(b,h,g,this.t);else if(a==Vi)Wi(b,h,g,this.t);else for(var k=0;d=a[k];k++)d.tagName&&"BLOCK"==d.tagName.toUpperCase()&&(d=La(this.t,d),b.push(d),h.push(3*g));a=g;for(k=0;d=b[k];k++){c=fi(d);e=0;for(var l;l=c[e];e++)l.Sb=!0,Ta(l,null);d.w();l=yf(d);e=uf(d);c=w?0:g+8;d.moveBy(c,a);a+=e.height+
h[k];e=I("rect",{"fill-opacity":0},null);this.t.$.insertBefore(e,yf(d));d.gd=e;this.ff[k]=e;this.Od?this.ub.push(M(l,"mousedown",null,Xi(this,d))):this.ub.push(M(l,"mousedown",null,Yi(this,d)));this.ub.push(M(l,"mouseover",d.j,d.j.Ye));this.ub.push(M(l,"mouseout",d.j,d.j.Ne));this.ub.push(M(e,"mousedown",null,Xi(this,d)));this.ub.push(M(e,"mouseover",d.j,d.j.Ye));this.ub.push(M(e,"mouseout",d.j,d.j.Ne))}this.ub.push(M(this.Wa,"mouseover",this,function(){for(var a=Fa(this.t,!1),b=0,c;c=a[b];b++)c.j.Ne()}));
this.D=0;this.Ih();this.sf();Zi(window,"resize");this.Xf=M(this.t.$,"blocklyWorkspaceChange",this,this.Ih);Xc(this.t)};f.Ih=function(){for(var a=0,b=this.sa,c=Fa(this.t,!1),d=0,e;e=c[d];d++)var g=uf(e),a=Math.max(a,g.width);a+=b+8+b/2+J;if(this.D!=a){for(d=0;e=c[d];d++){var g=uf(e),h=z(e);if(w){var k=a-b-8-h.x;e.moveBy(k,0);h.x+=k}e.gd&&(e.gd.setAttribute("width",g.width),e.gd.setAttribute("height",g.height),e.gd.setAttribute("x",w?h.x-g.width:h.x),e.gd.setAttribute("y",h.y))}this.D=a;id(window,"resize")}};
Gh.prototype.moveTo=function(a,b){var c=z(this);this.j.X().setAttribute("transform","translate("+a+", "+b+")");yh(this,a-c.x,b-c.y)};function Yi(a,b){return function(c){oi();N();cc(c)?si(b,c):(fc(),ih(!0),Ni=c,Oi=b,Pi=a,Qi=M(document,"mouseup",this,oi),Ri=M(document,"mousemove",this,a.xj));c.stopPropagation()}}Li.prototype.De=function(a){cc(a)||(N(!0),$i(),this.Qh=a.clientY,Si=M(document,"mousemove",this,this.Qf),Qi=M(document,"mouseup",this,$i),a.preventDefault(),a.stopPropagation())};
Li.prototype.Qf=function(a){var b=a.clientY-this.Qh;this.Qh=a.clientY;a=Mi(this);b=a.wb-b;b=Math.min(b,a.Ua-a.ra);b=Math.max(b,0);this.nc.set(b)};Li.prototype.xj=function(a){"mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button?a.stopPropagation():(fc(),Math.sqrt(Math.pow(a.clientX-Ni.clientX,2)+Math.pow(a.clientY-Ni.clientY,2))>Hi&&Xi(Pi,Oi)(Ni))};
function Xi(a,b){return function(c){if(!cc(c)&&!b.disabled){var d=Ga(b),d=La(a.Gd,d),e=yf(b);if(!e)throw"originBlock is not rendered.";var e=ec(e),g=yf(d);if(!g)throw"block is not rendered.";g=ec(g);d.moveBy(e.x-g.x,e.y-g.y);a.Od?a.Cb():a.sf();d.De(c)}}}Li.prototype.sf=function(){for(var a=jd(this.Gd),b=Fa(this.t,!1),c=0,d;d=b[c];c++){var e=fi(d).length>a;Qa(d,e)}};function $i(){Qi&&(K(Qi),Qi=null);Ri&&(K(Ri),Ri=null);Si&&(K(Si),Si=null);Qi&&(K(Qi),Qi=null);Pi=Oi=Ni=null};function aj(a){if("function"==typeof a.Af)return a.Af();if(q(a))return a.split("");if(fa(a)){for(var b=[],c=a.length,d=0;d<c;d++)b.push(a[d]);return b}b=[];c=0;for(d in a)b[c++]=a[d];return b};function bj(a){this.Na=void 0;this.ta={};if(a){var b;if("function"==typeof a.zf)b=a.zf();else if("function"!=typeof a.Af)if(fa(a)||q(a)){b=[];for(var c=a.length,d=0;d<c;d++)b.push(d)}else for(d in b=[],c=0,a)b[c++]=d;else b=void 0;a=aj(a);for(c=0;c<b.length;c++)this.set(b[c],a[c])}}f=bj.prototype;f.set=function(a,b){cj(this,a,b,!1)};f.add=function(a,b){cj(this,a,b,!0)};
function cj(a,b,c,d){for(var e=0;e<b.length;e++){var g=b.charAt(e);a.ta[g]||(a.ta[g]=new bj);a=a.ta[g]}if(d&&void 0!==a.Na)throw Error('The collection already contains the key "'+b+'"');a.Na=c}f.get=function(a){a:{for(var b=this,c=0;c<a.length;c++)if(b=b.ta[a.charAt(c)],!b){a=void 0;break a}a=b}return a?a.Na:void 0};f.Af=function(){var a=[];dj(this,a);return a};function dj(a,b){void 0!==a.Na&&b.push(a.Na);for(var c in a.ta)dj(a.ta[c],b)}
f.zf=function(a){var b=[];if(a){for(var c=this,d=0;d<a.length;d++){var e=a.charAt(d);if(!c.ta[e])return[];c=c.ta[e]}ej(c,a,b)}else ej(this,"",b);return b};function ej(a,b,c){void 0!==a.Na&&c.push(b);for(var d in a.ta)ej(a.ta[d],b+d,c)}f.clear=function(){this.ta={};this.Na=void 0};
f.remove=function(a){for(var b=this,c=[],d=0;d<a.length;d++){var e=a.charAt(d);if(!b.ta[e])throw Error('The collection does not have the key "'+a+'"');c.push([b,e]);b=b.ta[e]}a=b.Na;for(delete b.Na;0<c.length;)if(e=c.pop(),b=e[0],e=e[1],b.ta[e].rh())delete b.ta[e];else break;return a};f.clone=function(){return new bj(this)};f.rh=function(){var a;if(a=void 0===this.Na)a:{a=this.ta;for(var b in a){a=!1;break a}a=!0}return a};function fj(){this.hc=new bj}f=fj.prototype;f.U="";f.Mf=null;f.ze=null;f.vd=0;f.Kc=0;function gj(a,b){var c=!1,d=a.hc.zf(b);d&&d.length&&(a.Kc=0,a.vd=0,c=a.hc.get(d[0]),c=hj(a,c))&&(a.Mf=d);return c}function hj(a,b){var c;b&&(a.Kc<b.length&&(c=b[a.Kc],a.ze=b),c&&(c.Zf(),c.select()));return!!c}f.clear=function(){this.U=""};function ij(a){var b;b||(b=jj(a||arguments.callee.caller,[]));return b}
function jj(a,b){var c=[];if(Eb(b,a))c.push("[...circular reference...]");else if(a&&50>b.length){c.push(kj(a)+"(");for(var d=a.arguments,e=0;d&&e<d.length;e++){0<e&&c.push(", ");var g;g=d[e];switch(typeof g){case "object":g=g?"object":"null";break;case "string":break;case "number":g=String(g);break;case "boolean":g=g?"true":"false";break;case "function":g=(g=kj(g))?g:"[fn]";break;default:g=typeof g}40<g.length&&(g=g.substr(0,40)+"...");c.push(g)}b.push(a);c.push(")\n");try{c.push(jj(a.caller,b))}catch(h){c.push("[exception trying to get caller]\n")}}else a?
c.push("[...long stack...]"):c.push("[end]");return c.join("")}function kj(a){if(lj[a])return lj[a];a=String(a);if(!lj[a]){var b=/function ([^\(]+)/.exec(a);lj[a]=b?b[1]:"[Anonymous]"}return lj[a]}var lj={};function mj(a,b,c,d,e){this.reset(a,b,c,d,e)}mj.prototype.gh=null;mj.prototype.fh=null;var nj=0;mj.prototype.reset=function(a,b,c,d,e){"number"==typeof e||nj++;d||pa();this.ud=a;this.qj=b;delete this.gh;delete this.fh};mj.prototype.Mh=function(a){this.ud=a};function oj(a){this.yh=a;this.mh=this.Q=this.ud=this.xa=null}function pj(a,b){this.name=a;this.value=b}pj.prototype.toString=function(){return this.name};var qj=new pj("WARNING",900),rj=new pj("INFO",800),sj=new pj("CONFIG",700),tj=new pj("FINE",500);f=oj.prototype;f.getName=function(){return this.yh};f.getParent=function(){return this.xa};f.ec=function(){this.Q||(this.Q={});return this.Q};f.Mh=function(a){this.ud=a};
function uj(a){if(a.ud)return a.ud;if(a.xa)return uj(a.xa);yb("Root logger has no level set.");return null}f.log=function(a,b,c){if(a.value>=uj(this).value)for(u(b)&&(b=b()),a=this.Ti(a,b,c,oj.prototype.log),b="log:"+a.qj,n.console&&(n.console.timeStamp?n.console.timeStamp(b):n.console.markTimeline&&n.console.markTimeline(b)),n.msWriteProfilerMark&&n.msWriteProfilerMark(b),b=this;b;){c=b;var d=a;if(c.mh)for(var e=0,g=void 0;g=c.mh[e];e++)g(d);b=b.getParent()}};
f.Ti=function(a,b,c,d){var e=new mj(a,String(b),this.yh);if(c){var g;g=d||arguments.callee.caller;e.gh=c;var h;try{var k;var l=aa("window.location.href");if(q(c))k={message:c,name:"Unknown error",lineNumber:"Not available",fileName:l,stack:"Not available"};else{var m,p,r=!1;try{m=c.lineNumber||c.Fk||"Not available"}catch(t){m="Not available",r=!0}try{p=c.fileName||c.filename||c.sourceURL||n.$googDebugFname||l}catch(A){p="Not available",r=!0}k=!r&&c.lineNumber&&c.fileName&&c.stack&&c.message&&c.name?
c:{message:c.message||"Not available",name:c.name||"UnknownError",lineNumber:m,fileName:p,stack:c.stack||"Not available"}}h="Message: "+cb(k.message)+'\nUrl: <a href="view-source:'+k.fileName+'" target="_new">'+k.fileName+"</a>\nLine: "+k.lineNumber+"\n\nBrowser stack:\n"+cb(k.stack+"-> ")+"[end]\n\nJS stack traversal:\n"+cb(ij(g)+"-> ")}catch(ja){h="Exception trying to expose exception! You win, we lose. "+ja}e.fh=h}return e};f.Kd=function(a,b){this.log(qj,a,b)};
f.info=function(a,b){this.log(rj,a,b)};var vj={},wj=null;function xj(a){wj||(wj=new oj(""),vj[""]=wj,wj.Mh(sj));var b;if(!(b=vj[a])){b=new oj(a);var c=a.lastIndexOf("."),d=a.substr(c+1),c=xj(a.substr(0,c));c.ec()[d]=b;b.xa=c;vj[a]=b}return b};function yj(a){Mc.call(this);this.u=a;a=F?"focusout":"blur";this.oj=O(this.u,F?"focusin":"focus",this,!F);this.pj=O(this.u,a,this,!F)}v(yj,Mc);yj.prototype.handleEvent=function(a){var b=new wc(a.Bb);b.type="focusin"==a.type||"focus"==a.type?"focusin":"focusout";this.dispatchEvent(b)};yj.prototype.V=function(){yj.m.V.call(this);Ic(this.oj);Ic(this.pj);delete this.u};function zj(a,b,c){V.call(this,a,b,c);this.fd=!0;Og(this,!0);this.Pa=this;this.Hd=new fj;if(F)try{document.execCommand("BackgroundImageCache",!1,!0)}catch(d){(a=this.wh)&&a.Kd("Failed to enable background image cache",void 0)}}v(zj,V);zj.prototype.wa=null;zj.prototype.uf=null;var Aj=zj.prototype,Bj=xj("goog.ui.tree.TreeControl");Aj.wh=Bj;f=zj.prototype;f.wf=!1;f.Qi=null;f.Ed=!0;f.eg=!0;f.tc=!0;f.fg=!0;f.Aa=function(){return this};f.Ec=function(){return 0};f.Zf=function(){};
f.$i=function(){this.wf=!0;me(this.i(),"focused");this.Pa&&this.Pa.select()};f.Wi=function(){this.wf=!1;oe(this.i(),"focused")};f.hasFocus=function(){return this.wf};f.Ha=function(){return!this.tc||zj.m.Ha.call(this)};f.Hb=function(a){this.tc?zj.m.Hb.call(this,a):this.fd=a};f.yf=function(){return Eg};f.ee=function(){var a=Mg(this);return a?a.firstChild:null};f.ce=function(){return null};f.Yc=function(){};f.kd=function(){return zj.m.kd.call(this)+(this.tc?"":" "+this.ma.Sg)};
f.Zd=function(){var a=this.Ha(),b=this.Pi;if(a&&b)return b;b=this.hj;if(!a&&b)return b;b=this.ma;return a&&b.Rg?b.$b+" "+b.Rg:!a&&b.Ng?b.$b+" "+b.Ng:""};f.rc=function(a){if(this.Pa!=a){var b=!1;this.Pa&&(b=this.Pa==this.Qi,Og(this.Pa,!1));if(this.Pa=a)Og(a,!0),b&&a.select();this.dispatchEvent("change")}};function Cj(a){function b(a){var h=Jg(a);if(h){var k=!d||c==a.getParent()&&!e?a.ma.Lg:a.ma.Kg;h.className=k;if(h=a.ce())h.className=Sg(a)}R(a,b)}var c=a,d=c.Ed,e=c.fg;b(a)}
f.re=function(){zj.m.re.call(this);var a=this.i();te(a,"tree");T(a,"labelledby",Ig(this).id)};f.na=function(){zj.m.na.call(this);var a=this.i();a.className=this.ma.Vg;a.setAttribute("hideFocus","true");a=this.i();a.tabIndex=0;var b=this.wa=new Fe(a),c=this.uf=new yj(a);ee(this).B(c,"focusout",this.Wi).B(c,"focusin",this.$i).B(b,"key",this.hb).B(a,"mousedown",this.Cf).B(a,"click",this.Cf).B(a,"dblclick",this.Cf);this.re()};
f.Va=function(){zj.m.Va.call(this);this.wa.k();this.wa=null;this.uf.k();this.uf=null};f.Cf=function(a){var b=this.wh;b&&b.log(tj,"Received event "+a.type,void 0);if(b=Dj(this,a))switch(a.type){case "mousedown":b.Pf(a);break;case "click":a.preventDefault();break;case "dblclick":b.Ah(a)}};
f.hb=function(a){var b=!1,b=this.Hd,c=!1;switch(a.keyCode){case 40:case 38:if(a.ctrlKey){var c=40==a.keyCode?1:-1,d=b.Mf;if(d){var e=null,g=!1;if(b.ze){var h=b.Kc+c;0<=h&&h<b.ze.length?(b.Kc=h,e=b.ze):g=!0}e||(h=b.vd+c,0<=h&&h<d.length&&(b.vd=h),d.length>b.vd&&(e=b.hc.get(d[b.vd])),e&&e.length&&g&&(b.Kc=-1==c?e.length-1:0));hj(b,e)&&(b.Mf=d)}c=!0}break;case 8:d=b.U.length-1;c=!0;0<d?(b.U=b.U.substring(0,d),gj(b,b.U)):0==d?b.U="":c=!1;break;case 27:b.U="",c=!0}if(!(b=c)&&(b=this.Pa)){b=this.Pa;c=!0;
switch(a.keyCode){case 39:if(a.altKey)break;ie(b)&&(b.Ha()?S(b,0).select():b.Hb(!0));break;case 37:if(a.altKey)break;ie(b)&&b.Ha()&&b.td?b.Hb(!1):(d=b.getParent(),e=b.Aa(),d&&(e.tc||d!=e)&&d.select());break;case 40:a:if(ie(b)&&b.Ha())d=S(b,0);else{for(d=b;d!=b.Aa();){e=d.ib;if(null!=e){d=e;break a}d=d.getParent()}d=null}d&&d.select();break;case 38:d=b.jc;null!=d?d=Vg(d):(d=b.getParent(),e=b.Aa(),d=!e.tc&&d==e||b==e?null:d);d&&d.select();break;default:c=!1}c&&(a.preventDefault(),(e=b.Aa())&&e.Hd.clear());
b=c}b||(b=this.Hd,c=!1,a.ctrlKey||a.altKey||(d=String.fromCharCode(a.charCode||a.keyCode).toLowerCase(),(1==d.length&&" "<=d&&"~">=d||"\u0080"<=d&&"\ufffd">=d)&&(" "!=d||b.U)&&(b.U+=d,c=gj(b,b.U))),b=c);b&&a.preventDefault();return b};function Dj(a,b){for(var c=null,d=b.target;null!=d;){if(c=Hg[d.id])return c;if(d==a.i())break;d=d.parentNode}return null}f.createNode=function(a){return new Wg(a||Eg,this.ma,this.gb())};
function Ug(a,b){var c=a.Hd,d=b.rb();if(d&&!/^[\s\xa0]*$/.test(null==d?"":String(d))){var d=d.toLowerCase(),e=c.hc.get(d);e?e.push(b):c.hc.set(d,[b])}}f.removeNode=function(a){var b=this.Hd,c=a.rb();if(c&&!/^[\s\xa0]*$/.test(null==c?"":String(c))){var c=c.toLowerCase(),d=b.hc.get(c);d&&(Fb(d,a),d.length&&b.hc.remove(c))}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Ej,Fj,Gj,Hj=0,Ij={Hf:19,Vg:"blocklyTreeRoot",Sg:"blocklyHidden",Tg:"",Xg:"blocklyTreeRow",Ug:"blocklyTreeLabel",$b:"blocklyTreeIcon",lf:"blocklyTreeIconOpen",mf:"blocklyTreeIconNone",Wg:"blocklyTreeSelected"};function Jj(a,b){Ej=y("div","blocklyToolboxDiv");Ej.setAttribute("dir",w?"RTL":"LTR");b.appendChild(Ej);Fj=new Li;a.appendChild(Fj.G());M(Ej,"mousedown",null,function(a){cc(a)||a.target==Ej?N(!1):N(!0)})}
function Kj(){Ij.cleardotPath=Sc+"media/1x1.gif";Ij.cssCollapsedFolderIcon="blocklyTreeIconClosed"+(w?"Rtl":"Ltr");var a=new Lj(Eg,Ij);Gj=a;if(0!=a.tc){a.tc=!1;if(a.A){var b=Mg(a);b&&(b.className=a.kd())}a.Pa==a&&S(a,0)&&a.rc(S(a,0))}0!=a.Ed&&(a.Ed=!1,a.A&&Cj(a));0!=a.eg&&(a.eg=!1,a.A&&Cj(a));a.rc(null);Ej.style.display="block";Fj.M(P);Mj();a.w(Ej);O(window,"resize",Nj);Nj()}
function Nj(){var a=Ej,b=Xd(x),c=bi();w?(b=Oj(0,0,!1),a.style.left=b.x+c.width-a.offsetWidth+"px"):a.style.marginLeft=b.left;a.style.height=c.height+1+"px";Hj=a.offsetWidth;w||--Hj}
function Mj(){function a(c,d){for(var e=0,g;g=c.childNodes[e];e++)if(g.tagName){var h=g.tagName.toUpperCase();if("CATEGORY"==h){h=b.createNode(g.getAttribute("name"));h.Yb=[];d.add(h);var k=g.getAttribute("custom");k?h.Yb=k:a(g,h)}else"BLOCK"==h&&d.Yb.push(g)}}var b=Gj;b.Kh();b.Yb=[];a(va,Gj);if(b.Yb.length)throw"Toolbox cannot have both blocks and categories in the root level.";id(window,"resize")}function Lj(a,b,c){zj.call(this,a,b,c)}v(Lj,zj);
Lj.prototype.na=function(){Lj.m.na.call(this);if(uc){var a=this.i();M(a,"touchstart",this,this.ej)}};Lj.prototype.ej=function(a){a.preventDefault();var b=Dj(this,a);b&&"touchstart"===a.type&&window.setTimeout(function(){b.Pf(a)},1)};Lj.prototype.createNode=function(a){return new Pj(a?xg(a):Eg,this.ma,this.gb())};Lj.prototype.rc=function(a){this.Pa!=a&&(zj.prototype.rc.call(this,a),a&&a.Yb&&a.Yb.length?Fj.show(a.Yb):Fj.Cb())};
function Pj(a,b,c){function d(){id(window,"resize")}V.call(this,a,b,c);O(Gj,"expand",d);O(Gj,"collapse",d)}v(Pj,Wg);V.prototype.yf=function(){return Cg("span")};Pj.prototype.Pf=function(){ie(this)&&this.td?(this.toggle(),this.select()):this.te()?this.Aa().rc(null):this.select();Pg(this)};Pj.prototype.Ah=function(){};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Ti="VARIABLE";
function Ui(a,b,c,d){var e;e=cd(P);for(var g=Object.create(null),h=0;h<e.length;h++){var k=e[h].Vi;if(k)for(var k=k.call(e[h]),l=0;l<k.length;l++){var m=k[l];m&&(g[m.toLowerCase()]=m)}}e=[];for(var p in g)e.push(g[p]);e.sort(bb);e.unshift(null);g=void 0;for(p=0;p<e.length;p++)e[p]!==g&&((h=Hh.variables_get?Na(d,"variables_get"):null)&&Oa(h),(k=Hh.variables_set?Na(d,"variables_set"):null)&&Oa(k),null===e[p]?g=(h||k).Vi()[0]:(h&&Ua(h,"VAR").Sa(e[p]),k&&Ua(k,"VAR").Sa(e[p])),k&&a.push(k),h&&a.push(h),
h&&k?b.push(c,3*c):b.push(2*c))};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Vi="PROCEDURE";function Qj(){for(var a=cd(P),b=[],c=[],d=0;d<a.length;d++){var e=a[d].yk;e&&(e=e.call(a[d]))&&(e[2]?b.push(e):c.push(e))}c.sort(Rj);b.sort(Rj);return[c,b]}function Rj(a,b){var c=a[0].toLowerCase(),d=b[0].toLowerCase();return c>d?1:c<d?-1:0}
function Wi(a,b,c,d){function e(e,g){for(var l=0;l<e.length;l++){var m=Na(d,g);Ua(m,"NAME").Sa(e[l][0]);for(var p=[],r=0;r<e[l][1].length;r++)p[r]="ARG"+r;m.Rk(e[l][1],p);Oa(m);a.push(m);b.push(2*c)}}if(Hh.procedures_defnoreturn){var g=Na(d,"procedures_defnoreturn");Oa(g);a.push(g);b.push(2*c)}Hh.procedures_defreturn&&(g=Na(d,"procedures_defreturn"),Oa(g),a.push(g),b.push(2*c));Hh.procedures_ifreturn&&(g=Na(d,"procedures_ifreturn"),Oa(g),a.push(g),b.push(2*c));b.length&&(b[b.length-1]=3*c);g=Qj();
e(g[0],"procedures_callnoreturn");e(g[1],"procedures_callreturn")};var of=/#(.)(.)(.)/;function lf(a){var b=a[0],c=a[1];a=a[2];b=Number(b);c=Number(c);a=Number(a);if(isNaN(b)||0>b||255<b||isNaN(c)||0>c||255<c||isNaN(a)||0>a||255<a)throw Error('"('+b+","+c+","+a+'") is not a valid RGB color');b=Sj(b.toString(16));c=Sj(c.toString(16));a=Sj(a.toString(16));return"#"+b+c+a}var nf=/^#(?:[0-9a-f]{3}){1,2}$/i;function Sj(a){return 1==a.length?"0"+a:a}
function mf(a){var b=0,c=0,d=0,e=Math.floor(a/60),g=a/60-e;a=166.4*.55;var h=166.4*(1-.45*g),g=166.4*(1-.45*(1-g));switch(e){case 1:b=h;c=166.4;d=a;break;case 2:b=a;c=166.4;d=g;break;case 3:b=a;c=h;d=166.4;break;case 4:b=g;c=a;d=166.4;break;case 5:b=166.4;c=a;d=h;break;case 6:case 0:b=166.4,c=g,d=a}return[Math.floor(b),Math.floor(c),Math.floor(d)]}function pf(a,b,c){c=Math.min(Math.max(c,0),1);return[Math.round(c*a[0]+(1-c)*b[0]),Math.round(c*a[1]+(1-c)*b[1]),Math.round(c*a[2]+(1-c)*b[2])]};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function bf(a,b){var c=a.getAttribute("class")||"";-1==(" "+c+" ").indexOf(" "+b+" ")&&(c&&(c+=" "),a.setAttribute("class",c+b))}function cf(a,b){var c=a.getAttribute("class");if(-1!=(" "+c+" ").indexOf(" "+b+" ")){for(var c=c.split(/\s+/),d=0;d<c.length;d++)c[d]&&c[d]!=b||(c.splice(d,1),d--);c.length?a.setAttribute("class",c.join(" ")):a.removeAttribute("class")}}
function M(a,b,c,d){function e(a){d.apply(c,arguments)}a.addEventListener(b,e,!1);var g=[[a,b,e]];if(b in Tj)for(var e=function(a){if(1==a.changedTouches.length){var b=a.changedTouches[0];a.clientX=b.clientX;a.clientY=b.clientY}d.apply(c,arguments);a.preventDefault()},h=0,k;k=Tj[b][h];h++)a.addEventListener(k,e,!1),g.push([a,k,e]);return g}var Tj={};"ontouchstart"in document.documentElement&&(Tj={mousedown:["touchstart"],mousemove:["touchmove"],mouseup:["touchend","touchcancel"]});
function K(a){for(;a.length;){var b=a.pop();b[0].removeEventListener(b[1],b[2],!1)}}function Zi(a,b){var c=document;if(c.createEvent)c=c.createEvent("UIEvents"),c.initEvent(b,!0,!0),a.dispatchEvent(c);else if(c.createEventObject)c=c.createEventObject(),a.fireEvent("on"+b,c);else throw"FireEvent: No event creation mechanism.";}function id(a,b){setTimeout(function(){Zi(a,b)},0)}
function kh(a){var b={x:0,y:0},c=a.getAttribute("x");c&&(b.x=parseInt(c,10));if(c=a.getAttribute("y"))b.y=parseInt(c,10);if(a=(a=a.getAttribute("transform"))&&a.match(/translate\(\s*([-\d.]+)([ ,]\s*([-\d.]+)\s*\))?/))b.x+=parseInt(a[1],10),a[3]&&(b.y+=parseInt(a[3],10));return b}function ec(a){var b=0,c=0;do{var d=kh(a),b=b+d.x,c=c+d.y;a=a.parentNode}while(a&&a!=x);return{x:b,y:c}}function bg(a){a=ec(a);return Oj(a.x,a.y,!1)}
function I(a,b,c){a=document.createElementNS("http://www.w3.org/2000/svg",a);for(var d in b)a.setAttribute(d,b[d]);document.body.runtimeStyle&&(a.runtimeStyle=a.currentStyle=a.style);c&&c.appendChild(a);return a}function cc(a){return 2==a.button||a.ctrlKey}
function Oj(a,b,c){c&&(a-=window.scrollX||window.pageXOffset,b-=window.scrollY||window.pageYOffset);var d=x.createSVGPoint();d.x=a;d.y=b;a=x.getScreenCTM();c&&(a=a.inverse());d=d.matrixTransform(a);c||(d.x+=window.scrollX||window.pageXOffset,d.y+=window.scrollY||window.pageYOffset);return d}function dc(a){return Oj(a.clientX+(window.scrollX||window.pageXOffset),a.clientY+(window.scrollY||window.pageYOffset),!0)}
function eg(a){if(!a.length)return 0;for(var b=a[0].length,c=1;c<a.length;c++)b=Math.min(b,a[c].length);return b}function fg(a,b){if(!a.length)return 0;if(1==a.length)return a[0].length;for(var c=0,d=b||eg(a),e=0;e<d;e++){for(var g=a[0][e],h=1;h<a.length;h++)if(g!=a[h][e])return c;" "==g&&(c=e+1)}for(h=1;h<a.length;h++)if((g=a[h][e])&&" "!=g)return c;return d}
function gg(a,b){if(!a.length)return 0;if(1==a.length)return a[0].length;for(var c=0,d=b||eg(a),e=0;e<d;e++){for(var g=a[0].substr(-e-1,1),h=1;h<a.length;h++)if(g!=a[h].substr(-e-1,1))return c;" "==g&&(c=e+1)}for(h=1;h<a.length;h++)if((g=a[h].charAt(a[h].length-e-1))&&" "!=g)return c;return d};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Uj(){function a(a){a=a.slice(1).split("&");for(var c=0;c<a.length;c++){var g=a[c].split("=");b[decodeURIComponent(g[0])]=decodeURIComponent(g[1])}}var b={},c=window.location.hash;c&&a(c);(c=window.location.search)&&a(c);return b}var Vj=Uj();function X(a,b,c){if(a.hasOwnProperty(b))return a[b];void 0===c&&console.error(b+" should be present in the options.");return c}
function Wj(a){this.yi=X(a,"clientId");this.sg=Vj.userId;document.getElementById(X(a,"authButtonElementId"));document.getElementById(X(a,"authDivElementId"))}Wj.prototype.start=function(){gapi.load("auth:client,drive-realtime,drive-share",function(){})};
function Xj(a,b,c,d){function e(c){gapi.Kb.ea.files.se({resource:{mimeType:b,title:a,parents:[{id:c}]}}).cc(d)}function g(){function a(b){gapi.Kb.ea.Ej.se({fileId:"appdata",resource:{key:"folderId",value:b}}).cc(function(){e(b)})}function b(){gapi.Kb.ea.files.se({resource:{mimeType:"application/vnd.google-apps.folder",title:c}}).cc(function(b){a(b.id)})}gapi.Kb.ea.Ej.get({fileId:"appdata",propertyKey:"folderId"}).cc(function(d){if(d.error)c?b():a("root");else{var g=d.result.value;gapi.Kb.ea.files.get({fileId:g}).cc(function(a){a.error||
a.labels.Tk?b():e(g)})}})}gapi.Kb.load("drive","v2",function(){g()})}function Yj(a){this.Bh=X(a,"onFileLoaded");this.sj=X(a,"newFileMimeType","application/vnd.google-apps.drive-sdk");this.ph=X(a,"initializeModel");this.Jh=X(a,"registerTypes",function(){});this.xg=X(a,"afterAuth",function(){});this.qi=X(a,"autoCreate",!1);this.Ki=X(a,"defaultTitle","New Realtime File");this.Ji=X(a,"defaultFolderTitle","");this.yg=X(a,"afterCreate",function(){});this.df=new Wj(a)}
function Zj(a,b,c){var d=[];b&&d.push("fileIds="+b.join(","));c&&d.push("userId="+c);c=0==d.length?window.location.pathname:window.location.pathname+"#"+d.join("&");window.history&&window.history.replaceState?window.history.replaceState("Google Drive Realtime API Playground","Google Drive Realtime API Playground",c):window.location.href=c;Vj=Uj();for(var e in b)gapi.ea.vb.load(b[e],a.Bh,a.ph,a.kh)}Yj.prototype.start=function(){var a=this;this.df.start(function(){a.Jh&&a.Jh();a.xg&&a.xg();a.load()})};
Yj.prototype.kh=function(a){a.type!=gapi.ea.vb.ug.dk&&(a.type==gapi.ea.vb.ug.Yj?(alert("An Error happened: "+a.message),window.location.href="/"):a.type==gapi.ea.vb.ug.bk&&(alert("The file was not found. It does not exist or you do not have read access to the file."),window.location.href="/"))};
Yj.prototype.load=function(){var a=Vj.fileIds;a&&(a=a.split(","));var b=this.df.sg,b=Vj.state;if(a)for(var c in a)gapi.ea.vb.load(a[c],this.Bh,this.ph,this.kh);else{if(b){var d;try{d=JSON.parse(b)}catch(e){d=null}if("open"==d.action){a=d.Ck;b=d.sg;Zj(this,a,b);return}}this.qi&&ak(this)}};function ak(a){Xj(a.Ki,a.sj,a.Ji,function(b){b.id?(a.yg&&a.yg(b.id),Zj(a,[b.id],a.df.sg)):(console.error("Error creating file."),console.error(b))})};/*

 Visual Blocks Editor

 Copyright 2014 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var ad,bk,ck="media/progress.gif",$c=!1,dk=null,ii=null,ek=null,fk=null,ki=null,pi=!1,gk=null,hk=null,ik=null,ck="media/progress.gif";function jk(a){var b=a.Oi;a=a.Oi.length;for(var c=0;c<a;c++){var d=b[c];if(!d.mj){var e=d.target;"value_changed"==d.type&&("xmlDom"==d.Gh?kk(function(){lk(e,!1);mk(e)}):"relativeX"!=d.Gh&&"relativeY"!=d.Gh||kk(function(){e.j||lk(e,!1);mk(e)}))}}}function nk(a){if(!a.mj){var b=a.newValue;b?lk(b,!a.oldValue):(b=a.oldValue,ok(b))}}
function kk(a){if(pi)a();else try{pi=!0,a()}finally{pi=!1}}function lk(a,b){kk(function(){var c=Ja(a.tg).firstChild;if(c=La(P,c,!0))b&&Zc(c.s,c),(b||Eb(ad,c))&&mk(c)})}function mk(a){if(!isNaN(a.Ke)&&!isNaN(a.Le)){var b=bi().width,c=z(a),d=a.Ke-c.x;a.moveBy(w?b-d:d,a.Le-c.y)}}function ok(a){kk(function(){a.k(!0,!0,!0)})}
function qi(a){if(a.s==P&&$c&&!pi){a=wh(a);var b=z(a),c=!1,d=Ga(a);d.setAttribute("id",a.id);var e=y("xml");e.appendChild(d);d=Ia(e);d!=a.tg&&(c=!0,a.tg=d);if(a.Ke!=b.x||a.Le!=b.y)a.Ke=b.x,a.Le=b.y,c=!0;c&&ki.set(a.id.toString(),a)}}function pk(a,b){gapi.Kb.ea.Fh.list({fileId:a}).cc(function(a){for(var d=0;d<a.items.length;d++){var e=a.items[d];if("owner"==e.Lk){b(e.domain);break}}})}
var tk={clientId:null,authButtonElementId:"authorizeButton",authDivElementId:"authButtonDiv",initializeModel:function(a){ii=a;var b=a.tk();a.Fc().set("blocks",b);b=a.rk();a.Fc().set("topBlocks",b);hk&&a.Fc().set(hk,a.vk(ik))},autoCreate:!0,defaultTitle:"Realtime Blockly File",defaultFolderTitle:"Realtime Blockly Folder",newFileMimeType:null,onFileLoaded:function(a){dk=a;a:{for(var b=a.Si(),c=0;c<b.length;c++){var d=b[c];if(d.nj){ek=d.Ok;break a}}ek=void 0}ii=a.Ae;ki=ii.Fc().get("blocks");ad=ii.Fc().get("topBlocks");
ii.Fc().addEventListener(gapi.ea.vb.Xe.ck,jk);ki.addEventListener(gapi.ea.vb.Xe.ek,nk);fk();a.addEventListener(gapi.ea.vb.Xe.Zj,qk);a.addEventListener(gapi.ea.vb.Xe.$j,rk);sk();a=ad;for(b=0;b<a.length;b++)c=a.get(b),lk(c,!0)},registerTypes:function(){var a=gapi.ea.vb.wk;a.Jk(Gh,"Block");Gh.prototype.id=a.hf("id");Gh.prototype.tg=a.hf("xmlDom");Gh.prototype.Ke=a.hf("relativeX");Gh.prototype.Le=a.hf("relativeY");a.Pk(Gh,Gh.prototype.initialize)},afterAuth:function(){window.setTimeout(function(){},18E5)},
afterCreate:function(a){var b=gapi.Kb.ea.Fh.se({fileId:a,resource:{type:"anyone",role:"writer",value:"default",withLink:!0}});b.cc(function(c){c.error&&pk(a,function(c){b=gapi.Kb.ea.Fh.se({fileId:a,resource:{type:"domain",role:"writer",value:c,withLink:!0}});b.cc(function(){})})})}};function uk(){var a=xa,b=X(a,"chatbox");b&&(hk=X(b,"elementId"),ik=X(b,"initText",vk));tk.yi=X(a,"clientId");bk=X(a,"collabElementId")}
function wk(a,b){uk();$c=!0;xk(b);fk=function(){a();if(hk){var b=ii.Fc().get(hk),d=document.getElementById(hk);gapi.ea.vb.xk.ik(b,d);d.disabled=!1}};gk=new Yj(tk);gk.start()}
function xk(a){a.style.background="url("+Sc+ck+") no-repeat center center";var b=Rd(a),c=y("div");c.id=tk.authDivElementId;var d=y("p",null,yk);c.appendChild(d);d=y("button",null,"Authorize");d.id=tk.gk;c.appendChild(d);a.appendChild(c);c.style.display="none";c.style.position="relative";c.style.textAlign="center";c.style.border="1px solid";c.style.backgroundColor="#f6f9ff";c.style.borderRadius="15px";c.style.boxShadow="10px 10px 5px #888";c.style.width=b.width/3+"px";a=Rd(c);c.style.left=(b.width-
a.width)/3+"px";c.style.top=(b.height-a.height)/4+"px"}function sk(){if(bk){var a;a=bk;a=q(a)?document.getElementById(a):a;Ad(a);for(var b=dk.Si(),c=0;c<b.length;c++){var d=b[c],e=y("img",{src:d.Ik||Sc+"media/anon.jpeg",alt:d.displayName,title:d.displayName+(d.nj?" ("+zk+")":"")});e.style.backgroundColor=d.color;a.appendChild(e)}}}function qk(){sk()}function rk(){sk()}function ji(a){var b=ek+"-"+a;return ki.has(b)?ji("-"+a):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ak(){var a=Bk.join("\n"),b=Sc.replace(/[\\\/]$/,""),a=a.replace(/<<<PATH>>>/g,b),b=document,c=b.createElement("style");c.type="text/css";b.getElementsByTagName("head")[0].appendChild(c);c.styleSheet?c.styleSheet.cssText=a:c.appendChild(b.createTextNode(a))}
var Bk=[".blocklySvg {","  background-color: #fff;","  border: 1px solid #ddd;","  overflow: hidden;","}",".blocklyWidgetDiv {","  position: absolute;","  display: none;","  z-index: 999;","}",".blocklyDraggable {","  cursor: url(<<<PATH>>>/media/handopen.cur) 8 5, auto;","}",".blocklyResizeSE {","  fill: #aaa;","  cursor: se-resize;","}",".blocklyResizeSW {","  fill: #aaa;","  cursor: sw-resize;","}",".blocklyResizeLine {","  stroke-width: 1;","  stroke: #888;","}",".blocklyHighlightedConnectionPath {",
"  stroke-width: 4px;","  stroke: #fc3;","  fill: none;","}",".blocklyPathLight {","  fill: none;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklySelected>.blocklyPath {","  stroke-width: 3px;","  stroke: #fc3;","}",".blocklySelected>.blocklyPathLight {","  display: none;","}",".blocklyDragging>.blocklyPath,",".blocklyDragging>.blocklyPathLight {","  fill-opacity: .8;","  stroke-opacity: .8;","}",".blocklyDragging>.blocklyPathDark {","  display: none;","}",".blocklyDisabled>.blocklyPath {",
"  fill-opacity: .5;","  stroke-opacity: .5;","}",".blocklyDisabled>.blocklyPathLight,",".blocklyDisabled>.blocklyPathDark {","  display: none;","}",".blocklyText {","  cursor: default;","  font-family: sans-serif;","  font-size: 11pt;","  fill: #fff;","}",".blocklyNonEditableText>text {","  pointer-events: none;","}",".blocklyNonEditableText>rect,",".blocklyEditableText>rect {","  fill: #fff;","  fill-opacity: .6;","}",".blocklyNonEditableText>text,",".blocklyEditableText>text {","  fill: #000;",
"}",".blocklyEditableText:hover>rect {","  stroke-width: 2;","  stroke: #fff;","}",".blocklyBubbleText {","  fill: #000;","}",".blocklySvg text {","  -moz-user-select: none;","  -webkit-user-select: none;","  user-select: none;","  cursor: inherit;","}",".blocklyHidden {","  display: none;","}",".blocklyFieldDropdown:not(.blocklyHidden) {","  display: block;","}",".blocklyTooltipBackground {","  fill: #ffffc7;","  stroke-width: 1px;","  stroke: #d8d8d8;","}",".blocklyTooltipShadow,",".blocklyDropdownMenuShadow {",
"  fill: #bbb;","  filter: url(#blocklyShadowFilter);","}",".blocklyTooltipText {","  font-family: sans-serif;","  font-size: 9pt;","  fill: #000;","}",".blocklyIconShield {","  cursor: default;","  fill: #00c;","  stroke-width: 1px;","  stroke: #ccc;","}",".blocklyIconGroup:hover>.blocklyIconShield {","  fill: #00f;","  stroke: #fff;","}",".blocklyIconGroup:hover>.blocklyIconMark {","  fill: #fff;","}",".blocklyIconMark {","  cursor: default !important;","  font-family: sans-serif;","  font-size: 9pt;",
"  font-weight: bold;","  fill: #ccc;","  text-anchor: middle;","}",".blocklyWarningBody {","}",".blocklyMinimalBody {","  margin: 0;","  padding: 0;","}",".blocklyCommentTextarea {","  margin: 0;","  padding: 2px;","  border: 0;","  resize: none;","  background-color: #ffc;","}",".blocklyHtmlInput {","  font-family: sans-serif;","  font-size: 11pt;","  border: none;","  outline: none;","  width: 100%","}",".blocklyMutatorBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #ddd;","}",".blocklyFlyoutBackground {",
"  fill: #ddd;","  fill-opacity: .8;","}",".blocklyColourBackground {","  fill: #666;","}",".blocklyScrollbarBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #e4e4e4;","}",".blocklyScrollbarKnob {","  fill: #ccc;","}",".blocklyScrollbarBackground:hover+.blocklyScrollbarKnob,",".blocklyScrollbarKnob:hover {","  fill: #bbb;","}",".blocklyInvalidInput {","  background: #faa;","}",".blocklyAngleCircle {","  stroke: #444;","  stroke-width: 1;","  fill: #ddd;","  fill-opacity: .8;","}",".blocklyAngleMarks {",
"  stroke: #444;","  stroke-width: 1;","}",".blocklyAngleGauge {","  fill: #f88;","  fill-opacity: .8;  ","}",".blocklyAngleLine {","  stroke: #f00;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklyContextMenu {","  border-radius: 4px;","}",".blocklyDropdownMenu {","  padding: 0 !important;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(<<<PATH>>>/media/sprites.png) no-repeat -48px -16px !important;",
"}",".blocklyToolboxDiv {","  background-color: #ddd;","  display: none;","  overflow-x: visible;","  overflow-y: auto;","  position: absolute;","}",".blocklyTreeRoot {","  padding: 4px 0;","}",".blocklyTreeRoot:focus {","  outline: none;","}",".blocklyTreeRow {","  line-height: 22px;","  height: 22px;","  padding-right: 1em;","  white-space: nowrap;","}",'.blocklyToolboxDiv[dir="RTL"] .blocklyTreeRow {',"  padding-right: 0;","  padding-left: 1em !important;","}",".blocklyTreeRow:hover {","  background-color: #e4e4e4;",
"}",".blocklyTreeIcon {","  height: 16px;","  width: 16px;","  vertical-align: middle;","  background-image: url(<<<PATH>>>/media/sprites.png);","}",".blocklyTreeIconClosedLtr {","  background-position: -32px -1px;","}",".blocklyTreeIconClosedRtl {","  background-position: 0px -1px;","}",".blocklyTreeIconOpen {","  background-position: -16px -1px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedLtr {","  background-position: -32px -17px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedRtl {","  background-position: 0px -17px;",
"}",".blocklyTreeSelected>.blocklyTreeIconOpen {","  background-position: -16px -17px;","}",".blocklyTreeIconNone,",".blocklyTreeSelected>.blocklyTreeIconNone {","  background-position: -48px -1px;","}",".blocklyTreeLabel {","  cursor: default;","  font-family: sans-serif;","  font-size: 16px;","  padding: 0 3px;","  vertical-align: middle;","}",".blocklyTreeSelected  {","  background-color: #57e !important;","}",".blocklyTreeSelected .blocklyTreeLabel {","  color: #fff;","}",".blocklyWidgetDiv .goog-palette {",
"  outline: none;","  cursor: default;","}",".blocklyWidgetDiv .goog-palette-table {","  border: 1px solid #666;","  border-collapse: collapse;","}",".blocklyWidgetDiv .goog-palette-cell {","  height: 13px;","  width: 15px;","  margin: 0;","  border: 0;","  text-align: center;","  vertical-align: middle;","  border-right: 1px solid #666;","  font-size: 1px;","}",".blocklyWidgetDiv .goog-palette-colorswatch {","  position: relative;","  height: 13px;","  width: 15px;","  border: 1px solid #666;","}",
".blocklyWidgetDiv .goog-palette-cell-hover .goog-palette-colorswatch {","  border: 1px solid #FFF;","}",".blocklyWidgetDiv .goog-palette-cell-selected .goog-palette-colorswatch {","  border: 1px solid #000;","  color: #fff;","}",".blocklyWidgetDiv .goog-menu {","  background: #fff;","  border-color: #ccc #666 #666 #ccc;","  border-style: solid;","  border-width: 1px;","  cursor: default;","  font: normal 13px Arial, sans-serif;","  margin: 0;","  outline: none;","  padding: 4px 0;","  position: absolute;",
"  z-index: 20000;","}",".blocklyWidgetDiv .goog-menuitem {","  color: #000;","  font: normal 13px Arial, sans-serif;","  list-style: none;","  margin: 0;","  padding: 4px 7em 4px 28px;","  white-space: nowrap;","}",".blocklyWidgetDiv .goog-menuitem.goog-menuitem-rtl {","  padding-left: 7em;","  padding-right: 28px;","}",".blocklyWidgetDiv .goog-menu-nocheckbox .goog-menuitem,",".blocklyWidgetDiv .goog-menu-noicon .goog-menuitem {","  padding-left: 12px;","}",".blocklyWidgetDiv .goog-menu-noaccel .goog-menuitem {",
"  padding-right: 20px;","}",".blocklyWidgetDiv .goog-menuitem-content {","  color: #000;","  font: normal 13px Arial, sans-serif;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-accel,",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-content {","  color: #ccc !important;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-icon {","  opacity: 0.3;","  -moz-opacity: 0.3;","  filter: alpha(opacity=30);","}",".blocklyWidgetDiv .goog-menuitem-highlight,",".blocklyWidgetDiv .goog-menuitem-hover {",
"  background-color: #d6e9f8;","  border-color: #d6e9f8;","  border-style: dotted;","  border-width: 1px 0;","  padding-bottom: 3px;","  padding-top: 3px;","}",".blocklyWidgetDiv .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-icon {","  background-repeat: no-repeat;","  height: 16px;","  left: 6px;","  position: absolute;","  right: auto;","  vertical-align: middle;","  width: 16px;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-icon {",
"  left: auto;","  right: 6px;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(//ssl.gstatic.com/editor/editortoolbar.png) no-repeat -512px 0;","}",".blocklyWidgetDiv .goog-menuitem-accel {","  color: #999;","  direction: ltr;","  left: auto;","  padding: 0 6px;","  position: absolute;","  right: 0;","  text-align: right;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-accel {","  left: 0;",
"  right: auto;","  text-align: left;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-hint {","  text-decoration: underline;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-separator {","  color: #999;","  font-size: 12px;","  padding-left: 4px;","}",".blocklyWidgetDiv .goog-menuseparator {","  border-top: 1px solid #ccc;","  margin: 4px 0;","  padding: 0;","}",""];/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Ck(a,b){function c(){Dk(a);Ek()}if(!Cd(document,a))throw"Error: container is not in current document.";b&&Fk(b);if(wa){var d=document.getElementById("realtime");d&&(d.style.display="block");wk(c,a)}else c()}
function Fk(a){var b=!!a.readOnly;if(b)var c=!1,d=!1,e=!1,g=!1,h=!1,k=null;else(c=a.toolbox)?("string"!=typeof c&&"undefined"==typeof XSLTProcessor&&(c=c.outerHTML),"string"==typeof c&&(c=Ja(c))):c=null,k=c,c=Boolean(k&&k.getElementsByTagName("category").length),d=a.trashcan,void 0===d&&(d=c),e=a.collapse,void 0===e&&(e=c),g=a.comments,void 0===g&&(g=c),h=a.disable,void 0===h&&(h=c);if(k&&!c)var l=!1;else l=a.scrollbars,void 0===l&&(l=!0);var m=a.sounds;void 0===m&&(m=!0);var p=!!a.realtime,r=p?a.realtimeOptions:
void 0;w=!!a.rtl;ta=e;sa=g;ua=h;C=b;ya=a.maxBlocks||Infinity;Sc=a.path||"./";za=c;Aa=l;ra=d;Ba=m;va=k;wa=p;xa=r}
function Dk(a){a.setAttribute("dir","LTR");be=w;Ak();var b=I("svg",{xmlns:"http://www.w3.org/2000/svg","xmlns:html":"http://www.w3.org/1999/xhtml","xmlns:xlink":"http://www.w3.org/1999/xlink",version:"1.1","class":"blocklySvg"},null),c=I("defs",{},b),d,e;d=I("filter",{id:"blocklyEmboss"},c);I("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:1,result:"blur"},d);e=I("feSpecularLighting",{"in":"blur",surfaceScale:1,specularConstant:.5,specularExponent:10,"lighting-color":"white",result:"specOut"},d);
I("fePointLight",{x:-5E3,y:-1E4,z:2E4},e);I("feComposite",{"in":"specOut",in2:"SourceAlpha",operator:"in",result:"specOut"},d);I("feComposite",{"in":"SourceGraphic",in2:"specOut",operator:"arithmetic",k1:0,k2:1,k3:1,k4:0},d);d=I("filter",{id:"blocklyTrashcanShadowFilter"},c);I("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:2,result:"blur"},d);I("feOffset",{"in":"blur",dx:1,dy:1,result:"offsetBlur"},d);d=I("feMerge",{},d);I("feMergeNode",{"in":"offsetBlur"},d);I("feMergeNode",{"in":"SourceGraphic"},
d);d=I("filter",{id:"blocklyShadowFilter"},c);I("feGaussianBlur",{stdDeviation:2},d);c=I("pattern",{id:"blocklyDisabledPattern",patternUnits:"userSpaceOnUse",width:10,height:10},c);I("rect",{width:10,height:10,fill:"#aaa"},c);I("path",{d:"M 0 0 L 10 10 M 10 0 L 0 10",stroke:"#cc0"},c);P=new Vc(Gk,Hk);b.appendChild(P.G());P.Nf=ya;C||(za?Jj(b,a):(P.Xd=new Li,c=P.Xd,d=c.G(),c.Od=!1,Bd(d),Ik(function(){if(0==gd){var a=P.qb();if(0>a.cb||a.cb+a.Ua>a.ra+a.wb||a.yb<(w?a.Fa:0)||a.yb+a.Ac>(w?a.O:a.O+a.Fa))for(var b=
Fa(P,!1),c=0,d;d=b[c];c++){var e=z(d),p=uf(d),r=a.wb+25-p.height-e.y;0<r&&d.moveBy(0,r);r=a.wb+a.ra-25-e.y;0>r&&d.moveBy(0,r);r=25+a.Fa-e.x-(w?0:p.width);0<r&&d.moveBy(r,0);r=a.Fa+a.O-25-e.x+(w?p.width:0);0>r&&d.moveBy(r,0);d.ac&&!C&&50<(w?e.x-a.O:-e.x)&&d.k(!1,!0)}}})));b.appendChild(Uh());a.appendChild(b);x=b;ri();cg=y("div","blocklyWidgetDiv");cg.style.direction=w?"rtl":"ltr";document.body.appendChild(cg)}
function Ek(){M(x,"mousedown",null,Jk);M(x,"contextmenu",null,Kk);M(cg,"contextmenu",null,Kk);Ca||(M(window,"resize",document,ri),M(document,"keydown",null,Lk),document.addEventListener("mouseup",Mk,!1),Mb&&M(window,"orientationchange",document,function(){id(window,"resize")}),Ca=!0);if(va)if(za)Kj();else{P.Xd.M(P);P.Xd.show(va.childNodes);P.scrollX=P.Xd.D;w&&(P.scrollX*=-1);var a="translate("+P.scrollX+", 0)";P.$.setAttribute("transform",a);P.Wc.setAttribute("transform",a)}Aa&&(P.Wb=new Wb(P),P.Wb.resize());
Yc();if(Ba){Nk(["media/click.mp3","media/click.wav","media/click.ogg"],"click");Nk(["media/delete.mp3","media/delete.ogg","media/delete.wav"],"delete");var b=[],a=function(){for(;b.length;)K(b.pop());for(var a in Ok){var d=Ok[a];d.volume=.01;d.play();d.pause();if(Mb||Lb)break}};b.push(M(document,"mousemove",null,a));b.push(M(document,"touchstart",null,a))}};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var cg=null,$f=null,Pk=null;function Zf(a){ag();$f=a;Pk=null;cg.style.display="block"}function ag(){$f&&(cg.style.display="none",Pk&&Pk(),Pk=$f=null,Ad(cg))}function dg(a,b,c,d){b<d.y&&(b=d.y);w?a>c.width+d.x&&(a=c.width+d.x):a<d.x&&(a=d.x);cg.style.left=a+"px";cg.style.top=b+"px"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Qk(a,b,c,d){this.h=null;this.oa=Number(c);this.D=Number(b);this.Vc={height:this.oa+10,width:this.D};this.Da=d||"";this.W=I("g",{},null);this.oe=I("image",{height:this.oa+"px",width:this.D+"px",y:-12},this.W);this.Sa(a);Ob&&(this.Je=I("rect",{height:this.oa+"px",width:this.D+"px",y:-12,"fill-opacity":0},this.W))}v(Qk,xf);f=Qk.prototype;f.clone=function(){return new Qk(this.zk(),this.D,this.oa,this.rb())};f.Je=null;f.xc=!1;
f.M=function(a){if(this.h)throw"Image has already been initialized once.";this.h=a;yf(a).appendChild(this.W);a=this.Je||this.oe;a.Ea=this.h;Ze(a)};f.k=function(){L(this.W);this.Je=this.oe=this.W=null};f.Uc=function(a){(this.Je||this.oe).Ea=a};f.Gc=function(){return this.Nj};f.Sa=function(a){null!==a&&(this.Nj=a,this.oe.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",q(a)?a:""))};f.Ka=function(a){null!==a&&(this.Da=a)};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Sc="./",Qc=64,Rc=92,Tc="media/sprites.png",rh=[,2,1,4,3],Ok=Object.create(null),Q=null,C=!1,nh=null,oh=null,Hi=5,W=20,uh=250,Ji=30,P=null,Rk=null,Sk=null;function bi(){return{width:x.Eg,height:x.Dg}}function ri(){var a=x,b=a.parentNode,c=b.offsetWidth,b=b.offsetHeight;a.Eg!=c&&(a.setAttribute("width",c+"px"),a.Eg=c);a.Dg!=b&&(a.setAttribute("height",b+"px"),a.Dg=b);P.Wb&&P.Wb.resize()}
function Jk(a){ri();oi();N();var b=a.target&&a.target.nodeName&&"svg"==a.target.nodeName.toLowerCase();!C&&Q&&b&&hd(Q);a.target==x&&cc(a)?Tk(a):(C||b)&&P.Wb&&(P.rf=!0,P.jg=a.clientX,P.kg=a.clientY,P.Pj=P.qb(),P.Rj=P.scrollX,P.Sj=P.scrollY,"mouseup"in Tj&&(Sk=M(document,"mouseup",null,Mk)),Da=M(document,"mousemove",null,Uk))}function Mk(){ih(!1);P.rf=!1;Sk&&(K(Sk),Sk=null);Da&&(K(Da),Da=null)}
function Uk(a){if(P.rf){fc();var b=P.Pj,c=P.Rj+(a.clientX-P.jg),d=P.Sj+(a.clientY-P.kg),c=Math.min(c,-b.yb),d=Math.min(d,-b.cb),c=Math.max(c,b.O-b.yb-b.Ac),d=Math.max(d,b.ra-b.cb-b.Ua);P.Wb.set(-c-b.yb,-d-b.cb);a.stopPropagation()}}
function Lk(a){if(!hh(a))if(27==a.keyCode)N();else if(8==a.keyCode||46==a.keyCode)try{Q&&Q.ac&&!C&&(N(),Q.k(!0,!0))}finally{a.preventDefault()}else if(a.altKey||a.ctrlKey||a.metaKey)if(Q&&Q.ac&&!C&&Q.Fb&&!C&&Q.s==P&&(N(),67==a.keyCode?Vk():88==a.keyCode&&(Vk(),Q.k(!0,!0))),86==a.keyCode&&Rk){a=P;var b=Rk;if(!(b.getElementsByTagName("block").length>=jd(a))){var c=La(a,b),d=parseInt(b.getAttribute("x"),10),b=parseInt(b.getAttribute("y"),10);if(!isNaN(d)&&!isNaN(b)){w&&(d=-d);do for(var e=!1,g=cd(a),
h=0,k;k=g[h];h++)k=z(k),1>=Math.abs(d-k.x)&&1>=Math.abs(b-k.y)&&(d=w?d-W:d+W,b+=2*W,e=!0);while(e);c.moveBy(d,b)}c.select()}}}function oi(){li&&(K(li),li=null);mi&&(K(mi),mi=null);var a=Q;if(2==gd&&a){var b=z(a);yh(a,b.x-a.Rh,b.y-a.Sh);delete a.Wd;Gi(a,!1);a.w();Oc(a.Ga,uh,a);id(window,"resize")}a&&Xc(a.s);gd=0;$i()}function Vk(){var a=Q,b=Ga(a);Xa(b);a=z(a);b.setAttribute("x",w?-a.x:a.x);b.setAttribute("y",a.y);Rk=b}
function Tk(a){if(!C){var b=[];if(ta){for(var c=!1,d=!1,e=Fa(P,!1),g=0;g<e.length;g++)for(var h=e[g];h;)h.isCollapsed()?c=!0:d=!0,h=Ha(h);d={enabled:d};d.text=Wk;d.bb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Ad.bind(c,!0),a),c=Ha(c),a+=10};b.push(d);c={enabled:c};c.text=Xk;c.bb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Ad.bind(c,!1),a),c=Ha(c),a+=10};b.push(c)}Xg.show(a,b)}}function Kk(a){hh(a)||a.preventDefault()}
function N(a){Yh();ag();!a&&Fj&&Fj.Od&&Gj.rc(null)}function fc(){if(window.getSelection){var a=window.getSelection();a&&a.removeAllRanges&&(a.removeAllRanges(),window.setTimeout(function(){try{window.getSelection().removeAllRanges()}catch(a){}},0))}}function hh(a){return"textarea"==a.target.type||"text"==a.target.type}
function Nk(a,b){if(window.Audio&&a.length){for(var c,d=new window.Audio,e=0;e<a.length;e++){var g=a[e],h=g.match(/\.(\w+)$/);if(h&&d.canPlayType("audio/"+h[1])){c=new window.Audio(Sc+g);break}}c&&c.play&&(Ok[b]=c)}}function ni(a,b){var c=Ok[a];c&&(c=Vb&&9===Vb||Mb||Kb?c:c.cloneNode(),c.volume=void 0===b?1:b,c.play())}function ih(a){if(!C){var b="";a&&(b="url("+Sc+"media/handclosed.cur) 7 3, auto");Q&&(yf(Q).style.cursor=b);x.style.cursor=b}}
function Gk(){var a=bi();a.width-=Hj;var b=a.width-J,c=a.height-J;try{var d=P.$.getBBox()}catch(e){return null}if(P.Wb)var g=Math.min(d.x-b/2,d.x+d.width-b),b=Math.max(d.x+d.width+b/2,d.x+b),h=Math.min(d.y-c/2,d.y+d.height-c),c=Math.max(d.y+d.height+c/2,d.y+c);else g=d.x,b=g+d.width,h=d.y,c=h+d.height;return{ra:a.height,O:a.width,Ua:c-h,Ac:b-g,wb:-P.scrollY,Fa:-P.scrollX,cb:h,yb:g,Za:0,Ya:w?0:Hj}}
function Hk(a){if(!P.Wb)throw"Attempt to set main workspace scroll without scrollbars.";var b=Gk();s(a.x)&&(P.scrollX=-b.Ac*a.x-b.yb);s(a.y)&&(P.scrollY=-b.Ua*a.y-b.cb);a="translate("+(P.scrollX+b.Ya)+","+(P.scrollY+b.Za)+")";P.$.setAttribute("transform",a);P.Wc.setAttribute("transform",a)}function ti(a){a()}function Ik(a){return M(P.$,"blocklyWorkspaceChange",null,a)}window.Blockly||(window.Blockly={});window.Blockly.getMainWorkspace=function(){return P};window.Blockly.addChangeListener=Ik;
window.Blockly.removeChangeListener=function(a){K(a)};function Yk(a,b){var c;c=a.className;for(var d=c=q(c)&&c.match(/\S+/g)||[],e=Ib(arguments,1),g=0;g<e.length;g++)Eb(d,e[g])||d.push(e[g]);a.className=c.join(" ")};var Zk={},$k={ace:"\u0628\u0647\u0633\u0627 \u0627\u0686\u064a\u0647",af:"Afrikaans",ar:"\u0627\u0644\u0639\u0631\u0628\u064a\u0629",az:"Az\u0259rbaycanca","be-tarask":"Tara\u0161kievica",br:"Brezhoneg",ca:"Catal\u00e0",cdo:"\u95a9\u6771\u8a9e",cs:"\u010cesky",da:"Dansk",de:"Deutsch",el:"\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac",en:"English",es:"Espa\u00f1ol",eu:"Euskara",fa:"\u0641\u0627\u0631\u0633\u06cc",fi:"Suomi",fo:"F\u00f8royskt",fr:"Fran\u00e7ais",frr:"Frasch",gl:"Galego",hak:"\u5ba2\u5bb6\u8a71",
he:"\u05e2\u05d1\u05e8\u05d9\u05ea",hi:"\u0939\u093f\u0928\u094d\u0926\u0940",hrx:"Hunsrik",hu:"Magyar",ia:"Interlingua",id:"Bahasa Indonesia",is:"\u00cdslenska",it:"Italiano",ja:"\u65e5\u672c\u8a9e",ka:"\u10e5\u10d0\u10e0\u10d7\u10e3\u10da\u10d8",km:"\u1797\u17b6\u179f\u17b6\u1781\u17d2\u1798\u17c2\u179a",ko:"\ud55c\uad6d\uc5b4",ksh:"Ripoar\u0117sch",ky:"\u041a\u044b\u0440\u0433\u044b\u0437\u0447\u0430",la:"Latine",lb:"L\u00ebtzebuergesch",lt:"Lietuvi\u0173",lv:"Latvie\u0161u",mg:"Malagasy",ml:"\u0d2e\u0d32\u0d2f\u0d3e\u0d33\u0d02",
mk:"\u041c\u0430\u043a\u0435\u0434\u043e\u043d\u0441\u043a\u0438",mr:"\u092e\u0930\u093e\u0920\u0940",ms:"Bahasa Melayu",mzn:"\u0645\u0627\u0632\u0650\u0631\u0648\u0646\u06cc",nb:"Norsk Bokm\u00e5l",nl:"Nederlands, Vlaams",oc:"Lenga d'\u00f2c",pa:"\u092a\u0902\u091c\u093e\u092c\u0940",pl:"Polski",pms:"Piemont\u00e8is",ps:"\u067e\u069a\u062a\u0648",pt:"Portugu\u00eas",ro:"Rom\u00e2n\u0103","pt-br":"Portugu\u00eas Brasileiro",ru:"\u0420\u0443\u0441\u0441\u043a\u0438\u0439",sc:"Sardu",sco:"Scots",si:"\u0dc3\u0dd2\u0d82\u0dc4\u0dbd",
sk:"Sloven\u010dina",sr:"\u0421\u0440\u043f\u0441\u043a\u0438",sv:"Svenska",sw:"Kishwahili",th:"\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22",tl:"Tagalog",tlh:"tlhIngan Hol",tr:"T\u00fcrk\u00e7e",uk:"\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430",vi:"Ti\u1ebfng Vi\u1ec7t","zh-hans":"\u7c21\u9ad4\u4e2d\u6587","zh-hant":"\u6b63\u9ad4\u4e2d\u6587"},al="ace ar fa he mzn ps".split(" "),bl=window.BlocklyGamesLang,cl=window.BlocklyGamesLanguages,dl=!!window.location.pathname.match(/\.html$/);
function el(a,b){var c=window.location.search.match(new RegExp("[?&]"+a+"=([^&]+)"));return c?decodeURIComponent(c[1].replace(/\+/g,"%20")):b}var fl,gl=Number(el("level","NaN"));fl=isNaN(gl)?1:Math.min(Math.max(1,gl),10);
function hl(){document.title=document.getElementById("title").textContent;document.head.parentElement.setAttribute("dir",-1!=al.indexOf(bl)?"rtl":"ltr");document.head.parentElement.setAttribute("lang",bl);for(var a=[],b=0;b<cl.length;b++){var c=cl[b];a.push([$k[c],c])}a.sort(function(a,b){return a[0]>b[0]?1:a[0]<b[0]?-1:0});for(var d=document.getElementById("languageMenu"),b=d.options.length=0;b<a.length;b++){var e=a[b],c=e[1],e=new Option(e[0],c);c==bl&&(e.selected=!0);d.options.add(e)}for(b=1;10>=
b;b++)a=document.getElementById("level"+b),c=!!il(b),a&&c&&Yk(a,"level_done");(b=document.querySelector('meta[name="viewport"]'))&&725>screen.availWidth&&b.setAttribute("content","width=725, initial-scale=.35, user-scalable=no");setTimeout(jl,1)}function il(a){var b=kl,c;try{c=window.localStorage[b+a]}catch(d){}return c}function Y(a){var b=ll(a);return null===b?"[Unknown message: "+a+"]":b}function ll(a){return(a=document.getElementById(a))?(a=a.textContent,a=a.replace(/\\n/g,"\n")):null}
function ml(a,b){"string"==typeof a&&(a=document.getElementById(a));a.addEventListener("click",b,!0);a.addEventListener("touchend",b,!0)}function jl(){if(!dl){window.GoogleAnalyticsObject="GoogleAnalyticsFunction";var a=function(){(a.q=a.q||[]).push(arguments)};window.GoogleAnalyticsFunction=a;a.l=1*new Date;var b=document.createElement("script");b.async=1;b.src="//www.google-analytics.com/analytics.js";document.head.appendChild(b);a("create","UA-50448074-1","auto");a("send","pageview")}};Hh.animal={M:function(){this.Sc(120);ei(Ki(this,5,""),"","NAME");ei(gi(Ki(this,1,"PIC"),1),Y("Puzzle_picture"));ei(ei(gi(Ki(this,5,""),1),Y("Puzzle_legs")),new Vf(nl),"LEGS");var a=ei,b;b=Ki(this,3,"TRAITS");a(b,Y("Puzzle_traits"))},Nc:function(){var a=document.createElement("mutation");a.setAttribute("animal",this.Ta);return a},dd:function(a){this.ic(parseInt(a.getAttribute("animal"),10))},Ta:0,ic:function(a){this.Ta=a;var b=Y("Puzzle_animal"+a);Ua(this,"NAME").Sa(b);this.Qb=Y("Puzzle_animal"+a+
"HelpUrl")},If:function(){var a=Ua(this,"LEGS");return(a?a.Gc():null)==this.Ta}};Hh.picture={M:function(){this.Sc(30);Ki(this,5,"PIC");Dh(this);this.Uc("")},Nc:Hh.animal.Nc,dd:Hh.animal.dd,Ta:0,ic:function(a){this.Ta=a;var b="puzzle/"+Y("Puzzle_animal"+a+"Pic"),c=Y("Puzzle_animal"+a+"PicHeight");a=Y("Puzzle_animal"+a+"PicWidth");ei(Va(this,"PIC"),new Qk(b,a,c))},If:function(){var a=this.getParent();return a&&a.Ta==this.Ta}};
Hh.trait={M:function(){this.Sc(290);ei(Ki(this,5,""),"","NAME");Eh(this,!0);Fh(this,!0)},Nc:function(){var a=document.createElement("mutation");a.setAttribute("animal",this.Ta);a.setAttribute("trait",this.Vh);return a},dd:function(a){this.ic(parseInt(a.getAttribute("animal"),10),parseInt(a.getAttribute("trait"),10))},Ta:0,Vh:0,ic:function(a,b){this.Ta=a;this.Vh=b;var c=Y("Puzzle_animal"+a+"Trait"+b);Ua(this,"NAME").Sa(c)},If:function(){var a=Ii(this);return a&&a.Ta==this.Ta}};var wi="L\u00e4gg till kommentar",yk="Var god godk\u00e4nn denna app f\u00f6r att du ska kunna spara och dela den.",vk="Chatta med din medarbetare genom att skriva i detta f\u00e4lt.",Wk="F\u00e4ll ihop block",Ai="F\u00e4ll ihop block",Di="Radera block",Ei="Radera %1 block",Ci="Inaktivera block",ui="Duplicera",Bi="Aktivera block",Xk="F\u00e4ll ut block",zi="F\u00e4ll ut block",xi="Externa inmatningar",Fi="Hj\u00e4lp",yi="Radinmatning",zk="Jag",vi="Radera kommentar";var Z={Dc:null,M:function(){hl();var a=document.getElementById("linkButton");"BlocklyStorage"in window?(BlocklyStorage.HTTPREQUEST_ERROR=Y("Games_httpRequestError"),BlocklyStorage.LINK_ALERT=Y("Games_linkAlert"),BlocklyStorage.HASH_ERROR=Y("Games_hashError"),BlocklyStorage.XML_ERROR=Y("Games_xmlError"),BlocklyStorage.alert=Zk.Tj,a&&ml(a,BlocklyStorage.link)):a&&(a.style.display="none");document.getElementById("languageMenu").addEventListener("change",Z.xi,!0)},kj:function(a){document.body.innerHTML=
a;a=document.getElementById("blockly");a.style.height=window.innerHeight+"px";Ck(a,{path:"./",readOnly:!0,Mk:-1!=al.indexOf(bl),scrollbars:!1});a=el("xml","");Z.cg("<xml>"+a+"</xml>")},Gk:function(a,b){if("BlocklyStorage"in window&&1<window.location.hash.length)BlocklyStorage.retrieveXml(window.location.hash.substring(1));else{var c=null;try{c=window.sessionStorage.xe}catch(d){}c&&delete window.sessionStorage.xe;var e=il(fl),g=b&&il(fl-1);(c=c||e||g||a)&&Z.cg(c)}},cg:function(a){Z.Dc?Z.Dc.setValue(a,
-1):(a=Ja(a),Ka(P,a))},Kj:function(){if(void 0!=typeof qa&&window.localStorage){var a=kl+fl;if(Z.Dc)var b=Z.Dc.getValue();else b=Ea(P),b=Ia(b);window.localStorage[a]=b}},qe:function(){window.location=(dl?"index.html":"./")+"?lang="+bl},xi:function(){if(window.sessionStorage){if(Z.Dc)var a=Z.Dc.getValue();else a=Ea(P),a=Ia(a);window.sessionStorage.xe=a}var a=document.getElementById("languageMenu"),a=encodeURIComponent(a.options[a.selectedIndex].value),b=window.location.search,b=1>=b.length?"?lang="+
a:b.match(/[?&]lang=[^&]*/)?b.replace(/([?&]lang=)[^&]*/,"$1"+a):b.replace(/\?/,"?lang="+a+"&");window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+b},nh:function(a){if(a){var b=a.match(/^block_id_(\d+)$/);b&&(a=b[1])}fd(a)},Uj:function(a){return a.replace(/(,\s*)?'block_id_\d+'\)/g,")").trimRight()},Mb:function(a){if("click"==a.type&&"touchend"==Z.Mb.Wf&&Z.Mb.Vf+2E3>Date.now()||Z.Mb.Wf==a.type&&Z.Mb.Vf+400>Date.now())return a.preventDefault(),a.stopPropagation(),
!0;Z.Mb.Wf=a.type;Z.Mb.Vf=Date.now();return!1}};Z.Mb.Wf=null;Z.Mb.Vf=0;Z.Dk=function(){var a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","js-read-only/JS-Interpreter/compiled.js");document.head.appendChild(a)};
Z.Ek=function(){var a=document.createElement("link");a.setAttribute("rel","stylesheet");a.setAttribute("type","text/css");a.setAttribute("href","common/prettify.css");document.head.appendChild(a);a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","common/prettify.js");document.head.appendChild(a)};window.BlocklyInterface=Z;Z.setCode=Z.cg;var $={Eb:!1,Zg:null,Ud:null,Dd:function(a,b,c,d,e,g){function h(){$.Eb&&(k.style.visibility="visible",k.style.zIndex=10,l.style.visibility="hidden")}$.Eb&&$.Db(!1);N(!0);$.Eb=!0;$.Zg=b;$.Ud=g;var k=document.getElementById("dialog");g=document.getElementById("dialogShadow");var l=document.getElementById("dialogBorder"),m;for(m in e)k.style[m]=e[m];d&&(g.style.visibility="visible",g.style.opacity=.3,g.style.zIndex=9,d=document.createElement("div"),d.id="dialogHeader",k.appendChild(d),$.nf=M(d,"mousedown",
null,$.Li));k.appendChild(a);a.className=a.className.replace("dialogHiddenContent","");c&&b?($.ye(b,!1,.2),$.ye(k,!0,.8),setTimeout(h,175)):h()},$g:0,ah:0,Li:function(a){$.qf();if(!cc(a)){var b=document.getElementById("dialog");$.$g=b.offsetLeft-a.clientX;$.ah=b.offsetTop-a.clientY;$.pf=M(document,"mouseup",null,$.qf);$.of=M(document,"mousemove",null,$.Mi);a.stopPropagation()}},Mi:function(a){var b=document.getElementById("dialog"),c=$.$g+a.clientX;a=$.ah+a.clientY;a=Math.max(a,0);a=Math.min(a,window.innerHeight-
b.offsetHeight);c=Math.max(c,0);c=Math.min(c,window.innerWidth-b.offsetWidth);b.style.left=c+"px";b.style.top=a+"px"},qf:function(){$.pf&&(K($.pf),$.pf=null);$.of&&(K($.of),$.of=null)},Db:function(a){function b(){d.style.zIndex=-1;d.style.visibility="hidden";document.getElementById("dialogBorder").style.visibility="hidden"}if($.Eb){$.qf();$.nf&&(K($.nf),$.nf=null);$.Eb=!1;$.Ud&&$.Ud();$.Ud=null;var c=!1===a?null:$.Zg;a=document.getElementById("dialog");var d=document.getElementById("dialogShadow");
d.style.opacity=0;c?($.ye(a,!1,.8),$.ye(c,!0,.2),setTimeout(b,175)):b();a.style.visibility="hidden";a.style.zIndex=-1;for((c=document.getElementById("dialogHeader"))&&c.parentNode.removeChild(c);a.firstChild;)c=a.firstChild,c.className+=" dialogHiddenContent",document.body.appendChild(c)}},ye:function(a,b,c){function d(){e.style.width=g.width+"px";e.style.height=g.height+"px";e.style.left=g.x+"px";e.style.top=g.y+"px";e.style.opacity=c}if(a){var e=document.getElementById("dialogBorder"),g=$.Ri(a);
b?(e.className="dialogAnimate",setTimeout(d,1)):(e.className="",d());e.style.visibility="visible"}},Ri:function(a){if(a.getBBox){var b=a.getBBox(),c=b.height,b=b.width;a=bg(a);var d=a.x,e=a.y}else{c=a.offsetHeight;b=a.offsetWidth;e=d=0;do d+=a.offsetLeft,e+=a.offsetTop,a=a.offsetParent;while(a)}return{height:c,width:b,x:d,y:e}},Tj:function(a){var b=document.getElementById("containerStorage");b.textContent="";a=a.split("\n");for(var c=0;c<a.length;c++){var d=document.createElement("p");d.appendChild(document.createTextNode(a[c]));
b.appendChild(d)}b=document.getElementById("dialogStorage");a=document.getElementById("linkButton");$.Dd(b,a,!0,!0,{width:"50%",left:"25%",top:"5em"},$.lg);$.ig()},ji:function(){if(!il(fl))if($.Eb||0!=gd)setTimeout($.ji,15E3);else{var a=document.getElementById("dialogAbort"),b=document.getElementById("abortCancel");b.addEventListener("click",$.Db,!0);b.addEventListener("touchend",$.Db,!0);b=document.getElementById("abortOk");b.addEventListener("click",Z.qe,!0);b.addEventListener("touchend",Z.qe,!0);
$.Dd(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},function(){document.body.removeEventListener("keydown",$.wg,!0)});document.body.addEventListener("keydown",$.wg,!0)}},pk:function(){var a=document.getElementById("dialogDone");if(P){var b=document.getElementById("dialogLinesText");b.textContent="";var c=qa.ak.Uk(),c=Z.Uj(c),d=c.split("\n").length,e=document.getElementById("containerCode");e.textContent=c;"function"==typeof prettyPrintOne&&(c=e.innerHTML,c=prettyPrintOne(c,"js"),e.innerHTML=c);c=
1==d?Y("Games_linesOfCode1"):Y("Games_linesOfCode2").replace("%1",d);b.appendChild(document.createTextNode(c))}c=10>fl?Y("Games_nextLevel").replace("%1",fl+1):Y("Games_finalLevel");b=document.getElementById("doneCancel");b.addEventListener("click",$.Db,!0);b.addEventListener("touchend",$.Db,!0);b=document.getElementById("doneOk");b.addEventListener("click",Z.zh,!0);b.addEventListener("touchend",Z.zh,!0);$.Dd(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},function(){document.body.removeEventListener("keydown",
$.Jg,!0)});document.body.addEventListener("keydown",$.Jg,!0);document.getElementById("dialogDoneText").textContent=c},Yg:function(a){!$.Eb||13!=a.keyCode&&27!=a.keyCode&&32!=a.keyCode||($.Db(!0),a.stopPropagation(),a.preventDefault())},ig:function(){document.body.addEventListener("keydown",$.Yg,!0)},lg:function(){document.body.removeEventListener("keydown",$.Yg,!0)},Jg:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)$.Db(!0),a.stopPropagation(),a.preventDefault(),27!=a.keyCode&&Z.zh()},
wg:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)$.Db(!0),a.stopPropagation(),a.preventDefault(),27!=a.keyCode&&Z.qe()}};window.BlocklyDialogs=$;$.hideDialog=$.Db;var ol={Nk:!0};F&&H(8);function pl(a){return a&&a.Ai&&a.Ai===ol?a.content:String(a).replace(ql,rl)}var sl={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"};function rl(a){return sl[a]}var ql=/[\x00\x22\x26\x27\x3c\x3e]/g;function tl(){return'<div class="farSide" style="padding: 1ex 3ex 0"><button class="secondary" onclick="BlocklyDialogs.hideDialog(true)">OK</button></div>'};function ul(){return'<div style="display: none"><span id="Puzzle_animal1">Duck</span><span id="Puzzle_animal1Pic">duck.jpg</span><span id="Puzzle_animal1PicHeight">70</span><span id="Puzzle_animal1PicWidth">100</span><span id="Puzzle_animal1Legs">&nbsp;&nbsp;2&nbsp;&nbsp;</span><span id="Puzzle_animal1Trait1">Feathers</span><span id="Puzzle_animal1Trait2">Beak</span><span id="Puzzle_animal1HelpUrl">http://en.wikipedia.org/wiki/Duck</span><span id="Puzzle_animal2">Cat</span><span id="Puzzle_animal2Pic">cat.jpg</span><span id="Puzzle_animal2PicHeight">70</span><span id="Puzzle_animal2PicWidth">100</span><span id="Puzzle_animal2Legs">&nbsp;&nbsp;4&nbsp;&nbsp;</span><span id="Puzzle_animal2Trait1">Whiskers</span><span id="Puzzle_animal2Trait2">Fur</span><span id="Puzzle_animal2HelpUrl">http://en.wikipedia.org/wiki/Cat</span><span id="Puzzle_animal3">Bee</span><span id="Puzzle_animal3Pic">bee.jpg</span><span id="Puzzle_animal3PicHeight">70</span><span id="Puzzle_animal3PicWidth">100</span><span id="Puzzle_animal3Legs">&nbsp;&nbsp;6&nbsp;&nbsp;</span><span id="Puzzle_animal3Trait1">Honey</span><span id="Puzzle_animal3Trait2">Stinger</span><span id="Puzzle_animal3HelpUrl">http://en.wikipedia.org/wiki/bee</span><span id="Puzzle_animal4">Snail</span><span id="Puzzle_animal4Pic">snail.jpg</span><span id="Puzzle_animal4PicHeight">70</span><span id="Puzzle_animal4PicWidth">100</span><span id="Puzzle_animal4Legs">&nbsp;&nbsp;0&nbsp;&nbsp;</span><span id="Puzzle_animal4Trait1">Shell</span><span id="Puzzle_animal4Trait2">Slime</span><span id="Puzzle_animal4HelpUrl">http://en.wikipedia.org/wiki/snail</span><span id="Puzzle_picture">picture:</span><span id="Puzzle_legs">legs:</span><span id="Puzzle_legsChoose">v\u00e4lj...</span><span id="Puzzle_traits">traits:</span><span id="Puzzle_error0">Perfekt!\nAlla %1 block \u00e4r r\u00e4tt.</span><span id="Puzzle_error1">N\u00e4stan! Ett block \u00e4r fel.</span><span id="Puzzle_error2">%1 block \u00e4r fel.</span><span id="Puzzle_tryAgain">Det markerade blocket \u00e4r inte r\u00e4tt.\nF\u00f6rs\u00f6k igen.</span></div>'}
function vl(){var a=ul()+'<table id="header" width="100%"><tr><td valign="bottom"><h1>',b;b='<span id="title">'+(dl?'<a href="index.html?lang='+pl(bl)+'">':'<a href="./?lang='+pl(bl)+'">')+"Blockly Games</a> : "+pl("Pussel")+"</span>";return a+b+'</h1></td><td class="farSide"><select id="languageMenu"></select>&nbsp;<button id="helpButton">Hj\u00e4lp</button>&nbsp;<button id="checkButton" class="primary">Kontrollera svar</button></td></tr></table><div id="blockly"></div><div id="dialogShadow" class="dialogAnimate"></div><div id="dialogBorder"></div><div id="dialog"></div><div id="help" class="dialogHiddenContent"><div style="padding-bottom: 0.7ex">For each animal (green), attach its picture, choose its number of legs, and make a stack of its traits.</div><iframe style="height: 200px; width: 100%; border: none;" src="readonly.html?app=puzzle&lang='+
pl(bl)+'&xml=%3Cblock+type%3D%22animal%22+x%3D%225%22+y%3D%225%22%3E%3Cmutation+animal%3D%221%22%3E%3C%2Fmutation%3E%3Ctitle+name%3D%22LEGS%22%3E1%3C%2Ftitle%3E%3Cvalue+name%3D%22PIC%22%3E%3Cblock+type%3D%22picture%22%3E%3Cmutation+animal%3D%221%22%3E%3C%2Fmutation%3E%3C%2Fblock%3E%3C%2Fvalue%3E%3Cstatement+name%3D%22TRAITS%22%3E%3Cblock+type%3D%22trait%22%3E%3Cmutation+animal%3D%221%22+trait%3D%222%22%3E%3C%2Fmutation%3E%3Cnext%3E%3Cblock+type%3D%22trait%22%3E%3Cmutation+animal%3D%221%22+trait%3D%221%22%3E%3C%2Fmutation%3E%3C%2Fblock%3E%3C%2Fnext%3E%3C%2Fblock%3E%3C%2Fstatement%3E%3C%2Fblock%3E"></iframe>'+
tl()+'</div><div id="answers" class="dialogHiddenContent"><div id="answerMessage"></div><div id="graph"><div id="graphValue"></div></div>'+tl()+"</div>"};var kl="puzzle";
function wl(){function a(){c.style.width=window.innerWidth-20+"px";c.style.height=window.innerHeight-c.offsetTop-15+"px"}document.body.innerHTML=vl();Z.M();var b=-1!=al.indexOf(bl),c=document.getElementById("blockly");a();window.addEventListener("resize",a);Ck(document.getElementById("blockly"),{path:"./",rtl:b,scrollbars:!1,trashcan:!1});var d=il(fl);try{var e=window.sessionStorage.xe}catch(g){e=null}if(e)delete window.sessionStorage.xe,b=Ja(e),Ka(P,b);else if(d)b=Ja(d),Ka(P,b);else{for(var h=[],
k=[],l=[],e=1;ll("Puzzle_animal"+e);){var m=Na(P,"animal");m.ic(e);h.push(m);m=Na(P,"picture");m.ic(e);k.push(m);for(var p=1;ll("Puzzle_animal"+e+"Trait"+p);)m=Na(P,"trait"),m.ic(e,p),l.push(m),p++;e++}xl(h);xl(k);xl(l);h=[].concat(h,k,l);b&&h.reverse();for(e=0;m=h[e];e++)Ra(m,!1),Oa(m),m.w();for(e=k=0;m=h[e];e++){var r=m.j.X().getBBox();m.lk=r.width;m.kk=r.height;m.Fg=r.width*r.height;k+=m.Fg}ri();l=bi();l.width-=50;l.height-=50;for(e=p=0;m=h[e];e++){var r=m.j.X().getBBox(),t=b?r.width+p/k*l.width:
p/k*(l.width-r.width),t=Math.round(t+50*Math.random()),r=Math.round(Math.random()*(l.height-r.height));m.moveBy(t,r);p+=m.Fg}}ml("checkButton",yl);ml("helpButton",function(){zl(!0)});d||zl(!1);if(G){h=cd(P);for(e=0;m=h[e];e++)m.select();hd(Q)}W*=2;Nk(["puzzle/win.mp3","puzzle/win.ogg"],"win")}window.location.pathname.match(/readonly.html$/)?window.addEventListener("load",function(){Z.kj(ul()+'<div id="blockly"></div>')}):window.addEventListener("load",wl);
function xl(a){for(var b=a.length-1;0<b;b--){var c=Math.floor(Math.random()*(b+1)),d=a[b];a[b]=a[c];a[c]=d}}function nl(){for(var a=[[Y("Puzzle_legsChoose"),"0"]],b=1,c;c=ll("Puzzle_animal"+b+"Legs");)a[b]=[c,String(b)],b++;a.sort(function(a,b){return a[0]-b[0]});return a}
function yl(){for(var a=cd(P),b=0,c=[],d=0,e;e=a[d];d++)e.If()||(b++,e.select(),c.push(e));var g=document.getElementById("graphValue");setTimeout(function(){g.style.width=100*(a.length-b)/a.length+"px"},500);1==b?d=[Y("Puzzle_error1"),Y("Puzzle_tryAgain")]:b?d=[Y("Puzzle_error2").replace("%1",b),Y("Puzzle_tryAgain")]:(d=[Y("Puzzle_error0").replace("%1",a.length)],Z.Kj());e=document.getElementById("answerMessage");e.textContent="";for(var h=0;h<d.length;h++){var k=document.createElement("div");k.appendChild(document.createTextNode(d[h]));
e.appendChild(k)}d=document.getElementById("answers");e=document.getElementById("checkButton");$.Dd(d,e,!0,!0,{width:"25%",left:-1!=al.indexOf(bl)?"5%":"70%",top:"5em"},b?$.lg:Z.qe);$.ig();if(c.length){xl(c);var l=c[0],m=function(){l.select();$.Eb&&(setTimeout(function(){hd(l)},150),setTimeout(m,300))};m()}else setTimeout(Al,2E3),Q&&hd(Q)}function Al(){ni("win",.5);for(var a=Fa(P,!1),b=0,c;c=a[b];b++)Bl(c,b/a.length*360)}
function Bl(a,b){if($.Eb){var c=P.qb(),d=c.ra/2,e=c.O/2,c=z(a),g=uf(a),h=Math.max(175,Math.min(d,e)-Math.max(g.height,g.width)/2),k=Date.now(),l=b+k/50%360,h=h*(Math.sin(k%5E3/5E3*2*Math.PI)/8+.875),e=h*Math.cos(l*Math.PI/180)+e-g.width/2,g=h*Math.sin(l*Math.PI/180)+d-g.height/2;5>Math.sqrt(Math.pow(e-c.x,2)+Math.pow(g-c.y,2))?(d=e-c.x,c=g-c.y):(c=180*Math.atan2(g-c.y,e-c.x)/Math.PI%360,c=0>360*c?c+360:c,d=Math.round(5*Math.cos(c*Math.PI/180)),c=Math.round(5*Math.sin(c*Math.PI/180)));a.moveBy(d,c);
setTimeout(Bl.bind(null,a,b),50)}}function zl(a){var b=document.getElementById("help"),c=document.getElementById("helpButton");$.Dd(b,c,a,!0,{width:"50%",left:"25%",top:"5em"},$.lg);$.ig()};
