// Automatically generated file.  Do not edit!
'use strict';var g,n=this;function aa(a){a=a.split(".");for(var b=n,c;c=a.shift();)if(null!=b[c])b=b[c];else return null;return b}function ba(){}function ca(a){a.Vb=function(){return a.Ch?a.Ch:a.Ch=new a}}
function da(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;var c=Object.prototype.toString.call(a);if("[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==b&&"undefined"==typeof a.call)return"object";return b}function ea(a){return"array"==da(a)}function fa(a){var b=da(a);return"array"==b||"object"==b&&"number"==typeof a.length}function p(a){return"string"==typeof a}function r(a){return"number"==typeof a}function s(a){return"function"==da(a)}function ga(a){var b=typeof a;return"object"==b&&null!=a||"function"==b}function ia(a){return a[ja]||(a[ja]=++ka)}var ja="closure_uid_"+(1E9*Math.random()>>>0),ka=0;
function la(a,b,c){return a.call.apply(a.bind,arguments)}function ma(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var c=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(c,d);return a.apply(b,c)}}return function(){return a.apply(b,arguments)}}function na(a,b,c){na=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?la:ma;return na.apply(null,arguments)}
function oa(a,b){var c=Array.prototype.slice.call(arguments,1);return function(){var b=c.slice();b.push.apply(b,arguments);return a.apply(this,b)}}var pa=Date.now||function(){return+new Date};function u(a,b){function c(){}c.prototype=b.prototype;a.n=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.Wk=function(a,c,f){return b.prototype[c].apply(a,Array.prototype.slice.call(arguments,2))}};function qa(a,b){null!=a&&this.append.apply(this,arguments)}g=qa.prototype;g.W="";g.set=function(a){this.W=""+a};g.append=function(a,b,c){this.W+=a;if(null!=b)for(var d=1;d<arguments.length;d++)this.W+=arguments[d];return this};g.clear=function(){this.W=""};g.toString=function(){return this.W};var ra;function sa(a){if(Error.captureStackTrace)Error.captureStackTrace(this,sa);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}u(sa,Error);sa.prototype.name="CustomError";function ta(a,b){for(var c=a.split("%s"),d="",e=Array.prototype.slice.call(arguments,1);e.length&&1<c.length;)d+=c.shift()+e.shift();return d+c.join("%s")}function ua(a){return a.replace(/[\t\r\n ]+/g," ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g,"")}var va=String.prototype.trim?function(a){return a.trim()}:function(a){return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g,"")};function wa(a,b){var c=String(a).toLowerCase(),d=String(b).toLowerCase();return c<d?-1:c==d?0:1}
function xa(a){if(!ya.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(za,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(Aa,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(Ba,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(Ca,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(Da,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(Ea,"&#0;"));return a}var za=/&/g,Aa=/</g,Ba=/>/g,Ca=/"/g,Da=/'/g,Ea=/\x00/g,ya=/[\x00&<>"']/;
function Fa(a){var b={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"'},c;c=n.document.createElement("div");return a.replace(Ga,function(a,e){var f=b[a];if(f)return f;if("#"==e.charAt(0)){var h=Number("0"+e.substr(1));isNaN(h)||(f=String.fromCharCode(h))}f||(c.innerHTML=a+" ",f=c.firstChild.nodeValue.slice(0,-1));return b[a]=f})}
function Ha(a){return a.replace(/&([^;]+);/g,function(a,c){switch(c){case "amp":return"&";case "lt":return"<";case "gt":return">";case "quot":return'"';default:if("#"==c.charAt(0)){var d=Number("0"+c.substr(1));if(!isNaN(d))return String.fromCharCode(d)}return a}})}var Ga=/&([^;\s<&]+);?/g;function w(a,b){return-1!=a.indexOf(b)}function Ia(a,b){return a<b?-1:a>b?1:0};function Ja(a,b){b.unshift(a);sa.call(this,ta.apply(null,b));b.shift()}u(Ja,sa);Ja.prototype.name="AssertionError";function Ka(a,b){throw new Ja("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};function La(){this.tg="";this.Fi=Ma}La.prototype.te=!0;La.prototype.oe=function(){return this.tg};La.prototype.toString=function(){return"Const{"+this.tg+"}"};function Na(a){if(a instanceof La&&a.constructor===La&&a.Fi===Ma)return a.tg;Ka("expected object of type Const, got '"+a+"'");return"type_error:Const"}var Ma={};function Oa(){this.bc="";this.Bi=Pa}g=Oa.prototype;g.te=!0;g.oe=function(){return this.bc};g.Ah=!0;g.ie=function(){return 1};g.toString=function(){return"SafeUrl{"+this.bc+"}"};var Pa={};var x=Array.prototype,Qa=x.indexOf?function(a,b,c){return x.indexOf.call(a,b,c)}:function(a,b,c){c=null==c?0:0>c?Math.max(0,a.length+c):c;if(p(a))return p(b)&&1==b.length?a.indexOf(b,c):-1;for(;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},Ra=x.forEach?function(a,b,c){x.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=p(a)?a.split(""):a,f=0;f<d;f++)f in e&&b.call(c,e[f],f,a)},Sa=x.filter?function(a,b,c){return x.filter.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=[],f=0,h=p(a)?
a.split(""):a,k=0;k<d;k++)if(k in h){var l=h[k];b.call(c,l,k,a)&&(e[f++]=l)}return e},Ta=x.map?function(a,b,c){return x.map.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=Array(d),f=p(a)?a.split(""):a,h=0;h<d;h++)h in f&&(e[h]=b.call(c,f[h],h,a));return e},Ua=x.every?function(a,b,c){return x.every.call(a,b,c)}:function(a,b,c){for(var d=a.length,e=p(a)?a.split(""):a,f=0;f<d;f++)if(f in e&&!b.call(c,e[f],f,a))return!1;return!0};function Va(a,b){return 0<=Qa(a,b)}
function Wa(a,b){var c=Qa(a,b),d;(d=0<=c)&&x.splice.call(a,c,1);return d}function Xa(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]}function Ya(a,b,c,d){x.splice.apply(a,Za(arguments,1))}function Za(a,b,c){return 2>=arguments.length?x.slice.call(a,b):x.slice.call(a,b,c)};function ab(){this.Ke="";this.Ai=bb}ab.prototype.te=!0;var bb={};ab.prototype.oe=function(){return this.Ke};ab.prototype.toString=function(){return"SafeStyle{"+this.Ke+"}"};function cb(a){var b=new ab;b.Ke=a;return b}var db=cb("");
function eb(a){var b="",c;for(c in a){if(!/^[-_a-zA-Z0-9]+$/.test(c))throw Error("Name allows only [-_a-zA-Z0-9], got: "+c);var d=a[c];null!=d&&(d instanceof La?d=Na(d):fb.test(d)||(Ka("String value allows only [-.%_!# a-zA-Z0-9], got: "+d),d="zClosurez"),b+=c+":"+d+";")}return b?cb(b):db}var fb=/^[-.%_!# a-zA-Z0-9]+$/;function gb(a,b){for(var c in a)b.call(void 0,a[c],c,a)}var hb="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ib(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var f=0;f<hb.length;f++)c=hb[f],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}}
function jb(a){var b=arguments.length;if(1==b&&ea(arguments[0]))return jb.apply(null,arguments[0]);for(var c={},d=0;d<b;d++)c[arguments[d]]=!0;return c};var kb=jb("area base br col command embed hr img input keygen link meta param source track wbr".split(" "));function lb(){this.bc="";this.zi=mb;this.mh=null}g=lb.prototype;g.Ah=!0;g.ie=function(){return this.mh};g.te=!0;g.oe=function(){return this.bc};g.toString=function(){return"SafeHtml{"+this.bc+"}"};function nb(a){if(a instanceof lb&&a.constructor===lb&&a.zi===mb)return a.bc;Ka("expected object of type SafeHtml, got '"+a+"'");return"type_error:SafeHtml"}function ob(a){if(a instanceof lb)return a;var b=null;a.Ah&&(b=a.ie());return pb(xa(a.te?a.oe():String(a)),b)}
var qb=/^[a-zA-Z0-9-]+$/,rb=jb("action","cite","data","formaction","href","manifest","poster","src"),sb=jb("link","script","style");
function tb(a,b,c){if(!qb.test(a))throw Error("Invalid tag name <"+a+">.");if(a.toLowerCase()in sb)throw Error("Tag name <"+a+"> is not allowed for SafeHtml.");var d=null,e="<"+a;if(b)for(var f in b){if(!qb.test(f))throw Error('Invalid attribute name "'+f+'".');var h=b[f];if(null!=h){if(h instanceof La)h=Na(h);else if("style"==f.toLowerCase()){if(!ga(h))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof h+" given: "+h);h instanceof ab||(h=eb(h));h instanceof
ab&&h.constructor===ab&&h.Ai===bb?h=h.Ke:(Ka("expected object of type SafeStyle, got '"+h+"'"),h="type_error:SafeStyle")}else{if(/^on/i.test(f))throw Error('Attribute "'+f+'" requires goog.string.Const value, "'+h+'" given.');if(h instanceof Oa)h instanceof Oa&&h.constructor===Oa&&h.Bi===Pa?h=h.bc:(Ka("expected object of type SafeUrl, got '"+h+"'"),h="type_error:SafeUrl");else if(f.toLowerCase()in rb)throw Error('Attribute "'+f+'" requires goog.string.Const or goog.html.SafeUrl value, "'+h+'" given.');
}e+=" "+f+'="'+xa(String(h))+'"'}}void 0!==c?ea(c)||(c=[c]):c=[];!0===kb[a.toLowerCase()]?e+=">":(d=ub(c),e+=">"+nb(d)+"</"+a+">",d=d.ie());(a=b&&b.dir)&&(d=/^(ltr|rtl|auto)$/i.test(a)?0:null);return pb(e,d)}function ub(a){function b(a){ea(a)?Ra(a,b):(a=ob(a),d+=nb(a),a=a.ie(),0==c?c=a:0!=a&&c!=a&&(c=null))}var c=0,d="";Ra(arguments,b);return pb(d,c)}var mb={};function pb(a,b){var c=new lb;c.bc=a;c.mh=b;return c}var vb=pb("",0);var wb={yl:!0};var xb;a:{var yb=n.navigator;if(yb){var zb=yb.userAgent;if(zb){xb=zb;break a}}xb=""};var Ab,Bb,Cb,Db,Eb=w(xb,"Opera")||w(xb,"OPR"),y=w(xb,"Trident")||w(xb,"MSIE"),Fb=w(xb,"Gecko")&&!w(xb.toLowerCase(),"webkit")&&!(w(xb,"Trident")||w(xb,"MSIE")),z=w(xb.toLowerCase(),"webkit"),Gb=n.navigator||null;Ab=w(Gb&&Gb.platform||"","Mac");var Hb=xb;Bb=!!Hb&&w(Hb,"Android");Cb=!!Hb&&w(Hb,"iPhone");Db=!!Hb&&w(Hb,"iPad");function Ib(){var a=n.document;return a?a.documentMode:void 0}
var Jb=function(){var a="",b;if(Eb&&n.opera)return a=n.opera.version,s(a)?a():a;Fb?b=/rv\:([^\);]+)(\)|;)/:y?b=/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/:z&&(b=/WebKit\/(\S+)/);b&&(a=(a=b.exec(xb))?a[1]:"");return y&&(b=Ib(),b>parseFloat(a))?String(b):a}(),Kb={};
function A(a){var b;if(!(b=Kb[a])){b=0;for(var c=va(String(Jb)).split("."),d=va(String(a)).split("."),e=Math.max(c.length,d.length),f=0;0==b&&f<e;f++){var h=c[f]||"",k=d[f]||"",l=/(\d*)(\D*)/g,q=/(\d*)(\D*)/g;do{var m=l.exec(h)||["","",""],t=q.exec(k)||["","",""];if(0==m[0].length&&0==t[0].length)break;b=Ia(0==m[1].length?0:parseInt(m[1],10),0==t[1].length?0:parseInt(t[1],10))||Ia(0==m[2].length,0==t[2].length)||Ia(m[2],t[2])}while(0==b)}b=Kb[a]=0<=b}return b}
var Lb=n.document,Mb=Lb&&y?Ib()||("CSS1Compat"==Lb.compatMode?parseInt(Jb,10):5):void 0;function Nb(a,b){this.width=a;this.height=b}g=Nb.prototype;g.clone=function(){return new Nb(this.width,this.height)};g.toString=function(){return"("+this.width+" x "+this.height+")"};g.Eh=function(){return!(this.width*this.height)};g.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};g.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
g.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};g.scale=function(a,b){var c=r(b)?b:a;this.width*=a;this.height*=c;return this};var Ob=!y||y&&9<=Mb,Pb=!Fb&&!y||y&&y&&9<=Mb||Fb&&A("1.9.1"),Qb=y&&!A("9");function Rb(a,b,c){return Math.min(Math.max(a,b),c)}function Sb(a){a%=360;return 0>360*a?a+360:a};function C(a,b){this.x=void 0!==a?a:0;this.y=void 0!==b?b:0}g=C.prototype;g.clone=function(){return new C(this.x,this.y)};g.toString=function(){return"("+this.x+", "+this.y+")"};function Tb(a,b){var c=a.x-b.x,d=a.y-b.y;return Math.sqrt(c*c+d*d)}g.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};g.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};g.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};
g.translate=function(a,b){a instanceof C?(this.x+=a.x,this.y+=a.y):(this.x+=a,r(b)&&(this.y+=b));return this};g.scale=function(a,b){var c=r(b)?b:a;this.x*=a;this.y*=c;return this};function Ub(a){return a?new Vb(Wb(a)):ra||(ra=new Vb)}function Xb(a,b){gb(b,function(b,d){"style"==d?a.style.cssText=b:"class"==d?a.className=b:"for"==d?a.htmlFor=b:d in Yb?a.setAttribute(Yb[d],b):0==d.lastIndexOf("aria-",0)||0==d.lastIndexOf("data-",0)?a.setAttribute(d,b):a[d]=b})}var Yb={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};
function Zb(){var a=window.document,a="CSS1Compat"==a.compatMode?a.documentElement:a.body;return new Nb(a.clientWidth,a.clientHeight)}function D(a,b,c){return $b(document,arguments)}
function $b(a,b){var c=b[0],d=b[1];if(!Ob&&d&&(d.name||d.type)){c=["<",c];d.name&&c.push(' name="',xa(d.name),'"');if(d.type){c.push(' type="',xa(d.type),'"');var e={};ib(e,d);delete e.type;d=e}c.push(">");c=c.join("")}c=a.createElement(c);d&&(p(d)?c.className=d:ea(d)?c.className=d.join(" "):Xb(c,d));2<b.length&&ac(a,c,b,2);return c}
function ac(a,b,c,d){function e(c){c&&b.appendChild(p(c)?a.createTextNode(c):c)}for(;d<c.length;d++){var f=c[d];!fa(f)||ga(f)&&0<f.nodeType?e(f):Ra(bc(f)?Xa(f):f,e)}}function cc(a){for(var b;b=a.firstChild;)a.removeChild(b)}function dc(a){var b=E.g;b.parentNode&&b.parentNode.insertBefore(a,b)}function F(a){return a&&a.parentNode?a.parentNode.removeChild(a):null}
function ec(a,b){if(a.contains&&1==b.nodeType)return a==b||a.contains(b);if("undefined"!=typeof a.compareDocumentPosition)return a==b||Boolean(a.compareDocumentPosition(b)&16);for(;b&&a!=b;)b=b.parentNode;return b==a}function Wb(a){return 9==a.nodeType?a:a.ownerDocument||a.document}var fc={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1},gc={IMG:" ",BR:"\n"};function hc(a){a=a.getAttributeNode("tabindex");return null!=a&&a.specified}function ic(a){a=a.tabIndex;return r(a)&&0<=a&&32768>a}
function jc(a){var b=[];kc(a,b,!1);return b.join("")}function kc(a,b,c){if(!(a.nodeName in fc))if(3==a.nodeType)c?b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g,"")):b.push(a.nodeValue);else if(a.nodeName in gc)b.push(gc[a.nodeName]);else for(a=a.firstChild;a;)kc(a,b,c),a=a.nextSibling}function bc(a){if(a&&"number"==typeof a.length){if(ga(a))return"function"==typeof a.item||"string"==typeof a.item;if(s(a))return"function"==typeof a.item}return!1}
function Vb(a){this.Gb=a||n.document||document}g=Vb.prototype;g.ib=Ub;g.h=function(a){return p(a)?this.Gb.getElementById(a):a};g.H=function(a,b,c){return $b(this.Gb,arguments)};g.createElement=function(a){return this.Gb.createElement(a)};g.createTextNode=function(a){return this.Gb.createTextNode(String(a))};g.appendChild=function(a,b){a.appendChild(b)};g.append=function(a,b){ac(Wb(a),a,arguments,1)};g.canHaveChildren=function(a){if(1!=a.nodeType)return!1;switch(a.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case "SCRIPT":case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
g.Yh=cc;g.removeNode=F;g.lc=function(a){return Pb&&void 0!=a.children?a.children:Sa(a.childNodes,function(a){return 1==a.nodeType})};g.contains=ec;g.Xb=function(a){var b;(b="A"==a.tagName||"INPUT"==a.tagName||"TEXTAREA"==a.tagName||"SELECT"==a.tagName||"BUTTON"==a.tagName?!a.disabled&&(!hc(a)||ic(a)):hc(a)&&ic(a))&&y?(a=s(a.getBoundingClientRect)?a.getBoundingClientRect():{height:a.offsetHeight,width:a.offsetWidth},a=null!=a&&0<a.height&&0<a.width):a=b;return a};y&&A(8);function G(a){return a&&a.Yi&&a.Yi===wb?a.content:String(a).replace(lc,mc)}var nc={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"};function mc(a){return nc[a]}var lc=/[\x00\x22\x26\x27\x3c\x3e]/g;var oc={};function pc(){return'<div class="farSide" style="padding: 1ex 3ex 0"><button class="secondary" onclick="BlocklyDialogs.hideDialog(true)">OK</button></div>'};function qc(){for(var a=rc,b=H,c='<div style="display: none"><span id="Games_name">Blockly Games</span><span id="Games_puzzle">Puzzle</span><span id="Games_maze">Labirintu</span><span id="Games_bird">Bird</span><span id="Games_turtle">Tostoinu</span><span id="Games_movie">Movie</span><span id="Games_pondBasic">Pond</span><span id="Games_pondAdvanced">JS Pond</span><span id="Games_linesOfCode1">You solved this level with 1 line of JavaScript:</span><span id="Games_linesOfCode2">You solved this level with %1 lines of JavaScript:</span><span id="Games_nextLevel">Are you ready for level %1?</span><span id="Games_finalLevel">Are you ready for the next challenge?</span><span id="Games_linkTooltip">Sarva e alli\u00f2ngia a is brocus. </span><span id="Games_runTooltip">Run the program you wrote.</span><span id="Games_runProgram">Arr\u00f2llia su Programa</span><span id="Games_resetTooltip">Stop the program and reset the level.</span><span id="Games_resetProgram">Reset</span><span id="Games_help">Agiudu</span><span id="Games_dialogOk">OK</span><span id="Games_dialogCancel">Anudda</span><span id="Games_catLogic">L\u00f2gica</span><span id="Games_catLoops">L\u00f2rigas</span><span id="Games_catMath">Matem\u00e0tica</span><span id="Games_catText">Testu</span><span id="Games_catLists">Lista</span><span id="Games_catColour">Colori</span><span id="Games_catVariables">Variabilis</span><span id="Games_catProcedures">Funtzionis</span><span id="Games_httpRequestError">Ddui fut unu problema cun sa pregunta</span><span id="Games_linkAlert">Poni is brocus tuus in custu ac\u00e0piu:\n\n%1</span><span id="Games_hashError">Mi dispraxit, \'%1\' non torrat a pari cun nimancu unu de is programas sarvaus.</span><span id="Games_xmlError">Non potzu carrigai su file sarvau. Fortzis est st\u00e8tiu fatu cun d-una versioni diferenti de Blockly?</span><span id="Games_listVariable">lista</span><span id="Games_textVariable">testu</span></div><div style="display: none"><span id="Pond_playerName">Player</span><span id="Pond_targetName">Target</span><span id="Pond_rabbitName">Rabbit</span><span id="Pond_counterName">Counter</span><span id="Pond_rookName">Rook</span><span id="Pond_sniperName">Sniper</span><span id="Pond_pendulumName">Pendulum</span><span id="Pond_scaredName">Scared</span><span id="Pond_scanTooltip">Scan for enemies.  Specify a direction (0-360).  Returns the distance to the closest enemy in that direction.  Returns Infinity if no enemy found.</span><span id="Pond_cannonTooltip">Fire the cannon.  Specify a direction (0-360) and a range (0-70).</span><span id="Pond_swimTooltip">Swim forward.  Specify a direction (0-360).</span><span id="Pond_stopTooltip">Stop swimming.  Player will slow to a stop.</span><span id="Pond_healthTooltip">Returns the player\'s current health (0 is dead, 100 is healthy).</span><span id="Pond_speedTooltip">Returns the current speed of the player (0 is stopped, 100 is full speed).</span><span id="Pond_locXTooltip">Returns the X coordinate of the player (0 is the left edge, 100 is the right edge).</span><span id="Pond_locYTooltip">Returns the Y coordinate of the player (0 is the bottom edge, 100 is the top edge).</span></div><div style="display: none"></div><table width="100%"><tr><td><h1>'+
('<span id="title">'+(sc?'<a href="index.html?lang='+G(a)+'">':'<a href="./?lang='+G(a)+'">')+"Blockly Games</a> : "+G("JS Pond")+"</span>"),d=" &nbsp; ",e=1;11>e;e++)d+=" "+(e==b?'<span class="level_number level_done" id="level'+G(e)+'">'+G(e)+"</span>":10==e?'<a class="level_number" id="level'+G(e)+'" href="?lang='+G(a)+"&level="+G(e)+G("")+'">'+G(e)+"</a>":'<a class="level_dot" id="level'+G(e)+'" href="?lang='+G(a)+"&level="+G(e)+G("")+'"></a>');return c+d+'</h1></td><td class="farSide"><select id="languageMenu"></select>&nbsp;<button id="linkButton" title="Sarva e alli\u00f2ngia a is brocus. "><img src="media/1x1.gif" class="link icon21"></button>&nbsp;<button id="helpButton">Agiudu</button></td></tr></table><div id="visualization"><canvas id="scratch" width="400" height="400" style="display: none"></canvas><canvas id="display" width="400" height="400"></canvas></div><table id="playerStatTable"><tbody><tr id="playerStatRow"></tr></tbody></table><table width="400"><tr><td style="width: 190px; text-align: center; vertical-align: top;"><button id="docsButton" title="Display the language documentation.">Documentation</button></td><td><button id="runButton" class="primary" title="Run the program you wrote."><img src="media/1x1.gif" class="run icon21"> Arr\u00f2llia su Programa</button><button id="resetButton" class="primary" style="display: none" title="Stop the program and reset the level."><img src="media/1x1.gif" class="stop icon21"> Reset</button></td></tr></table><div id="dialogDocs"><img src="media/1x1.gif" class="close icon21" id="closeDocs"><iframe id="frameDocs"></iframe></div><div id="editor"></div>\n<div id="playerTarget" style="display: none">\n</div>\n\n<div id="playerRabbit" style="display: none">\n/* rabbit */\n// rabbit runs around the field, randomly and never fires; use as a target.\n\n/* go - go to the point specified */\nfunction go (dest_x, dest_y) {\n  var course = plot_course(dest_x, dest_y);\n  while (distance(loc_x(), loc_y(), dest_x, dest_y) > 5) {\n    drive(course, 25);\n  }\n  while (speed() > 0) {\n    drive(course, 0);\n  }\n}\n\n/* distance forumula. */\nfunction distance(x1, y1, x2, y2) {\n  var x = x1 - x2;\n  var y = y1 - y2;\n  return Math.sqrt((x * x) + (y * y));\n}\n\n/* plot_course - figure out which heading to go. */\nfunction plot_course(xx, yy) {\n  var d;\n  var curx = loc_x();\n  var cury = loc_y();\n  var x = curx - xx;\n  var y = cury - yy;\n\n  if (x == 0) {\n    if (yy > cury) {\n      d = 90;\n    } else {\n      d = 270;\n    }\n  } else {\n    if (yy < cury) {\n      if (xx > curx) {\n        d = 360 + Math.atan_deg(y / x);\n      } else {\n        d = 180 + Math.atan_deg(y / x);\n      }\n    } else {\n      if (xx > curx) {\n        d = Math.atan_deg(y / x);\n      } else {\n        d = 180 + Math.atan_deg(y / x);\n      }\n    }\n  }\n  return d;\n}\n\nwhile (true) {\n  // Go somewhere in the field.\n  var x = Math.random() * 100;\n  var y = Math.random() * 100;\n  go(x, y);\n}\n</div>\n\n<div id="playerCounter" style="display: none">\n/* counter */\n/* scan in a counter-clockwise direction (increasing degrees) */\n/* moves when hit */\n\nvar range;\nvar last_dir = 0;\n\nvar res = 2;\nvar d = damage();\nvar angle = Math.random() * 360;\nwhile (true) {\n  while ((range = scan(angle, res)) != Infinity) {\n    if (range > 70) { /* out of range, head toward it */\n      drive(angle, 50);\n      var i = 1;\n      while (i++ < 50) /* use a counter to limit move time */\n        ;\n      drive (angle, 0);\n      if (d != damage()) {\n        d = damage();\n        run();\n      }\n      angle -= 3;\n    } else {\n      while (!cannon(angle, range))\n        ;\n      if (d != damage()) {\n        d = damage();\n        run();\n      }\n      angle -= 15;\n    }\n  }\n  if (d != damage()) {\n    d = damage();\n    run();\n  }\n  angle += res;\n  angle %= 360;\n}\n\n/* run moves around the center of the field */\nfunction run() {\n  var i = 0;\n  var x = loc_x();\n  var y = loc_y();\n\n  if (last_dir == 0) {\n    last_dir = 1;\n    if (y > 51) {\n      drive(270, 100);\n      while (y - 10 < loc_y() && i++ < 50)\n        ;\n      drive(270, 0);\n    } else {\n      drive(90, 100);\n      while (y + 10 > loc_y() && i++ < 50)\n        ;\n      drive(90, 0);\n    }\n  } else {\n    last_dir = 0;\n    if (x > 51) {\n      drive(180, 100);\n      while (x - 10 < loc_x() && i++ < 50)\n        ;\n      drive(180, 0);\n    } else {\n      drive(0, 100);\n      while (x + 10 > loc_x() && i++ < 50)\n        ;\n      drive(0, 0);\n    }\n  }\n}\n</div>\n\n<div id="playerRook" style="display: none">\n/* rook.r  -  scans the battlefield like a rook, i.e., only 0,90,180,270 */\n/* move horizontally only, but looks horz and vertically */\n\n/* move to center of board */\nif (loc_y() < 50) {\n  while (loc_y() < 40)        /* stop near center */\n    drive(90, 100);           /* start moving */\n} else {\n  while (loc_y() > 60)        /* stop near center */\n    drive(270, 100);          /* start moving */\n}\ndrive(0, 0);\nwhile (speed() > 0)\n  ;\n\n/* initialize starting parameters */\nvar d = damage();\nvar course = 0;\nvar boundary = 99;\ndrive(course, 30);\n\n/* main loop */\nwhile(true) {\n  /* look all directions */\n  look(0);\n  look(90);\n  look(180);\n  look(270);\n\n  /* if near end of battlefield, change directions */\n  if (course == 0) {\n    if (loc_x() > boundary || speed() == 0)\n      change();\n  }\n  else {\n    if (loc_x() < boundary || speed() == 0)\n      change();\n  }\n}\n\n/* look somewhere, and fire cannon repeatedly at in-range target */\nfunction look(deg) {\n  var range;\n  while ((range = scan(deg, 4)) <= 70)  {\n    drive(course, 0);\n    cannon(deg, range);\n    if (d + 20 != damage()) {\n      d = damage();\n      change();\n    }\n  }\n}\n\nfunction change() {\n  if (course == 0) {\n    boundary = 1;\n    course = 180;\n  } else {\n    boundary = 99;\n    course = 0;\n  }\n  drive(course, 30);\n}\n</div>\n\n<div id="playerSniper" style="display: none">\n/* sniper */\n/* strategy: since a scan of the entire battlefield can be done in 90 */\n/* degrees from a corner, sniper can scan the field quickly. */\n\n/* external variables, that can be used by any function */\nvar corner = 0;           /* current corner 0, 1, 2, or 2 */\nvar sc = 0;               /* current scan start */\n\nvar range;          /* range to target */\n\n/* initialize the corner info */\n/* x and y location of a corner, and starting scan degree */\nvar c1x = 2,  c1y = 2,  s1 = 0;\nvar c2x = 2,  c2y = 98, s2 = 270;\nvar c3x = 98, c3y = 98, s3 = 180;\nvar c4x = 98, c4y = 2,  s4 = 90;\nvar closest = Infinity;\nnew_corner();       /* start at a random corner */\nvar d = damage();       /* get current damage */\nvar dir = sc;           /* starting scan direction */\n\nwhile (true) {         /* loop is executed forever */\n  while (dir < sc + 90) {  /* scan through 90 degree range */\n    range = scan(dir, 2);   /* look at a direction */\n    if (range <= 70) {\n      while (range > 0) {    /* keep firing while in range */\n        closest = range;     /* set closest flag */\n        cannon(dir, range);   /* fire! */\n        range = scan(dir, 1); /* check target again */\n        if (d + 15 > damage())  /* sustained several hits, */\n          range = 0;            /* goto new corner */\n      }\n      dir -= 10;             /* back up scan, in case */\n    }\n\n    dir += 2;                /* increment scan */\n    if (d != damage()) {     /* check for damage incurred */\n      new_corner();          /* we\'re hit, move now */\n      d = damage();\n      dir = sc;\n    }\n  }\n\n  if (closest == Infinity) {       /* check for any targets in range */\n    new_corner();             /* nothing, move to new corner */\n    d = damage();\n    dir = sc;\n  } else {                     /* targets in range, resume */\n    dir = sc;\n  }\n  closest = Infinity;\n}\n\n/* new corner function to move to a different corner */\nfunction new_corner() {\n  var x, y;\n\n  var rand = Math.floor(Math.random() * 4);           /* pick a random corner */\n  if (rand == corner)       /* but make it different than the */\n    corner = (rand + 1) % 4;/* current corner */\n  else\n    corner = rand;\n  if (corner == 0) {       /* set new x,y and scan start */\n    x = c1x;\n    y = c1y;\n    sc = s1;\n  }\n  if (corner == 1) {\n    x = c2x;\n    y = c2y;\n    sc = s2;\n  }\n  if (corner == 2) {\n    x = c3x;\n    y = c3y;\n    sc = s3;\n  }\n  if (corner == 3) {\n    x = c4x;\n    y = c4y;\n    sc = s4;\n  }\n\n  /* find the heading we need to get to the desired corner */\n  var angle = plot_course(x,y);\n\n  /* start drive train, full speed */\n\n  /* keep traveling until we are within 15 meters */\n  /* speed is checked in case we run into wall, other robot */\n  /* not terribly great, since were are doing nothing while moving */\n\n  while (distance(loc_x(), loc_y(), x, y) > 15)\n    drive(angle, 100);\n\n  /* cut speed, and creep the rest of the way */\n\n  while (distance(loc_x(), loc_y(), x, y) > 1)\n    drive(angle, 20);\n\n  /* stop drive, should coast in the rest of the way */\n  drive(angle, 0);\n}  /* end of new_corner */\n\n/* classical pythagorean distance formula */\nfunction distance(x1, y1, x2, y2) {\n  var x = x1 - x2;\n  var y = y1 - y2;\n  return Math.sqrt((x * x) + (y * y));\n}\n\n/* plot course function, return degree heading to */\n/* reach destination x, y; uses atan() trig function */\nfunction plot_course(xx, yy) {\n  var d;\n  var x,y;\n  var curx, cury;\n\n  curx = loc_x();  /* get current location */\n  cury = loc_y();\n  x = curx - xx;\n  y = cury - yy;\n\n  /* atan only returns -90 to +90, so figure out how to use */\n  /* the atan() value */\n\n  if (x == 0) {      /* x is zero, we either move due north or south */\n    if (yy > cury)\n      d = 90;        /* north */\n    else\n      d = 270;       /* south */\n  } else {\n    if (yy < cury) {\n      if (xx > curx)\n        d = 360 + Math.atan_deg(y / x);  /* south-east, quadrant 4 */\n      else\n        d = 180 + Math.atan_deg(y / x);  /* south-west, quadrant 3 */\n    } else {\n      if (xx > curx)\n        d = Math.atan_deg(y / x);        /* north-east, quadrant 1 */\n      else\n        d = 180 + Math.atan_deg(y / x);  /* north-west, quadrant 2 */\n    }\n  }\n  return d;\n}\n</div>\n\n<div id="playerPendulum" style="display: none">\n/* Slowly moves east and west.  Does not fire. */\nvar west = false;\nwhile (true) {\n  if (west) {\n    if (loc_x() > 15) {\n      drive(180, 25);\n    } else {\n      west = false;\n      drive(0, 0);\n    }\n  } else {\n    if (loc_x() < 75) {\n      drive(0, 25);\n    } else {\n      west = true;\n      drive(0, 0);\n    }\n  }\n}\n</div>\n\n<div id="playerScared" style="display: none">\n/* Moves south-west when hit.  Does not fire. */\nvar d = damage();\nwhile (true) {\n  if (d != damage()) {\n    drive(315, 100);\n    var t = 0;\n    for (var t = 0; t < 100; t++) {}\n    d = damage();\n    drive(0, 0);\n  }\n}\n</div>\n<div id="dialogShadow" class="dialogAnimate"></div><div id="dialogBorder"></div><div id="dialog"></div><div id="dialogDone" class="dialogHiddenContent"><div style="font-size: large; margin: 1em;">Congratulations!</div><div id="dialogLinesText" style="font-size: large; margin: 1em;"></div><pre id="containerCode"></pre><div id="dialogDoneText" style="font-size: large; margin: 1em;"></div><div id="dialogDoneButtons" class="farSide" style="padding: 1ex 3ex 0"><button id="doneCancel">Anudda</button><button id="doneOk" class="secondary">OK</button></div></div>'+
('<div id="dialogStorage" class="dialogHiddenContent"><div id="containerStorage"></div>'+pc()+"</div>")+(3==b?'<div id="helpUseScan" class="dialogHiddenContent"><div style="padding-bottom: 0.7ex">Your solution works, but you can do better.  Use \'scan\' to tell the cannon how far to shoot.</div>'+pc()+"</div>":"")+'<div id="help" class="dialogHiddenContent"><div style="padding-bottom: 0.7ex">'+(1==b?"Use the 'cannon' command to hit the target.  The first parameter is the angle, the second parameter is the range.  Find the right combination.<pre>cannon(0, 70);</pre>":
2==b?"This target needs to be hit many times.  Use a 'while (true)' loop to do something indefinitely.<pre>while (true) {\n  ...\n}</pre>":3==b?"This opponent moves back and forth, making it hard to hit. The 'scan' expression returns the exact range to the opponent in the specified direction.<pre>scan(0, 5)</pre>This range is exactly what the 'cannon' command needs to fire accurately.":4==b?"This opponent is too far away to use the cannon (which has a limit of 70 meters).  Instead, use the 'swim' command to start swimming towards the opponent and crash into it.<pre>swim(0, 50);</pre>":
5==b?"This opponent is also too far away to use the cannon.  But you are too weak to survive a collision.  Swim towards the opponent while your horizontal location is less than than 50.  Then 'stop' and use the cannon.<pre>loc_x() &lt; 50</pre><pre>stop();</pre>":6==b?"This opponent will move away when it is hit.  Swim towards it if it is out of range (70 meters).":7==b?"Rabbit runs around randomly.  Can you hit it?":8==b?"Rook fights back!  But it only looks north, south, east and west.":9==b?"Counter looks in all directions. Can you handle two opponents at once?":
10==b?"Sniper hides in a corner looking for targets.  Good luck.  Seriously.":"")+"</div>"+pc()+"</div>"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var tc={},I,uc,J,vc,wc,xc,yc,zc,Ac,Bc,Cc,Dc,Ec,Fc,Gc;/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Hc(a){var b;I&&(b=a.Ib().Q);var c=D("xml");a=Ic(a,!0);for(var d=0,e;e=a[d];d++){var f=Jc(e);e=K(e);f.setAttribute("x",I?b-e.x:e.x);f.setAttribute("y",e.y);c.appendChild(f)}return c}
function Jc(a){var b=D("block");b.setAttribute("type",a.type);b.setAttribute("id",a.id);if(a.Lh){var c=a.Lh();c&&b.appendChild(c)}for(var d=0;c=a.T[d];d++)for(var e=0,f;f=c.ta[e];e++)if(f.name&&f.$c){var h=D("field",null,f.uh());h.setAttribute("name",f.name);b.appendChild(h)}a.ya&&(c=D("comment",null,a.ya.Jb()),c.setAttribute("pinned",a.ya.A()),d=a.ya.kc(),c.setAttribute("h",d.height),c.setAttribute("w",d.width),b.appendChild(c));d=!1;for(e=0;c=a.T[e];e++){var k;f=!0;5!=c.type&&(h=L(c.p),1==c.type?
(k=D("value"),d=!0):3==c.type&&(k=D("statement")),h&&(k.appendChild(Jc(h)),f=!1),k.setAttribute("name",c.name),f||b.appendChild(k))}d&&b.setAttribute("inline",a.ud);a.isCollapsed()&&b.setAttribute("collapsed",!0);a.disabled&&b.setAttribute("disabled",!0);a.hc&&!M||b.setAttribute("deletable",!1);a.Mb&&!M||b.setAttribute("movable",!1);a.Kc&&!M||b.setAttribute("editable",!1);if(a=Kc(a))k=D("next",null,Jc(a)),b.appendChild(k);return b}function Lc(a){return(new XMLSerializer).serializeToString(a)}
function Mc(a){a=(new DOMParser).parseFromString(a,"text/xml");if(!a||!a.firstChild||"xml"!=a.firstChild.nodeName.toLowerCase()||a.firstChild!==a.lastChild)throw"Blockly.Xml.textToDom did not obtain a valid XML tree.";return a.firstChild}function Nc(a,b){if(I)var c=a.Ib().Q;for(var d=0,e;e=b.childNodes[d];d++)if("block"==e.nodeName.toLowerCase()){var f=Oc(a,e),h=parseInt(e.getAttribute("x"),10);e=parseInt(e.getAttribute("y"),10);isNaN(h)||isNaN(e)||f.moveBy(I?c-h:h,e)}}
function Oc(a,b,c){var d=null,e=b.getAttribute("type");if(!e)throw"Block type unspecified: \n"+b.outerHTML;var f=b.getAttribute("id");if(c&&f){d=Pc(f,a);if(!d)throw"Couldn't get Block with id: "+f;f=d.getParent();d.s&&d.j(!0,!1,!0);d.fill(a,e);d.wa=f}else d=Qc(a,e);d.i||Rc(d);(f=b.getAttribute("inline"))&&Sc(d,"true"==f);(f=b.getAttribute("disabled"))&&Tc(d,"true"==f);(f=b.getAttribute("deletable"))&&Uc(d,"true"==f);if(f=b.getAttribute("movable"))d.Mb="true"==f;(f=b.getAttribute("editable"))&&Vc(d,
"true"==f);for(var h=null,f=0,k;k=b.childNodes[f];f++)if(3!=k.nodeType||!k.data.match(/^\s*$/)){for(var h=null,l=0,q;q=k.childNodes[l];l++)3==q.nodeType&&q.data.match(/^\s*$/)||(h=q);l=k.getAttribute("name");switch(k.nodeName.toLowerCase()){case "mutation":d.kj&&d.kj(k);break;case "comment":Wc(d,k.textContent);var m=k.getAttribute("pinned");m&&setTimeout(function(){d.ya.I("true"==m)},1);h=parseInt(k.getAttribute("w"),10);k=parseInt(k.getAttribute("h"),10);isNaN(h)||isNaN(k)||d.ya.yc(h,k);break;case "title":case "field":Xc(d,
l).Wc(k.textContent);break;case "value":case "statement":k=Yc(d,l);if(!k)throw"Input "+l+" does not exist in block "+e;if(h&&"block"==h.nodeName.toLowerCase())if(h=Oc(a,h,c),h.K)Zc(k.p,h.K);else if(h.C)Zc(k.p,h.C);else throw"Child block does not have output or previous statement.";break;case "next":if(h&&"block"==h.nodeName.toLowerCase()){if(!d.J)throw"Next statement does not exist.";if(d.J.o)throw"Next statement is already connected.";h=Oc(a,h,c);if(!h.C)throw"Next block does not have previous statement.";
Zc(d.J,h.C)}}}(a=b.getAttribute("collapsed"))&&d.Dd("true"==a);(a=Kc(d))?a.F():d.F();return d}function $c(a){for(var b=0,c;c=a.childNodes[b];b++)if("next"==c.nodeName.toLowerCase()){a.removeChild(c);break}}window.Blockly||(window.Blockly={});window.Blockly.Xml||(window.Blockly.Xml={});window.Blockly.Xml.domToText=Lc;window.Blockly.Xml.domToWorkspace=Nc;window.Blockly.Xml.textToDom=Mc;window.Blockly.Xml.workspaceToDom=Hc;/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ad(a){this.v=a;this.P=null;this.nd=new bd(a,!0,!0);this.Pd=new bd(a,!1,!0);this.dd=N("rect",{height:O,width:O,style:"fill: #fff"},null);cd(this.dd,a.Xc)}ad.prototype.j=function(){P(this.He);this.He=null;F(this.dd);this.P=this.v=this.dd=null;this.nd.j();this.nd=null;this.Pd.j();this.Pd=null};
ad.prototype.resize=function(){var a=this.v.Ib();if(a){var b=!1,c=!1;this.P&&this.P.Q==a.Q&&this.P.xa==a.xa&&this.P.Za==a.Za&&this.P.Ya==a.Ya?(this.P&&this.P.Ic==a.Ic&&this.P.Ca==a.Ca&&this.P.Db==a.Db||(b=!0),this.P&&this.P.Ra==a.Ra&&this.P.Bb==a.Bb&&this.P.cb==a.cb||(c=!0)):c=b=!0;b&&this.nd.resize(a);c&&this.Pd.resize(a);this.P&&this.P.Q==a.Q&&this.P.Ya==a.Ya||this.dd.setAttribute("x",this.Pd.dc);this.P&&this.P.xa==a.xa&&this.P.Za==a.Za||this.dd.setAttribute("y",this.nd.Ze);this.P=a}};
ad.prototype.set=function(a,b){this.nd.set(a);this.Pd.set(b)};function bd(a,b,c){this.v=a;this.Ie=c||!1;this.Aa=b;this.pf();b?(this.Va.setAttribute("height",O),this.ba.setAttribute("height",O-6),this.ba.setAttribute("y",3)):(this.Va.setAttribute("width",O),this.ba.setAttribute("width",O-6),this.ba.setAttribute("x",3));this.Ph=Q(this.Va,"mousedown",this,this.Yj);this.Qh=Q(this.ba,"mousedown",this,this.Zj)}var dd,ed,O="ontouchstart"in document.documentElement?25:15;g=bd.prototype;
g.j=function(){this.Ge();this.He&&(P(this.He),this.He=null);P(this.Ph);this.Ph=null;P(this.Qh);this.Qh=null;F(this.g);this.v=this.ba=this.Va=this.g=null};
g.resize=function(a){if(!a&&(a=this.v.Ib(),!a))return;if(this.Aa){var b=a.Q;this.Ie?b-=O:this.I(b<a.Ra);this.Ga=b/a.Ic;if(-Infinity===this.Ga||Infinity===this.Ga||isNaN(this.Ga))this.Ga=0;var c=a.Q*this.Ga,d=(a.Ca-a.Db)*this.Ga;this.ba.setAttribute("width",Math.max(0,c));this.dc=a.Ya;this.Ie&&I&&(this.dc+=a.Ya+O);this.Ze=a.Za+a.xa-O;this.g.setAttribute("transform","translate("+this.dc+", "+this.Ze+")");this.Va.setAttribute("width",Math.max(0,b));this.ba.setAttribute("x",fd(this,d))}else{b=a.xa;this.Ie?
b-=O:this.I(b<a.Ra);this.Ga=b/a.Ra;if(-Infinity===this.Ga||Infinity===this.Ga||isNaN(this.Ga))this.Ga=0;c=a.xa*this.Ga;d=(a.Bb-a.cb)*this.Ga;this.ba.setAttribute("height",Math.max(0,c));this.dc=a.Ya;I||(this.dc+=a.Q-O);this.Ze=a.Za;this.g.setAttribute("transform","translate("+this.dc+", "+this.Ze+")");this.Va.setAttribute("height",Math.max(0,b));this.ba.setAttribute("y",fd(this,d))}gd(this)};
g.pf=function(){this.g=N("g",{},null);this.Va=N("rect",{"class":"blocklyScrollbarBackground"},this.g);var a=Math.floor((O-6)/2);this.ba=N("rect",{"class":"blocklyScrollbarKnob",rx:a,ry:a},this.g);cd(this.g,this.v.Xc)};g.A=function(){return"none"!=this.g.getAttribute("display")};g.I=function(a){if(a!=this.A()){if(this.Ie)throw"Unable to toggle visibility of paired scrollbars.";a?this.g.setAttribute("display","block"):(this.v.bi({x:0,y:0}),this.g.setAttribute("display","none"))}};
g.Yj=function(a){this.Ge();if(!hd(a)){var b=id(a),b=this.Aa?b.x:b.y,c=jd(this.ba),c=this.Aa?c.x:c.y,d=parseFloat(this.ba.getAttribute(this.Aa?"width":"height")),e=parseFloat(this.ba.getAttribute(this.Aa?"x":"y")),f=.95*d;b<=c?e-=f:b>=c+d&&(e+=f);this.ba.setAttribute(this.Aa?"x":"y",fd(this,e));gd(this)}a.stopPropagation()};
g.Zj=function(a){this.Ge();hd(a)||(this.vk=parseFloat(this.ba.getAttribute(this.Aa?"x":"y")),this.xk=this.Aa?a.clientX:a.clientY,dd=Q(document,"mouseup",this,this.Ge),ed=Q(document,"mousemove",this,this.ak));a.stopPropagation()};g.ak=function(a){this.ba.setAttribute(this.Aa?"x":"y",fd(this,this.vk+((this.Aa?a.clientX:a.clientY)-this.xk)));gd(this)};g.Ge=function(){kd();ld(!0);dd&&(P(dd),dd=null);ed&&(P(ed),ed=null)};
function fd(a,b){if(0>=b||isNaN(b))b=0;else{var c=a.Aa?"width":"height",d=parseFloat(a.Va.getAttribute(c)),c=parseFloat(a.ba.getAttribute(c));b=Math.min(b,d-c)}return b}function gd(a){var b=parseFloat(a.ba.getAttribute(a.Aa?"x":"y")),c=parseFloat(a.Va.getAttribute(a.Aa?"width":"height")),b=b/c;isNaN(b)&&(b=0);c={};a.Aa?c.x=b:c.y=b;a.v.bi(c)}g.set=function(a){this.ba.setAttribute(this.Aa?"x":"y",a*this.Ga);gd(this)};
function cd(a,b){var c=b.nextSibling,d=b.parentNode;if(!d)throw"Reference node has no parent.";c?d.insertBefore(a,c):d.appendChild(a)};function md(){0!=nd&&(od[ia(this)]=this);this.ed=this.ed;this.Ee=this.Ee}var nd=0,od={};md.prototype.ed=!1;md.prototype.j=function(){if(!this.ed&&(this.ed=!0,this.X(),0!=nd)){var a=ia(this);delete od[a]}};md.prototype.X=function(){if(this.Ee)for(;this.Ee.length;)this.Ee.shift()()};var pd="closure_listenable_"+(1E6*Math.random()|0),qd=0;function rd(a,b,c,d,e){this.qc=a;this.Le=null;this.src=b;this.type=c;this.Vd=!!d;this.qe=e;this.key=++qd;this.Tc=this.Ud=!1}function sd(a){a.Tc=!0;a.qc=null;a.Le=null;a.src=null;a.qe=null};function td(a){this.src=a;this.Ba={};this.Od=0}td.prototype.add=function(a,b,c,d,e){var f=a.toString();a=this.Ba[f];a||(a=this.Ba[f]=[],this.Od++);var h=ud(a,b,d,e);-1<h?(b=a[h],c||(b.Ud=!1)):(b=new rd(b,this.src,f,!!d,e),b.Ud=c,a.push(b));return b};td.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.Ba))return!1;var e=this.Ba[a];b=ud(e,b,c,d);return-1<b?(sd(e[b]),x.splice.call(e,b,1),0==e.length&&(delete this.Ba[a],this.Od--),!0):!1};
function vd(a,b){var c=b.type;if(!(c in a.Ba))return!1;var d=Wa(a.Ba[c],b);d&&(sd(b),0==a.Ba[c].length&&(delete a.Ba[c],a.Od--));return d}td.prototype.Pe=function(a){a=a&&a.toString();var b=0,c;for(c in this.Ba)if(!a||c==a){for(var d=this.Ba[c],e=0;e<d.length;e++)++b,sd(d[e]);delete this.Ba[c];this.Od--}return b};td.prototype.ld=function(a,b,c,d){a=this.Ba[a.toString()];var e=-1;a&&(e=ud(a,b,c,d));return-1<e?a[e]:null};
function ud(a,b,c,d){for(var e=0;e<a.length;++e){var f=a[e];if(!f.Tc&&f.qc==b&&f.Vd==!!c&&f.qe==d)return e}return-1};function wd(a,b){this.type=a;this.currentTarget=this.target=b;this.defaultPrevented=this.uc=!1;this.Zh=!0}wd.prototype.X=function(){};wd.prototype.j=function(){};wd.prototype.stopPropagation=function(){this.uc=!0};wd.prototype.preventDefault=function(){this.defaultPrevented=!0;this.Zh=!1};var xd=!y||y&&9<=Mb,yd=!y||y&&9<=Mb,zd=y&&!A("9");!z||A("528");Fb&&A("1.9b")||y&&A("8")||Eb&&A("9.5")||z&&A("528");Fb&&!A("8")||y&&A("9");var Ad="ontouchstart"in n||!!(n.document&&document.documentElement&&"ontouchstart"in document.documentElement)||!(!n.navigator||!n.navigator.msMaxTouchPoints);function Bd(a){Bd[" "](a);return a}Bd[" "]=ba;function Cd(a,b){wd.call(this,a?a.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.charCode=this.keyCode=this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.$f=!1;this.Hb=null;a&&this.Y(a,b)}u(Cd,wd);var Dd=[1,4,2];
Cd.prototype.Y=function(a,b){var c=this.type=a.type;this.target=a.target||a.srcElement;this.currentTarget=b;var d=a.relatedTarget;if(d){if(Fb){var e;a:{try{Bd(d.nodeName);e=!0;break a}catch(f){}e=!1}e||(d=null)}}else"mouseover"==c?d=a.fromElement:"mouseout"==c&&(d=a.toElement);this.relatedTarget=d;this.offsetX=z||void 0!==a.offsetX?a.offsetX:a.layerX;this.offsetY=z||void 0!==a.offsetY?a.offsetY:a.layerY;this.clientX=void 0!==a.clientX?a.clientX:a.pageX;this.clientY=void 0!==a.clientY?a.clientY:a.pageY;
this.screenX=a.screenX||0;this.screenY=a.screenY||0;this.button=a.button;this.keyCode=a.keyCode||0;this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.$f=Ab?a.metaKey:a.ctrlKey;this.state=a.state;this.Hb=a;a.defaultPrevented&&this.preventDefault()};function Ed(a){return xd?0==a.Hb.button:"click"==a.type?!0:!!(a.Hb.button&Dd[0])}
Cd.prototype.stopPropagation=function(){Cd.n.stopPropagation.call(this);this.Hb.stopPropagation?this.Hb.stopPropagation():this.Hb.cancelBubble=!0};Cd.prototype.preventDefault=function(){Cd.n.preventDefault.call(this);var a=this.Hb;if(a.preventDefault)a.preventDefault();else if(a.returnValue=!1,zd)try{if(a.ctrlKey||112<=a.keyCode&&123>=a.keyCode)a.keyCode=-1}catch(b){}};Cd.prototype.X=function(){};var Fd="closure_lm_"+(1E6*Math.random()|0),Gd={},Hd=0;function Id(a,b,c,d,e){if(ea(b)){for(var f=0;f<b.length;f++)Id(a,b[f],c,d,e);return null}c=Jd(c);if(a&&a[pd])a=a.D(b,c,d,e);else{if(!b)throw Error("Invalid event type");var f=!!d,h=Kd(a);h||(a[Fd]=h=new td(a));c=h.add(b,c,!1,d,e);c.Le||(d=Ld(),c.Le=d,d.src=a,d.qc=c,a.addEventListener?a.addEventListener(b.toString(),d,f):a.attachEvent(Md(b.toString()),d),Hd++);a=c}return a}
function Ld(){var a=Nd,b=yd?function(c){return a.call(b.src,b.qc,c)}:function(c){c=a.call(b.src,b.qc,c);if(!c)return c};return b}function Od(a,b,c,d,e){if(ea(b))for(var f=0;f<b.length;f++)Od(a,b[f],c,d,e);else c=Jd(c),a&&a[pd]?a.Wa(b,c,d,e):a&&(a=Kd(a))&&(b=a.ld(b,c,!!d,e))&&Pd(b)}
function Pd(a){if(r(a)||!a||a.Tc)return!1;var b=a.src;if(b&&b[pd])return vd(b.Ub,a);var c=a.type,d=a.Le;b.removeEventListener?b.removeEventListener(c,d,a.Vd):b.detachEvent&&b.detachEvent(Md(c),d);Hd--;(c=Kd(b))?(vd(c,a),0==c.Od&&(c.src=null,b[Fd]=null)):sd(a);return!0}function Md(a){return a in Gd?Gd[a]:Gd[a]="on"+a}function Qd(a,b,c,d){var e=1;if(a=Kd(a))if(b=a.Ba[b.toString()])for(b=b.concat(),a=0;a<b.length;a++){var f=b[a];f&&f.Vd==c&&!f.Tc&&(e&=!1!==Rd(f,d))}return Boolean(e)}
function Rd(a,b){var c=a.qc,d=a.qe||a.src;a.Ud&&Pd(a);return c.call(d,b)}
function Nd(a,b){if(a.Tc)return!0;if(!yd){var c=b||aa("window.event"),d=new Cd(c,this),e=!0;if(!(0>c.keyCode||void 0!=c.returnValue)){a:{var f=!1;if(0==c.keyCode)try{c.keyCode=-1;break a}catch(h){f=!0}if(f||void 0==c.returnValue)c.returnValue=!0}c=[];for(f=d.currentTarget;f;f=f.parentNode)c.push(f);for(var f=a.type,k=c.length-1;!d.uc&&0<=k;k--)d.currentTarget=c[k],e&=Qd(c[k],f,!0,d);for(k=0;!d.uc&&k<c.length;k++)d.currentTarget=c[k],e&=Qd(c[k],f,!1,d)}return e}return Rd(a,new Cd(b,this))}
function Kd(a){a=a[Fd];return a instanceof td?a:null}var Sd="__closure_events_fn_"+(1E9*Math.random()>>>0);function Jd(a){if(s(a))return a;a[Sd]||(a[Sd]=function(b){return a.handleEvent(b)});return a[Sd]};function Td(){md.call(this);this.Ub=new td(this);this.Ii=this;this.Zf=null}u(Td,md);Td.prototype[pd]=!0;g=Td.prototype;g.me=function(){return this.Zf};g.jg=function(a){this.Zf=a};g.addEventListener=function(a,b,c,d){Id(this,a,b,c,d)};g.removeEventListener=function(a,b,c,d){Od(this,a,b,c,d)};
g.dispatchEvent=function(a){var b,c=this.me();if(c)for(b=[];c;c=c.me())b.push(c);var c=this.Ii,d=a.type||a;if(p(a))a=new wd(a,c);else if(a instanceof wd)a.target=a.target||c;else{var e=a;a=new wd(d,c);ib(a,e)}var e=!0,f;if(b)for(var h=b.length-1;!a.uc&&0<=h;h--)f=a.currentTarget=b[h],e=Ud(f,d,!0,a)&&e;a.uc||(f=a.currentTarget=c,e=Ud(f,d,!0,a)&&e,a.uc||(e=Ud(f,d,!1,a)&&e));if(b)for(h=0;!a.uc&&h<b.length;h++)f=a.currentTarget=b[h],e=Ud(f,d,!1,a)&&e;return e};
g.X=function(){Td.n.X.call(this);this.Ub&&this.Ub.Pe(void 0);this.Zf=null};g.D=function(a,b,c,d){return this.Ub.add(String(a),b,!1,c,d)};g.Wa=function(a,b,c,d){return this.Ub.remove(String(a),b,c,d)};function Ud(a,b,c,d){b=a.Ub.Ba[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,f=0;f<b.length;++f){var h=b[f];if(h&&!h.Tc&&h.Vd==c){var k=h.qc,l=h.qe||h.src;h.Ud&&vd(a.Ub,h);e=!1!==k.call(l,d)&&e}}return e&&0!=d.Zh}g.ld=function(a,b,c,d){return this.Ub.ld(String(a),b,c,d)};function Vd(a,b,c){if(s(a))c&&(a=na(a,c));else if(a&&"function"==typeof a.handleEvent)a=na(a.handleEvent,a);else throw Error("Invalid listener argument");return 2147483647<b?-1:n.setTimeout(a,b||0)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Wd(a){this.v=a}g=Wd.prototype;g.cd=47;g.$e=45;g.ad=15;g.wi=35;g.Cg=35;g.Rd=25;g.wb=!1;g.g=null;g.We=null;g.Rf=0;g.$b=0;g.Hh=0;g.li=0;
g.H=function(){this.g=N("g",{filter:"url(#blocklyTrashcanShadowFilter)"},null);var a=N("clipPath",{id:"blocklyTrashBodyClipPath"},this.g);N("rect",{width:this.cd,height:this.$e,y:this.ad},a);N("image",{width:Xd,height:Yd,y:-32,"clip-path":"url(#blocklyTrashBodyClipPath)"},this.g).setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",Zd+$d);a=N("clipPath",{id:"blocklyTrashLidClipPath"},this.g);N("rect",{width:this.cd,height:this.ad},a);this.We=N("image",{width:Xd,height:Yd,y:-32,"clip-path":"url(#blocklyTrashLidClipPath)"},
this.g);this.We.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",Zd+$d);return this.g};g.Y=function(){ae(this,!1);this.zd();Q(window,"resize",this,this.zd)};g.j=function(){this.g&&(F(this.g),this.g=null);this.v=this.We=null;n.clearTimeout(this.Rf)};g.zd=function(){var a=this.v.Ib();a&&(this.Hh=I?this.Cg:a.Q+a.Ya-this.cd-this.Cg,this.li=a.xa+a.Za-(this.$e+this.ad)-this.wi,this.g.setAttribute("transform","translate("+this.Hh+","+this.li+")"))};
function ae(a,b){a.wb!=b&&(n.clearTimeout(a.Rf),a.wb=b,a.Hg())}g.Hg=function(){this.$b+=this.wb?10:-10;this.$b=Math.max(0,this.$b);this.We.setAttribute("transform","rotate("+(I?-this.$b:this.$b)+", "+(I?4:this.cd-4)+", "+(this.ad-2)+")");if(this.wb?45>this.$b:0<this.$b)this.Rf=Vd(this.Hg,5,this)};g.close=function(){ae(this,!1)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function be(a,b){this.Ib=a;this.bi=b;this.Fh=!1;this.Yc=[];this.Tf=Infinity;var c=[];c[1]=new ce;c[2]=new ce;c[3]=new ce;c[4]=new ce;this.Xi=c}g=be.prototype;g.xf=!1;g.scrollX=0;g.scrollY=0;g.Ia=null;g.zf=null;g.cc=null;g.H=function(){this.g=N("g",{},null);this.aa=N("g",{},this.g);this.Xc=N("g",{},this.g);de(this);return this.g};g.j=function(){this.g&&(F(this.g),this.g=null);this.Xc=this.aa=null;this.Ia&&(this.Ia.j(),this.Ia=null)};
function ee(){var a=E;if(uc&&!M){a.Ia=new Wd(a);var b=a.Ia.H();a.g.insertBefore(b,a.aa);a.Ia.Y()}}function fe(a,b){a.Yc.push(b);ge&&a==E&&-1==he.indexOf(b)&&he.push(b);de(a)}function ie(a,b){for(var c=!1,d,e=0;d=a.Yc[e];e++)if(d==b){a.Yc.splice(e,1);c=!0;break}if(!c)throw"Block not present in workspace's list of top-most blocks.";ge&&a==E&&he.vl(b);de(a)}
function Ic(a,b){var c=[].concat(a.Yc);if(b&&1<c.length){var d=Math.sin(3/180*Math.PI);I&&(d*=-1);c.sort(function(a,b){var c=K(a),k=K(b);return c.y+d*c.x-(k.y+d*k.x)})}return c}function je(a){a=Ic(a,!1);for(var b=0;b<a.length;b++)a.push.apply(a,a[b].lc());return a}g.clear=function(){for(ld();this.Yc.length;)this.Yc[0].j()};g.F=function(){for(var a=je(this),b=0,c;c=a[b];b++)c.lc().length||c.F()};function ke(a,b){for(var c=je(a),d=0,e;e=c[d];d++)if(e.id==b)return e;return null}
function le(a,b){a.wg=b;a.xg&&(P(a.xg),a.xg=null);b&&(a.xg=Q(a.aa,"blocklySelectChange",a,function(){this.wg=!1}))}function me(a){var b=E;b.wg&&0!=ne&&le(b,!1);if(b.wg){var c=null;if(a&&(c=ke(b,a),!c))return;le(b,!1);c?c.select():R&&oe();setTimeout(function(){le(b,!0)},1)}}function de(a){a.zf&&window.clearTimeout(a.zf);var b=a.aa;b&&(a.zf=window.setTimeout(function(){pe(b,"blocklyWorkspaceChange")},0))}function qe(a){return Infinity==a.Tf?Infinity:a.Tf-je(a).length}be.prototype.clear=be.prototype.clear;function re(a,b,c,d){this.top=a;this.right=b;this.bottom=c;this.left=d}g=re.prototype;g.clone=function(){return new re(this.top,this.right,this.bottom,this.left)};g.toString=function(){return"("+this.top+"t, "+this.right+"r, "+this.bottom+"b, "+this.left+"l)"};g.contains=function(a){return this&&a?a instanceof re?a.left>=this.left&&a.right<=this.right&&a.top>=this.top&&a.bottom<=this.bottom:a.x>=this.left&&a.x<=this.right&&a.y>=this.top&&a.y<=this.bottom:!1};
g.expand=function(a,b,c,d){ga(a)?(this.top-=a.top,this.right+=a.right,this.bottom+=a.bottom,this.left-=a.left):(this.top-=a,this.right+=b,this.bottom+=c,this.left-=d);return this};g.ceil=function(){this.top=Math.ceil(this.top);this.right=Math.ceil(this.right);this.bottom=Math.ceil(this.bottom);this.left=Math.ceil(this.left);return this};g.floor=function(){this.top=Math.floor(this.top);this.right=Math.floor(this.right);this.bottom=Math.floor(this.bottom);this.left=Math.floor(this.left);return this};
g.round=function(){this.top=Math.round(this.top);this.right=Math.round(this.right);this.bottom=Math.round(this.bottom);this.left=Math.round(this.left);return this};g.translate=function(a,b){a instanceof C?(this.left+=a.x,this.right+=a.x,this.top+=a.y,this.bottom+=a.y):(this.left+=a,this.right+=a,r(b)&&(this.top+=b,this.bottom+=b));return this};g.scale=function(a,b){var c=r(b)?b:a;this.left*=a;this.right*=a;this.top*=c;this.bottom*=c;return this};function se(a,b,c,d){this.left=a;this.top=b;this.width=c;this.height=d}g=se.prototype;g.clone=function(){return new se(this.left,this.top,this.width,this.height)};g.toString=function(){return"("+this.left+", "+this.top+" - "+this.width+"w x "+this.height+"h)"};g.contains=function(a){return a instanceof se?this.left<=a.left&&this.left+this.width>=a.left+a.width&&this.top<=a.top&&this.top+this.height>=a.top+a.height:a.x>=this.left&&a.x<=this.left+this.width&&a.y>=this.top&&a.y<=this.top+this.height};
g.sh=function(){return new Nb(this.width,this.height)};g.ceil=function(){this.left=Math.ceil(this.left);this.top=Math.ceil(this.top);this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};g.floor=function(){this.left=Math.floor(this.left);this.top=Math.floor(this.top);this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
g.round=function(){this.left=Math.round(this.left);this.top=Math.round(this.top);this.width=Math.round(this.width);this.height=Math.round(this.height);return this};g.translate=function(a,b){a instanceof C?(this.left+=a.x,this.top+=a.y):(this.left+=a,r(b)&&(this.top+=b));return this};g.scale=function(a,b){var c=r(b)?b:a;this.left*=a;this.width*=a;this.top*=c;this.height*=c;return this};function te(a,b){var c=Wb(a);return c.defaultView&&c.defaultView.getComputedStyle&&(c=c.defaultView.getComputedStyle(a,null))?c[b]||c.getPropertyValue(b)||"":""}function ue(a,b){return te(a,b)||(a.currentStyle?a.currentStyle[b]:null)||a.style&&a.style[b]}function ve(){var a=document,b=a.body,a=a.documentElement;return new C(b.scrollLeft||a.scrollLeft,b.scrollTop||a.scrollTop)}
function we(a){var b;try{b=a.getBoundingClientRect()}catch(c){return{left:0,top:0,right:0,bottom:0}}y&&a.ownerDocument.body&&(a=a.ownerDocument,b.left-=a.documentElement.clientLeft+a.body.clientLeft,b.top-=a.documentElement.clientTop+a.body.clientTop);return b}
function xe(a){if(y&&!(y&&8<=Mb))return a.offsetParent;var b=Wb(a),c=ue(a,"position"),d="fixed"==c||"absolute"==c;for(a=a.parentNode;a&&a!=b;a=a.parentNode)if(c=ue(a,"position"),d=d&&"static"==c&&a!=b.documentElement&&a!=b.body,!d&&(a.scrollWidth>a.clientWidth||a.scrollHeight>a.clientHeight||"fixed"==c||"absolute"==c||"relative"==c))return a;return null}
function ye(a){var b,c=Wb(a),d=ue(a,"position"),e=Fb&&c.getBoxObjectFor&&!a.getBoundingClientRect&&"absolute"==d&&(b=c.getBoxObjectFor(a))&&(0>b.screenX||0>b.screenY),f=new C(0,0),h;b=c?Wb(c):document;(h=!y||y&&9<=Mb)||(h="CSS1Compat"==Ub(b).Gb.compatMode);h=h?b.documentElement:b.body;if(a==h)return f;if(a.getBoundingClientRect)b=we(a),c=Ub(c).Gb,a=z||"CSS1Compat"!=c.compatMode?c.body||c.documentElement:c.documentElement,c=c.parentWindow||c.defaultView,a=y&&A("10")&&c.pageYOffset!=a.scrollTop?new C(a.scrollLeft,
a.scrollTop):new C(c.pageXOffset||a.scrollLeft,c.pageYOffset||a.scrollTop),f.x=b.left+a.x,f.y=b.top+a.y;else if(c.getBoxObjectFor&&!e)b=c.getBoxObjectFor(a),a=c.getBoxObjectFor(h),f.x=b.screenX-a.screenX,f.y=b.screenY-a.screenY;else{b=a;do{f.x+=b.offsetLeft;f.y+=b.offsetTop;b!=a&&(f.x+=b.clientLeft||0,f.y+=b.clientTop||0);if(z&&"fixed"==ue(b,"position")){f.x+=c.body.scrollLeft;f.y+=c.body.scrollTop;break}b=b.offsetParent}while(b&&b!=a);if(Eb||z&&"absolute"==d)f.y-=c.body.offsetTop;for(b=a;(b=xe(b))&&
b!=c.body&&b!=h;)f.x-=b.scrollLeft,Eb&&"TR"==b.tagName||(f.y-=b.scrollTop)}return f}function ze(a){var b=Ae;if("none"!=ue(a,"display"))return b(a);var c=a.style,d=c.display,e=c.visibility,f=c.position;c.visibility="hidden";c.position="absolute";c.display="inline";a=b(a);c.display=d;c.position=f;c.visibility=e;return a}function Ae(a){var b=a.offsetWidth,c=a.offsetHeight,d=z&&!b&&!c;return(void 0===b||d)&&a.getBoundingClientRect?(a=we(a),new Nb(a.right-a.left,a.bottom-a.top)):new Nb(b,c)}
function Be(a){var b=ye(a);a=ze(a);return new se(b.x,b.y,a.width,a.height)}function Ce(a,b){a.style.display=b?"":"none"}var De=Fb?"MozUserSelect":z?"WebkitUserSelect":null;function Ee(a,b,c){c=c?null:a.getElementsByTagName("*");if(De){if(b=b?"none":"",a.style[De]=b,c){a=0;for(var d;d=c[a];a++)d.style[De]=b}}else if(y||Eb)if(b=b?"on":"",a.setAttribute("unselectable",b),c)for(a=0;d=c[a];a++)d.setAttribute("unselectable",b)}var Fe={thin:2,medium:4,thick:6};
function Ge(a,b){if("none"==(a.currentStyle?a.currentStyle[b+"Style"]:null))return 0;var c=a.currentStyle?a.currentStyle[b+"Width"]:null,d;if(c in Fe)d=Fe[c];else if(/^\d+px?$/.test(c))d=parseInt(c,10);else{d=a.style.left;var e=a.runtimeStyle.left;a.runtimeStyle.left=a.currentStyle.left;a.style.left=c;c=a.style.pixelLeft;a.style.left=d;a.runtimeStyle.left=e;d=c}return d}
function He(a){if(y&&!(y&&9<=Mb)){var b=Ge(a,"borderLeft"),c=Ge(a,"borderRight"),d=Ge(a,"borderTop");a=Ge(a,"borderBottom");return new re(d,c,a,b)}b=te(a,"borderLeftWidth");c=te(a,"borderRightWidth");d=te(a,"borderTopWidth");a=te(a,"borderBottomWidth");return new re(parseFloat(d),parseFloat(c),parseFloat(a),parseFloat(b))};function Ie(a){md.call(this);this.xh=a;this.Ae={}}u(Ie,md);var Je=[];g=Ie.prototype;g.D=function(a,b,c,d){ea(b)||(b&&(Je[0]=b.toString()),b=Je);for(var e=0;e<b.length;e++){var f=Id(a,b[e],c||this.handleEvent,d||!1,this.xh||this);if(!f)break;this.Ae[f.key]=f}return this};
g.Wa=function(a,b,c,d,e){if(ea(b))for(var f=0;f<b.length;f++)this.Wa(a,b[f],c,d,e);else c=c||this.handleEvent,e=e||this.xh||this,c=Jd(c),d=!!d,b=a&&a[pd]?a.ld(b,c,d,e):a?(a=Kd(a))?a.ld(b,c,d,e):null:null,b&&(Pd(b),delete this.Ae[b.key]);return this};g.Pe=function(){gb(this.Ae,Pd);this.Ae={}};g.X=function(){Ie.n.X.call(this);this.Pe()};g.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented");};function Ke(){}ca(Ke);Ke.prototype.Wj=0;function Le(a){Td.call(this);this.Zd=a||Ub();this.Se=Me;this.se=null;this.B=!1;this.w=null;this.Wb=void 0;this.Rb=this.R=this.wa=this.Ce=null;this.Kk=!1}u(Le,Td);Le.prototype.Ij=Ke.Vb();var Me=null;
function Ne(a,b){switch(a){case 1:return b?"disable":"enable";case 2:return b?"highlight":"unhighlight";case 4:return b?"activate":"deactivate";case 8:return b?"select":"unselect";case 16:return b?"check":"uncheck";case 32:return b?"focus":"blur";case 64:return b?"open":"close"}throw Error("Invalid component state");}function Oe(a){return a.se||(a.se=":"+(a.Ij.Wj++).toString(36))}g=Le.prototype;g.h=function(){return this.w};function Pe(a){a.Wb||(a.Wb=new Ie(a));return a.Wb}
g.Na=function(a){if(this==a)throw Error("Unable to set parent component");if(a&&this.wa&&this.se&&Qe(this.wa,this.se)&&this.wa!=a)throw Error("Unable to set parent component");this.wa=a;Le.n.jg.call(this,a)};g.getParent=function(){return this.wa};g.jg=function(a){if(this.wa&&this.wa!=a)throw Error("Method not supported");Le.n.jg.call(this,a)};g.ib=function(){return this.Zd};g.H=function(){this.w=this.Zd.createElement("div")};g.F=function(a){this.Cd(a)};
g.Cd=function(a,b){if(this.B)throw Error("Component already rendered");this.w||this.H();a?a.insertBefore(this.w,b||null):this.Zd.Gb.body.appendChild(this.w);this.wa&&!this.wa.B||this.na()};g.na=function(){this.B=!0;Re(this,function(a){!a.B&&a.h()&&a.na()})};g.Sa=function(){Re(this,function(a){a.B&&a.Sa()});this.Wb&&this.Wb.Pe();this.B=!1};
g.X=function(){this.B&&this.Sa();this.Wb&&(this.Wb.j(),delete this.Wb);Re(this,function(a){a.j()});!this.Kk&&this.w&&F(this.w);this.wa=this.Ce=this.w=this.Rb=this.R=null;Le.n.X.call(this)};g.df=function(a,b){this.Gc(a,Se(this),b)};
g.Gc=function(a,b,c){if(a.B&&(c||!this.B))throw Error("Component already rendered");if(0>b||b>Se(this))throw Error("Child component index out of bounds");this.Rb&&this.R||(this.Rb={},this.R=[]);if(a.getParent()==this){var d=Oe(a);this.Rb[d]=a;Wa(this.R,a)}else{var d=this.Rb,e=Oe(a);if(e in d)throw Error('The object already contains the key "'+e+'"');d[e]=a}a.Na(this);Ya(this.R,b,0,a);a.B&&this.B&&a.getParent()==this?(c=this.hb(),c.insertBefore(a.h(),c.childNodes[b]||null)):c?(this.w||this.H(),b=S(this,
b+1),a.Cd(this.hb(),b?b.w:null)):this.B&&!a.B&&a.w&&a.w.parentNode&&1==a.w.parentNode.nodeType&&a.na()};g.hb=function(){return this.w};function Te(a){null==a.Se&&(a.Se="rtl"==ue(a.B?a.w:a.Zd.Gb.body,"direction"));return a.Se}g.Fd=function(a){if(this.B)throw Error("Component already rendered");this.Se=a};function Ue(a){return!!a.R&&0!=a.R.length}function Se(a){return a.R?a.R.length:0}function Qe(a,b){var c;a.Rb&&b?(c=a.Rb,c=(b in c?c[b]:void 0)||null):c=null;return c}
function S(a,b){return a.R?a.R[b]||null:null}function Re(a,b,c){a.R&&Ra(a.R,b,c)}function Ve(a,b){return a.R&&b?Qa(a.R,b):-1}g.removeChild=function(a,b){if(a){var c=p(a)?a:Oe(a);a=Qe(this,c);if(c&&a){var d=this.Rb;c in d&&delete d[c];Wa(this.R,a);b&&(a.Sa(),a.w&&F(a.w));a.Na(null)}}if(!a)throw Error("Child is not in parent component");return a};g.Yh=function(a){for(var b=[];Ue(this);)b.push(this.removeChild(S(this,0),a));return b};function We(a){if(a.classList)return a.classList;a=a.className;return p(a)&&a.match(/\S+/g)||[]}function Xe(a,b){return a.classList?a.classList.contains(b):Va(We(a),b)}function Ye(a,b){a.classList?a.classList.add(b):Xe(a,b)||(a.className+=0<a.className.length?" "+b:b)}function Ze(a,b){if(a.classList)Ra(b,function(b){Ye(a,b)});else{var c={};Ra(We(a),function(a){c[a]=!0});Ra(b,function(a){c[a]=!0});a.className="";for(var d in c)a.className+=0<a.className.length?" "+d:d}}
function $e(a,b){a.classList?a.classList.remove(b):Xe(a,b)&&(a.className=Sa(We(a),function(a){return a!=b}).join(" "))}function af(a,b){a.classList?Ra(b,function(b){$e(a,b)}):a.className=Sa(We(a),function(a){return!Va(b,a)}).join(" ")};function bf(a,b){if(!a)throw Error("Invalid class name "+a);if(!s(b))throw Error("Invalid decorator function "+b);}var df={};var ef;function ff(a,b){b?a.setAttribute("role",b):a.removeAttribute("role")}function T(a,b,c){ea(c)&&(c=c.join(" "));var d="aria-"+b;""===c||void 0==c?(ef||(ef={atomic:!1,autocomplete:"none",dropeffect:"none",haspopup:!1,live:"off",multiline:!1,multiselectable:!1,orientation:"vertical",readonly:!1,relevant:"additions text",required:!1,sort:"none",busy:!1,disabled:!1,hidden:!1,invalid:"false"}),c=ef,b in c?a.setAttribute(d,c[b]):a.removeAttribute(d)):a.setAttribute(d,c)};function gf(){}var hf;ca(gf);var jf={button:"pressed",checkbox:"checked",menuitem:"selected",menuitemcheckbox:"checked",menuitemradio:"checked",radio:"checked",tab:"selected",treeitem:"selected"};g=gf.prototype;g.ce=function(){};g.H=function(a){var b=a.ib().H("div",this.ge(a).join(" "),a.Eb);kf(a,b);return b};g.hb=function(a){return a};g.fd=function(a,b,c){if(a=a.h?a.h():a){var d=[b];y&&!A("7")&&(d=lf(We(a),b),d.push(b));(c?Ze:af)(a,d)}};
g.td=function(a){Te(a)&&this.Fd(a.h(),!0);a.isEnabled()&&this.zc(a,a.A())};function mf(a,b,c){if(a=c||a.ce())c=b.getAttribute("role")||null,a!=c&&ff(b,a)}function kf(a,b){a.A()||T(b,"hidden",!a.A());a.isEnabled()||nf(b,1,!a.isEnabled());a.V&8&&nf(b,8,a.xe());a.V&16&&nf(b,16,!!(a.$&16));a.V&64&&nf(b,64,a.wb())}g.gg=function(a,b){Ee(a,!b,!y&&!Eb)};g.Fd=function(a,b){this.fd(a,this.ua()+"-rtl",b)};g.Xb=function(a){var b;return a.V&32&&(b=a.ga())?hc(b)&&ic(b):!1};
g.zc=function(a,b){var c;if(a.V&32&&(c=a.ga())){if(!b&&a.$&32){try{c.blur()}catch(d){}a.$&32&&a.od(null)}(hc(c)&&ic(c))!=b&&(b?c.tabIndex=0:(c.tabIndex=-1,c.removeAttribute("tabIndex")))}};g.I=function(a,b){Ce(a,b);a&&T(a,"hidden",!b)};g.Ua=function(a,b,c){var d=a.h();if(d){var e=this.fe(b);e&&this.fd(a,e,c);nf(d,b,c)}};
function nf(a,b,c){hf||(hf={1:"disabled",8:"selected",16:"checked",64:"expanded"});b=hf[b];var d=a.getAttribute("role")||null;d&&(d=jf[d]||b,b="checked"==b||"selected"==b?d:b);b&&T(a,b,c)}g.ga=function(a){return a.h()};g.ua=function(){return"goog-control"};g.ge=function(a){var b=this.ua(),c=[b],d=this.ua();d!=b&&c.push(d);b=a.$;for(d=[];b;){var e=b&-b;d.push(this.fe(e));b&=~e}c.push.apply(c,d);(a=a.ub)&&c.push.apply(c,a);y&&!A("7")&&c.push.apply(c,lf(c));return c};
function lf(a,b){var c=[];b&&(a=a.concat([b]));Ra([],function(d){!Ua(d,oa(Va,a))||b&&!Va(d,b)||c.push(d.join("_"))});return c}g.fe=function(a){if(!this.Og){var b=this.ua();b.replace(/\xa0|\s/g," ");this.Og={1:b+"-disabled",2:b+"-hover",4:b+"-active",8:b+"-selected",16:b+"-checked",32:b+"-focused",64:b+"-open"}}return this.Og[a]};function of(a,b,c,d,e){if(!(y||z&&A("525")))return!0;if(Ab&&e)return pf(a);if(e&&!d)return!1;r(b)&&(b=qf(b));if(!c&&(17==b||18==b||Ab&&91==b))return!1;if(z&&d&&c)switch(a){case 220:case 219:case 221:case 192:case 186:case 189:case 187:case 188:case 190:case 191:case 192:case 222:return!1}if(y&&d&&b==a)return!1;switch(a){case 13:return!0;case 27:return!z}return pf(a)}
function pf(a){if(48<=a&&57>=a||96<=a&&106>=a||65<=a&&90>=a||z&&0==a)return!0;switch(a){case 32:case 63:case 107:case 109:case 110:case 111:case 186:case 59:case 189:case 187:case 61:case 188:case 190:case 191:case 192:case 222:case 219:case 220:case 221:return!0;default:return!1}}function qf(a){if(Fb)a=rf(a);else if(Ab&&z)a:switch(a){case 93:a=91;break a}return a}
function rf(a){switch(a){case 61:return 187;case 59:return 186;case 173:return 189;case 224:return 91;case 0:return 224;default:return a}};function sf(a,b){Td.call(this);a&&tf(this,a,b)}u(sf,Td);g=sf.prototype;g.w=null;g.ye=null;g.Of=null;g.ze=null;g.La=-1;g.Zb=-1;g.hf=!1;
var uf={3:13,12:144,63232:38,63233:40,63234:37,63235:39,63236:112,63237:113,63238:114,63239:115,63240:116,63241:117,63242:118,63243:119,63244:120,63245:121,63246:122,63247:123,63248:44,63272:46,63273:36,63275:35,63276:33,63277:34,63289:144,63302:45},vf={Up:38,Down:40,Left:37,Right:39,Enter:13,F1:112,F2:113,F3:114,F4:115,F5:116,F6:117,F7:118,F8:119,F9:120,F10:121,F11:122,F12:123,"U+007F":46,Home:36,End:35,PageUp:33,PageDown:34,Insert:45},wf=y||z&&A("525"),xf=Ab&&Fb;g=sf.prototype;
g.Aj=function(a){z&&(17==this.La&&!a.ctrlKey||18==this.La&&!a.altKey||Ab&&91==this.La&&!a.metaKey)&&(this.Zb=this.La=-1);-1==this.La&&(a.ctrlKey&&17!=a.keyCode?this.La=17:a.altKey&&18!=a.keyCode?this.La=18:a.metaKey&&91!=a.keyCode&&(this.La=91));wf&&!of(a.keyCode,this.La,a.shiftKey,a.ctrlKey,a.altKey)?this.handleEvent(a):(this.Zb=qf(a.keyCode),xf&&(this.hf=a.altKey))};g.Bj=function(a){this.Zb=this.La=-1;this.hf=a.altKey};
g.handleEvent=function(a){var b=a.Hb,c,d,e=b.altKey;y&&"keypress"==a.type?(c=this.Zb,d=13!=c&&27!=c?b.keyCode:0):z&&"keypress"==a.type?(c=this.Zb,d=0<=b.charCode&&63232>b.charCode&&pf(c)?b.charCode:0):Eb?(c=this.Zb,d=pf(c)?b.keyCode:0):(c=b.keyCode||this.Zb,d=b.charCode||0,xf&&(e=this.hf),Ab&&63==d&&224==c&&(c=191));var f=c=qf(c),h=b.keyIdentifier;c?63232<=c&&c in uf?f=uf[c]:25==c&&a.shiftKey&&(f=9):h&&h in vf&&(f=vf[h]);a=f==this.La;this.La=f;b=new yf(f,d,a,b);b.altKey=e;this.dispatchEvent(b)};
g.h=function(){return this.w};function tf(a,b,c){a.ze&&a.detach();a.w=b;a.ye=Id(a.w,"keypress",a,c);a.Of=Id(a.w,"keydown",a.Aj,c,a);a.ze=Id(a.w,"keyup",a.Bj,c,a)}g.detach=function(){this.ye&&(Pd(this.ye),Pd(this.Of),Pd(this.ze),this.ze=this.Of=this.ye=null);this.w=null;this.Zb=this.La=-1};g.X=function(){sf.n.X.call(this);this.detach()};function yf(a,b,c,d){Cd.call(this,d);this.type="key";this.keyCode=a;this.charCode=b;this.repeat=c}u(yf,Cd);function U(a,b,c){Le.call(this,c);if(!b){b=this.constructor;for(var d;b;){d=ia(b);if(d=df[d])break;b=b.n?b.n.constructor:null}b=d?s(d.Vb)?d.Vb():new d:null}this.G=b;this.qk(void 0!==a?a:null)}u(U,Le);g=U.prototype;g.Eb=null;g.$=0;g.V=39;g.Qi=255;g.Kd=0;g.ea=!0;g.ub=null;g.rd=!0;g.gf=!1;g.fk=null;g.ga=function(){return this.G.ga(this)};g.le=function(){return this.va||(this.va=new sf)};
g.fd=function(a,b){b?a&&(this.ub?Va(this.ub,a)||this.ub.push(a):this.ub=[a],this.G.fd(this,a,!0)):a&&this.ub&&Wa(this.ub,a)&&(0==this.ub.length&&(this.ub=null),this.G.fd(this,a,!1))};g.H=function(){var a=this.G.H(this);this.w=a;mf(this.G,a,this.ne());this.gf||this.G.gg(a,!1);this.A()||this.G.I(a,!1)};g.ne=function(){return this.fk};g.hb=function(){return this.G.hb(this.h())};
g.na=function(){U.n.na.call(this);this.G.td(this);if(this.V&-2&&(this.rd&&zf(this,!0),this.V&32)){var a=this.ga();if(a){var b=this.le();tf(b,a);Pe(this).D(b,"key",this.jb).D(a,"focus",this.pe).D(a,"blur",this.od)}}};
function zf(a,b){var c=Pe(a),d=a.h();b?(c.D(d,"mouseover",a.Kf).D(d,"mousedown",a.qd).D(d,"mouseup",a.sd).D(d,"mouseout",a.Jf),a.pd!=ba&&c.D(d,"contextmenu",a.pd),y&&c.D(d,"dblclick",a.vh)):(c.Wa(d,"mouseover",a.Kf).Wa(d,"mousedown",a.qd).Wa(d,"mouseup",a.sd).Wa(d,"mouseout",a.Jf),a.pd!=ba&&c.Wa(d,"contextmenu",a.pd),y&&c.Wa(d,"dblclick",a.vh))}g.Sa=function(){U.n.Sa.call(this);this.va&&this.va.detach();this.A()&&this.isEnabled()&&this.G.zc(this,!1)};
g.X=function(){U.n.X.call(this);this.va&&(this.va.j(),delete this.va);delete this.G;this.ub=this.Eb=null};g.qk=function(a){this.Eb=a};g.Df=function(){var a=this.Eb;if(!a)return"";if(!p(a))if(ea(a))a=Ta(a,jc).join("");else{if(Qb&&"innerText"in a)a=a.innerText.replace(/(\r\n|\r|\n)/g,"\n");else{var b=[];kc(a,b,!0);a=b.join("")}a=a.replace(/ \xAD /g," ").replace(/\xAD/g,"");a=a.replace(/\u200B/g,"");Qb||(a=a.replace(/ +/g," "));" "!=a&&(a=a.replace(/^\s*/,""))}return ua(a)};
g.Fd=function(a){U.n.Fd.call(this,a);var b=this.h();b&&this.G.Fd(b,a)};g.gg=function(a){this.gf=a;var b=this.h();b&&this.G.gg(b,a)};g.A=function(){return this.ea};g.I=function(a,b){if(b||this.ea!=a&&this.dispatchEvent(a?"show":"hide")){var c=this.h();c&&this.G.I(c,a);this.isEnabled()&&this.G.zc(this,a);this.ea=a;return!0}return!1};g.isEnabled=function(){return!(this.$&1)};
g.Ed=function(a){var b=this.getParent();b&&"function"==typeof b.isEnabled&&!b.isEnabled()||!Af(this,1,!a)||(a||(this.setActive(!1),this.mb(!1)),this.A()&&this.G.zc(this,a),this.Ua(1,!a,!0))};g.mb=function(a){Af(this,2,a)&&this.Ua(2,a)};g.Nj=function(){return!!(this.$&4)};g.setActive=function(a){Af(this,4,a)&&this.Ua(4,a)};g.xe=function(){return!!(this.$&8)};g.rk=function(){Af(this,8,!0)&&this.Ua(8,!0)};g.wb=function(){return!!(this.$&64)};function Bf(a,b){Af(a,64,b)&&a.Ua(64,b)}
g.Ua=function(a,b,c){c||1!=a?this.V&a&&b!=!!(this.$&a)&&(this.G.Ua(this,a,b),this.$=b?this.$|a:this.$&~a):this.Ed(!b)};g.Oa=function(a,b){if(this.B&&this.$&a&&!b)throw Error("Component already rendered");!b&&this.$&a&&this.Ua(a,!1);this.V=b?this.V|a:this.V&~a};function Cf(a,b){return!!(a.Qi&b)&&!!(a.V&b)}function Af(a,b,c){return!!(a.V&b)&&!!(a.$&b)!=c&&(!(a.Kd&b)||a.dispatchEvent(Ne(b,c)))&&!a.ed}g.Kf=function(a){!Df(a,this.h())&&this.dispatchEvent("enter")&&this.isEnabled()&&Cf(this,2)&&this.mb(!0)};
g.Jf=function(a){!Df(a,this.h())&&this.dispatchEvent("leave")&&(Cf(this,4)&&this.setActive(!1),Cf(this,2)&&this.mb(!1))};g.pd=ba;function Df(a,b){return!!a.relatedTarget&&ec(b,a.relatedTarget)}g.qd=function(a){this.isEnabled()&&(Cf(this,2)&&this.mb(!0),!Ed(a)||z&&Ab&&a.ctrlKey||(Cf(this,4)&&this.setActive(!0),this.G.Xb(this)&&this.ga().focus()));this.gf||!Ed(a)||z&&Ab&&a.ctrlKey||a.preventDefault()};g.sd=function(a){this.isEnabled()&&(Cf(this,2)&&this.mb(!0),this.Nj()&&this.Je(a)&&Cf(this,4)&&this.setActive(!1))};
g.vh=function(a){this.isEnabled()&&this.Je(a)};g.Je=function(a){if(Cf(this,16)){var b=!(this.$&16);Af(this,16,b)&&this.Ua(16,b)}Cf(this,8)&&this.rk();Cf(this,64)&&Bf(this,!this.wb());b=new wd("action",this);a&&(b.altKey=a.altKey,b.ctrlKey=a.ctrlKey,b.metaKey=a.metaKey,b.shiftKey=a.shiftKey,b.$f=a.$f);return this.dispatchEvent(b)};g.pe=function(){Cf(this,32)&&Af(this,32,!0)&&this.Ua(32,!0)};g.od=function(){Cf(this,4)&&this.setActive(!1);Cf(this,32)&&Af(this,32,!1)&&this.Ua(32,!1)};
g.jb=function(a){return this.A()&&this.isEnabled()&&this.mc(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};g.mc=function(a){return 13==a.keyCode&&this.Je(a)};if(!s(U))throw Error("Invalid component class "+U);if(!s(gf))throw Error("Invalid renderer class "+gf);var Ef=ia(U);df[Ef]=gf;bf("goog-control",function(){return new U(null)});function Ff(){this.Pg=[]}u(Ff,gf);ca(Ff);function Gf(a,b){var c=a.Pg[b];if(!c){switch(b){case 0:c=a.ua()+"-highlight";break;case 1:c=a.ua()+"-checkbox";break;case 2:c=a.ua()+"-content"}a.Pg[b]=c}return c}g=Ff.prototype;g.ce=function(){return"menuitem"};g.H=function(a){var b=a.ib().H("div",this.ge(a).join(" "),Hf(this,a.Eb,a.ib()));If(this,a,b,!!(a.V&8)||!!(a.V&16));return b};g.hb=function(a){return a&&a.firstChild};function Hf(a,b,c){a=Gf(a,2);return c.H("div",a,b)}
g.ci=function(a,b,c){a&&b&&If(this,a,b,c)};g.$h=function(a,b,c){a&&b&&If(this,a,b,c)};function If(a,b,c,d){mf(a,c,b.ne());kf(b,c);var e;if(e=a.hb(c)){e=e.firstChild;var f=Gf(a,1);e=!!e&&ga(e)&&1==e.nodeType&&Xe(e,f)}else e=!1;d!=e&&(d?Ye(c,"goog-option"):$e(c,"goog-option"),c=a.hb(c),d?(a=Gf(a,1),c.insertBefore(b.ib().H("div",a),c.firstChild||null)):c.removeChild(c.firstChild))}
g.fe=function(a){switch(a){case 2:return Gf(this,0);case 16:case 8:return"goog-option-selected";default:return Ff.n.fe.call(this,a)}};g.ua=function(){return"goog-menuitem"};function Jf(a,b,c,d){U.call(this,a,d||Ff.Vb(),c);this.Wc(b)}u(Jf,U);g=Jf.prototype;g.uh=function(){var a=this.Ce;return null!=a?a:this.Df()};g.Wc=function(a){this.Ce=a};g.Oa=function(a,b){Jf.n.Oa.call(this,a,b);switch(a){case 8:this.$&16&&!b&&Af(this,16,!1)&&this.Ua(16,!1);var c=this.h();c&&this.G.ci(this,c,b);break;case 16:(c=this.h())&&this.G.$h(this,c,b)}};g.ci=function(a){this.Oa(8,a)};g.$h=function(a){this.Oa(16,a)};
g.Df=function(){var a=this.Eb;return ea(a)?(a=Ta(a,function(a){return ga(a)&&1==a.nodeType&&(Xe(a,"goog-menuitem-accel")||Xe(a,"goog-menuitem-mnemonic-separator"))?"":jc(a)}).join(""),ua(a)):Jf.n.Df.call(this)};g.sd=function(a){var b=this.getParent();if(b){var c=b.Rh;b.Rh=null;if(b=c&&r(a.clientX))b=new C(a.clientX,a.clientY),b=c==b?!0:c&&b?c.x==b.x&&c.y==b.y:!1;if(b)return}Jf.n.sd.call(this,a)};g.mc=function(a){return a.keyCode==this.Kh&&this.Je(a)?!0:Jf.n.mc.call(this,a)};g.sj=function(){return this.Kh};
bf("goog-menuitem",function(){return new Jf(null)});Jf.prototype.ne=function(){return this.V&16?"menuitemcheckbox":this.V&8?"menuitemradio":Jf.n.ne.call(this)};Jf.prototype.getParent=function(){return U.prototype.getParent.call(this)};Jf.prototype.me=function(){return U.prototype.me.call(this)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Kf(a){this.m=a;this.g=N("g",{},null);this.Xe=N("path",{"class":"blocklyPathDark",transform:"translate(1, 1)"},this.g);this.Pb=N("path",{"class":"blocklyPath"},this.g);this.Ye=N("path",{"class":"blocklyPathLight"},this.g);this.Pb.Qa=this.m;Lf(this.Pb);Mf(this)}Kf.prototype.height=0;Kf.prototype.width=0;Kf.prototype.Y=function(){var a=this.m;this.Dc();for(var b=0,c;c=a.T[b];b++)c.Y();a.De&&a.De.al()};function Mf(a){a.m.Mb&&!M?Nf(a.g,"blocklyDraggable"):Of(a.g,"blocklyDraggable")}
Kf.prototype.oa=function(){return this.g};var Pf=7*(1-Math.SQRT1_2)+1,Qf=9*(1-Math.SQRT1_2)-1,Rf="m "+Pf+","+Pf,Sf="a 9,9 0 0,0 "+(-Qf-1)+","+(8-Qf),Tf="a 9,9 0 0,0 "+(8-Qf)+","+(Qf+1);g=Kf.prototype;g.j=function(){F(this.g);this.m=this.Xe=this.Ye=this.Pb=this.g=null};function Uf(a){var b=(new Date-a.og)/150;1<b?F(a):(a.setAttribute("transform","translate("+(a.mi+(I?-1:1)*a.Jg.width/2*b+", "+(a.ni+a.Jg.height*b))+") scale("+(1-b)+")"),window.setTimeout(function(){Uf(a)},10))}
function Vf(a){var b=(new Date-a.og)/150;1<b?F(a):(a.setAttribute("r",25*b),a.style.opacity=1-b,window.setTimeout(function(){Vf(a)},10))}
g.Dc=function(){if(!this.m.disabled){var a=Wf(Xf(this.m.Sg)),b,c;c=a;if(!Yf.test(c))throw Error("'"+c+"' is not a valid hex color");4==c.length&&(c=c.replace(Zf,"#$1$1$2$2$3$3"));c=c.toLowerCase();b=[parseInt(c.substr(1,2),16),parseInt(c.substr(3,2),16),parseInt(c.substr(5,2),16)];c=$f([255,255,255],b,.3);b=$f([0,0,0],b,.4);this.Ye.setAttribute("stroke",Wf(c));this.Xe.setAttribute("fill",Wf(b));this.Pb.setAttribute("fill",a)}};
function ag(a){a.m.disabled||bg(a.m)?(Nf(a.g,"blocklyDisabled"),a.Pb.setAttribute("fill","url(#blocklyDisabledPattern)")):(Of(a.g,"blocklyDisabled"),a.Dc());a=a.m.lc();for(var b=0,c;c=a[b];b++)ag(c.i)}g.ef=function(){Nf(this.g,"blocklySelected");this.g.parentNode.appendChild(this.g)};g.Qe=function(){Of(this.g,"blocklySelected")};
g.F=function(){this.m.N=!0;var a=10;I&&(a=-a);for(var b=cg(this.m),c=0;c<b.length;c++){var d=b[c];d.m.isCollapsed()?d.Fa.setAttribute("display","none"):(d.Fa.setAttribute("display","block"),I&&(a-=16),d.Fa.setAttribute("transform","translate("+a+", 5)"),dg(d),a=I?a-10:a+26)}var e=a+=I?10:-10,f=this.m.T,b=[];b.U=e+20;if(this.m.C||this.m.J)b.U=Math.max(b.U,40);for(var d=c=0,h=!1,k=!1,l=!1,q=void 0,m=this.m.ud&&!this.m.isCollapsed(),t=0,v;v=f[t];t++)if(v.A()){var B;m&&q&&3!=q&&3!=v.type?B=b[b.length-
1]:(q=v.type,B=[],B.type=m&&3!=v.type?-1:v.type,B.height=0,b.push(B));B.push(v);v.wc=25;v.qa=m&&1==v.type?20.5:0;if(v.p&&v.p.o){var ha=eg(L(v.p));v.wc=Math.max(v.wc,ha.height);v.qa=Math.max(v.qa,ha.width)}t==f.length-1&&v.wc--;B.height=Math.max(B.height,v.wc);v.gb=0;1==b.length&&(v.gb+=I?-e:e);for(var ha=!1,cf=0,$a;$a=v.ta[cf];cf++){0!=cf&&(v.gb+=10);var Ch=$a.sh();$a.qa=Ch.width;$a.Re=ha&&$a.$c?10:0;v.gb+=$a.qa+$a.Re;B.height=Math.max(B.height,Ch.height);ha=$a.$c}-1!=B.type&&(3==B.type?(k=!0,d=Math.max(d,
v.gb)):(1==B.type?h=!0:5==B.type&&(l=!0),c=Math.max(c,v.gb)))}for(e=0;B=b[e];e++)if(B.ki=!1,-1==B.type)for(f=0;v=B[f];f++)if(1==v.type){B.height+=10;B.ki=!0;break}b.Ve=20+d;k&&(b.U=Math.max(b.U,b.Ve+30));h?b.U=Math.max(b.U,c+20+8):l&&(b.U=Math.max(b.U,c+20));b.Fj=h;b.kl=k;b.jl=l;d=a;this.m.K?this.ng=this.Ue=!0:(this.ng=this.Ue=!1,this.m.C&&(a=L(this.m.C))&&Kc(a)==this.m&&(this.Ue=!0),Kc(this.m)&&(this.ng=!0));h=K(this.m);k=[];l=[];a=[];c=[];v=b.U;this.Ue?(k.push("m 0,0"),a.push("m 1,1")):(k.push("m 0,8"),
a.push(I?Rf:"m 1,7"),k.push("A 8,8 0 0,1 8,0"),a.push("A 7,7 0 0,1 8,1"));this.m.C&&(k.push("H",15),a.push("H",15),k.push("l 6,4 3,0 6,-4"),a.push("l 6.5,4 2,0 6.5,-4"),this.m.C.moveTo(h.x+(I?-30:30),h.y));k.push("H",v);a.push("H",v+(I?-1:0));this.width=v;for(B=v=0;e=b[B];B++){m=10;0==B&&(m+=I?-d:d);a.push("M",b.U-1+","+(v+1));if(this.m.isCollapsed())f=e[0],t=v+18,fg(f.ta,m,t),k.push("l 8,0 0,4 8,4 -16,8 8,4"),I?a.push("l 8,0 0,3.8 7,3.2 m -14.5,9 l 8,4"):a.push("h 8"),f=e.height-20,k.push("v",f),
I&&a.push("v",f-2),this.width+=15;else if(-1==e.type){for(q=0;f=e[q];q++)t=v+18,e.ki&&(t+=5),m=fg(f.ta,m,t),5!=f.type&&(m+=f.qa+10),1==f.type&&(l.push("M",m-10+","+(v+5)),l.push("h",6-f.qa),l.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),l.push("v",f.wc+1-20),l.push("h",f.qa+2-8),l.push("z"),I?(c.push("M",m-10-3+8-f.qa+","+(v+5+1)),c.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),c.push("v",f.wc-20+3),c.push("h",f.qa-8+1)):(c.push("M",m-10+1+","+(v+5+1)),c.push("v",f.wc+1),c.push("h",
6-f.qa),c.push("M",m-f.qa-10+.8+","+(v+5+20-.4)),c.push("l","3.36,-1.8")),t=I?h.x-m-8+10+f.qa+1:h.x+m+8-10-f.qa-1,ha=h.y+v+5+1,f.p.moveTo(t,ha),f.p.o&&gg(f.p));m=Math.max(m,b.U);this.width=Math.max(this.width,m);k.push("H",m);a.push("H",m+(I?-1:0));k.push("v",e.height);I&&a.push("v",e.height-2)}else 1==e.type?(f=e[0],t=v+18,-1!=f.align&&(q=b.U-f.gb-8-20,1==f.align?m+=q:0==f.align&&(m+=(q+m)/2)),fg(f.ta,m,t),k.push("v 5 c 0,10 -8,-8 -8,7.5 s 8,-2.5 8,7.5"),q=e.height-20,k.push("v",q),I?(a.push("v 6.5 m -7.84,2.5 q -0.4,10 2.16,10 m 5.68,-2.5 v 1.5"),
a.push("v",q)):(a.push("M",b.U-4.2+","+(v+20-.4)),a.push("l","3.36,-1.8")),t=h.x+(I?-b.U-1:b.U+1),ha=h.y+v,f.p.moveTo(t,ha),f.p.o&&(gg(f.p),this.width=Math.max(this.width,b.U+eg(L(f.p)).width-8+1))):5==e.type?(f=e[0],t=v+18,-1!=f.align&&(q=b.U-f.gb-20,b.Fj&&(q-=8),1==f.align?m+=q:0==f.align&&(m+=(q+m)/2)),fg(f.ta,m,t),k.push("v",e.height),I&&a.push("v",e.height-2)):3==e.type&&(f=e[0],0==B&&(k.push("v",10),I&&a.push("v",9),v+=10),t=v+18,-1!=f.align&&(q=b.Ve-f.gb-20,1==f.align?m+=q:0==f.align&&(m+=
(q+m)/2)),fg(f.ta,m,t),m=b.Ve+30,k.push("H",m),k.push("l -6,4 -3,0 -6,-4 h -7 a 8,8 0 0,0 -8,8"),k.push("v",e.height-16),k.push("a 8,8 0 0,0 8,8"),k.push("H",b.U),I?(a.push("M",m-30+Qf+","+(v+Qf)),a.push(Sf),a.push("v",e.height-16),a.push("a 9,9 0 0,0 9,9"),a.push("H",b.U-1)):(a.push("M",m-30+Qf+","+(v+e.height-Qf)),a.push(Tf),a.push("H",b.U)),t=h.x+(I?-m:m),ha=h.y+v+1,f.p.moveTo(t,ha),f.p.o&&(gg(f.p),this.width=Math.max(this.width,b.Ve+eg(L(f.p)).width)),B==b.length-1||3==b[B+1].type)&&(k.push("v",
10),I&&a.push("v",9),v+=10);v+=e.height}b.length||(v=25,k.push("V",v),I&&a.push("V",v-1));b=v;this.height=b+1;this.m.J&&(k.push("H","30 l -6,4 -3,0 -6,-4"),this.m.J.moveTo(I?h.x-30:h.x+30,h.y+b+1),this.m.J.o&&gg(this.m.J),this.height+=4);this.ng?(k.push("H 0"),I||a.push("M","1,"+b)):(k.push("H",8),k.push("a","8,8 0 0,1 -8,-8"),I||(a.push("M",Pf+","+(b-Pf)),a.push("A","7,7 0 0,1 1,"+(b-8))));this.m.K?(this.m.K.moveTo(h.x,h.y),k.push("V",20),k.push("c 0,-10 -8,8 -8,-7.5 s 8,2.5 8,-7.5"),I?(a.push("M",
"-2.4,8.9"),a.push("l","-3.6,-2.1")):(a.push("V",19),a.push("m","-7.36,-1 q -1.52,-5.5 0,-11"),a.push("m","7.36,1 V 1 H 2")),this.width+=8):I||(this.Ue?a.push("V",1):a.push("V",8));k.push("z");b=k.join(" ")+"\n"+l.join(" ");this.Pb.setAttribute("d",b);this.Xe.setAttribute("d",b);b=a.join(" ")+"\n"+c.join(" ");this.Ye.setAttribute("d",b);I&&(this.Pb.setAttribute("transform","scale(-1 1)"),this.Ye.setAttribute("transform","scale(-1 1)"),this.Xe.setAttribute("transform","translate(1,1) scale(-1 1)"));
(b=this.m.getParent())?b.F():pe(window,"resize")};function fg(a,b,c){I&&(b=-b);for(var d=0,e;e=a[d];d++)I?(b-=e.Re+e.qa,e.oa().setAttribute("transform","translate("+b+", "+c+")"),e.qa&&(b-=10)):(e.oa().setAttribute("transform","translate("+(b+e.Re)+", "+c+")"),e.qa&&(b+=e.Re+e.qa+10));return I?-b:b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function hg(a){this.k=null;this.Ka=N("g",{},null);this.mf=N("rect",{rx:4,ry:4,x:-5,y:-12,height:16},this.Ka);this.Pa=N("text",{"class":"blocklyText"},this.Ka);this.Id={height:25,width:0};this.zb(a);this.ea=!0}g=hg.prototype;g.clone=function(){Ka("There should never be an instance of Field, only its derived classes.")};g.$c=!0;g.Y=function(a){if(this.k)throw"Field has already been initialized once.";this.k=a;this.Ec();ig(a).appendChild(this.Ka);this.Uf=Q(this.Ka,"mouseup",this,this.Yf);this.zb(null)};
g.j=function(){this.Uf&&(P(this.Uf),this.Uf=null);this.k=null;F(this.Ka);this.mf=this.Pa=this.Ka=null};g.Ec=function(){this.$c&&(this.k.Kc&&!M?(Nf(this.Ka,"blocklyEditableText"),Of(this.Ka,"blocklyNoNEditableText"),this.Ka.style.cursor=this.Ok):(Nf(this.Ka,"blocklyNonEditableText"),Of(this.Ka,"blocklyEditableText"),this.Ka.style.cursor=""))};g.A=function(){return this.ea};g.I=function(a){this.ea=a;this.oa().style.display=a?"block":"none";this.Cd()};g.oa=function(){return this.Ka};
g.Cd=function(){try{var a=this.Pa.getComputedTextLength()}catch(b){a=8*this.Pa.childNodes[0].length}this.mf&&this.mf.setAttribute("width",a+10);this.Id.width=a};g.sh=function(){this.Id.width||this.Cd();return this.Id};g.Jb=function(){return this.ob};g.zb=function(a){null!==a&&a!==this.ob&&(a=this.ob=a,cc(this.Pa),a=a.replace(/\s/g,"\u00a0"),I&&a&&(a+="\u200f"),a||(a="\u00a0"),this.Pa.appendChild(document.createTextNode(a)),this.Id.width=0,this.k&&this.k.N&&(this.k.F(),this.k.Ja(),de(this.k.s)))};
g.uh=function(){return this.Jb()};g.Wc=function(a){this.zb(a)};g.Yf=function(a){if(!Cb&&!Db||0===a.layerX||0===a.layerY)hd(a)||2!=ne&&this.k.Kc&&!M&&this.Dl()};g.Te=function(){};function jg(a){this.Ig=a}ca(jg);g=jg.prototype;g.ce=function(){return this.Ig};function kg(a,b){a&&(a.tabIndex=b?0:-1)}g.H=function(a){return a.ib().H("div",this.ge(a).join(" "))};g.hb=function(a){return a};g.td=function(a){a=a.h();Ee(a,!0,Fb);y&&(a.hideFocus=!0);var b=this.ce();b&&ff(a,b)};g.ga=function(a){return a.h()};g.ua=function(){return"goog-container"};g.ge=function(a){var b=this.ua(),c=[b,a.Rc==lg?b+"-horizontal":b+"-vertical"];a.isEnabled()||c.push(b+"-disabled");return c};function mg(){}u(mg,gf);ca(mg);mg.prototype.H=function(a){return a.ib().H("div",this.ua())};mg.prototype.ua=function(){return"goog-menuseparator"};function ng(a,b){U.call(this,null,a||mg.Vb(),b);this.Oa(1,!1);this.Oa(2,!1);this.Oa(4,!1);this.Oa(32,!1);this.$=1}u(ng,U);ng.prototype.na=function(){ng.n.na.call(this);var a=this.h();ff(a,"separator")};bf("goog-menuseparator",function(){return new ng});function og(a){this.Ig=a||"menu"}u(og,jg);ca(og);og.prototype.ua=function(){return"goog-menu"};og.prototype.td=function(a){og.n.td.call(this,a);a=a.h();T(a,"haspopup","true")};bf("goog-menuseparator",function(){return new ng});function pg(a,b,c){Le.call(this,c);this.G=b||jg.Vb();this.Rc=a||qg}u(pg,Le);var lg="horizontal",qg="vertical";g=pg.prototype;g.Pf=null;g.va=null;g.G=null;g.Rc=null;g.ea=!0;g.ic=!0;g.Bf=!0;g.M=-1;g.Z=null;g.Qc=!1;g.Li=!1;g.ck=!0;g.Cb=null;g.ga=function(){return this.Pf||this.G.ga(this)};g.le=function(){return this.va||(this.va=new sf(this.ga()))};g.H=function(){this.w=this.G.H(this)};g.hb=function(){return this.G.hb(this.h())};
g.na=function(){pg.n.na.call(this);Re(this,function(a){a.B&&rg(this,a)},this);var a=this.h();this.G.td(this);this.I(this.ea,!0);Pe(this).D(this,"enter",this.Hf).D(this,"highlight",this.zj).D(this,"unhighlight",this.Ej).D(this,"open",this.Cj).D(this,"close",this.wj).D(a,"mousedown",this.qd).D(Wb(a),"mouseup",this.xj).D(a,["mousedown","mouseup","mouseover","mouseout","contextmenu"],this.vj);this.Xb()&&sg(this,!0)};
function sg(a,b){var c=Pe(a),d=a.ga();b?c.D(d,"focus",a.pe).D(d,"blur",a.od).D(a.le(),"key",a.jb):c.Wa(d,"focus",a.pe).Wa(d,"blur",a.od).Wa(a.le(),"key",a.jb)}g.Sa=function(){this.Vc(-1);this.Z&&Bf(this.Z,!1);this.Qc=!1;pg.n.Sa.call(this)};g.X=function(){pg.n.X.call(this);this.va&&(this.va.j(),this.va=null);this.G=this.Z=this.Cb=this.Pf=null};g.Hf=function(){return!0};
g.zj=function(a){var b=Ve(this,a.target);if(-1<b&&b!=this.M){var c=S(this,this.M);c&&c.mb(!1);this.M=b;c=S(this,this.M);this.Qc&&c.setActive(!0);this.ck&&this.Z&&c!=this.Z&&(c.V&64?Bf(c,!0):Bf(this.Z,!1))}b=this.h();null!=a.target.h()&&T(b,"activedescendant",a.target.h().id)};g.Ej=function(a){a.target==S(this,this.M)&&(this.M=-1);this.h().removeAttribute("aria-activedescendant")};g.Cj=function(a){(a=a.target)&&a!=this.Z&&a.getParent()==this&&(this.Z&&Bf(this.Z,!1),this.Z=a)};
g.wj=function(a){a.target==this.Z&&(this.Z=null)};g.qd=function(a){this.ic&&(this.Qc=!0);var b=this.ga();b&&hc(b)&&ic(b)?b.focus():a.preventDefault()};g.xj=function(){this.Qc=!1};g.vj=function(a){var b;a:{b=a.target;if(this.Cb)for(var c=this.h();b&&b!==c;){var d=b.id;if(d in this.Cb){b=this.Cb[d];break a}b=b.parentNode}b=null}if(b)switch(a.type){case "mousedown":b.qd(a);break;case "mouseup":b.sd(a);break;case "mouseover":b.Kf(a);break;case "mouseout":b.Jf(a);break;case "contextmenu":b.pd(a)}};
g.pe=function(){};g.od=function(){this.Vc(-1);this.Qc=!1;this.Z&&Bf(this.Z,!1)};g.jb=function(a){return this.isEnabled()&&this.A()&&(0!=Se(this)||this.Pf)&&this.mc(a)?(a.preventDefault(),a.stopPropagation(),!0):!1};
g.mc=function(a){var b=S(this,this.M);if(b&&"function"==typeof b.jb&&b.jb(a)||this.Z&&this.Z!=b&&"function"==typeof this.Z.jb&&this.Z.jb(a))return!0;if(a.shiftKey||a.ctrlKey||a.metaKey||a.altKey)return!1;switch(a.keyCode){case 27:if(this.Xb())this.ga().blur();else return!1;break;case 36:tg(this);break;case 35:ug(this);break;case 38:if(this.Rc==qg)vg(this);else return!1;break;case 37:if(this.Rc==lg)Te(this)?wg(this):vg(this);else return!1;break;case 40:if(this.Rc==qg)wg(this);else return!1;break;case 39:if(this.Rc==
lg)Te(this)?vg(this):wg(this);else return!1;break;default:return!1}return!0};function rg(a,b){var c=b.h(),c=c.id||(c.id=Oe(b));a.Cb||(a.Cb={});a.Cb[c]=b}g.df=function(a,b){pg.n.df.call(this,a,b)};g.Gc=function(a,b,c){a.Kd|=2;a.Kd|=64;!this.Xb()&&this.Li||a.Oa(32,!1);a.B&&0!=a.rd&&zf(a,!1);a.rd=!1;var d=a.getParent()==this?Ve(this,a):-1;pg.n.Gc.call(this,a,b,c);a.B&&this.B&&rg(this,a);a=d;-1==a&&(a=Se(this));a==this.M?this.M=Math.min(Se(this)-1,b):a>this.M&&b<=this.M?this.M++:a<this.M&&b>this.M&&this.M--};
g.removeChild=function(a,b){if(a=p(a)?Qe(this,a):a){var c=Ve(this,a);-1!=c&&(c==this.M?(a.mb(!1),this.M=-1):c<this.M&&this.M--);var d=a.h();d&&d.id&&this.Cb&&(c=this.Cb,d=d.id,d in c&&delete c[d])}c=a=pg.n.removeChild.call(this,a,b);c.B&&1!=c.rd&&zf(c,!0);c.rd=!0;return a};g.A=function(){return this.ea};
g.I=function(a,b){if(b||this.ea!=a&&this.dispatchEvent(a?"show":"hide")){this.ea=a;var c=this.h();c&&(Ce(c,a),this.Xb()&&kg(this.ga(),this.ic&&this.ea),b||this.dispatchEvent(this.ea?"aftershow":"afterhide"));return!0}return!1};g.isEnabled=function(){return this.ic};
g.Ed=function(a){this.ic!=a&&this.dispatchEvent(a?"enable":"disable")&&(a?(this.ic=!0,Re(this,function(a){a.pi?delete a.pi:a.Ed(!0)})):(Re(this,function(a){a.isEnabled()?a.Ed(!1):a.pi=!0}),this.Qc=this.ic=!1),this.Xb()&&kg(this.ga(),a&&this.ea))};g.Xb=function(){return this.Bf};g.zc=function(a){a!=this.Bf&&this.B&&sg(this,a);this.Bf=a;this.ic&&this.ea&&kg(this.ga(),a)};g.Vc=function(a){(a=S(this,a))?a.mb(!0):-1<this.M&&S(this,this.M).mb(!1)};g.mb=function(a){this.Vc(Ve(this,a))};
function tg(a){xg(a,function(a,c){return(a+1)%c},Se(a)-1)}function ug(a){xg(a,function(a,c){a--;return 0>a?c-1:a},0)}function wg(a){xg(a,function(a,c){return(a+1)%c},a.M)}function vg(a){xg(a,function(a,c){a--;return 0>a?c-1:a},a.M)}function xg(a,b,c){c=0>c?Ve(a,a.Z):c;var d=Se(a);c=b.call(a,c,d);for(var e=0;e<=d;){var f=S(a,c);if(f&&a.Ng(f)){a.Vc(c);break}e++;c=b.call(a,c,d)}}g.Ng=function(a){return a.A()&&a.isEnabled()&&!!(a.V&2)};function yg(){}u(yg,gf);ca(yg);yg.prototype.ua=function(){return"goog-menuheader"};function zg(a,b,c){U.call(this,a,c||yg.Vb(),b);this.Oa(1,!1);this.Oa(2,!1);this.Oa(4,!1);this.Oa(32,!1);this.$=1}u(zg,U);bf("goog-menuheader",function(){return new zg(null)});function Ag(a,b){pg.call(this,qg,b||og.Vb(),a);this.zc(!1)}u(Ag,pg);g=Ag.prototype;g.ff=!0;g.Mi=!1;g.ua=function(){return this.G.ua()};g.removeItem=function(a){(a=this.removeChild(a,!0))&&a.j()};function Bg(a){a.ff=!0;a.zc(!0)}g.I=function(a,b,c){(b=Ag.n.I.call(this,a,b))&&a&&this.B&&this.ff&&this.ga().focus();this.Rh=a&&c&&r(c.clientX)?new C(c.clientX,c.clientY):null;return b};g.Hf=function(a){this.ff&&this.ga().focus();return Ag.n.Hf.call(this,a)};
g.Ng=function(a){return(this.Mi||a.isEnabled())&&a.A()&&!!(a.V&2)};g.mc=function(a){var b=Ag.n.mc.call(this,a);b||Re(this,function(c){!b&&c.sj&&c.Kh==a.keyCode&&(this.isEnabled()&&this.mb(c),b=c.jb(a))},this);return b};
g.Vc=function(a){Ag.n.Vc.call(this,a);if(a=S(this,a)){var b=a.h();a=this.h();var c=ye(b),d=ye(a),e=He(a),f=c.x-d.x-e.left,c=c.y-d.y-e.top,d=a.clientHeight-b.offsetHeight,e=a.scrollLeft,h=a.scrollTop,e=e+Math.min(f,Math.max(f-(a.clientWidth-b.offsetWidth),0)),h=h+Math.min(c,Math.max(c-d,0)),b=new C(e,h);a.scrollLeft=b.x;a.scrollTop=b.y}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Cg(a,b){a.innerHTML=nb(b)};function V(a,b,c){Le.call(this,c);this.ma=b||Dg;this.Lf=a instanceof lb?a:pb(a,null)}u(V,Le);var Eg={};g=V.prototype;g.fg=!1;g.hd=!1;g.Fk=null;g.Ki=vb;g.wd=!0;g.Xd=-1;g.X=function(){V.n.X.call(this);this.Cc&&(this.Cc.removeNode(this),this.Cc=null);this.w=null};
g.ve=function(){var a=this.h();if(a){var b=Fg(this);b&&!b.id&&(b.id=Oe(this)+".label");ff(a,"treeitem");T(a,"selected",!1);T(a,"expanded",!1);T(a,"level",this.Lc());b&&T(a,"labelledby",b.id);(a=this.ke())&&ff(a,"presentation");(a=this.je())&&ff(a,"presentation");if(a=Gg(this))if(ff(a,"group"),a.hasChildNodes())for(a=Se(this),b=1;b<=a;b++){var c=S(this,b-1).h();T(c,"setsize",a);T(c,"posinset",b)}}};
g.H=function(){var a=this.ib(),b=nb(this.vg());var c=a.Gb,a=c.createElement("div");y?(a.innerHTML="<br>"+b,a.removeChild(a.firstChild)):a.innerHTML=b;if(1==a.childNodes.length)b=a.removeChild(a.firstChild);else for(b=c.createDocumentFragment();a.firstChild;)b.appendChild(a.firstChild);this.w=b};g.na=function(){V.n.na.call(this);Eg[Oe(this)]=this;this.ve()};g.Sa=function(){V.n.Sa.call(this);delete Eg[Oe(this)]};
g.Gc=function(a,b){var c=S(this,b-1),d=S(this,b);V.n.Gc.call(this,a,b);a.tc=c;a.kb=d;c?c.kb=a:this.rh=a;d?d.tc=a:this.Gh=a;var e=this.za();e&&Hg(a,e);Ig(a,this.Lc()+1);if(this.h()&&(this.Zc(),this.Ea())){e=Gg(this);a.h()||a.H();var f=a.h(),h=d&&d.h();e.insertBefore(f,h);this.B&&a.na();d||(c?c.Zc():(Ce(e,!0),this.Ob(this.Ea())))}};g.add=function(a,b){a.getParent()&&a.getParent().removeChild(a);this.Gc(a,b?Ve(this,b):Se(this));return a};
g.removeChild=function(a){var b=this.za(),c=b?b.Ma:null;if(c==a||a.contains(c))b.hasFocus()?(this.select(),Vd(this.bk,10,this)):this.select();V.n.removeChild.call(this,a);this.Gh==a&&(this.Gh=a.tc);this.rh==a&&(this.rh=a.kb);a.tc&&(a.tc.kb=a.kb);a.kb&&(a.kb.tc=a.tc);c=!a.kb;a.Cc=null;a.Xd=-1;if(b&&(b.removeNode(this),this.B)){b=Gg(this);if(a.B){var d=a.h();b.removeChild(d);a.Sa()}c&&(c=S(this,Se(this)-1))&&c.Zc();Ue(this)||(b.style.display="none",this.Zc(),this.ke().className=this.ee())}return a};
g.remove=V.prototype.removeChild;g.bk=function(){this.select()};g.Lc=function(){var a=this.Xd;0>a&&(a=(a=this.getParent())?a.Lc()+1:0,Ig(this,a));return a};function Ig(a,b){if(b!=a.Xd){a.Xd=b;var c=Jg(a);if(c){var d=Kg(a)+"px";Te(a)?c.style.paddingRight=d:c.style.paddingLeft=d}Re(a,function(a){Ig(a,b+1)})}}g.contains=function(a){for(;a;){if(a==this)return!0;a=a.getParent()}return!1};g.lc=function(){var a=[];Re(this,function(b){a.push(b)});return a};g.xe=function(){return this.fg};
g.select=function(){var a=this.za();a&&a.Ac(this)};function Lg(a,b){if(a.fg!=b){a.fg=b;Mg(a);var c=a.h();c&&(T(c,"selected",b),b&&(c=a.za().h(),T(c,"activedescendant",Oe(a))))}}g.Ea=function(){return this.hd};
g.Ob=function(a){var b=a!=this.hd;if(!b||this.dispatchEvent(a?"beforeexpand":"beforecollapse")){var c;this.hd=a;c=this.za();var d=this.h();if(Ue(this)){if(!a&&c&&this.contains(c.Ma)&&this.select(),d){if(c=Gg(this))if(Ce(c,a),a&&this.B&&!c.hasChildNodes()){var e=[];Re(this,function(a){e.push(a.vg())});Cg(c,ub(e));Re(this,function(a){a.na()})}this.Zc()}}else(c=Gg(this))&&Ce(c,!1);d&&(this.ke().className=this.ee(),T(d,"expanded",a));b&&this.dispatchEvent(a?"expand":"collapse")}};g.toggle=function(){this.Ob(!this.Ea())};
g.expand=function(){this.Ob(!0)};g.collapse=function(){this.Ob(!1)};g.eg=function(){var a=this.getParent();a&&(a.Ob(!0),a.eg())};g.vg=function(){var a=this.za(),b=!a.Hd||a==this.getParent()&&!a.lg?this.ma.Vg:this.ma.Ug,a=this.Ea()&&Ue(this),b={"class":b,style:Ng(this)},c=[];a&&Re(this,function(a){c.push(a.vg())});a=tb("div",b,c);return tb("div",{"class":this.ma.dh,id:Oe(this)},[Og(this),a])};function Kg(a){return Math.max(0,(a.Lc()-1)*a.ma.Nf)}
function Og(a){var b={};b["padding-"+(Te(a)?"right":"left")]=Kg(a)+"px";var b={"class":a.md(),style:b},c=a.Ef(),d=tb("span",{style:{display:"inline-block"},"class":a.ee()}),e=tb("span",{"class":a.ma.eh,title:a.Fk||null},a.Lf);a=ub(e,tb("span",{},a.Ki));return tb("div",b,[c,d,a])}g.md=function(){return this.ma.hh+(this.xe()?" "+this.ma.gh:"")};g.Ef=function(){return tb("span",{type:"expand",style:{display:"inline-block"},"class":Pg(this)})};
function Pg(a){var b=a.za(),c=!b.Hd||b==a.getParent()&&!b.lg,d=a.ma,e=new qa;e.append(d.gc," ",d.Zi," ");if(Ue(a)){var f=0;b.kg&&a.wd&&(f=a.Ea()?2:1);c||(f=a.kb?f+8:f+4);switch(f){case 1:e.append(d.cj);break;case 2:e.append(d.bj);break;case 4:e.append(d.Zg);break;case 5:e.append(d.aj);break;case 6:e.append(d.$i);break;case 8:e.append(d.$g);break;case 9:e.append(d.ej);break;case 10:e.append(d.dj);break;default:e.append(d.Yg)}}else c?e.append(d.Yg):a.kb?e.append(d.$g):e.append(d.Zg);return e.toString()}
function Ng(a){var b=a.Ea()&&Ue(a);return eb({"background-position":Qg(a),display:b?null:"none"})}function Qg(a){return(a.kb?(a.Lc()-1)*a.ma.Nf:"-100")+"px 0"}g.h=function(){var a=V.n.h.call(this);a||(this.w=a=this.ib().h(Oe(this)));return a};function Jg(a){return(a=a.h())?a.firstChild:null}g.je=function(){var a=Jg(this);return a?a.firstChild:null};g.ke=function(){var a=Jg(this);return a?a.childNodes[1]:null};function Fg(a){return(a=Jg(a))&&a.lastChild?a.lastChild.previousSibling:null}
function Gg(a){return(a=a.h())?a.lastChild:null}g.zb=function(a){this.Lf=a=ob(a);var b=Fg(this);b&&Cg(b,a);(a=this.za())&&Rg(a,this)};g.Jb=function(){var a=nb(this.Lf);return w(a,"&")?"document"in n?Fa(a):Ha(a):a};function Mg(a){var b=Jg(a);b&&(b.className=a.md())}g.Zc=function(){var a=this.je();a&&(a.className=Pg(this));if(a=Gg(this))a.style.backgroundPosition=Qg(this)};g.Wf=function(a){"expand"==a.target.getAttribute("type")&&Ue(this)?this.wd&&this.toggle():(this.select(),Mg(this))};
g.Nh=function(a){"expand"==a.target.getAttribute("type")&&Ue(this)||this.wd&&this.toggle()};function Sg(a){return a.Ea()&&Ue(a)?Sg(S(a,Se(a)-1)):a}function Hg(a,b){a.Cc!=b&&(a.Cc=b,Rg(b,a),Re(a,function(a){Hg(a,b)}))}
var Dg={Nf:19,fh:"goog-tree-root goog-tree-item",bh:"goog-tree-hide-root",dh:"goog-tree-item",Ug:"goog-tree-children",Vg:"goog-tree-children-nolines",hh:"goog-tree-row",eh:"goog-tree-item-label",gc:"goog-tree-icon",Zi:"goog-tree-expand-icon",cj:"goog-tree-expand-icon-plus",bj:"goog-tree-expand-icon-minus",ej:"goog-tree-expand-icon-tplus",dj:"goog-tree-expand-icon-tminus",aj:"goog-tree-expand-icon-lplus",$i:"goog-tree-expand-icon-lminus",$g:"goog-tree-expand-icon-t",Zg:"goog-tree-expand-icon-l",Yg:"goog-tree-expand-icon-blank",
qf:"goog-tree-expanded-folder-icon",Wg:"goog-tree-collapsed-folder-icon",rf:"goog-tree-file-icon",ah:"goog-tree-expanded-folder-icon",Xg:"goog-tree-collapsed-folder-icon",gh:"selected"};function Tg(a,b,c){V.call(this,a,b,c)}u(Tg,V);Tg.prototype.za=function(){if(this.Cc)return this.Cc;var a=this.getParent();return a&&(a=a.za())?(Hg(this,a),a):null};Tg.prototype.ee=function(){var a=this.Ea(),b=this.nj;if(a&&b)return b;b=this.Gj;if(!a&&b)return b;b=this.ma;if(Ue(this)){if(a&&b.qf)return b.gc+" "+b.qf;if(!a&&b.Wg)return b.gc+" "+b.Wg}else if(b.rf)return b.gc+" "+b.rf;return""};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Vg={Wd:null,show:function(a,b){Ug();if(b.length){for(var c=new Ag,d=0,e;e=b[d];d++){var f=new Jf(e.text);c.df(f,!0);f.Ed(e.enabled);e.enabled&&Id(f,"action",function(a){return function(){a()}}(e.bb))}Id(c,"action",Vg.Kb);e=Zb();f=ve();c.F(Wg);var h=c.h();Nf(h,"blocklyContextMenu");var k=ze(h),d=a.clientX+f.x,l=a.clientY+f.y;a.clientY+k.height>=e.height&&(l-=k.height);I?k.width>=a.clientX&&(d+=k.width):a.clientX+k.width>=e.width&&(d-=k.width);Xg(d,l,e,f);Bg(c);setTimeout(function(){h.focus()},
1);Vg.Wd=null}else Vg.Kb()},Kb:function(){Yg==Vg&&Zg();Vg.Wd=null},Zk:function(a,b){return function(){var c=Oc(a.s,b),d=K(a);d.x=I?d.x-W:d.x+W;d.y+=2*W;c.moveBy(d.x,d.y);c.select()}}};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function $g(a,b,c,d,e,f,h){var k=ah;I&&(k=-k);this.Oi=k/360*Math.PI*2;this.v=a;this.Eb=b;this.di=c;a.Xc.appendChild(this.pf(b,!(!f||!h)));bh(this,d,e);f&&h||(a=this.Eb.getBBox(),f=a.width+2*ch,h=a.height+2*ch);this.yc(f,h);dh(this);eh(this);this.dg=!0;M||(Q(this.Td,"mousedown",this,this.Si),this.Nb&&Q(this.Nb,"mousedown",this,this.nk))}var ch=6,ah=20,fh=null,gh=null;function hh(){fh&&(P(fh),fh=null);gh&&(P(gh),gh=null)}g=$g.prototype;g.dg=!1;g.$a=0;g.jf=0;g.vc=0;g.Bd=0;g.L=0;g.Ta=0;g.lf=!0;
g.pf=function(a,b){this.ab=N("g",{},null);var c=N("g",{filter:"url(#blocklyEmboss)"},this.ab);this.Kg=N("path",{},c);this.Td=N("rect",{"class":"blocklyDraggable",x:0,y:0,rx:ch,ry:ch},c);b?(this.Nb=N("g",{"class":I?"blocklyResizeSW":"blocklyResizeSE"},this.ab),c=2*ch,N("polygon",{points:"0,x x,x x,0".replace(/x/g,c.toString())},this.Nb),N("line",{"class":"blocklyResizeLine",x1:c/3,y1:c-1,x2:c-1,y2:c/3},this.Nb),N("line",{"class":"blocklyResizeLine",x1:2*c/3,y1:c-1,x2:c-1,y2:2*c/3},this.Nb)):this.Nb=
null;this.ab.appendChild(a);return this.ab};g.Si=function(a){ih(this);hh();hd(a)||jh(a)||(kh(!0),this.nh=I?this.vc+a.clientX:this.vc-a.clientX,this.lj=this.Bd-a.clientY,fh=Q(document,"mouseup",this,hh),gh=Q(document,"mousemove",this,this.Ti),ld(),a.stopPropagation())};g.Ti=function(a){this.lf=!1;this.vc=I?this.nh-a.clientX:this.nh+a.clientX;this.Bd=this.lj+a.clientY;dh(this);eh(this)};
g.nk=function(a){ih(this);hh();hd(a)||(kh(!0),this.lk=I?this.L+a.clientX:this.L-a.clientX,this.kk=this.Ta-a.clientY,fh=Q(document,"mouseup",this,hh),gh=Q(document,"mousemove",this,this.ok),ld(),a.stopPropagation())};g.ok=function(a){this.lf=!1;var b=this.lk,c=this.kk+a.clientY,b=I?b-a.clientX:b+a.clientX;this.yc(b,c);I&&dh(this)};function ih(a){a.ab.parentNode.appendChild(a.ab)}function bh(a,b,c){a.$a=b;a.jf=c;a.dg&&dh(a)}
function dh(a){a.ab.setAttribute("transform","translate("+(I?a.$a-a.vc-a.L:a.$a+a.vc)+", "+(a.Bd+a.jf)+")")}g.kc=function(){return{width:this.L,height:this.Ta}};
g.yc=function(a,b){var c=2*ch;a=Math.max(a,c+45);b=Math.max(b,c+18);this.L=a;this.Ta=b;this.Td.setAttribute("width",a);this.Td.setAttribute("height",b);this.Nb&&(I?this.Nb.setAttribute("transform","translate("+2*ch+", "+(b-c)+") scale(-1 1)"):this.Nb.setAttribute("transform","translate("+(a-c)+", "+(b-c)+")"));if(this.dg){if(this.lf){var c=-this.L/4,d=-this.Ta-25,e=this.v.Ib();I?this.$a-e.Ca-c-this.L<O?c=this.$a-e.Ca-this.L-O:this.$a-e.Ca-c>e.Q&&(c=this.$a-e.Ca-e.Q):this.$a+c<e.Ca?c=e.Ca-this.$a:
e.Ca+e.Q<this.$a+c+this.L+10+O&&(c=e.Ca+e.Q-this.$a-this.L-O);this.jf+d<e.Bb&&(d=this.di.getBBox().height);this.vc=c;this.Bd=d}dh(this);eh(this)}pe(this.ab,"resize")};
function eh(a){var b=[],c=a.L/2,d=a.Ta/2,e=-a.vc,f=-a.Bd;if(c==e&&d==f)b.push("M "+c+","+d);else{f-=d;e-=c;I&&(e*=-1);var h=Math.sqrt(f*f+e*e),k=Math.acos(e/h);0>f&&(k=2*Math.PI-k);var l=k+Math.PI/2;l>2*Math.PI&&(l-=2*Math.PI);var q=Math.sin(l),m=Math.cos(l),t=a.kc(),l=(t.width+t.height)/10,l=Math.min(l,t.width,t.height)/2,t=1-8/h,e=c+t*e,f=d+t*f,t=c+l*m,v=d+l*q,c=c-l*m,d=d-l*q,q=k+a.Oi;q>2*Math.PI&&(q-=2*Math.PI);k=Math.sin(q)*h/4;h=Math.cos(q)*h/4;b.push("M"+t+","+v);b.push("C"+(t+h)+","+(v+k)+
" "+e+","+f+" "+e+","+f);b.push("C"+e+","+f+" "+(c+h)+","+(d+k)+" "+c+","+d)}b.push("z");a.Kg.setAttribute("d",b.join(" "))}g.ig=function(a){this.Td.setAttribute("fill",a);this.Kg.setAttribute("fill",a)};g.j=function(){hh();F(this.ab);this.di=this.Eb=this.v=this.ab=null};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function lh(a){this.m=a}g=lh.prototype;g.ha=null;g.Nc=0;g.Oc=0;g.Jc=function(){this.Fa=N("g",{},null);ig(this.m).appendChild(this.Fa);Q(this.Fa,"mouseup",this,this.Hj);this.Ec()};g.j=function(){F(this.Fa);this.Fa=null;this.I(!1);this.m=null};g.Ec=function(){this.m.Yb?Of(this.Fa,"blocklyIconGroup"):Nf(this.Fa,"blocklyIconGroup")};g.A=function(){return!!this.ha};g.Hj=function(){this.m.Yb||this.I(!this.A())};g.Dc=function(){if(this.A()){var a=Wf(Xf(this.m.Sg));this.ha.ig(a)}};
function dg(a){var b=K(a.m),c=mh(a.Fa),d=b.x+c.x+8,b=b.y+c.y+8;if(d!==a.Nc||b!==a.Oc)a.Nc=d,a.Oc=b,a.A()&&bh(a.ha,d,b)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function nh(a,b){this.k=a;this.o=null;this.type=b;this.O=this.pb=0;this.vb=!1;this.Tb=this.k.s.Xi}g=nh.prototype;g.j=function(){if(this.o)throw"Disconnect connection before disposing of it.";this.vb&&oh(this.Tb[this.type],this);this.vb=!1;ph==this&&(ph=null);qh==this&&(qh=null)};function rh(a){return 1==a.type||3==a.type}
function Zc(a,b){if(a.k==b.k)throw"Attempted to connect a block to itself.";if(a.k.s!==b.k.s)throw"Blocks are on different workspaces.";if(sh[a.type]!=b.type)throw"Attempt to connect incompatible types.";if(1==a.type||2==a.type){if(a.o)throw"Source connection already connected (value).";if(b.o){var c=L(b);c.Na(null);if(!c.K)throw"Orphan block does not have an output connection.";for(var d=a.k;d=th(d,c);)if(L(d))d=L(d);else{Zc(d,c.K);c=null;break}c&&window.setTimeout(function(){uh(c.K,b)},vh)}}else{if(a.o)throw"Source connection already connected (block).";
if(b.o){if(4!=a.type)throw"Can only do a mid-stack connection with the top of a block.";c=L(b);c.Na(null);if(!c.C)throw"Orphan block does not have a previous connection.";for(d=a.k;d.J;)if(d.J.o)d=Kc(d);else{wh(c.C,d.J)&&(Zc(d.J,c.C),c=null);break}c&&window.setTimeout(function(){uh(c.C,b)},vh)}}var e;rh(a)?(d=a.k,e=b.k):(d=b.k,e=a.k);a.o=b;b.o=a;e.Na(d);d.N&&ag(d.i);e.N&&ag(e.i);d.N&&e.N&&(3==a.type||4==a.type?e.F():d.F())}
function th(a,b){for(var c=!1,d=0;d<a.T.length;d++){var e=a.T[d].p;if(e&&1==e.type&&wh(b.K,e)){if(c)return null;c=e}}return c}g.disconnect=function(){var a=this.o;if(!a)throw"Source connection not connected.";if(a.o!=this)throw"Target connection not connected to source connection.";this.o=a.o=null;var b;rh(this)?(b=this.k,a=a.k):(b=a.k,a=this.k);b.N&&b.F();a.N&&(ag(a.i),a.F())};function L(a){return a.o?a.o.k:null}
function uh(a,b){if(0==ne){var c=xh(a.k);if(!c.Yb){var d=!1;if(!c.Mb||M){c=xh(b.k);if(!c.Mb||M)return;b=a;d=!0}ig(c).parentNode.appendChild(ig(c));var e=b.pb+W-a.pb,f=b.O+W-a.O;d&&(f=-f);I&&(e=-e);c.moveBy(e,f)}}}g.moveTo=function(a,b){this.vb&&oh(this.Tb[this.type],this);this.pb=a;this.O=b;yh(this.Tb[this.type],this)};g.moveBy=function(a,b){this.moveTo(this.pb+a,this.O+b)};
g.zh=function(){var a;1==this.type||2==this.type?(a=I?-8:8,a="m 0,0 v 5 c 0,10 "+-a+",-8 "+-a+",7.5 s "+a+",-2.5 "+a+",7.5 v 5"):a=I?"m 20,0 h -5 l -6,4 -3,0 -6,-4 h -5":"m -20,0 h 5 l 6,4 3,0 6,-4 h 5";var b=K(this.k);nh.re=N("path",{"class":"blocklyHighlightedConnectionPath",d:a,transform:"translate("+(this.pb-b.x)+", "+(this.O-b.y)+")"},ig(this.k))};
function gg(a){var b=Math.round(a.o.pb-a.pb),c=Math.round(a.o.O-a.O);if(0!=b||0!=c){a=L(a);var d=ig(a);if(!d)throw"block is not rendered.";d=mh(d);ig(a).setAttribute("transform","translate("+(d.x-b)+", "+(d.y-c)+")");zh(a,-b,-c)}}
function Ah(a,b,c,d){function e(a){var c=f[a];if((2==c.type||4==c.type)&&c.o||1==c.type&&c.o&&(!L(c).Mb||M)||!wh(t,c))return!0;c=c.k;do{if(m==c)return!0;c=c.getParent()}while(c);var d=h-f[a].pb,c=k-f[a].O,d=Math.sqrt(d*d+c*c);d<=b&&(q=f[a],b=d);return c<b}if(a.o)return{p:null,Vh:b};var f=a.Tb[sh[a.type]],h=a.pb+c,k=a.O+d;c=0;for(var l=d=f.length-2;c<l;)f[l].O<k?c=l:d=l,l=Math.floor((c+d)/2);d=c=l;var q=null,m=a.k,t=a;if(f.length){for(;0<=c&&e(c);)c--;do d++;while(d<f.length&&e(d))}return{p:q,Vh:b}}
function wh(a,b){if(!a.Hc||!b.Hc)return!0;for(var c=0;c<a.Hc.length;c++)if(-1!=b.Hc.indexOf(a.Hc[c]))return!0;return!1}g.Uc=function(a){a?(ea(a)||(a=[a]),this.Hc=a,this.o&&!wh(this,this.o)&&(rh(this)?L(this).Na(null):this.k.Na(null),this.k.Ja())):this.Hc=null;return this};
function Bh(a){var b=W;function c(a){var c=e-d[a].pb,h=f-d[a].O;Math.sqrt(c*c+h*h)<=b&&l.push(d[a]);return h<b}var d=a.Tb[sh[a.type]],e=a.pb,f=a.O;a=0;for(var h=d.length-2,k=h;a<k;)d[k].O<f?a=k:h=k,k=Math.floor((a+h)/2);var h=a=k,l=[];if(d.length){for(;0<=a&&c(a);)a--;do h++;while(h<d.length&&c(h))}return l}
function Dh(a){a.vb||yh(a.Tb[a.type],a);var b=[];if(1!=a.type&&3!=a.type)return b;if(a=L(a)){var c;a.isCollapsed()?(c=[],a.K&&c.push(a.K),a.J&&c.push(a.J),a.C&&c.push(a.C)):c=Eh(a,!0);for(var d=0;d<c.length;d++)b.push.apply(b,Dh(c[d]));0==b.length&&(b[0]=a)}return b}function ce(){}ce.prototype=[];function yh(a,b){if(b.vb)throw"Connection already in database.";for(var c=0,d=a.length;c<d;){var e=Math.floor((c+d)/2);if(a[e].O<b.O)c=e+1;else if(a[e].O>b.O)d=e;else{c=e;break}}a.splice(c,0,b);b.vb=!0}
function oh(a,b){if(!b.vb)throw"Connection not in database.";b.vb=!1;for(var c=0,d=a.length-2,e=d;c<e;)a[e].O<b.O?c=e:d=e,e=Math.floor((c+d)/2);for(d=c=e;0<=c&&a[c].O==b.O;){if(a[c]==b){a.splice(c,1);return}c--}do{if(a[d]==b){a.splice(d,1);return}d++}while(d<a.length&&a[d].O==b.O);throw"Unable to find connection in connectionDB.";};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Jh={Uk:function(a){var b={Y:function(){var b=this;this.ig(a.$k);this.nc=a.nc;"string"==typeof a.Qa?this.Te(a.Qa):"function"==typeof a.Qa&&this.Te(function(){return a.Qa(b)});"undefined"!=a.dk?Fh(this,a.dk):(Gh(this,"undefined"==typeof a.hk?!0:a.hk),Hh(this,"undefined"==typeof a.Xj?!0:a.Xj));var d=[];d.push(a.text);a.Ni&&a.Ni.forEach(function(a){"undefined"==a.type||1==a.type?d.push([a.name,a.check,"undefined"==typeof a.align?1:a.align]):Ka("addTemplate() can only handle value inputs.")});d.push(1);
a.Mj&&this.Bl(a.Mj);Ih.prototype.vd.apply(this,d)}};b.Lh=a.Fl?function(){var b=a.Uj?a.rl():document.createElement("mutation");b.setAttribute("is_statement",this.isStatement||!1);return b}:a.Uj;Jh[a.Yk]=b}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Kh(a){Kh.n.constructor.call(this,a);this.Jc()}u(Kh,lh);g=Kh.prototype;g.ob="";g.L=160;g.Ta=80;g.Jc=function(){lh.prototype.Jc.call(this);N("circle",{"class":"blocklyIconShield",r:8,cx:8,cy:8},this.Fa);this.Mf=N("text",{"class":"blocklyIconMark",x:8,y:13},this.Fa);this.Mf.appendChild(document.createTextNode("?"))};g.Ec=function(){this.A()&&(this.I(!1),this.I(!0));lh.prototype.Ec.call(this)};
g.jk=function(){var a=this.ha.kc(),b=2*ch;this.kd.setAttribute("width",a.width-b);this.kd.setAttribute("height",a.height-b);this.Ha.style.width=a.width-b-4+"px";this.Ha.style.height=a.height-b-4+"px"};
g.I=function(a){if(a!=this.A())if((!this.m.Kc||M)&&!this.Ha||y)Lh.prototype.I.call(this,a);else{var b=this.Jb(),c=this.kc();if(a){a=this.m.s;this.kd=N("foreignObject",{x:ch,y:ch},null);var d=document.createElementNS("http://www.w3.org/1999/xhtml","body");d.setAttribute("xmlns","http://www.w3.org/1999/xhtml");d.className="blocklyMinimalBody";this.Ha=document.createElementNS("http://www.w3.org/1999/xhtml","textarea");this.Ha.className="blocklyCommentTextarea";this.Ha.setAttribute("dir",I?"RTL":"LTR");
d.appendChild(this.Ha);this.kd.appendChild(d);Q(this.Ha,"mouseup",this,this.Ek);this.ha=new $g(a,this.kd,this.m.i.Pb,this.Nc,this.Oc,this.L,this.Ta);Q(this.ha.ab,"resize",this,this.jk);this.Dc();this.ob=null}else this.ha.j(),this.kd=this.Ha=this.ha=null;this.zb(b);this.yc(c.width,c.height)}};g.Ek=function(){ih(this.ha);this.Ha.focus()};g.kc=function(){return this.A()?this.ha.kc():{width:this.L,height:this.Ta}};g.yc=function(a,b){this.Ha?this.ha.yc(a,b):(this.L=a,this.Ta=b)};
g.Jb=function(){return this.Ha?this.Ha.value:this.ob};g.zb=function(a){this.Ha?this.Ha.value=a:this.ob=a};g.j=function(){this.m.ya=null;lh.prototype.j.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Mh=!1,Nh=0,Oh=0,Ph={x:0,y:0},Qh=null,Rh=null,Sh=null,Th=null,Uh=null,Vh=null;function Wh(){var a=N("g",{"class":"blocklyHidden"},null);Sh=a;Vh=N("rect",{"class":"blocklyTooltipShadow",x:2,y:2},a);Uh=N("rect",{"class":"blocklyTooltipBackground"},a);Th=N("text",{"class":"blocklyTooltipText"},a);return a}function Lf(a){Q(a,"mouseover",null,Xh);Q(a,"mouseout",null,Yh);Q(a,"mousemove",null,Zh)}
function Xh(a){for(a=a.target;!p(a.Qa)&&!s(a.Qa);)a=a.Qa;Qh!=a&&($h(),Rh=null,Qh=a);window.clearTimeout(Nh)}function Yh(){Nh=window.setTimeout(function(){Rh=Qh=null;$h()},1);window.clearTimeout(Oh)}function Zh(a){Qh&&Qh.Qa&&0==ne&&!Yg&&(Mh?(a=id(a),10<Math.sqrt(Math.pow(Ph.x-a.x,2)+Math.pow(Ph.y-a.y,2))&&$h()):Rh!=Qh&&(window.clearTimeout(Oh),Ph=id(a),Oh=window.setTimeout(ai,1E3)))}function $h(){Mh&&(Mh=!1,Sh&&(Sh.style.display="none"));window.clearTimeout(Oh)}
function ai(){Rh=Qh;if(Sh){cc(Th);var a=Qh.Qa;s(a)&&(a=a());var b=a,a=50;if(b.length<=a)a=b;else{for(var c=b.trim().split(/\s+/),d=0;d<c.length;d++)c[d].length>a&&(a=c[d].length);var e,d=-Infinity,f,h=1;do{e=d;f=b;for(var b=[],k=c.length/h,l=1,d=0;d<c.length-1;d++)l<(d+1.5)/k?(l++,b[d]=!0):b[d]=!1;for(var b=bi(c,b,a),d=ci(c,b,a),k=c,l=[],q=0;q<k.length;q++)l.push(k[q]),void 0!==b[q]&&l.push(b[q]?"\n":" ");b=l.join("");h++}while(d>e);a=f}a=a.split("\n");for(c=0;c<a.length;c++)N("tspan",{dy:"1em",x:5},
Th).appendChild(document.createTextNode(a[c]));Mh=!0;Sh.style.display="block";a=Th.getBBox();c=10+a.width;e=a.height;Uh.setAttribute("width",c);Uh.setAttribute("height",e);Vh.setAttribute("width",c);Vh.setAttribute("height",e);if(I)for(e=a.width,f=0;h=Th.childNodes[f];f++)h.setAttribute("text-anchor","end"),h.setAttribute("x",e+5);e=Ph.x;e=I?e-(0+c):e+0;c=Ph.y+10;f=di();c+a.height>f.height&&(c-=a.height+20);I?e=Math.max(5,e):e+a.width>f.width-10&&(e=f.width-a.width-10);Sh.setAttribute("transform",
"translate("+e+","+c+")")}}function ci(a,b,c){for(var d=[0],e=[],f=0;f<a.length;f++)d[d.length-1]+=a[f].length,!0===b[f]?(d.push(0),e.push(a[f].charAt(a[f].length-1))):!1===b[f]&&d[d.length-1]++;a=Math.max.apply(Math,d);for(f=b=0;f<d.length;f++)b-=2*Math.pow(Math.abs(c-d[f]),1.5),b-=Math.pow(a-d[f],1.5),-1!=".?!".indexOf(e[f])?b+=c/3:-1!=",;)]}".indexOf(e[f])&&(b+=c/4);1<d.length&&d[d.length-1]<=d[d.length-2]&&(b+=.5);return b}
function bi(a,b,c){for(var d=ci(a,b,c),e,f=0;f<b.length-1;f++)if(b[f]!=b[f+1]){var h=[].concat(b);h[f]=!h[f];h[f+1]=!h[f+1];var k=ci(a,h,c);k>d&&(d=k,e=h)}return e?bi(a,e,c):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function ei(a){this.k=null;this.Pa=N("text",{"class":"blocklyText"},null);this.Id={height:25,width:0};this.zb(a)}u(ei,hg);g=ei.prototype;g.clone=function(){return new ei(this.Jb())};g.$c=!1;g.Y=function(a){if(this.k)throw"Text has already been initialized once.";this.k=a;ig(a).appendChild(this.Pa);this.Pa.Qa=this.k;Lf(this.Pa)};g.j=function(){F(this.Pa);this.Pa=null};g.oa=function(){return this.Pa};g.Te=function(a){this.Pa.Qa=a};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function fi(a,b,c,d){this.type=a;this.name=b;this.k=c;this.p=d;this.ta=[];this.align=-1;this.ea=!0}function gi(a,b,c){if(b||c)p(b)&&(b=new ei(b)),a.k.i&&b.Y(a.k),b.name=c,b.gk&&gi(a,b.gk),a.ta.push(b),b.Dk&&gi(a,b.Dk),a.k.N&&(a.k.F(),a.k.Ja())}g=fi.prototype;g.A=function(){return this.ea};
g.I=function(a){var b=[];if(this.ea==a)return b;for(var c=(this.ea=a)?"block":"none",d=0,e;e=this.ta[d];d++)e.I(a);if(this.p){if(a)b=Dh(this.p);else if(d=this.p,d.vb&&oh(d.Tb[d.type],d),d.o){e=hi(L(d));for(var f=0;f<e.length;f++){for(var h=e[f],k=Eh(h,!0),l=0;l<k.length;l++){var q=k[l];q.vb&&oh(d.Tb[q.type],q)}h=cg(h);for(k=0;k<h.length;k++)h[k].I(!1)}}if(d=L(this.p))d.i.oa().style.display=c,a||(d.N=!1)}return b};
g.Uc=function(a){if(!this.p)throw"This input does not have a connection.";this.p.Uc(a);return this};function ii(a,b){a.align=b;a.k.N&&a.k.F();return a}g.Y=function(){for(var a=0;a<this.ta.length;a++)this.ta[a].Y(this.k)};g.j=function(){for(var a=0,b;b=this.ta[a];a++)b.j();this.p&&this.p.j();this.k=null};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Lh(a){Lh.n.constructor.call(this,a);this.Jc()}u(Lh,lh);g=Lh.prototype;g.ob="";g.Jc=function(){lh.prototype.Jc.call(this);N("path",{"class":"blocklyIconShield",d:"M 2,15 Q -1,15 0.5,12 L 6.5,1.7 Q 8,-1 9.5,1.7 L 15.5,12 Q 17,15 14,15 z"},this.Fa);this.Mf=N("text",{"class":"blocklyIconMark",x:8,y:13},this.Fa);this.Mf.appendChild(document.createTextNode("!"))};
g.I=function(a){if(a!=this.A())if(a){var b=this.ob;a=N("text",{"class":"blocklyText blocklyBubbleText",y:ch},null);for(var b=b.split("\n"),c=0;c<b.length;c++)N("tspan",{dy:"1em",x:ch},a).appendChild(document.createTextNode(b[c]));this.ha=new $g(this.m.s,a,this.m.i.Pb,this.Nc,this.Oc,null,null);if(I)for(var b=a.getBBox().width,c=0,d;d=a.childNodes[c];c++)d.setAttribute("text-anchor","end"),d.setAttribute("x",b+ch);this.Dc();a=this.ha.kc();this.ha.yc(a.width,a.height)}else this.ha.j(),this.ha=null};
g.zb=function(a){this.ob!=a&&(this.ob=a,this.A()&&(this.I(!1),this.I(!0)))};g.j=function(){this.m.Qd=null;lh.prototype.j.call(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var ji=0;function Ih(){}function Qc(a,b){if(ge)return ki.create(Ih,a,b);var c=new Ih;c.initialize(a,b);return c}g=Ih.prototype;g.initialize=function(a,b){var c=(++ji).toString();this.id=ge?li(c):c;fe(a,this);this.fill(a,b);s(this.onchange)&&Q(a.aa,"blocklyWorkspaceChange",this,this.onchange)};
g.fill=function(a,b){this.C=this.J=this.K=null;this.T=[];this.disabled=this.N=this.ud=!1;this.Qa="";this.contextMenu=!0;this.Sc=null;this.qb=[];this.Kc=this.Mb=this.hc=!0;this.fc=!1;this.s=a;this.Yb=a.Fh;if(b){this.type=b;var c=Jh[b],d;for(d in c)this[d]=c[d]}s(this.Y)&&this.Y()};function Pc(a,b){return ge?mi.get(a):ke(b,a)}g.i=null;g.De=null;g.ya=null;g.Qd=null;function cg(a){var b=[];a.De&&b.push(a.De);a.ya&&b.push(a.ya);a.Qd&&b.push(a.Qd);return b}
function Rc(a){a.i=new Kf(a);a.i.Y();M||Q(a.i.oa(),"mousedown",a,a.Fe);a.s.aa.appendChild(a.i.oa())}function ig(a){return a.i&&a.i.oa()}var ne=0,ni=null,oi=null;g=Ih.prototype;g.select=function(){R&&oe();R=this;this.i.ef();pe(this.s.aa,"blocklySelectChange")};function oe(){var a=R;R=null;a.i.Qe();pe(a.s.aa,"blocklySelectChange")}
g.j=function(a,b,c){this.N=!1;var d;d=!1;if(this.K)this.K.o&&this.Na(null);else{var e=null;this.C&&this.C.o&&(e=this.C.o,this.Na(null));var f=Kc(this);a&&f&&(a=this.J.o,f.Na(null),e&&Zc(e,a))}d&&this.moveBy(W*(I?-1:1),2*W);b&&this.i&&(d=this.i,pi("delete"),b=jd(d.g),d=d.g.cloneNode(!0),d.mi=b.x,d.ni=b.y,d.setAttribute("transform","translate("+d.mi+","+d.ni+")"),J.appendChild(d),d.Jg=d.getBBox(),d.og=new Date,Uf(d));this.s&&!c&&(ie(this.s,this),this.s=null);R==this&&(R=null,qi());Vg.Wd==this&&Vg.Kb();
for(c=this.qb.length-1;0<=c;c--)this.qb[c].j(!1);b=cg(this);for(c=0;c<b.length;c++)b[c].j();for(c=0;b=this.T[c];c++)b.j();this.T=[];b=Eh(this,!0);for(c=0;c<b.length;c++)d=b[c],d.o&&d.disconnect(),b[c].j();this.i&&(this.i.j(),this.i=null);if(ge&&!ri)mi["delete"](this.id.toString())};function K(a){var b=0,c=0;if(a.i){var d=a.i.oa();do var e=mh(d),b=b+e.x,c=c+e.y,d=d.parentNode;while(d&&d!=a.s.aa)}return{x:b,y:c}}
g.moveBy=function(a,b){var c=K(this);this.i.oa().setAttribute("transform","translate("+(c.x+a)+", "+(c.y+b)+")");zh(this,a,b);si(this)};function eg(a){var b=a.i.height,c=a.i.width;if(a=Kc(a))a=eg(a),b+=a.height-4,c=Math.max(c,a.width);return{height:b,width:c}}
g.Fe=function(a){if(!this.Yb){ti();qi();this.select();ld();if(hd(a))ui(this,a);else if(this.Mb&&!M){kd();kh(!0);var b=K(this);this.gi=b.x;this.ii=b.y;this.qg=a.clientX;this.rg=a.clientY;ne=1;ni=Q(document,"mouseup",this,this.Yf);oi=Q(document,"mousemove",this,this.Xf);this.$d=[];for(var b=hi(this),c=0,d;d=b[c];c++){d=cg(d);for(var e=0;e<d.length;e++){var f;f=d[e];f={x:f.Nc,y:f.Oc};f.Ri=d[e];this.$d.push(f)}}}else return;a.stopPropagation()}};
g.Yf=function(){var a=this;vi(function(){qi();if(R&&ph){Zc(qh,ph);if(a.i){var b=(rh(qh)?ph:qh).k.i;pi("click");var c=jd(b.g);b.m.K?(c.x+=I?3:-3,c.y+=13):b.m.C&&(c.x+=I?-23:23,c.y+=3);b=N("circle",{cx:c.x,cy:c.y,r:0,fill:"none",stroke:"#888","stroke-width":10},J);b.og=new Date;Vf(b)}a.s.Ia&&a.s.Ia.wb&&a.s.Ia.close()}else a.s.Ia&&a.s.Ia.wb&&(b=a.s.Ia,Vd(b.close,100,b),R.j(!1,!0),pe(window,"resize"));ph&&(F(nh.re),delete nh.re,ph=null)})};
function ui(a,b){if(!M&&a.contextMenu){var c=[];if(a.hc&&!M&&a.Mb&&!M&&!a.Yb){var d={text:wi,enabled:!0,bb:function(){var b=Jc(a);$c(b);var b=Oc(a.s,b),c=K(a);c.x=I?c.x-W:c.x+W;c.y+=2*W;b.moveBy(c.x,c.y);b.select()}};hi(a).length>qe(a.s)&&(d.enabled=!1);c.push(d);a.Kc&&!M&&!a.fc&&vc&&(d={enabled:!0},a.ya?(d.text=xi,d.bb=function(){Wc(a,null)}):(d.text=yi,d.bb=function(){Wc(a,"")}),c.push(d));if(!a.fc)for(d=0;d<a.T.length;d++)if(1==a.T[d].type){d={enabled:!0};d.text=a.ud?zi:Ai;d.bb=function(){Sc(a,
!a.ud)};c.push(d);break}wc&&(a.fc?(d={enabled:!0},d.text=Bi,d.bb=function(){a.Dd(!1)}):(d={enabled:!0},d.text=Ci,d.bb=function(){a.Dd(!0)}),c.push(d));xc&&(d={text:a.disabled?Di:Ei,enabled:!bg(a),bb:function(){Tc(a,!a.disabled)}},c.push(d));var d=hi(a).length,e=Kc(a);e&&(d-=hi(e).length);d={text:1==d?Fi:Gi.replace("%1",String(d)),enabled:!0,bb:function(){a.j(!0,!0)}};c.push(d)}d={enabled:!(s(a.nc)?!a.nc():!a.nc)};d.text=Hi;d.bb=function(){var b=s(a.nc)?a.nc():a.nc;b&&window.open(b)};c.push(d);a.fj&&
!a.Yb&&a.fj(c);Vg.show(b,c);Vg.Wd=a}}function Eh(a,b){var c=[];if(b||a.N)if(a.K&&c.push(a.K),a.J&&c.push(a.J),a.C&&c.push(a.C),b||!a.fc)for(var d=0,e;e=a.T[d];d++)e.p&&c.push(e.p);return c}function zh(a,b,c){if(a.N){for(var d=Eh(a,!1),e=0;e<d.length;e++)d[e].moveBy(b,c);d=cg(a);for(e=0;e<d.length;e++)dg(d[e]);for(e=0;e<a.qb.length;e++)zh(a.qb[e],b,c)}}function Ii(a,b){b?Nf(a.i.g,"blocklyDragging"):Of(a.i.g,"blocklyDragging");for(var c=0;c<a.qb.length;c++)Ii(a.qb[c],b)}
g.Xf=function(a){var b=this;vi(function(){if(!("mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button)){kd();var c=a.clientX-b.qg,d=a.clientY-b.rg;1==ne&&Math.sqrt(Math.pow(c,2)+Math.pow(d,2))>Ji&&(ne=2,b.Na(null),Ii(b,!0));if(2==ne){b.i.oa().setAttribute("transform","translate("+(b.gi+c)+", "+(b.ii+d)+")");for(var e=0;e<b.$d.length;e++){var f=b.$d[e],h=f.Ri,k=f.x+c,f=f.y+d;h.Nc=k;h.Oc=f;h.A()&&bh(h.ha,k,f)}for(var h=Eh(b,!1),f=k=null,l=W,e=0;e<h.length;e++){var q=h[e],m=Ah(q,l,c,d);m.p&&(k=
m.p,f=q,l=m.Vh)}ph&&ph!=k&&(F(nh.re),delete nh.re,qh=ph=null);k&&k!=ph&&(k.zh(),ph=k,qh=f);b.s.Ia&&b.hc&&!M&&(c=b.s.Ia,c.g&&(d=id(a),e=jd(c.g),d=d.x>e.x-c.Rd&&d.x<e.x+c.cd+c.Rd&&d.y>e.y-c.Rd&&d.y<e.y+c.$e+c.ad+c.Rd,c.wb!=d&&ae(c,d)))}}a.stopPropagation()})};g.Ja=function(){if(0==ne){var a=xh(this);if(!a.Yb)for(var b=Eh(this,!1),c=0;c<b.length;c++){var d=b[c];d.o&&rh(d)&&L(d).Ja();for(var e=Bh(d),f=0;f<e.length;f++){var h=e[f];d.o&&h.o||xh(h.k)!=a&&(rh(d)?uh(h,d):uh(d,h))}}}};g.getParent=function(){return this.Sc};
function Kc(a){return a.J&&L(a.J)}function xh(a){var b=a;do a=b,b=a.Sc;while(b);return a}g.lc=function(){return this.qb};
g.Na=function(a){if(this.Sc){for(var b=this.Sc.qb,c,d=0;c=b[d];d++)if(c==this){b.splice(d,1);break}b=K(this);this.s.aa.appendChild(this.i.oa());this.i.oa().setAttribute("transform","translate("+b.x+", "+b.y+")");this.Sc=null;this.C&&this.C.o&&this.C.disconnect();this.K&&this.K.o&&this.K.disconnect()}else Va(Ic(this.s,!1),this)&&ie(this.s,this);(this.Sc=a)?(a.qb.push(this),b=K(this),a.i&&this.i&&a.i.oa().appendChild(this.i.oa()),a=K(this),zh(this,a.x-b.x,a.y-b.y)):fe(this.s,this)};
function hi(a){for(var b=[a],c,d=0;c=a.qb[d];d++)b.push.apply(b,hi(c));return b}function Uc(a,b){a.hc=b;a.i&&Mf(a.i)}function Vc(a,b){a.Kc=b;for(var c=0,d;d=a.T[c];c++)for(var e=0,f;f=d.ta[e];e++)f.Ec();d=cg(a);for(c=0;c<d.length;c++)d[c].Ec()}g.ig=function(a){this.Sg=a;this.i&&this.i.Dc();var b=cg(this);for(a=0;a<b.length;a++)b[a].Dc();if(this.N){for(a=0;b=this.T[a];a++)for(var c=0,d;d=b.ta[c];c++)d.zb(null);this.F()}};
function Xc(a,b){for(var c=0,d;d=a.T[c];c++)for(var e=0,f;f=d.ta[e];e++)if(f.name===b)return f;return null}g.Te=function(a){this.Qa=a};function Gh(a,b){var c;a.C&&(a.C.j(),a.C=null);b&&(void 0===c&&(c=null),a.C=new nh(a,4),a.C.Uc(c));a.N&&(a.F(),a.Ja())}function Hh(a,b){var c;a.J&&(a.J.j(),a.J=null);b&&(void 0===c&&(c=null),a.J=new nh(a,3),a.J.Uc(c));a.N&&(a.F(),a.Ja())}function Fh(a,b){a.K&&(a.K.j(),a.K=null);void 0===b&&(b=null);a.K=new nh(a,2);a.K.Uc(b);a.N&&(a.F(),a.Ja())}
function Sc(a,b){a.ud=b;a.N&&(a.F(),a.Ja(),de(a.s))}function Tc(a,b){a.disabled!=b&&(a.disabled=b,ag(a.i),de(a.s))}function bg(a){for(;;){a:for(;;){do{var b=a;a=a.getParent();if(!a){a=null;break a}}while(Kc(a)==b);break a}if(!a)return!1;if(a.disabled)return!0}}g.isCollapsed=function(){return this.fc};
g.Dd=function(a){if(this.fc!=a){this.fc=a;for(var b=[],c=0,d;d=this.T[c];c++)b.push.apply(b,d.I(!a));if(a){a=cg(this);for(c=0;c<a.length;c++)a[c].I(!1);c=this.toString(Ki);gi(Li(this,5,"_TEMP_COLLAPSED_INPUT"),c)}else a:{for(c=0;a=this.T[c];c++)if("_TEMP_COLLAPSED_INPUT"==a.name){a.p&&a.p.o&&L(a.p).Na(null);a.j();this.T.splice(c,1);this.N&&(this.F(),this.Ja());break a}Ka('Input "%s" not found.',"_TEMP_COLLAPSED_INPUT")}b.length||(b[0]=this);if(this.N){for(c=0;a=b[c];c++)a.F();this.Ja()}}};
g.toString=function(a){for(var b=[],c=0,d;d=this.T[c];c++){for(var e=0,f;f=d.ta[e];e++)b.push(f.Jb());d.p&&((d=L(d.p))?b.push(d.toString()):b.push("?"))}b=va(b.join(" "))||"???";a&&b.length>a&&(b=b.substring(0,a-3)+"...");return b};
g.vd=function(a,b){function c(a){a instanceof hg?gi(this,a):gi(this,a[1],a[0])}var d=arguments[arguments.length-1];--arguments.length;for(var e=a.split(this.vd.Ci),f=[],h=0;h<e.length;h+=2){var k=va(e[h]),l=void 0;k&&f.push(new ei(k));if((k=e[h+1])&&"%"==k.charAt(0)){var k=parseInt(k.substring(1),10),q=arguments[k];q[1]instanceof hg?f.push([q[0],q[1]]):l=ii(Li(this,1,q[0]).Uc(q[1]),q[2]);arguments[k]=null}else"\n"==k&&f.length&&(l=Li(this,5,""));l&&f.length&&(f.forEach(c,l),f=[])}f.length&&(l=ii(Li(this,
5,""),d),f.forEach(c,l));for(h=1;h<arguments.length-1;h++);Sc(this,!a.match(this.vd.ui))};g.vd.Ci=/(%\d+|\n)/;g.vd.ui=/%1\s*$/;function Li(a,b,c){var d=null;if(1==b||3==b)d=new nh(a,b);b=new fi(b,c,a,d);a.T.push(b);a.N&&(a.F(),a.Ja());return b}function Yc(a,b){for(var c=0,d;d=a.T[c];c++)if(d.name==b)return d;return null}function Wc(a,b){var c=!1;p(b)?(a.ya||(a.ya=new Kh(a),c=!0),a.ya.zb(b)):a.ya&&(a.ya.j(),c=!0);a.N&&(a.F(),c&&a.Ja())}g.F=function(){this.i.F();si(this)};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Mi(){var a=this;this.v=new be(function(){return Ni(a)},function(b){var c=Ni(a);c&&(r(b.y)&&(a.v.scrollY=-c.Ra*b.y-c.cb),a.v.aa.setAttribute("transform","translate(0,"+(a.v.scrollY+c.Za)+")"))});this.v.Fh=!0;this.oh=[];this.Ta=this.L=0;this.nf=[];this.xb=[]}var Oi,Pi,Qi,Ri,Si,Ti;g=Mi.prototype;g.Sd=!0;g.ra=8;g.H=function(){this.g=N("g",{},null);this.Va=N("path",{"class":"blocklyFlyoutBackground"},this.g);this.g.appendChild(this.v.H());return this.g};
g.j=function(){this.Kb();P(this.oh);this.oh.length=0;this.xc&&(this.xc.j(),this.xc=null);this.v=null;this.g&&(F(this.g),this.g=null);this.Md=this.Va=null};function Ni(a){if(!a.A())return null;var b=a.Ta-2*a.ra,c=a.L;try{var d=a.v.aa.getBBox()}catch(e){d={height:0,y:0}}return{xa:b,Q:c,Ra:d.height+d.y,Bb:-a.v.scrollY,cb:0,Za:a.ra,Ya:0}}
g.Y=function(a){this.Md=a;this.xc=new bd(this.v,!1,!1);this.Kb();Q(window,"resize",this,this.zd);this.zd();Q(this.g,"wheel",this,this.qi);Q(this.g,"mousewheel",this,this.qi);Q(this.Md.aa,"blocklyWorkspaceChange",this,this.yf);Q(this.g,"mousedown",this,this.Fe)};
g.zd=function(){if(this.A()){var a=this.Md.Ib();if(a){var b=this.L-this.ra;I&&(b*=-1);var c=["M "+(I?this.L:0)+",0"];c.push("h",b);c.push("a",this.ra,this.ra,0,0,I?0:1,I?-this.ra:this.ra,this.ra);c.push("v",Math.max(0,a.xa-2*this.ra));c.push("a",this.ra,this.ra,0,0,I?0:1,I?this.ra:-this.ra,this.ra);c.push("h",-b);c.push("z");this.Va.setAttribute("d",c.join(" "));b=a.Ya;I&&(b+=a.Q,b-=this.L);this.g.setAttribute("transform","translate("+b+","+a.Za+")");this.Ta=a.xa;this.xc&&this.xc.resize()}}};
g.qi=function(a){var b=a.deltaY||-a.wheelDeltaY;if(b){Fb&&(b*=10);var c=Ni(this),b=c.Bb+b,b=Math.min(b,c.Ra-c.xa),b=Math.max(b,0);this.xc.set(b);a.preventDefault()}};g.A=function(){return this.g&&"block"==this.g.style.display};g.Kb=function(){if(this.A()){this.g.style.display="none";for(var a=0,b;b=this.xb[a];a++)P(b);this.xb.length=0;this.cg&&(P(this.cg),this.cg=null)}};
g.show=function(a){this.Kb();for(var b=Ic(this.v,!1),c=0,d;d=b[c];c++)d.s==this.v&&d.j(!1,!1);for(var c=0,e;e=this.nf[c];c++)F(e);this.nf.length=0;var f=this.ra;this.g.style.display="block";var b=[],h=[];if(a==Ui)Vi(b,h,f,this.v);else if(a==Wi)Xi(b,h,f,this.v);else for(var k=0;d=a[k];k++)d.tagName&&"BLOCK"==d.tagName.toUpperCase()&&(d=Oc(this.v,d),b.push(d),h.push(3*f));a=f;for(k=0;d=b[k];k++){c=hi(d);e=0;for(var l;l=c[e];e++)l.Yb=!0,Wc(l,null);d.F();l=ig(d);e=eg(d);c=I?0:f+8;d.moveBy(c,a);a+=e.height+
h[k];e=N("rect",{"fill-opacity":0},null);this.v.aa.insertBefore(e,ig(d));d.jd=e;this.nf[k]=e;this.Sd?this.xb.push(Q(l,"mousedown",null,Yi(this,d))):this.xb.push(Q(l,"mousedown",null,Zi(this,d)));this.xb.push(Q(l,"mouseover",d.i,d.i.ef));this.xb.push(Q(l,"mouseout",d.i,d.i.Qe));this.xb.push(Q(e,"mousedown",null,Yi(this,d)));this.xb.push(Q(e,"mouseover",d.i,d.i.ef));this.xb.push(Q(e,"mouseout",d.i,d.i.Qe))}this.xb.push(Q(this.Va,"mouseover",this,function(){for(var a=Ic(this.v,!1),b=0,c;c=a[b];b++)c.i.Qe()}));
this.L=0;this.Wh();this.yf();$i(window,"resize");this.cg=Q(this.v.aa,"blocklyWorkspaceChange",this,this.Wh);de(this.v)};
g.Wh=function(){for(var a=0,b=this.ra,c=Ic(this.v,!1),d=0,e;e=c[d];d++)var f=eg(e),a=Math.max(a,f.width);a+=b+8+b/2+O;if(this.L!=a){for(d=0;e=c[d];d++){var f=eg(e),h=K(e);if(I){var k=a-b-8-h.x;e.moveBy(k,0);h.x+=k}e.jd&&(e.jd.setAttribute("width",f.width),e.jd.setAttribute("height",f.height),e.jd.setAttribute("x",I?h.x-f.width:h.x),e.jd.setAttribute("y",h.y))}this.L=a;pe(window,"resize")}};
Ih.prototype.moveTo=function(a,b){var c=K(this);this.i.oa().setAttribute("transform","translate("+a+", "+b+")");zh(this,a-c.x,b-c.y)};function Zi(a,b){return function(c){qi();ld();hd(c)?ui(b,c):(kd(),kh(!0),Oi=c,Pi=b,Qi=a,Ri=Q(document,"mouseup",this,qi),Si=Q(document,"mousemove",this,a.$j));c.stopPropagation()}}Mi.prototype.Fe=function(a){hd(a)||(ld(!0),aj(),this.ei=a.clientY,Ti=Q(document,"mousemove",this,this.Xf),Ri=Q(document,"mouseup",this,aj),a.preventDefault(),a.stopPropagation())};
Mi.prototype.Xf=function(a){var b=a.clientY-this.ei;this.ei=a.clientY;a=Ni(this);b=a.Bb-b;b=Math.min(b,a.Ra-a.xa);b=Math.max(b,0);this.xc.set(b)};Mi.prototype.$j=function(a){"mousemove"==a.type&&1>=a.clientX&&0==a.clientY&&0==a.button?a.stopPropagation():(kd(),Math.sqrt(Math.pow(a.clientX-Oi.clientX,2)+Math.pow(a.clientY-Oi.clientY,2))>Ji&&Yi(Qi,Pi)(Oi))};
function Yi(a,b){return function(c){if(!hd(c)&&!b.disabled){var d=Jc(b),d=Oc(a.Md,d),e=ig(b);if(!e)throw"originBlock is not rendered.";var e=jd(e),f=ig(d);if(!f)throw"block is not rendered.";f=jd(f);d.moveBy(e.x-f.x,e.y-f.y);a.Sd?a.Kb():a.yf();d.Fe(c)}}}Mi.prototype.yf=function(){for(var a=qe(this.Md),b=Ic(this.v,!1),c=0,d;d=b[c];c++){var e=hi(d).length>a;Tc(d,e)}};function aj(){Ri&&(P(Ri),Ri=null);Si&&(P(Si),Si=null);Ti&&(P(Ti),Ti=null);Ri&&(P(Ri),Ri=null);Qi=Pi=Oi=null};function bj(a){if("function"==typeof a.Gf)return a.Gf();if(p(a))return a.split("");if(fa(a)){for(var b=[],c=a.length,d=0;d<c;d++)b.push(a[d]);return b}b=[];c=0;for(d in a)b[c++]=a[d];return b};function cj(a){this.Ab=void 0;this.sa={};if(a){var b;if("function"==typeof a.Ff)b=a.Ff();else if("function"!=typeof a.Gf)if(fa(a)||p(a)){b=[];for(var c=a.length,d=0;d<c;d++)b.push(d)}else for(d in b=[],c=0,a)b[c++]=d;else b=void 0;a=bj(a);for(c=0;c<b.length;c++)this.set(b[c],a[c])}}g=cj.prototype;g.set=function(a,b){dj(this,a,b,!1)};g.add=function(a,b){dj(this,a,b,!0)};
function dj(a,b,c,d){for(var e=0;e<b.length;e++){var f=b.charAt(e);a.sa[f]||(a.sa[f]=new cj);a=a.sa[f]}if(d&&void 0!==a.Ab)throw Error('The collection already contains the key "'+b+'"');a.Ab=c}g.get=function(a){a:{for(var b=this,c=0;c<a.length;c++)if(b=b.sa[a.charAt(c)],!b){a=void 0;break a}a=b}return a?a.Ab:void 0};g.Gf=function(){var a=[];ej(this,a);return a};function ej(a,b){void 0!==a.Ab&&b.push(a.Ab);for(var c in a.sa)ej(a.sa[c],b)}
g.Ff=function(a){var b=[];if(a){for(var c=this,d=0;d<a.length;d++){var e=a.charAt(d);if(!c.sa[e])return[];c=c.sa[e]}fj(c,a,b)}else fj(this,"",b);return b};function fj(a,b,c){void 0!==a.Ab&&c.push(b);for(var d in a.sa)fj(a.sa[d],b+d,c)}g.clear=function(){this.sa={};this.Ab=void 0};
g.remove=function(a){for(var b=this,c=[],d=0;d<a.length;d++){var e=a.charAt(d);if(!b.sa[e])throw Error('The collection does not have the key "'+a+'"');c.push([b,e]);b=b.sa[e]}a=b.Ab;for(delete b.Ab;0<c.length;)if(e=c.pop(),b=e[0],e=e[1],b.sa[e].Eh())delete b.sa[e];else break;return a};g.clone=function(){return new cj(this)};g.Eh=function(){var a;if(a=void 0===this.Ab)a:{a=this.sa;for(var b in a){a=!1;break a}a=!0}return a};function gj(){this.rc=new cj}g=gj.prototype;g.W="";g.Sf=null;g.Be=null;g.yd=0;g.Pc=0;function hj(a,b){var c=!1,d=a.rc.Ff(b);d&&d.length&&(a.Pc=0,a.yd=0,c=a.rc.get(d[0]),c=ij(a,c))&&(a.Sf=d);return c}function ij(a,b){var c;b&&(a.Pc<b.length&&(c=b[a.Pc],a.Be=b),c&&(c.eg(),c.select()));return!!c}g.clear=function(){this.W=""};function jj(a){var b;b||(b=kj(a||arguments.callee.caller,[]));return b}
function kj(a,b){var c=[];if(Va(b,a))c.push("[...circular reference...]");else if(a&&50>b.length){c.push(lj(a)+"(");for(var d=a.arguments,e=0;d&&e<d.length;e++){0<e&&c.push(", ");var f;f=d[e];switch(typeof f){case "object":f=f?"object":"null";break;case "string":break;case "number":f=String(f);break;case "boolean":f=f?"true":"false";break;case "function":f=(f=lj(f))?f:"[fn]";break;default:f=typeof f}40<f.length&&(f=f.substr(0,40)+"...");c.push(f)}b.push(a);c.push(")\n");try{c.push(kj(a.caller,b))}catch(h){c.push("[exception trying to get caller]\n")}}else a?
c.push("[...long stack...]"):c.push("[end]");return c.join("")}function lj(a){if(mj[a])return mj[a];a=String(a);if(!mj[a]){var b=/function ([^\(]+)/.exec(a);mj[a]=b?b[1]:"[Anonymous]"}return mj[a]}var mj={};function nj(a,b,c,d,e){this.reset(a,b,c,d,e)}nj.prototype.qh=null;nj.prototype.ph=null;var oj=0;nj.prototype.reset=function(a,b,c,d,e){"number"==typeof e||oj++;d||pa();this.xd=a;this.Tj=b;delete this.qh;delete this.ph};nj.prototype.ai=function(a){this.xd=a};function pj(a){this.Mh=a;this.yh=this.R=this.xd=this.wa=null}function qj(a,b){this.name=a;this.value=b}qj.prototype.toString=function(){return this.name};var rj=new qj("WARNING",900),sj=new qj("INFO",800),tj=new qj("CONFIG",700),uj=new qj("FINE",500);g=pj.prototype;g.getName=function(){return this.Mh};g.getParent=function(){return this.wa};g.lc=function(){this.R||(this.R={});return this.R};g.ai=function(a){this.xd=a};
function vj(a){if(a.xd)return a.xd;if(a.wa)return vj(a.wa);Ka("Root logger has no level set.");return null}g.log=function(a,b,c){if(a.value>=vj(this).value)for(s(b)&&(b=b()),a=this.rj(a,b,c,pj.prototype.log),b="log:"+a.Tj,n.console&&(n.console.timeStamp?n.console.timeStamp(b):n.console.markTimeline&&n.console.markTimeline(b)),n.msWriteProfilerMark&&n.msWriteProfilerMark(b),b=this;b;){c=b;var d=a;if(c.yh)for(var e=0,f=void 0;f=c.yh[e];e++)f(d);b=b.getParent()}};
g.rj=function(a,b,c,d){var e=new nj(a,String(b),this.Mh);if(c){var f;f=d||arguments.callee.caller;e.qh=c;var h;try{var k;var l=aa("window.location.href");if(p(c))k={message:c,name:"Unknown error",lineNumber:"Not available",fileName:l,stack:"Not available"};else{var q,m,t=!1;try{q=c.lineNumber||c.ql||"Not available"}catch(v){q="Not available",t=!0}try{m=c.fileName||c.filename||c.sourceURL||n.$googDebugFname||l}catch(B){m="Not available",t=!0}k=!t&&c.lineNumber&&c.fileName&&c.stack&&c.message&&c.name?
c:{message:c.message||"Not available",name:c.name||"UnknownError",lineNumber:q,fileName:m,stack:c.stack||"Not available"}}h="Message: "+xa(k.message)+'\nUrl: <a href="view-source:'+k.fileName+'" target="_new">'+k.fileName+"</a>\nLine: "+k.lineNumber+"\n\nBrowser stack:\n"+xa(k.stack+"-> ")+"[end]\n\nJS stack traversal:\n"+xa(jj(f)+"-> ")}catch(ha){h="Exception trying to expose exception! You win, we lose. "+ha}e.ph=h}return e};g.Qd=function(a,b){this.log(rj,a,b)};
g.info=function(a,b){this.log(sj,a,b)};var wj={},xj=null;function yj(a){xj||(xj=new pj(""),wj[""]=xj,xj.ai(tj));var b;if(!(b=wj[a])){b=new pj(a);var c=a.lastIndexOf("."),d=a.substr(c+1),c=yj(a.substr(0,c));c.lc()[d]=b;b.wa=c;wj[a]=b}return b};function zj(a){Td.call(this);this.w=a;a=y?"focusout":"blur";this.Qj=Id(this.w,y?"focusin":"focus",this,!y);this.Rj=Id(this.w,a,this,!y)}u(zj,Td);zj.prototype.handleEvent=function(a){var b=new Cd(a.Hb);b.type="focusin"==a.type||"focus"==a.type?"focusin":"focusout";this.dispatchEvent(b)};zj.prototype.X=function(){zj.n.X.call(this);Pd(this.Qj);Pd(this.Rj);delete this.w};function Aj(a,b,c){V.call(this,a,b,c);this.hd=!0;Lg(this,!0);this.Ma=this;this.Nd=new gj;if(y)try{document.execCommand("BackgroundImageCache",!1,!0)}catch(d){(a=this.Jh)&&a.Qd("Failed to enable background image cache",void 0)}}u(Aj,V);g=Aj.prototype;g.va=null;g.Af=null;g.Jh=yj("goog.ui.tree.TreeControl");g.Cf=!1;g.oj=null;g.Hd=!0;g.kg=!0;g.Bc=!0;g.lg=!0;g.za=function(){return this};g.Lc=function(){return 0};g.eg=function(){};g.yj=function(){this.Cf=!0;Ye(this.h(),"focused");this.Ma&&this.Ma.select()};
g.uj=function(){this.Cf=!1;$e(this.h(),"focused")};g.hasFocus=function(){return this.Cf};g.Ea=function(){return!this.Bc||Aj.n.Ea.call(this)};g.Ob=function(a){this.Bc?Aj.n.Ob.call(this,a):this.hd=a};g.Ef=function(){return vb};g.ke=function(){var a=Jg(this);return a?a.firstChild:null};g.je=function(){return null};g.Zc=function(){};g.md=function(){return Aj.n.md.call(this)+(this.Bc?"":" "+this.ma.bh)};
g.ee=function(){var a=this.Ea(),b=this.nj;if(a&&b)return b;b=this.Gj;if(!a&&b)return b;b=this.ma;return a&&b.ah?b.gc+" "+b.ah:!a&&b.Xg?b.gc+" "+b.Xg:""};g.Ac=function(a){if(this.Ma!=a){var b=!1;this.Ma&&(b=this.Ma==this.oj,Lg(this.Ma,!1));if(this.Ma=a)Lg(a,!0),b&&a.select();this.dispatchEvent("change")}};function Bj(a){function b(a){var h=Gg(a);if(h){var k=!d||c==a.getParent()&&!e?a.ma.Vg:a.ma.Ug;h.className=k;if(h=a.je())h.className=Pg(a)}Re(a,b)}var c=a,d=c.Hd,e=c.lg;b(a)}
g.ve=function(){Aj.n.ve.call(this);var a=this.h();ff(a,"tree");T(a,"labelledby",Fg(this).id)};g.na=function(){Aj.n.na.call(this);var a=this.h();a.className=this.ma.fh;a.setAttribute("hideFocus","true");a=this.h();a.tabIndex=0;var b=this.va=new sf(a),c=this.Af=new zj(a);Pe(this).D(c,"focusout",this.uj).D(c,"focusin",this.yj).D(b,"key",this.jb).D(a,"mousedown",this.If).D(a,"click",this.If).D(a,"dblclick",this.If);this.ve()};
g.Sa=function(){Aj.n.Sa.call(this);this.va.j();this.va=null;this.Af.j();this.Af=null};g.If=function(a){var b=this.Jh;b&&b.log(uj,"Received event "+a.type,void 0);if(b=Cj(this,a))switch(a.type){case "mousedown":b.Wf(a);break;case "click":a.preventDefault();break;case "dblclick":b.Nh(a)}};
g.jb=function(a){var b=!1,b=this.Nd,c=!1;switch(a.keyCode){case 40:case 38:if(a.ctrlKey){var c=40==a.keyCode?1:-1,d=b.Sf;if(d){var e=null,f=!1;if(b.Be){var h=b.Pc+c;0<=h&&h<b.Be.length?(b.Pc=h,e=b.Be):f=!0}e||(h=b.yd+c,0<=h&&h<d.length&&(b.yd=h),d.length>b.yd&&(e=b.rc.get(d[b.yd])),e&&e.length&&f&&(b.Pc=-1==c?e.length-1:0));ij(b,e)&&(b.Sf=d)}c=!0}break;case 8:d=b.W.length-1;c=!0;0<d?(b.W=b.W.substring(0,d),hj(b,b.W)):0==d?b.W="":c=!1;break;case 27:b.W="",c=!0}if(!(b=c)&&(b=this.Ma)){b=this.Ma;c=!0;
switch(a.keyCode){case 39:if(a.altKey)break;Ue(b)&&(b.Ea()?S(b,0).select():b.Ob(!0));break;case 37:if(a.altKey)break;Ue(b)&&b.Ea()&&b.wd?b.Ob(!1):(d=b.getParent(),e=b.za(),d&&(e.Bc||d!=e)&&d.select());break;case 40:a:if(Ue(b)&&b.Ea())d=S(b,0);else{for(d=b;d!=b.za();){e=d.kb;if(null!=e){d=e;break a}d=d.getParent()}d=null}d&&d.select();break;case 38:d=b.tc;null!=d?d=Sg(d):(d=b.getParent(),e=b.za(),d=!e.Bc&&d==e||b==e?null:d);d&&d.select();break;default:c=!1}c&&(a.preventDefault(),(e=b.za())&&e.Nd.clear());
b=c}b||(b=this.Nd,c=!1,a.ctrlKey||a.altKey||(d=String.fromCharCode(a.charCode||a.keyCode).toLowerCase(),(1==d.length&&" "<=d&&"~">=d||"\u0080"<=d&&"\ufffd">=d)&&(" "!=d||b.W)&&(b.W+=d,c=hj(b,b.W))),b=c);b&&a.preventDefault();return b};function Cj(a,b){for(var c=null,d=b.target;null!=d;){if(c=Eg[d.id])return c;if(d==a.h())break;d=d.parentNode}return null}g.createNode=function(a){return new Tg(a||vb,this.ma,this.ib())};
function Rg(a,b){var c=a.Nd,d=b.Jb();if(d&&!/^[\s\xa0]*$/.test(null==d?"":String(d))){var d=d.toLowerCase(),e=c.rc.get(d);e?e.push(b):c.rc.set(d,[b])}}g.removeNode=function(a){var b=this.Nd,c=a.Jb();if(c&&!/^[\s\xa0]*$/.test(null==c?"":String(c))){var c=c.toLowerCase(),d=b.rc.get(c);d&&(Wa(d,a),d.length&&b.rc.remove(c))}};/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Dj,Ej,Fj,Gj=0,Hj={Nf:19,fh:"blocklyTreeRoot",bh:"blocklyHidden",dh:"",hh:"blocklyTreeRow",eh:"blocklyTreeLabel",gc:"blocklyTreeIcon",qf:"blocklyTreeIconOpen",rf:"blocklyTreeIconNone",gh:"blocklyTreeSelected"};function Ij(a,b){Dj=D("div","blocklyToolboxDiv");Dj.setAttribute("dir",I?"RTL":"LTR");b.appendChild(Dj);Ej=new Mi;a.appendChild(Ej.H());Q(Dj,"mousedown",null,function(a){hd(a)||a.target==Dj?ld(!1):ld(!0)})}
function Jj(){Hj.cleardotPath=Zd+"media/1x1.gif";Hj.cssCollapsedFolderIcon="blocklyTreeIconClosed"+(I?"Rtl":"Ltr");var a=new Kj(vb,Hj);Fj=a;if(0!=a.Bc){a.Bc=!1;if(a.B){var b=Jg(a);b&&(b.className=a.md())}a.Ma==a&&S(a,0)&&a.Ac(S(a,0))}0!=a.Hd&&(a.Hd=!1,a.B&&Bj(a));0!=a.kg&&(a.kg=!1,a.B&&Bj(a));a.Ac(null);Dj.style.display="block";Ej.Y(E);Lj();a.F(Dj);Id(window,"resize",Mj);Mj()}
function Mj(){var a=Dj,b=He(J),c=di();I?(b=Nj(0,0,!1),a.style.left=b.x+c.width-a.offsetWidth+"px"):a.style.marginLeft=b.left;a.style.height=c.height+1+"px";Gj=a.offsetWidth;I||--Gj}
function Lj(){function a(c,d){for(var e=0,f;f=c.childNodes[e];e++)if(f.tagName){var h=f.tagName.toUpperCase();if("CATEGORY"==h){h=b.createNode(f.getAttribute("name"));h.ec=[];d.add(h);var k=f.getAttribute("custom");k?h.ec=k:a(f,h)}else"BLOCK"==h&&d.ec.push(f)}}var b=Fj;b.Yh();b.ec=[];a(yc,Fj);if(b.ec.length)throw"Toolbox cannot have both blocks and categories in the root level.";pe(window,"resize")}function Kj(a,b,c){Aj.call(this,a,b,c)}u(Kj,Aj);
Kj.prototype.na=function(){Kj.n.na.call(this);if(Ad){var a=this.h();Q(a,"touchstart",this,this.Dj)}};Kj.prototype.Dj=function(a){a.preventDefault();var b=Cj(this,a);b&&"touchstart"===a.type&&window.setTimeout(function(){b.Wf(a)},1)};Kj.prototype.createNode=function(a){return new Oj(a?ob(a):vb,this.ma,this.ib())};Kj.prototype.Ac=function(a){this.Ma!=a&&(Aj.prototype.Ac.call(this,a),a&&a.ec&&a.ec.length?Ej.show(a.ec):Ej.Kb())};
function Oj(a,b,c){function d(){pe(window,"resize")}V.call(this,a,b,c);Id(Fj,"expand",d);Id(Fj,"collapse",d)}u(Oj,Tg);V.prototype.Ef=function(){return tb("span")};Oj.prototype.Wf=function(){Ue(this)&&this.wd?(this.toggle(),this.select()):this.xe()?this.za().Ac(null):this.select();Mg(this)};Oj.prototype.Nh=function(){};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Ui="VARIABLE";
function Vi(a,b,c,d){var e;e=je(E);for(var f=Object.create(null),h=0;h<e.length;h++){var k=e[h].tj;if(k)for(var k=k.call(e[h]),l=0;l<k.length;l++){var q=k[l];q&&(f[q.toLowerCase()]=q)}}e=[];for(var m in f)e.push(f[m]);e.sort(wa);e.unshift(null);f=void 0;for(m=0;m<e.length;m++)e[m]!==f&&((h=Jh.variables_get?Qc(d,"variables_get"):null)&&Rc(h),(k=Jh.variables_set?Qc(d,"variables_set"):null)&&Rc(k),null===e[m]?f=(h||k).tj()[0]:(h&&Xc(h,"VAR").Wc(e[m]),k&&Xc(k,"VAR").Wc(e[m])),k&&a.push(k),h&&a.push(h),
h&&k?b.push(c,3*c):b.push(2*c))};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Wi="PROCEDURE";function Pj(){for(var a=je(E),b=[],c=[],d=0;d<a.length;d++){var e=a[d].il;e&&(e=e.call(a[d]))&&(e[2]?b.push(e):c.push(e))}c.sort(Qj);b.sort(Qj);return[c,b]}function Qj(a,b){var c=a[0].toLowerCase(),d=b[0].toLowerCase();return c>d?1:c<d?-1:0}
function Xi(a,b,c,d){function e(e,f){for(var l=0;l<e.length;l++){var q=Qc(d,f);Xc(q,"NAME").Wc(e[l][0]);for(var m=[],t=0;t<e[l][1].length;t++)m[t]="ARG"+t;q.Cl(e[l][1],m);Rc(q);a.push(q);b.push(2*c)}}if(Jh.procedures_defnoreturn){var f=Qc(d,"procedures_defnoreturn");Rc(f);a.push(f);b.push(2*c)}Jh.procedures_defreturn&&(f=Qc(d,"procedures_defreturn"),Rc(f),a.push(f),b.push(2*c));Jh.procedures_ifreturn&&(f=Qc(d,"procedures_ifreturn"),Rc(f),a.push(f),b.push(2*c));b.length&&(b[b.length-1]=3*c);f=Pj();
e(f[0],"procedures_callnoreturn");e(f[1],"procedures_callreturn")};var Zf=/#(.)(.)(.)/;function Wf(a){var b=a[0],c=a[1];a=a[2];b=Number(b);c=Number(c);a=Number(a);if(isNaN(b)||0>b||255<b||isNaN(c)||0>c||255<c||isNaN(a)||0>a||255<a)throw Error('"('+b+","+c+","+a+'") is not a valid RGB color');b=Rj(b.toString(16));c=Rj(c.toString(16));a=Rj(a.toString(16));return"#"+b+c+a}var Yf=/^#(?:[0-9a-f]{3}){1,2}$/i;function Rj(a){return 1==a.length?"0"+a:a}
function Xf(a){var b=0,c=0,d=0,e=Math.floor(a/60),f=a/60-e;a=166.4*.55;var h=166.4*(1-.45*f),f=166.4*(1-.45*(1-f));switch(e){case 1:b=h;c=166.4;d=a;break;case 2:b=a;c=166.4;d=f;break;case 3:b=a;c=h;d=166.4;break;case 4:b=f;c=a;d=166.4;break;case 5:b=166.4;c=a;d=h;break;case 6:case 0:b=166.4,c=f,d=a}return[Math.floor(b),Math.floor(c),Math.floor(d)]}function $f(a,b,c){c=Rb(c,0,1);return[Math.round(c*a[0]+(1-c)*b[0]),Math.round(c*a[1]+(1-c)*b[1]),Math.round(c*a[2]+(1-c)*b[2])]};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Nf(a,b){var c=a.getAttribute("class")||"";-1==(" "+c+" ").indexOf(" "+b+" ")&&(c&&(c+=" "),a.setAttribute("class",c+b))}function Of(a,b){var c=a.getAttribute("class");if(-1!=(" "+c+" ").indexOf(" "+b+" ")){for(var c=c.split(/\s+/),d=0;d<c.length;d++)c[d]&&c[d]!=b||(c.splice(d,1),d--);c.length?a.setAttribute("class",c.join(" ")):a.removeAttribute("class")}}
function Q(a,b,c,d){function e(a){d.apply(c,arguments)}a.addEventListener(b,e,!1);var f=[[a,b,e]];if(b in Sj)for(var e=function(a){if(1==a.changedTouches.length){var b=a.changedTouches[0];a.clientX=b.clientX;a.clientY=b.clientY}d.apply(c,arguments);a.preventDefault()},h=0,k;k=Sj[b][h];h++)a.addEventListener(k,e,!1),f.push([a,k,e]);return f}var Sj={};"ontouchstart"in document.documentElement&&(Sj={mousedown:["touchstart"],mousemove:["touchmove"],mouseup:["touchend","touchcancel"]});
function P(a){for(;a.length;){var b=a.pop();b[0].removeEventListener(b[1],b[2],!1)}}function $i(a,b){var c=document;if(c.createEvent)c=c.createEvent("UIEvents"),c.initEvent(b,!0,!0),a.dispatchEvent(c);else if(c.createEventObject)c=c.createEventObject(),a.fireEvent("on"+b,c);else throw"FireEvent: No event creation mechanism.";}function pe(a,b){setTimeout(function(){$i(a,b)},0)}
function mh(a){var b={x:0,y:0},c=a.getAttribute("x");c&&(b.x=parseInt(c,10));if(c=a.getAttribute("y"))b.y=parseInt(c,10);if(a=(a=a.getAttribute("transform"))&&a.match(/translate\(\s*([-\d.]+)([ ,]\s*([-\d.]+)\s*\))?/))b.x+=parseInt(a[1],10),a[3]&&(b.y+=parseInt(a[3],10));return b}function jd(a){var b=0,c=0;do{var d=mh(a),b=b+d.x,c=c+d.y;a=a.parentNode}while(a&&a!=J);return{x:b,y:c}}
function N(a,b,c){a=document.createElementNS("http://www.w3.org/2000/svg",a);for(var d in b)a.setAttribute(d,b[d]);document.body.runtimeStyle&&(a.runtimeStyle=a.currentStyle=a.style);c&&c.appendChild(a);return a}function hd(a){return 2==a.button||a.ctrlKey}
function Nj(a,b,c){c&&(a-=window.scrollX||window.pageXOffset,b-=window.scrollY||window.pageYOffset);var d=J.createSVGPoint();d.x=a;d.y=b;a=J.getScreenCTM();c&&(a=a.inverse());d=d.matrixTransform(a);c||(d.x+=window.scrollX||window.pageXOffset,d.y+=window.scrollY||window.pageYOffset);return d}function id(a){return Nj(a.clientX+(window.scrollX||window.pageXOffset),a.clientY+(window.scrollY||window.pageYOffset),!0)};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Tj(){function a(a){a=a.slice(1).split("&");for(var c=0;c<a.length;c++){var f=a[c].split("=");b[decodeURIComponent(f[0])]=decodeURIComponent(f[1])}}var b={},c=window.location.hash;c&&a(c);(c=window.location.search)&&a(c);return b}var Uj=Tj();function X(a,b,c){if(a.hasOwnProperty(b))return a[b];void 0===c&&console.error(b+" should be present in the options.");return c}
function Vj(a){this.Vi=X(a,"clientId");this.yg=Uj.userId;document.getElementById(X(a,"authButtonElementId"));document.getElementById(X(a,"authDivElementId"))}Vj.prototype.start=function(){gapi.load("auth:client,drive-realtime,drive-share",function(){})};
function Wj(a,b,c,d){function e(c){gapi.Sb.S.files.we({resource:{mimeType:b,title:a,parents:[{id:c}]}}).jc(d)}function f(){function a(b){gapi.Sb.S.ik.we({fileId:"appdata",resource:{key:"folderId",value:b}}).jc(function(){e(b)})}function b(){gapi.Sb.S.files.we({resource:{mimeType:"application/vnd.google-apps.folder",title:c}}).jc(function(b){a(b.id)})}gapi.Sb.S.ik.get({fileId:"appdata",propertyKey:"folderId"}).jc(function(d){if(d.error)c?b():a("root");else{var f=d.result.value;gapi.Sb.S.files.get({fileId:f}).jc(function(a){a.error||
a.labels.Gl?b():e(f)})}})}gapi.Sb.load("drive","v2",function(){f()})}function Xj(a){this.Oh=X(a,"onFileLoaded");this.Vj=X(a,"newFileMimeType","application/vnd.google-apps.drive-sdk");this.Bh=X(a,"initializeModel");this.Xh=X(a,"registerTypes",function(){});this.Fg=X(a,"afterAuth",function(){});this.Pi=X(a,"autoCreate",!1);this.hj=X(a,"defaultTitle","New Realtime File");this.gj=X(a,"defaultFolderTitle","");this.Gg=X(a,"afterCreate",function(){});this.kf=new Vj(a)}
function Yj(a,b,c){var d=[];b&&d.push("fileIds="+b.join(","));c&&d.push("userId="+c);c=0==d.length?window.location.pathname:window.location.pathname+"#"+d.join("&");window.history&&window.history.replaceState?window.history.replaceState("Google Drive Realtime API Playground","Google Drive Realtime API Playground",c):window.location.href=c;Uj=Tj();for(var e in b)gapi.S.yb.load(b[e],a.Oh,a.Bh,a.wh)}Xj.prototype.start=function(){var a=this;this.kf.start(function(){a.Xh&&a.Xh();a.Fg&&a.Fg();a.load()})};
Xj.prototype.wh=function(a){a.type!=gapi.S.yb.Bg.Sk&&(a.type==gapi.S.yb.Bg.Lk?(alert("An Error happened: "+a.message),window.location.href="/"):a.type==gapi.S.yb.Bg.Qk&&(alert("The file was not found. It does not exist or you do not have read access to the file."),window.location.href="/"))};
Xj.prototype.load=function(){var a=Uj.fileIds;a&&(a=a.split(","));var b=this.kf.yg,b=Uj.state;if(a)for(var c in a)gapi.S.yb.load(a[c],this.Oh,this.Bh,this.wh);else{if(b){var d;try{d=JSON.parse(b)}catch(e){d=null}if("open"==d.action){a=d.ll;b=d.yg;Yj(this,a,b);return}}this.Pi&&Zj(this)}};function Zj(a){Wj(a.hj,a.Vj,a.gj,function(b){b.id?(a.Gg&&a.Gg(b.id),Yj(a,[b.id],a.kf.yg)):(console.error("Error creating file."),console.error(b))})};/*

 Visual Blocks Editor

 Copyright 2014 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var he,ak,bk="media/progress.gif",ge=!1,ck=null,ki=null,dk=null,ek=null,mi=null,ri=!1,fk=null,gk=null,hk=null,bk="media/progress.gif";function ik(a){var b=a.mj;a=a.mj.length;for(var c=0;c<a;c++){var d=b[c];if(!d.Oj){var e=d.target;"value_changed"==d.type&&("xmlDom"==d.Uh?jk(function(){kk(e,!1);lk(e)}):"relativeX"!=d.Uh&&"relativeY"!=d.Uh||jk(function(){e.i||kk(e,!1);lk(e)}))}}}function mk(a){if(!a.Oj){var b=a.newValue;b?kk(b,!a.oldValue):(b=a.oldValue,nk(b))}}
function jk(a){if(ri)a();else try{ri=!0,a()}finally{ri=!1}}function kk(a,b){jk(function(){var c=Mc(a.zg).firstChild;if(c=Oc(E,c,!0))b&&fe(c.s,c),(b||Va(he,c))&&lk(c)})}function lk(a){if(!isNaN(a.Ne)&&!isNaN(a.Oe)){var b=di().width,c=K(a),d=a.Ne-c.x;a.moveBy(I?b-d:d,a.Oe-c.y)}}function nk(a){jk(function(){a.j(!0,!0,!0)})}
function si(a){if(a.s==E&&ge&&!ri){a=xh(a);var b=K(a),c=!1,d=Jc(a);d.setAttribute("id",a.id);var e=D("xml");e.appendChild(d);d=Lc(e);d!=a.zg&&(c=!0,a.zg=d);if(a.Ne!=b.x||a.Oe!=b.y)a.Ne=b.x,a.Oe=b.y,c=!0;c&&mi.set(a.id.toString(),a)}}function ok(a,b){gapi.Sb.S.Sh.list({fileId:a}).jc(function(a){for(var d=0;d<a.items.length;d++){var e=a.items[d];if("owner"==e.wl){b(e.domain);break}}})}
var sk={clientId:null,authButtonElementId:"authorizeButton",authDivElementId:"authButtonDiv",initializeModel:function(a){ki=a;var b=a.cl();a.Mc().set("blocks",b);b=a.bl();a.Mc().set("topBlocks",b);gk&&a.Mc().set(gk,a.dl(hk))},autoCreate:!0,defaultTitle:"Realtime Blockly File",defaultFolderTitle:"Realtime Blockly Folder",newFileMimeType:null,onFileLoaded:function(a){ck=a;a:{for(var b=a.qj(),c=0;c<b.length;c++){var d=b[c];if(d.Pj){dk=d.zl;break a}}dk=void 0}ki=a.Ce;mi=ki.Mc().get("blocks");he=ki.Mc().get("topBlocks");
ki.Mc().addEventListener(gapi.S.yb.cf.Rk,ik);mi.addEventListener(gapi.S.yb.cf.Tk,mk);ek();a.addEventListener(gapi.S.yb.cf.Mk,pk);a.addEventListener(gapi.S.yb.cf.Nk,qk);rk();a=he;for(b=0;b<a.length;b++)c=a.get(b),kk(c,!0)},registerTypes:function(){var a=gapi.S.yb.fl;a.ul(Ih,"Block");Ih.prototype.id=a.of("id");Ih.prototype.zg=a.of("xmlDom");Ih.prototype.Ne=a.of("relativeX");Ih.prototype.Oe=a.of("relativeY");a.Al(Ih,Ih.prototype.initialize)},afterAuth:function(){window.setTimeout(function(){},18E5)},
afterCreate:function(a){var b=gapi.Sb.S.Sh.we({fileId:a,resource:{type:"anyone",role:"writer",value:"default",withLink:!0}});b.jc(function(c){c.error&&ok(a,function(c){b=gapi.Sb.S.Sh.we({fileId:a,resource:{type:"domain",role:"writer",value:c,withLink:!0}});b.jc(function(){})})})}};function tk(){var a=Ac,b=X(a,"chatbox");b&&(gk=X(b,"elementId"),hk=X(b,"initText",uk));sk.Vi=X(a,"clientId");ak=X(a,"collabElementId")}
function vk(a,b){tk();ge=!0;wk(b);ek=function(){a();if(gk){var b=ki.Mc().get(gk),d=document.getElementById(gk);gapi.S.yb.hl.Xk(b,d);d.disabled=!1}};fk=new Xj(sk);fk.start()}
function wk(a){a.style.background="url("+Zd+bk+") no-repeat center center";var b=Be(a),c=D("div");c.id=sk.authDivElementId;var d=D("p",null,xk);c.appendChild(d);d=D("button",null,"Authorize");d.id=sk.Vk;c.appendChild(d);a.appendChild(c);c.style.display="none";c.style.position="relative";c.style.textAlign="center";c.style.border="1px solid";c.style.backgroundColor="#f6f9ff";c.style.borderRadius="15px";c.style.boxShadow="10px 10px 5px #888";c.style.width=b.width/3+"px";a=Be(c);c.style.left=(b.width-
a.width)/3+"px";c.style.top=(b.height-a.height)/4+"px"}function rk(){if(ak){var a;a=ak;a=p(a)?document.getElementById(a):a;cc(a);for(var b=ck.qj(),c=0;c<b.length;c++){var d=b[c],e=D("img",{src:d.sl||Zd+"media/anon.jpeg",alt:d.displayName,title:d.displayName+(d.Pj?" ("+yk+")":"")});e.style.backgroundColor=d.color;a.appendChild(e)}}}function pk(){rk()}function qk(){rk()}function li(a){var b=dk+"-"+a;return mi.has(b)?li("-"+a):b};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function zk(){var a=Ak.join("\n"),b=Zd.replace(/[\\\/]$/,""),a=a.replace(/<<<PATH>>>/g,b),b=document,c=b.createElement("style");c.type="text/css";b.getElementsByTagName("head")[0].appendChild(c);c.styleSheet?c.styleSheet.cssText=a:c.appendChild(b.createTextNode(a))}
var Ak=[".blocklySvg {","  background-color: #fff;","  border: 1px solid #ddd;","  overflow: hidden;","}",".blocklyWidgetDiv {","  position: absolute;","  display: none;","  z-index: 999;","}",".blocklyDraggable {","  cursor: url(<<<PATH>>>/media/handopen.cur) 8 5, auto;","}",".blocklyResizeSE {","  fill: #aaa;","  cursor: se-resize;","}",".blocklyResizeSW {","  fill: #aaa;","  cursor: sw-resize;","}",".blocklyResizeLine {","  stroke-width: 1;","  stroke: #888;","}",".blocklyHighlightedConnectionPath {",
"  stroke-width: 4px;","  stroke: #fc3;","  fill: none;","}",".blocklyPathLight {","  fill: none;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklySelected>.blocklyPath {","  stroke-width: 3px;","  stroke: #fc3;","}",".blocklySelected>.blocklyPathLight {","  display: none;","}",".blocklyDragging>.blocklyPath,",".blocklyDragging>.blocklyPathLight {","  fill-opacity: .8;","  stroke-opacity: .8;","}",".blocklyDragging>.blocklyPathDark {","  display: none;","}",".blocklyDisabled>.blocklyPath {",
"  fill-opacity: .5;","  stroke-opacity: .5;","}",".blocklyDisabled>.blocklyPathLight,",".blocklyDisabled>.blocklyPathDark {","  display: none;","}",".blocklyText {","  cursor: default;","  font-family: sans-serif;","  font-size: 11pt;","  fill: #fff;","}",".blocklyNonEditableText>text {","  pointer-events: none;","}",".blocklyNonEditableText>rect,",".blocklyEditableText>rect {","  fill: #fff;","  fill-opacity: .6;","}",".blocklyNonEditableText>text,",".blocklyEditableText>text {","  fill: #000;",
"}",".blocklyEditableText:hover>rect {","  stroke-width: 2;","  stroke: #fff;","}",".blocklyBubbleText {","  fill: #000;","}",".blocklySvg text {","  -moz-user-select: none;","  -webkit-user-select: none;","  user-select: none;","  cursor: inherit;","}",".blocklyHidden {","  display: none;","}",".blocklyFieldDropdown:not(.blocklyHidden) {","  display: block;","}",".blocklyTooltipBackground {","  fill: #ffffc7;","  stroke-width: 1px;","  stroke: #d8d8d8;","}",".blocklyTooltipShadow,",".blocklyDropdownMenuShadow {",
"  fill: #bbb;","  filter: url(#blocklyShadowFilter);","}",".blocklyTooltipText {","  font-family: sans-serif;","  font-size: 9pt;","  fill: #000;","}",".blocklyIconShield {","  cursor: default;","  fill: #00c;","  stroke-width: 1px;","  stroke: #ccc;","}",".blocklyIconGroup:hover>.blocklyIconShield {","  fill: #00f;","  stroke: #fff;","}",".blocklyIconGroup:hover>.blocklyIconMark {","  fill: #fff;","}",".blocklyIconMark {","  cursor: default !important;","  font-family: sans-serif;","  font-size: 9pt;",
"  font-weight: bold;","  fill: #ccc;","  text-anchor: middle;","}",".blocklyWarningBody {","}",".blocklyMinimalBody {","  margin: 0;","  padding: 0;","}",".blocklyCommentTextarea {","  margin: 0;","  padding: 2px;","  border: 0;","  resize: none;","  background-color: #ffc;","}",".blocklyHtmlInput {","  font-family: sans-serif;","  font-size: 11pt;","  border: none;","  outline: none;","  width: 100%","}",".blocklyMutatorBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #ddd;","}",".blocklyFlyoutBackground {",
"  fill: #ddd;","  fill-opacity: .8;","}",".blocklyColourBackground {","  fill: #666;","}",".blocklyScrollbarBackground {","  fill: #fff;","  stroke-width: 1;","  stroke: #e4e4e4;","}",".blocklyScrollbarKnob {","  fill: #ccc;","}",".blocklyScrollbarBackground:hover+.blocklyScrollbarKnob,",".blocklyScrollbarKnob:hover {","  fill: #bbb;","}",".blocklyInvalidInput {","  background: #faa;","}",".blocklyAngleCircle {","  stroke: #444;","  stroke-width: 1;","  fill: #ddd;","  fill-opacity: .8;","}",".blocklyAngleMarks {",
"  stroke: #444;","  stroke-width: 1;","}",".blocklyAngleGauge {","  fill: #f88;","  fill-opacity: .8;  ","}",".blocklyAngleLine {","  stroke: #f00;","  stroke-width: 2;","  stroke-linecap: round;","}",".blocklyContextMenu {","  border-radius: 4px;","}",".blocklyDropdownMenu {","  padding: 0 !important;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(<<<PATH>>>/media/sprites.png) no-repeat -48px -16px !important;",
"}",".blocklyToolboxDiv {","  background-color: #ddd;","  display: none;","  overflow-x: visible;","  overflow-y: auto;","  position: absolute;","}",".blocklyTreeRoot {","  padding: 4px 0;","}",".blocklyTreeRoot:focus {","  outline: none;","}",".blocklyTreeRow {","  line-height: 22px;","  height: 22px;","  padding-right: 1em;","  white-space: nowrap;","}",'.blocklyToolboxDiv[dir="RTL"] .blocklyTreeRow {',"  padding-right: 0;","  padding-left: 1em !important;","}",".blocklyTreeRow:hover {","  background-color: #e4e4e4;",
"}",".blocklyTreeIcon {","  height: 16px;","  width: 16px;","  vertical-align: middle;","  background-image: url(<<<PATH>>>/media/sprites.png);","}",".blocklyTreeIconClosedLtr {","  background-position: -32px -1px;","}",".blocklyTreeIconClosedRtl {","  background-position: 0px -1px;","}",".blocklyTreeIconOpen {","  background-position: -16px -1px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedLtr {","  background-position: -32px -17px;","}",".blocklyTreeSelected>.blocklyTreeIconClosedRtl {","  background-position: 0px -17px;",
"}",".blocklyTreeSelected>.blocklyTreeIconOpen {","  background-position: -16px -17px;","}",".blocklyTreeIconNone,",".blocklyTreeSelected>.blocklyTreeIconNone {","  background-position: -48px -1px;","}",".blocklyTreeLabel {","  cursor: default;","  font-family: sans-serif;","  font-size: 16px;","  padding: 0 3px;","  vertical-align: middle;","}",".blocklyTreeSelected  {","  background-color: #57e !important;","}",".blocklyTreeSelected .blocklyTreeLabel {","  color: #fff;","}",".blocklyWidgetDiv .goog-palette {",
"  outline: none;","  cursor: default;","}",".blocklyWidgetDiv .goog-palette-table {","  border: 1px solid #666;","  border-collapse: collapse;","}",".blocklyWidgetDiv .goog-palette-cell {","  height: 13px;","  width: 15px;","  margin: 0;","  border: 0;","  text-align: center;","  vertical-align: middle;","  border-right: 1px solid #666;","  font-size: 1px;","}",".blocklyWidgetDiv .goog-palette-colorswatch {","  position: relative;","  height: 13px;","  width: 15px;","  border: 1px solid #666;","}",
".blocklyWidgetDiv .goog-palette-cell-hover .goog-palette-colorswatch {","  border: 1px solid #FFF;","}",".blocklyWidgetDiv .goog-palette-cell-selected .goog-palette-colorswatch {","  border: 1px solid #000;","  color: #fff;","}",".blocklyWidgetDiv .goog-menu {","  background: #fff;","  border-color: #ccc #666 #666 #ccc;","  border-style: solid;","  border-width: 1px;","  cursor: default;","  font: normal 13px Arial, sans-serif;","  margin: 0;","  outline: none;","  padding: 4px 0;","  position: absolute;",
"  z-index: 20000;","}",".blocklyWidgetDiv .goog-menuitem {","  color: #000;","  font: normal 13px Arial, sans-serif;","  list-style: none;","  margin: 0;","  padding: 4px 7em 4px 28px;","  white-space: nowrap;","}",".blocklyWidgetDiv .goog-menuitem.goog-menuitem-rtl {","  padding-left: 7em;","  padding-right: 28px;","}",".blocklyWidgetDiv .goog-menu-nocheckbox .goog-menuitem,",".blocklyWidgetDiv .goog-menu-noicon .goog-menuitem {","  padding-left: 12px;","}",".blocklyWidgetDiv .goog-menu-noaccel .goog-menuitem {",
"  padding-right: 20px;","}",".blocklyWidgetDiv .goog-menuitem-content {","  color: #000;","  font: normal 13px Arial, sans-serif;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-accel,",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-content {","  color: #ccc !important;","}",".blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-icon {","  opacity: 0.3;","  -moz-opacity: 0.3;","  filter: alpha(opacity=30);","}",".blocklyWidgetDiv .goog-menuitem-highlight,",".blocklyWidgetDiv .goog-menuitem-hover {",
"  background-color: #d6e9f8;","  border-color: #d6e9f8;","  border-style: dotted;","  border-width: 1px 0;","  padding-bottom: 3px;","  padding-top: 3px;","}",".blocklyWidgetDiv .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-icon {","  background-repeat: no-repeat;","  height: 16px;","  left: 6px;","  position: absolute;","  right: auto;","  vertical-align: middle;","  width: 16px;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-icon {",
"  left: auto;","  right: 6px;","}",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-checkbox,",".blocklyWidgetDiv .goog-option-selected .goog-menuitem-icon {","  background: url(//ssl.gstatic.com/editor/editortoolbar.png) no-repeat -512px 0;","}",".blocklyWidgetDiv .goog-menuitem-accel {","  color: #999;","  direction: ltr;","  left: auto;","  padding: 0 6px;","  position: absolute;","  right: 0;","  text-align: right;","}",".blocklyWidgetDiv .goog-menuitem-rtl .goog-menuitem-accel {","  left: 0;",
"  right: auto;","  text-align: left;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-hint {","  text-decoration: underline;","}",".blocklyWidgetDiv .goog-menuitem-mnemonic-separator {","  color: #999;","  font-size: 12px;","  padding-left: 4px;","}",".blocklyWidgetDiv .goog-menuseparator {","  border-top: 1px solid #ccc;","  margin: 4px 0;","  padding: 0;","}",""];/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
function Bk(a){function b(){Ck(a);Dk()}var c={path:"./",readOnly:!0,xl:-1!=Ek.indexOf(rc),scrollbars:!1};if(!ec(document,a))throw"Error: container is not in current document.";c&&Fk(c);if(zc){if(c=document.getElementById("realtime"))c.style.display="block";vk(b,a)}else b()}
function Fk(a){var b=!!a.readOnly;if(b)var c=!1,d=!1,e=!1,f=!1,h=!1,k=null;else(c=a.toolbox)?("string"!=typeof c&&"undefined"==typeof XSLTProcessor&&(c=c.outerHTML),"string"==typeof c&&(c=Mc(c))):c=null,k=c,c=Boolean(k&&k.getElementsByTagName("category").length),d=a.trashcan,void 0===d&&(d=c),e=a.collapse,void 0===e&&(e=c),f=a.comments,void 0===f&&(f=c),h=a.disable,void 0===h&&(h=c);if(k&&!c)var l=!1;else l=a.scrollbars,void 0===l&&(l=!0);var q=a.sounds;void 0===q&&(q=!0);var m=!!a.realtime,t=m?a.realtimeOptions:
void 0;I=!!a.rtl;wc=e;vc=f;xc=h;M=b;Bc=a.maxBlocks||Infinity;Zd=a.path||"./";Cc=c;Dc=l;uc=d;Ec=q;yc=k;zc=m;Ac=t}
function Ck(a){a.setAttribute("dir","LTR");Me=I;zk();var b=N("svg",{xmlns:"http://www.w3.org/2000/svg","xmlns:html":"http://www.w3.org/1999/xhtml","xmlns:xlink":"http://www.w3.org/1999/xlink",version:"1.1","class":"blocklySvg"},null),c=N("defs",{},b),d,e;d=N("filter",{id:"blocklyEmboss"},c);N("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:1,result:"blur"},d);e=N("feSpecularLighting",{"in":"blur",surfaceScale:1,specularConstant:.5,specularExponent:10,"lighting-color":"white",result:"specOut"},d);
N("fePointLight",{x:-5E3,y:-1E4,z:2E4},e);N("feComposite",{"in":"specOut",in2:"SourceAlpha",operator:"in",result:"specOut"},d);N("feComposite",{"in":"SourceGraphic",in2:"specOut",operator:"arithmetic",k1:0,k2:1,k3:1,k4:0},d);d=N("filter",{id:"blocklyTrashcanShadowFilter"},c);N("feGaussianBlur",{"in":"SourceAlpha",stdDeviation:2,result:"blur"},d);N("feOffset",{"in":"blur",dx:1,dy:1,result:"offsetBlur"},d);d=N("feMerge",{},d);N("feMergeNode",{"in":"offsetBlur"},d);N("feMergeNode",{"in":"SourceGraphic"},
d);d=N("filter",{id:"blocklyShadowFilter"},c);N("feGaussianBlur",{stdDeviation:2},d);c=N("pattern",{id:"blocklyDisabledPattern",patternUnits:"userSpaceOnUse",width:10,height:10},c);N("rect",{width:10,height:10,fill:"#aaa"},c);N("path",{d:"M 0 0 L 10 10 M 10 0 L 0 10",stroke:"#cc0"},c);E=new be(Gk,Hk);b.appendChild(E.H());E.Tf=Bc;M||(Cc?Ij(b,a):(E.be=new Mi,c=E.be,d=c.H(),c.Sd=!1,dc(d),Ik(function(){if(0==ne){var a=E.Ib();if(0>a.cb||a.cb+a.Ra>a.xa+a.Bb||a.Db<(I?a.Ca:0)||a.Db+a.Ic>(I?a.Q:a.Q+a.Ca))for(var b=
Ic(E,!1),c=0,d;d=b[c];c++){var e=K(d),m=eg(d),t=a.Bb+25-m.height-e.y;0<t&&d.moveBy(0,t);t=a.Bb+a.xa-25-e.y;0>t&&d.moveBy(0,t);t=25+a.Ca-e.x-(I?0:m.width);0<t&&d.moveBy(t,0);t=a.Ca+a.Q-25-e.x+(I?m.width:0);0>t&&d.moveBy(t,0);d.hc&&!M&&50<(I?e.x-a.Q:-e.x)&&d.j(!1,!0)}}})));b.appendChild(Wh());a.appendChild(b);J=b;ti();Wg=D("div","blocklyWidgetDiv");Wg.style.direction=I?"rtl":"ltr";document.body.appendChild(Wg)}
function Dk(){Q(J,"mousedown",null,Jk);Q(J,"contextmenu",null,Kk);Q(Wg,"contextmenu",null,Kk);Fc||(Q(window,"resize",document,ti),Q(document,"keydown",null,Lk),document.addEventListener("mouseup",Mk,!1),Db&&Q(window,"orientationchange",document,function(){pe(window,"resize")}),Fc=!0);if(yc)if(Cc)Jj();else{E.be.Y(E);E.be.show(yc.childNodes);E.scrollX=E.be.L;I&&(E.scrollX*=-1);var a="translate("+E.scrollX+", 0)";E.aa.setAttribute("transform",a);E.Xc.setAttribute("transform",a)}Dc&&(E.cc=new ad(E),E.cc.resize());
ee();if(Ec){Nk(["media/click.mp3","media/click.wav","media/click.ogg"],"click");Nk(["media/delete.mp3","media/delete.ogg","media/delete.wav"],"delete");var b=[],a=function(){for(;b.length;)P(b.pop());for(var a in Ok){var d=Ok[a];d.volume=.01;d.play();d.pause();if(Db||Cb)break}};b.push(Q(document,"mousemove",null,a));b.push(Q(document,"touchstart",null,a))}};/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Wg=null,Yg=null,Pk=null;function Ug(){var a=Vg;Zg();Yg=a;Pk=null;Wg.style.display="block"}function Zg(){Yg&&(Wg.style.display="none",Pk&&Pk(),Pk=Yg=null,cc(Wg))}function Xg(a,b,c,d){b<d.y&&(b=d.y);I?a>c.width+d.x&&(a=c.width+d.x):a<d.x&&(a=d.x);Wg.style.left=a+"px";Wg.style.top=b+"px"};/*

 Visual Blocks Editor

 Copyright 2012 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2013 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
/*

 Visual Blocks Editor

 Copyright 2011 Google Inc.
 https://developers.google.com/blockly/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
var Zd="./",Xd=64,Yd=92,$d="media/sprites.png",sh=[,2,1,4,3],Ok=Object.create(null),R=null,M=!1,ph=null,qh=null,Ji=5,W=20,vh=250,Ki=30,E=null,Qk=null,Rk=null;function di(){return{width:J.Mg,height:J.Lg}}function ti(){var a=J,b=a.parentNode,c=b.offsetWidth,b=b.offsetHeight;a.Mg!=c&&(a.setAttribute("width",c+"px"),a.Mg=c);a.Lg!=b&&(a.setAttribute("height",b+"px"),a.Lg=b);E.cc&&E.cc.resize()}
function Jk(a){ti();qi();ld();var b=a.target&&a.target.nodeName&&"svg"==a.target.nodeName.toLowerCase();!M&&R&&b&&oe();a.target==J&&hd(a)?Sk(a):(M||b)&&E.cc&&(E.xf=!0,E.qg=a.clientX,E.rg=a.clientY,E.wk=E.Ib(),E.yk=E.scrollX,E.zk=E.scrollY,"mouseup"in Sj&&(Rk=Q(document,"mouseup",null,Mk)),Gc=Q(document,"mousemove",null,Tk))}function Mk(){kh(!1);E.xf=!1;Rk&&(P(Rk),Rk=null);Gc&&(P(Gc),Gc=null)}
function Tk(a){if(E.xf){kd();var b=E.wk,c=E.yk+(a.clientX-E.qg),d=E.zk+(a.clientY-E.rg),c=Math.min(c,-b.Db),d=Math.min(d,-b.cb),c=Math.max(c,b.Q-b.Db-b.Ic),d=Math.max(d,b.xa-b.cb-b.Ra);E.cc.set(-c-b.Db,-d-b.cb);a.stopPropagation()}}
function Lk(a){if(!jh(a))if(27==a.keyCode)ld();else if(8==a.keyCode||46==a.keyCode)try{R&&R.hc&&!M&&(ld(),R.j(!0,!0))}finally{a.preventDefault()}else if(a.altKey||a.ctrlKey||a.metaKey)if(R&&R.hc&&!M&&R.Mb&&!M&&R.s==E&&(ld(),67==a.keyCode?Uk():88==a.keyCode&&(Uk(),R.j(!0,!0))),86==a.keyCode&&Qk){a=E;var b=Qk;if(!(b.getElementsByTagName("block").length>=qe(a))){var c=Oc(a,b),d=parseInt(b.getAttribute("x"),10),b=parseInt(b.getAttribute("y"),10);if(!isNaN(d)&&!isNaN(b)){I&&(d=-d);do for(var e=!1,f=je(a),
h=0,k;k=f[h];h++)k=K(k),1>=Math.abs(d-k.x)&&1>=Math.abs(b-k.y)&&(d=I?d-W:d+W,b+=2*W,e=!0);while(e);c.moveBy(d,b)}c.select()}}}function qi(){ni&&(P(ni),ni=null);oi&&(P(oi),oi=null);var a=R;if(2==ne&&a){var b=K(a);zh(a,b.x-a.gi,b.y-a.ii);delete a.$d;Ii(a,!1);a.F();Vd(a.Ja,vh,a);pe(window,"resize")}a&&de(a.s);ne=0;aj()}function Uk(){var a=R,b=Jc(a);$c(b);a=K(a);b.setAttribute("x",I?-a.x:a.x);b.setAttribute("y",a.y);Qk=b}
function Sk(a){if(!M){var b=[];if(wc){for(var c=!1,d=!1,e=Ic(E,!1),f=0;f<e.length;f++)for(var h=e[f];h;)h.isCollapsed()?c=!0:d=!0,h=Kc(h);d={enabled:d};d.text=Vk;d.bb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Dd.bind(c,!0),a),c=Kc(c),a+=10};b.push(d);c={enabled:c};c.text=Wk;c.bb=function(){for(var a=0,b=0;b<e.length;b++)for(var c=e[b];c;)setTimeout(c.Dd.bind(c,!1),a),c=Kc(c),a+=10};b.push(c)}Vg.show(a,b)}}function Kk(a){jh(a)||a.preventDefault()}
function ld(a){$h();Zg();!a&&Ej&&Ej.Sd&&Fj.Ac(null)}function kd(){if(window.getSelection){var a=window.getSelection();a&&a.removeAllRanges&&(a.removeAllRanges(),window.setTimeout(function(){try{window.getSelection().removeAllRanges()}catch(a){}},0))}}function jh(a){return"textarea"==a.target.type||"text"==a.target.type}
function Nk(a,b){if(window.Audio&&a.length){for(var c,d=new window.Audio,e=0;e<a.length;e++){var f=a[e],h=f.match(/\.(\w+)$/);if(h&&d.canPlayType("audio/"+h[1])){c=new window.Audio(Zd+f);break}}c&&c.play&&(Ok[b]=c)}}function pi(a,b){var c=Ok[a];c&&(c=Mb&&9===Mb||Db||Bb?c:c.cloneNode(),c.volume=void 0===b?1:b,c.play())}function kh(a){if(!M){var b="";a&&(b="url("+Zd+"media/handclosed.cur) 7 3, auto");R&&(ig(R).style.cursor=b);J.style.cursor=b}}
function Gk(){var a=di();a.width-=Gj;var b=a.width-O,c=a.height-O;try{var d=E.aa.getBBox()}catch(e){return null}if(E.cc)var f=Math.min(d.x-b/2,d.x+d.width-b),b=Math.max(d.x+d.width+b/2,d.x+b),h=Math.min(d.y-c/2,d.y+d.height-c),c=Math.max(d.y+d.height+c/2,d.y+c);else f=d.x,b=f+d.width,h=d.y,c=h+d.height;return{xa:a.height,Q:a.width,Ra:c-h,Ic:b-f,Bb:-E.scrollY,Ca:-E.scrollX,cb:h,Db:f,Za:0,Ya:I?0:Gj}}
function Hk(a){if(!E.cc)throw"Attempt to set main workspace scroll without scrollbars.";var b=Gk();r(a.x)&&(E.scrollX=-b.Ic*a.x-b.Db);r(a.y)&&(E.scrollY=-b.Ra*a.y-b.cb);a="translate("+(E.scrollX+b.Ya)+","+(E.scrollY+b.Za)+")";E.aa.setAttribute("transform",a);E.Xc.setAttribute("transform",a)}function vi(a){a()}function Ik(a){return Q(E.aa,"blocklyWorkspaceChange",null,a)}window.Blockly||(window.Blockly={});window.Blockly.getMainWorkspace=function(){return E};window.Blockly.addChangeListener=Ik;
window.Blockly.removeChangeListener=function(a){P(a)};var yi="Add Comment",xk="Please authorize this app to enable your work to be saved and to allow it to be shared by you.",uk="Chat with your collaborator by typing in this box!",Vk="Collapse Blocks",Ci="Collapse Block",Fi="Delete Block",Gi="Delete %1 Blocks",Ei="Disable Block",wi="Duplicate",Di="Enable Block",Wk="Expand Blocks",Bi="Expand Block",zi="External Inputs",Hi="Help",Ai="Inline Inputs",yk="Me",xi="Remove Comment";function Xk(a,b){var c;c=a.className;for(var d=c=p(c)&&c.match(/\S+/g)||[],e=Za(arguments,1),f=0;f<e.length;f++)Va(d,e[f])||d.push(e[f]);a.className=c.join(" ")};var Yk={ace:"\u0628\u0647\u0633\u0627 \u0627\u0686\u064a\u0647",af:"Afrikaans",ar:"\u0627\u0644\u0639\u0631\u0628\u064a\u0629",az:"Az\u0259rbaycanca","be-tarask":"Tara\u0161kievica",br:"Brezhoneg",ca:"Catal\u00e0",cdo:"\u95a9\u6771\u8a9e",cs:"\u010cesky",da:"Dansk",de:"Deutsch",el:"\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac",en:"English",es:"Espa\u00f1ol",eu:"Euskara",fa:"\u0641\u0627\u0631\u0633\u06cc",fi:"Suomi",fo:"F\u00f8royskt",fr:"Fran\u00e7ais",frr:"Frasch",gl:"Galego",hak:"\u5ba2\u5bb6\u8a71",
he:"\u05e2\u05d1\u05e8\u05d9\u05ea",hi:"\u0939\u093f\u0928\u094d\u0926\u0940",hrx:"Hunsrik",hu:"Magyar",ia:"Interlingua",id:"Bahasa Indonesia",is:"\u00cdslenska",it:"Italiano",ja:"\u65e5\u672c\u8a9e",ka:"\u10e5\u10d0\u10e0\u10d7\u10e3\u10da\u10d8",km:"\u1797\u17b6\u179f\u17b6\u1781\u17d2\u1798\u17c2\u179a",ko:"\ud55c\uad6d\uc5b4",ksh:"Ripoar\u0117sch",ky:"\u041a\u044b\u0440\u0433\u044b\u0437\u0447\u0430",la:"Latine",lb:"L\u00ebtzebuergesch",lt:"Lietuvi\u0173",lv:"Latvie\u0161u",mg:"Malagasy",ml:"\u0d2e\u0d32\u0d2f\u0d3e\u0d33\u0d02",
mk:"\u041c\u0430\u043a\u0435\u0434\u043e\u043d\u0441\u043a\u0438",mr:"\u092e\u0930\u093e\u0920\u0940",ms:"Bahasa Melayu",mzn:"\u0645\u0627\u0632\u0650\u0631\u0648\u0646\u06cc",nb:"Norsk Bokm\u00e5l",nl:"Nederlands, Vlaams",oc:"Lenga d'\u00f2c",pa:"\u092a\u0902\u091c\u093e\u092c\u0940",pl:"Polski",pms:"Piemont\u00e8is",ps:"\u067e\u069a\u062a\u0648",pt:"Portugu\u00eas","pt-br":"Portugu\u00eas Brasileiro",ro:"Rom\u00e2n\u0103",ru:"\u0420\u0443\u0441\u0441\u043a\u0438\u0439",sc:"Sardu",sco:"Scots",si:"\u0dc3\u0dd2\u0d82\u0dc4\u0dbd",
sk:"Sloven\u010dina",sr:"\u0421\u0440\u043f\u0441\u043a\u0438",sv:"Svenska",sw:"Kishwahili",th:"\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22",tl:"Tagalog",tlh:"tlhIngan Hol",tr:"T\u00fcrk\u00e7e",uk:"\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430",vi:"Ti\u1ebfng Vi\u1ec7t","zh-hans":"\u7c21\u9ad4\u4e2d\u6587","zh-hant":"\u6b63\u9ad4\u4e2d\u6587"},Ek="ace ar fa he mzn ps".split(" "),rc=window.BlocklyGamesLang,Zk=window.BlocklyGamesLanguages,sc=!!window.location.pathname.match(/\.html$/);
function $k(a,b){var c=window.location.search.match(new RegExp("[?&]"+a+"=([^&]+)"));return c?decodeURIComponent(c[1].replace(/\+/g,"%20")):b}var H,al=Number($k("level","NaN"));H=isNaN(al)?1:Rb(1,al,10);
function bl(){document.title=document.getElementById("title").textContent;document.head.parentElement.setAttribute("dir",-1!=Ek.indexOf(rc)?"rtl":"ltr");document.head.parentElement.setAttribute("lang",rc);for(var a=[],b=0;b<Zk.length;b++){var c=Zk[b];a.push([Yk[c],c])}a.sort(function(a,b){return a[0]>b[0]?1:a[0]<b[0]?-1:0});for(var d=document.getElementById("languageMenu"),b=d.options.length=0;b<a.length;b++){var e=a[b],c=e[1],e=new Option(e[0],c);c==rc&&(e.selected=!0);d.options.add(e)}1>=d.options.length&&
(d.style.display="none");for(b=1;10>=b;b++)a=document.getElementById("level"+b),c=!!cl(b),a&&c&&Xk(a,"level_done");(b=document.querySelector('meta[name="viewport"]'))&&725>screen.availWidth&&b.setAttribute("content","width=725, initial-scale=.35, user-scalable=no");setTimeout(dl,1)}function cl(a){var b=el,c;try{c=window.localStorage[b+a]}catch(d){}return c}
function fl(a){var b;(b=document.getElementById(a))?(b=b.textContent,b=b.replace(/\\n/g,"\n")):b=null;return null===b?"[Unknown message: "+a+"]":b}function gl(a,b){"string"==typeof a&&(a=document.getElementById(a));a.addEventListener("click",b,!0);a.addEventListener("touchend",b,!0)}
function dl(){if(!sc){window.GoogleAnalyticsObject="GoogleAnalyticsFunction";var a=function(){(a.q=a.q||[]).push(arguments)};window.GoogleAnalyticsFunction=a;a.l=1*new Date;var b=document.createElement("script");b.async=1;b.src="//www.google-analytics.com/analytics.js";document.head.appendChild(b);a("create","UA-50448074-1","auto");a("send","pageview")}};var Y={sb:null,Y:function(){bl();var a=document.getElementById("linkButton");"BlocklyStorage"in window?(BlocklyStorage.HTTPREQUEST_ERROR=fl("Games_httpRequestError"),BlocklyStorage.LINK_ALERT=fl("Games_linkAlert"),BlocklyStorage.HASH_ERROR=fl("Games_hashError"),BlocklyStorage.XML_ERROR=fl("Games_xmlError"),BlocklyStorage.alert=oc.Bk,a&&gl(a,BlocklyStorage.link)):a&&(a.style.display="none");document.getElementById("languageMenu").addEventListener("change",Y.Ui,!0)},ol:function(a){document.body.innerHTML=
a;a=document.getElementById("blockly");a.style.height=window.innerHeight+"px";Bk(a);a=$k("xml","");Y.hg("<xml>"+a+"</xml>")},Sj:function(a,b){if("BlocklyStorage"in window&&1<window.location.hash.length)BlocklyStorage.retrieveXml(window.location.hash.substring(1));else{var c=null;try{c=window.sessionStorage.Ih}catch(d){}c&&delete window.sessionStorage.Ih;var e=cl(H),f=b&&cl(H-1);(c=c||e||f||a)&&Y.hg(c)}},hg:function(a){Y.sb?Y.sb.setValue(a,-1):(a=Mc(a),Nc(E,a))},pk:function(){if(void 0!=typeof tc&&
window.localStorage){var a=el+H;if(Y.sb)var b=Y.sb.getValue();else b=Hc(E),b=Lc(b);window.localStorage[a]=b}},ue:function(){window.location=(sc?"index.html":"./")+"?lang="+rc},Ui:function(){if(window.sessionStorage){if(Y.sb)var a=Y.sb.getValue();else a=Hc(E),a=Lc(a);window.sessionStorage.Ih=a}var a=document.getElementById("languageMenu"),a=encodeURIComponent(a.options[a.selectedIndex].value),b=window.location.search,b=1>=b.length?"?lang="+a:b.match(/[?&]lang=[^&]*/)?b.replace(/([?&]lang=)[^&]*/,"$1"+
a):b.replace(/\?/,"?lang="+a+"&");window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+b},zh:function(a){if(a){var b=a.match(/^block_id_(\d+)$/);b&&(a=b[1])}me(a)},Ck:function(a){return a.replace(/(,\s*)?'block_id_\d+'\)/g,")").trimRight()},tb:function(a){if("click"==a.type&&"touchend"==Y.tb.bg&&Y.tb.ag+2E3>Date.now()||Y.tb.bg==a.type&&Y.tb.ag+400>Date.now())return a.preventDefault(),a.stopPropagation(),!0;Y.tb.bg=a.type;Y.tb.ag=Date.now();return!1}};
Y.tb.bg=null;Y.tb.ag=0;Y.Jj=function(){var a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","js-read-only/JS-Interpreter/compiled.js");document.head.appendChild(a)};
Y.Kj=function(){var a=document.createElement("link");a.setAttribute("rel","stylesheet");a.setAttribute("type","text/css");a.setAttribute("href","common/prettify.css");document.head.appendChild(a);a=document.createElement("script");a.setAttribute("type","text/javascript");a.setAttribute("src","common/prettify.js");document.head.appendChild(a)};window.BlocklyInterface=Y;Y.setCode=Y.hg;var Z={pc:!1,jh:null,Yd:null,Gd:function(a,b,c,d,e,f){function h(){Z.pc&&(k.style.visibility="visible",k.style.zIndex=10,l.style.visibility="hidden")}Z.pc&&Z.Lb(!1);ld(!0);Z.pc=!0;Z.jh=b;Z.Yd=f;var k=document.getElementById("dialog");f=document.getElementById("dialogShadow");var l=document.getElementById("dialogBorder"),q;for(q in e)k.style[q]=e[q];d&&(f.style.visibility="visible",f.style.opacity=.3,f.style.zIndex=9,d=document.createElement("div"),d.id="dialogHeader",k.appendChild(d),Z.sf=Q(d,"mousedown",
null,Z.ij));k.appendChild(a);a.className=a.className.replace("dialogHiddenContent","");c&&b?(Z.ac(b,!1,.2),Z.ac(k,!0,.8),setTimeout(h,175)):h()},kh:0,lh:0,ij:function(a){Z.vf();if(!hd(a)){var b=document.getElementById("dialog");Z.kh=b.offsetLeft-a.clientX;Z.lh=b.offsetTop-a.clientY;Z.uf=Q(document,"mouseup",null,Z.vf);Z.tf=Q(document,"mousemove",null,Z.jj);a.stopPropagation()}},jj:function(a){var b=document.getElementById("dialog"),c=Z.kh+a.clientX;a=Z.lh+a.clientY;a=Math.max(a,0);a=Math.min(a,window.innerHeight-
b.offsetHeight);c=Math.max(c,0);c=Math.min(c,window.innerWidth-b.offsetWidth);b.style.left=c+"px";b.style.top=a+"px"},vf:function(){Z.uf&&(P(Z.uf),Z.uf=null);Z.tf&&(P(Z.tf),Z.tf=null)},Lb:function(a){function b(){d.style.zIndex=-1;d.style.visibility="hidden";document.getElementById("dialogBorder").style.visibility="hidden"}if(Z.pc){Z.vf();Z.sf&&(P(Z.sf),Z.sf=null);Z.pc=!1;Z.Yd&&Z.Yd();Z.Yd=null;var c=!1===a?null:Z.jh;a=document.getElementById("dialog");var d=document.getElementById("dialogShadow");
d.style.opacity=0;c?(Z.ac(a,!1,.8),Z.ac(c,!0,.2),setTimeout(b,175)):b();a.style.visibility="hidden";a.style.zIndex=-1;for((c=document.getElementById("dialogHeader"))&&c.parentNode.removeChild(c);a.firstChild;)c=a.firstChild,c.className+=" dialogHiddenContent",document.body.appendChild(c)}},ac:function(a,b,c){function d(){e.style.width=f.width+"px";e.style.height=f.height+"px";e.style.left=f.x+"px";e.style.top=f.y+"px";e.style.opacity=c}if(a){var e=document.getElementById("dialogBorder"),f=Z.pj(a);
b?(e.className="dialogAnimate",setTimeout(d,1)):(e.className="",d());e.style.visibility="visible"}},pj:function(a){if(a.getBBox){var b=a.getBBox(),c=b.height,b=b.width;a=jd(a);a=Nj(a.x,a.y,!1);var d=a.x,e=a.y}else{c=a.offsetHeight;b=a.offsetWidth;e=d=0;do d+=a.offsetLeft,e+=a.offsetTop,a=a.offsetParent;while(a)}return{height:c,width:b,x:d,y:e}},Bk:function(a){var b=document.getElementById("containerStorage");b.textContent="";a=a.split("\n");for(var c=0;c<a.length;c++){var d=document.createElement("p");
d.appendChild(document.createTextNode(a[c]));b.appendChild(d)}b=document.getElementById("dialogStorage");a=document.getElementById("linkButton");Z.Gd(b,a,!0,!0,{width:"50%",left:"25%",top:"5em"},Z.sg);Z.pg()},Hi:function(){if(!cl(H))if(Z.pc||0!=ne)setTimeout(Z.Hi,15E3);else{var a=document.getElementById("dialogAbort"),b=document.getElementById("abortCancel");b.addEventListener("click",Z.Lb,!0);b.addEventListener("touchend",Z.Lb,!0);b=document.getElementById("abortOk");b.addEventListener("click",Y.ue,
!0);b.addEventListener("touchend",Y.ue,!0);Z.Gd(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},function(){document.body.removeEventListener("keydown",Z.Eg,!0)});document.body.addEventListener("keydown",Z.Eg,!0)}},Wi:function(){var a=document.getElementById("dialogDone");if(E){var b=document.getElementById("dialogLinesText");b.textContent="";var c=tc.Pk.Hl(),c=Y.Ck(c),d=c.split("\n").length,e=document.getElementById("containerCode");e.textContent=c;"function"==typeof prettyPrintOne&&(c=e.innerHTML,
c=prettyPrintOne(c,"js"),e.innerHTML=c);c=1==d?fl("Games_linesOfCode1"):fl("Games_linesOfCode2").replace("%1",d);b.appendChild(document.createTextNode(c))}c=10>H?fl("Games_nextLevel").replace("%1",H+1):fl("Games_finalLevel");b=document.getElementById("doneCancel");b.addEventListener("click",Z.Lb,!0);b.addEventListener("touchend",Z.Lb,!0);b=document.getElementById("doneOk");b.addEventListener("click",Y.Vf,!0);b.addEventListener("touchend",Y.Vf,!0);Z.Gd(a,null,!1,!0,{width:"40%",left:"30%",top:"3em"},
function(){document.body.removeEventListener("keydown",Z.Tg,!0)});document.body.addEventListener("keydown",Z.Tg,!0);document.getElementById("dialogDoneText").textContent=c},ih:function(a){!Z.pc||13!=a.keyCode&&27!=a.keyCode&&32!=a.keyCode||(Z.Lb(!0),a.stopPropagation(),a.preventDefault())},pg:function(){document.body.addEventListener("keydown",Z.ih,!0)},sg:function(){document.body.removeEventListener("keydown",Z.ih,!0)},Tg:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)Z.Lb(!0),a.stopPropagation(),
a.preventDefault(),27!=a.keyCode&&Y.Vf()},Eg:function(a){if(13==a.keyCode||27==a.keyCode||32==a.keyCode)Z.Lb(!0),a.stopPropagation(),a.preventDefault(),27!=a.keyCode&&Y.ue()}};window.BlocklyDialogs=Z;Z.hideDialog=Z.Lb;yj("goog.net.XhrIo");function hl(a,b,c,d,e){this.name=a;this.Rg=b;this.ji=c;this.tk=d||0;this.Qb=e;this.u=new C;this.reset();console.log(this+" loaded.")}g=hl.prototype;g.Ak=!1;g.fb=!1;g.t=0;g.Fb=0;g.facing=0;g.speed=0;g.rb=0;g.u=null;g.Qf=0;g.toString=function(){return"["+this.name+"]"};
g.reset=function(){delete this.Ak;delete this.fb;delete this.speed;delete this.rb;delete this.Qf;this.t=this.tk;this.u.x=this.ji.x;this.u.y=this.ji.y;this.facing=this.Fb=Sb(180*Math.atan2(50-this.u.y,50-this.u.x)/Math.PI);var a=this.Rg;if(s(a))a=a();else if(!p(a))throw"Player "+this.name+" has invalid code: "+a;this.Dh="Interpreter"in window?new Interpreter(a,this.Qb.Lj):null};function il(a,b){a.t+=b;100<=a.t&&jl(a)}
function jl(a){a.speed=0;a.fb=!0;a.t=100;a.Qb.bd.unshift(a);a.Qb.Xa.push({type:"DIE",player:a});console.log(a+" dies.")}
function kl(a,b){var c=$.eb,d;d=void 0===b||null===b?5:b;if(!r(a)||isNaN(a)||!r(d)||isNaN(d))throw TypeError;a=Sb(a);d=Rb(d,0,20);c.Qb.Xa.push({type:"SCAN",player:c,degree:a,resolution:d});var e=Sb(a-d/2);d=Sb(a+d/2);e>d&&(d+=360);for(var f=c.u.x,h=c.u.y,k=Infinity,l=0,q;q=c.Qb.Da[l];l++)if(q!=c&&!q.fb){var m=q.u.x,t=q.u.y;q=Math.sqrt((t-h)*(t-h)+(m-f)*(m-f));q>=k||(m=Math.atan2(t-h,m-f),m=Sb(180*m/Math.PI),m<e&&(m+=360),e<=m&&m<=d&&(k=q))}return k}
g.S=function(a,b){var c;c=void 0===b||null===b?50:b;if(!r(a)||isNaN(a)||!r(c)||isNaN(c))throw TypeError;this.Fb!=Sb(a)&&(50>=this.speed?this.facing=this.Fb=Sb(a):c=0);0==this.speed&&0<c&&(this.speed=.1);this.rb=Rb(c,0,100)};g.stop=function(){this.rb=0};
function ll(a,b){var c=$.eb;if(!r(a)||isNaN(a)||!r(b)||isNaN(b))throw TypeError;var d=Date.now();if(c.Qf+1E3*c.Qb.yi>d)return!1;c.Qf=d;d=c.u.clone();a=Sb(a);c.facing=a;b=Rb(b,0,70);d={ek:c,Jd:d,Fb:a,Me:b,gd:new C(d.x+b*Math.cos(a*Math.PI/180),d.y+b*Math.sin(a*Math.PI/180)),Ad:0};c.Qb.Fc.push(d);c.Qb.Xa.push({type:"BANG",player:c,degree:d.Fb});return!0};var $={Da:[],bd:[],Xa:[],Fc:[],ti:50,Ei:100,yi:.5,eb:null,xi:1,Dg:3,Ag:5,ri:5,bf:3,Th:0,ae:0,ug:0,Gi:3E5,wf:null};$.Di=[new C(10,90),new C(90,10),new C(10,10),new C(90,90),new C(50,99),new C(50,1),new C(1,50),new C(99,50),new C(50,49)];$.reset=function(){clearTimeout($.Th);$.Xa.length=0;$.Fc.length=0;$.bd.length=0;for(var a=$.ug=0,b;b=$.Da[a];a++)b.reset()};$.Ji=function(a,b,c,d){c||(c=$.Di[$.Da.length]);a=new hl(a,b,c,d,$);$.Da.push(a)};
$.start=function(a){$.wf=a;$.ae=Date.now()+$.Gi;console.log("Starting battle with "+$.Da.length+" players.");$.update()};$.update=function(){$.Gk();$.Hk();$.Ik();$.Da.length<=$.bd.length+1&&($.ae=Math.min($.ae,Date.now()+1E3));Date.now()>$.ae?$.stop():$.Th=setTimeout($.update,1E3/$.ti)};$.stop=function(){for(var a=[],b=0,c;c=$.Da[b];b++)c.fb||a.push(c);b=a.length;for(a.sort(function(a,b){return a.t-b.t});a.length;)$.bd.unshift(a.pop());$.wf&&$.wf(b)};
$.Hk=function(){for(var a=$.Fc.length-1;0<=a;a--){var b=$.Fc[a];b.Ad+=$.Dg;var c=0;if(b.Me-b.Ad<$.Dg/2){$.Fc.splice(a,1);for(var d=0,e;e=$.Da[d];d++)if(!e.fb){var f=10*(1-Tb(e.u,b.gd)/4);0<f&&(il(e,f),c=Math.max(c,f))}$.Xa.push({type:"BOOM",damage:c,x:b.gd.x,y:b.gd.y})}}};
$.Ik=function(){for(var a=0,b;b=$.Da[a];a++)if(!b.fb&&(b.speed<b.rb?b.speed=Math.min(b.speed+$.Ag,b.rb):b.speed>b.rb&&(b.speed=Math.max(b.speed-$.Ag,b.rb)),0<b.speed)){var c=$.Qg(b),d=c[1],e=b.Fb*Math.PI/180,f=b.speed/100*$.xi,h=Math.cos(e)*f,f=Math.sin(e)*f;b.u.x+=h;b.u.y+=f;0>b.u.x||100<b.u.x||0>b.u.y||100<b.u.y?(b.u.x=Rb(b.u.x,0,100),b.u.y=Rb(b.u.y,0,100),d=b.speed/100*$.bf,il(b,d),b.speed=0,b.rb=0,$.Xa.push({type:"CRASH",player:b,damage:d})):(c=$.Qg(b),e=c[0],c=c[1],c<$.ri&&d>c&&(b.u.x-=h,b.u.y-=
f,d=Math.max(b.speed,e.speed)/100*$.bf,il(b,d),b.speed=0,b.rb=0,il(e,d),e.speed=0,e.rb=0,$.Xa.push({type:"CRASH",player:b,damage:d}),$.Xa.push({type:"CRASH",player:e,damage:d})))}};$.Gk=function(){for(var a=0;a<$.Ei;a++){$.ug++;for(var b=0,c;c=$.Da[b];b++)if(!c.fb){$.eb=c;try{c.Dh.step()}catch(d){console.log(c+" throws an error: "+d),console.dir(c.Dh.El),jl(c)}$.eb=null}}};
$.Lj=function(a,b){var c;c=function(b,c){return a.createPrimitive(kl(b&&b.valueOf(),c&&c.valueOf()))};a.setProperty(b,"scan",a.createNativeFunction(c));c=function(b,c){return a.createPrimitive(ll(b&&b.valueOf(),c&&c.valueOf()))};a.setProperty(b,"cannon",a.createNativeFunction(c));c=function(a,b){$.eb.S(a&&a.valueOf(),b&&b.valueOf())};a.setProperty(b,"drive",a.createNativeFunction(c));a.setProperty(b,"swim",a.createNativeFunction(c));a.setProperty(b,"stop",a.createNativeFunction(function(){$.eb.stop()}));
a.setProperty(b,"damage",a.createNativeFunction(function(){return a.createPrimitive($.eb.t)}));a.setProperty(b,"health",a.createNativeFunction(function(){return a.createPrimitive(100-$.eb.t)}));a.setProperty(b,"speed",a.createNativeFunction(function(){return a.createPrimitive($.eb.speed)}));a.setProperty(b,"loc_x",a.createNativeFunction(function(){return a.createPrimitive($.eb.u.x)}));a.setProperty(b,"loc_y",a.createNativeFunction(function(){return a.createPrimitive($.eb.u.y)}));var d=a.getProperty(b,
"Math");d!=a.UNDEFINED&&(c=function(b){return a.createPrimitive(Math.sin((b&&b.valueOf())/180*Math.PI))},a.setProperty(d,"sin_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.cos((b&&b.valueOf())/180*Math.PI))},a.setProperty(d,"cos_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.tan((b&&b.valueOf())/180*Math.PI))},a.setProperty(d,"tan_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.asin(b&&b.valueOf())/Math.PI*180)},
a.setProperty(d,"asin_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.acos(b&&b.valueOf())/Math.PI*180)},a.setProperty(d,"acos_deg",a.createNativeFunction(c)),c=function(b){return a.createPrimitive(Math.atan(b&&b.valueOf())/Math.PI*180)},a.setProperty(d,"atan_deg",a.createNativeFunction(c)))};$.Qg=function(a){for(var b=null,c=Infinity,d=0,e;e=$.Da[d];d++)if(!e.fb&&a!=e){var f=Math.min(c,Tb(a.u,e.u));f<c&&(c=f,b=e)}return[b,c]};var ml,nl,ol,pl={},ql=[],rl=new Image;rl.src="pond/sprites.png";var sl=["#ff8b00","#c90015","#166c0b","#11162a"],tl=0;function ul(){ml=document.getElementById("scratch").getContext("2d");var a=document.getElementById("display").getContext("2d");nl=a;ol=a.canvas.width;a.globalCompositeOperation="copy";Nk(["pond/whack.mp3","pond/whack.ogg"],"whack");Nk(["pond/boom.mp3","pond/boom.ogg"],"boom");Nk(["pond/splash.mp3","pond/splash.ogg"],"splash")}
function vl(){clearTimeout(tl);ql.length=0;var a=document.getElementById("playerStatRow");a.innerHTML="";for(var b=[],c=[],d=0,e;e=$.Da[d];d++){var f=sl[d%sl.length];e.oi=d;var h=document.createElement("td");h.style.borderColor=f;var k=document.createElement("div");k.className="playerStatHealth";k.style.background=f;e.Jk=k;c[d]=k;h.appendChild(k);k=document.createElement("div");k.className="playerStatName";e=document.createTextNode(e.name);k.appendChild(e);b[d]=k;h.appendChild(k);k=document.createElement("div");
e=document.createTextNode("\u00a0");k.appendChild(e);h.appendChild(k);a.appendChild(h)}for(d=0;k=b[d];d++)k.style.width=k.parentNode.offsetWidth-2+"px";for(d=0;k=c[d];d++)k.style.height=k.parentNode.offsetHeight-2+"px";wl()}var xl=0,yl=0;function zl(){wl();var a=Date.now(),b=Math.max(1,1E3/36-(a-xl-yl));tl=setTimeout(zl,b);xl=a;yl=b}function Al(a){return a/100*(ol-35)+17.5}
function wl(){var a=ml;a.beginPath();a.rect(0,0,a.canvas.width,a.canvas.height);a.fillStyle="#527dbf";a.fill();for(var b=[],c=0,d;d=$.Da[c];c++)d.fb&&b.push(d);for(c=0;d=$.Da[c];c++)d.fb||b.push(d);for(c=0;d=b[c];c++){a.save();var e=Al(d.u.x),f=Al(100-d.u.y);a.translate(e,f);var h=d.oi%sl.length*35;d.fb&&(a.globalAlpha=.25);0<d.speed&&(a.save(),e=50<d.speed?0:25<d.speed?35:70,a.rotate(-d.Fb/180*Math.PI),a.drawImage(rl,455,e,35,35,-45.5,-17.5,35,35),a.restore());a.drawImage(rl,0,h,35,35,-17.5,-17.5,
35,35);e=d.facing/180*Math.PI;a.translate(12*Math.cos(e),12*-Math.sin(e)-2);e=(14-Math.round(d.facing/360*12))%12+1;d=d.facing%30;15<=d&&(d-=30);d/=1.5;a.rotate(-d/180*Math.PI);a.drawImage(rl,35*e,h,35,35,-15.5,-15.5,35,35);a.restore()}for(c=0;d=$.Fc[c];c++){a.save();var f=d.Ad/d.Me,h=(d.gd.y-d.Jd.y)*-f,e=d.Me/2,k=.15*d.Me,e=k-Math.pow((d.Ad-e)/Math.sqrt(k)*k/e,2),f=Al(d.Jd.x+(d.gd.x-d.Jd.x)*f),k=Al(100-d.Jd.y+h-e),h=Al(100-d.Jd.y+h);a.beginPath();a.arc(f,h,5*Math.max(0,1-e/10),0,2*Math.PI,!0);a.closePath();
a.fillStyle="rgba(128, 128, 128, "+Math.max(0,1-e/10)+")";a.fill();a.beginPath();a.arc(f,k,5,0,2*Math.PI,!0);a.closePath();a.fillStyle=sl[d.ek.oi%sl.length];a.fill()}for(c=0;c<$.Xa.length;c++)if(e=$.Xa[c],d=e.player,"CRASH"==e.type){if(h=pl[d.id],!h||h+1E3<pa())pi("whack",e.damage/$.bf),pl[d.id]=pa()}else"SCAN"==e.type?(f=Math.max(e.resolution/2,.5),h=-((e.degree+f)*Math.PI/180),k=-((e.degree-f)*Math.PI/180),a.beginPath(),e=Al(d.u.x),f=Al(100-d.u.y),a.moveTo(e,f),a.lineTo(e+200*Math.cos(h),f+200*
Math.sin(h)),a.arc(e,f,200,h,k),a.lineTo(e,f),d=a.createRadialGradient(e,f,17.5,e,f,200),d.addColorStop(0,"rgba(255, 255, 255, 0.3)"),d.addColorStop(1,"rgba(255, 255, 255, 0)"),a.fillStyle=d,a.fill()):"BANG"!=e.type&&("BOOM"==e.type?(e.damage&&pi("boom",e.damage/10),ql.push({x:e.x,y:e.y,Ld:0})):"DIE"==e.type&&pi("splash"));$.Xa.length=0;for(c=ql.length-1;0<=c;c--)d=ql[c],e=Al(d.x),f=Al(100-d.y),a.beginPath(),a.arc(e,f,d.Ld+1,0,2*Math.PI,!0),a.closePath(),a.lineWidth=5,a.strokeStyle="rgba(255, 255, 255, "+
(1-d.Ld/10)+")",a.stroke(),d.Ld+=2,10<d.Ld&&ql.splice(c,1);nl.drawImage(a.canvas,0,0);for(c=0;d=b[c];c++)a=d.Jk,a.parentNode.title=Math.round(100-d.t)+"%",a.style.width=Math.max(0,a.parentNode.offsetWidth*(1-d.t/100)-2)+"px"};var Bl=null,Cl=!1;function Dl(){function a(){c.style.visibility="visible";document.getElementById("dialogBorder").style.visibility="hidden"}if(!Cl){var b=document.getElementById("docsButton"),c=document.getElementById("dialogDocs"),d=document.getElementById("frameDocs");d.src||(d.src="pond/docs.html?lang="+rc+"&app="+el+"&level="+H);Cl=!0;Z.ac(b,!1,.2);Z.ac(c,!0,.8);setTimeout(a,175)}}
function El(){var a=document.getElementById("docsButton"),b=document.getElementById("dialogDocs");Cl=!1;Z.ac(b,!1,.8);Z.ac(a,!0,.2);setTimeout(function(){document.getElementById("dialogBorder").style.visibility="hidden"},175);b.style.visibility="hidden"}function Fl(a){if(!Y.tb(a)){a=document.getElementById("runButton");var b=document.getElementById("resetButton");b.style.minWidth||(b.style.minWidth=a.offsetWidth+"px");a.style.display="none";b.style.display="inline";Gl()}}
function Hl(a){Y.tb(a)||(document.getElementById("runButton").style.display="inline",document.getElementById("resetButton").style.display="none",$.reset(),vl())}function Gl(){"Interpreter"in window?($.reset(),vl(),$.start(Bl),zl()):setTimeout(Gl,250)}function Il(){var a=document.getElementById("help"),b=document.getElementById("helpButton");Z.Gd(a,b,!0,!0,{width:"50%",left:"25%",top:"5em"},Z.sg);Z.pg()};Y.Vf=function(){10>H?window.location=window.location.protocol+"//"+window.location.host+window.location.pathname+"?lang="+rc+"&level="+(H+1):Y.ue()};
var Jl=[void 0,[{start:new C(50,30),t:0,name:"Pond_playerName",code:null},{start:new C(50,70),t:99,name:"Pond_targetName",code:"playerTarget"}],[{start:new C(20,20),t:0,name:"Pond_playerName",code:null},{start:new C(62.4264,62.4264),t:0,name:"Pond_targetName",code:"playerTarget"}],[{start:new C(90,50),t:0,name:"Pond_playerName",code:null},{start:new C(50,50),t:0,name:"Pond_pendulumName",code:"playerPendulum"}],[{start:new C(20,80),t:0,name:"Pond_playerName",code:null},{start:new C(80,20),t:99,name:"Pond_targetName",
code:"playerTarget"}],[{start:new C(5,50),t:99,name:"Pond_playerName",code:null},{start:new C(95,50),t:0,name:"Pond_targetName",code:"playerTarget"}],[{start:new C(10,90),t:50,name:"Pond_playerName",code:null},{start:new C(40,60),t:0,name:"Pond_scaredName",code:"playerScared"}],[{start:new C(50,50),t:0,name:"Pond_playerName",code:null},{start:new C(50,20),t:0,name:"Pond_rabbitName",code:"playerRabbit"}],[{start:new C(20,80),t:0,name:"Pond_playerName",code:null},{start:new C(50,50),t:0,name:"Pond_rookName",
code:"playerRook"}],[{start:new C(20,80),t:0,name:"Pond_playerName",code:null},{start:new C(80,20),t:0,name:"Pond_rookName",code:"playerRook"},{start:new C(20,20),t:0,name:"Pond_counterName",code:"playerCounter"}],[{start:new C(20,80),t:0,name:"Pond_playerName",code:null},{start:new C(80,20),t:0,name:"Pond_rookName",code:"playerRook"},{start:new C(20,20),t:0,name:"Pond_counterName",code:"playerCounter"},{start:new C(80,80),t:0,name:"Pond_sniperName",code:"playerSniper"}]][H],Bl=function(a){clearTimeout(tl);
0!=a&&1==a&&"function"==typeof $.bd[0].Rg&&(3==H&&2E5<$.ug?(a=document.getElementById("helpUseScan"),Z.Gd(a,null,!1,!0,{width:"30%",left:"35%",top:"12em"},Z.sg),Z.pg()):(Y.pk(),Z.Wi()))};var el="pond-advanced";
window.addEventListener("load",function(){function a(){var a=e.offsetTop,b=document.getElementById("editor");b.style.top=Math.max(10,a-window.pageYOffset)+"px";b.style.left=d?"10px":"420px";b.style.width=window.innerWidth-440+"px"}document.body.innerHTML=qc();Y.Y();ul();gl("runButton",Fl);gl("resetButton",Hl);gl("docsButton",Dl);gl("closeDocs",El);setTimeout(Y.Jj,1);setTimeout(Y.Kj,1);gl("helpButton",Il);2>location.hash.length&&!cl(H)&&setTimeout(Il,1E3);var b=document.getElementById("containerCode");b.parentNode.removeChild(b);
b=4==H?"swim(0, 50);":"cannon(0, 70);";Y.sb=window.ace.edit("editor");Y.sb.setTheme("ace/theme/chrome");var c=Y.sb.getSession();c.setMode("ace/mode/javascript");c.setTabSize(2);c.setUseSoftTabs(!0);Y.Sj(b+"\n",4!=H);var d=-1!=Ek.indexOf(rc),e=document.getElementById("visualization");window.addEventListener("scroll",a);window.addEventListener("resize",a);a();for(c=0;b=Jl[c];c++){var f=b.code?document.getElementById(b.code).textContent:function(){return Y.sb.getValue()},h=fl(b.name);$.Ji(h,f,b.start,
b.t)}$.reset();vl()});
